SCMockController = (function ($) {
	var mockHelper = new MockHelper(''),
		getJSON = mockHelper.getJSON;

	var initialize = function (requestParams, callback) {
		getJSON('sc/initialize', callback);
	};

	var getAppointments = function (queryParams, callback) {
		getJSON('sc/get-appointments', callback);
	};

	var getExceptionLogs = function (queryParams, callback) {
		getJSON('sc/get-exception-logs', callback);
	};

	return {
		initialize: initialize,
		getAppointments: getAppointments,
		getExceptionLogs: getExceptionLogs
	}

})(jQuery.noConflict());