JCMockController = (function () {
    var mockHelper = new MockHelper(''),
        getJSON = mockHelper.getJSON;

    var getJobs = function (requestParams, callback) {
        setTimeout(function () {
            getJSON('pac/get-recurrence-jobs', callback);
        }, 500);
    };

    var saveJobs = function (requestParams, callback) {
        setTimeout(function () {
            getJSON('save--success', callback)
        }, 500);
    };

    return {
        getJobs: getJobs,
        saveJobs:saveJobs
    };

})();