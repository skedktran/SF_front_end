ACMockController = (function ($) {
	var mockHelper = new MockHelper(''),
		getJSON = mockHelper.getJSON;

	var initialize = function (requestParams, callback) {
		getJSON('ac/initialize', callback);
	};

	var getSettings = function (keys, callback) {
		setTimeout(function () {
			getJSON('ac/get-settings__' + keys[0], callback);
		}, 500);
	};

	var saveSettings = function (keys, params, callback) {
		getJSON('save--success', callback);
	};

	return {
		initialize: initialize,
		getSettings: getSettings,
		saveSettings: saveSettings
	}

})(jQuery.noConflict());