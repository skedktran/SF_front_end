PACMockController = (function () {
    var mockHelper = new MockHelper(''),
        getJSON = mockHelper.getJSON;

    var initialize = function (requestParams, callback) {
        getJSON('pac/initialize', callback);
    };

    var getClientAvailability = function(params, callback) {
        getJSON('pac/get-grid-data', callback);
    };

    var getClientEvents = function(params, callback) {
        getJSON('pac/get-client-events', callback);
    };

    var getExceptionLogs = function(params, callback) {
        getJSON('pac/get-exception-logs', callback);
    };

    var saveClientAvailability = function(params, callback) {
        getJSON('pac/save-availability--conflicts', callback);
    };

    var handleSaveConflicts = function(params, callback) {
        getJSON('save--success', callback);
    };

    var deleteClientAvailability = function(params, callback) {
        getJSON('save--success', callback);
    };

    var getJobDetails = function (jobId, callback) {
        getJSON('pac/get-job-details', callback);
    };

    var saveJob = function(params, callback) {
        getJSON('save--success', callback);
    };

    var saveJobSObject = function(params, callback) {
		getJSON('save--success', callback);
	};

	var editJobSObject = function(params, callback) {
		getJSON('save--success', callback);
	};
    
    var cancelJob = function(params, callback) {
        getJSON('save--success', callback);
    };

    var createOffer = function(params, callback) {
        getJSON('pac/create-offer--success', callback);
    };

    var stopOffer = function(params, callback) {
        getJSON('pac/stop-offer--success', callback);
    };

    var getScheduledJobs = function (accountId, callback) {
        getJSON('bg/get-scheduled-jobs', callback);
    };

    var getBookingGrid = function (gridQuery, callback) {
        getJSON('bg/get-booking-grid', callback);
    };

    var searchSchedules = function (searchParams, callback) {
        getJSON('pac/search-schedules', callback);
    };

    var search = function (params, callback) {
        getJSON('pac/search-' + params.objectType.toLowerCase(), callback);
    };

    return {
        initialize: initialize,
        getClientAvailability: getClientAvailability,
        getClientEvents: getClientEvents,
        getExceptionLogs: getExceptionLogs,
        saveClientAvailability: saveClientAvailability,
        handleSaveConflicts: handleSaveConflicts,
        deleteClientAvailability: deleteClientAvailability,
        cancelJob: cancelJob,
        saveJob: saveJob,
        saveJobSObject: saveJobSObject,
        editJobSObject: editJobSObject,
        createOffer: createOffer,
        stopOffer: stopOffer,
        getJobDetails: getJobDetails,

        getScheduledJobs: getScheduledJobs,
        getBookingGrid: getBookingGrid,
        searchSchedules: searchSchedules,

        search: search
    };

})();