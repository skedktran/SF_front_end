MockHelper = (function ($) {
		
	return function (dataContext) {
		
		/**
		 * private method to process throgh data object, remove redundant properties (s, r)
		 */
		var processObject = function (object, dataRefCache) {
			var rt = null;

			if (object !== undefined && object !== null) {
				if (object.hasOwnProperty('s')) {
					rt = processData(object.v || null, dataRefCache);
					dataRefCache[object.s] = rt;
				} else if (object.hasOwnProperty('r')) {
					if (dataRefCache && dataRefCache[object.r]) {
						rt = dataRefCache[object.r];
					} else {
						rt = null;
					}
				} else {
					rt = {};
					for (var i in object) {
						if (object.hasOwnProperty(i)) {
							if (object[i] === undefined) {
								continue;
							} else if (object[i] === null) {
								rt[i] = null;
							} else if (object[i].hasOwnProperty('s')) {
								rt[i] = processData(object[i].v || null, dataRefCache);
								dataRefCache[object[i].s] = rt[i];
							} else if (object[i].hasOwnProperty('r')) {
								if (dataRefCache && dataRefCache[object[i].r]) {
									rt[i] = dataRefCache[object[i].r];
								} else {
									rt[i] = null;
								}
							} else {
								rt[i] = processData(object[i], dataRefCache);
							}
						}
					}
				}
					
			}

			return rt;
		};

		/**
		 * private method to process array data
		 */
		var processArray = function (array, dataRefCache) {
			var rt = null;

			if (array !== undefined && array !== null) {
				rt = [];
				for (var i in array) {
					rt[i] = processData(array[i], dataRefCache);
				}
			}

			return rt;
		};

		/**
		 * private method to process mocked json data
		 */
		var processData = function (data, dataRefCache) {
			var rt = null;
			dataRefCache = dataRefCache || {};

			if (data !== undefined && data !== null) {
				if (data instanceof Array) {
					rt = processArray(data, dataRefCache);
				} else if (data instanceof Object) {
					rt = processObject(data, dataRefCache);
				} else {
					rt = data;
				}
			}

			return rt;
		};

		/**
		 * helper method to get and process mocked json data
		 */
		this.getJSON = function (jsonName, callback) {
			$.getJSON([
				'mock','data',
				dataContext,
				jsonName + '.json'
				].join('/'))
			.done(function (data) {
				callback(processData(data), {
					status: true
				});
			})
			.fail(function (jqxhr, textStatus, error ) {
				var err = textStatus + ", " + error;
				console.error( "Request Failed: " + err );
				callback(null, {
					status: false,
					message: error
				});
			});
		};
	};
})(jQuery.noConflict()); 