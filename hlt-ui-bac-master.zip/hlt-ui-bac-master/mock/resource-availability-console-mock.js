RACMockController = (function ($) {
  var mockHelper = new MockHelper(''),
    getJSON = mockHelper.getJSON;

  var approveAvailability = function (shiftId, callback) {
    getJSON('save--success', callback);
  };

  var declineAvailability = function (shiftId, callback) {
    getJSON('save--success', callback);
  };

  var checkOverlapAvailability = function (shiftSaveModelJson, callback) {

  };

  var initialize = function (requestParams, callback) {
    getJSON('rac/initialize', callback);
  };

  var saveAvailability = function (availabilitySaveModel, callback) {
    // getJSON('save--success', callback);
    getJSON('rac/save--conflicted', callback);
  };

  var saveActivity = function (activitySaveModel, callback) {
    getJSON('save--success', callback);
  };

  var getResourceData = function (queryModel, callback) {
    getJSON('rac/get-resource-data--all', callback);
  };

  var getIndividualResourceData = function (queryModel, callback) {
    getJSON('rac/get-resource-data--individual', callback);
  };

  var handleSaveConflicts = function (params, callback) {
    getJSON('save--success', callback);
  };

  var deleteActivity = function (params, callback) {
    getJSON('save--success', callback);
  };

  var deleteAvailability = function (params, callback) {
    getJSON('save--success', callback);
  };

  var saveSchedule = function (params, callback) {
    //getJSON('save--success', callback);
    getJSON('rac/save-schedule--conflicts', callback);
  };

  var getSchedule = function (scheduleId, callback) {
    getJSON('rac/get-schedule', callback);
  };

  var searchSchedules = function (searchParams, callback) {
    getJSON('rac/search-schedules', callback);
  };

  var getResources = function (queryModel, callback) {
    setTimeout(function () {
      getJSON('rac/get-resources', callback);
    }, 300);
  };

  var search = function (params, callback) {
    getJSON('rac/search-' + params.objectType.toLowerCase(), callback);
  };

  var getEventDetails = function (params, callback) {
    getJSON('rac/get-event-details', callback);
  };

  var getPendingAvailability = function (params, callback) {
    setTimeout(function () {
      getJSON('rac/get-pending-availability', callback);
    }, 300);
  };

  var getTemplateDetails = function (params, callback) {
    getJSON('rac/get-template-details', callback);
  };

  var getPatternDetails = function (params, callback) {
    getJSON('rac/get-pattern-details', callback);
  };

  var savePattern = function (params, callback) {
    getJSON('save--success', callback);
  };

  return {
    approveAvailability: approveAvailability,
    declineAvailability: declineAvailability,
    checkOverlapAvailability: checkOverlapAvailability,
    initialize: initialize,
    saveAvailability: saveAvailability,
    saveActivity: saveActivity,
    handleSaveConflicts: handleSaveConflicts,
    getResourceData: getResourceData,
    getIndividualResourceData: getIndividualResourceData,
    deleteActivity: deleteActivity,
    deleteAvailability: deleteAvailability,
    saveSchedule: saveSchedule,
    getSchedule: getSchedule,
    searchSchedules: searchSchedules,
    getResources: getResources,
    search: search,
    getEventDetails: getEventDetails,
    getPendingAvailability: getPendingAvailability,
    getTemplateDetails: getTemplateDetails,
    getPatternDetails: getPatternDetails,
    savePattern: savePattern
  };

})(jQuery.noConflict());