PSTMockController = (function ($) {
	var mockHelper = new MockHelper(''),
		getJSON = mockHelper.getJSON;

	var initialize = function (requestParams, callback) {
		getJSON('pst/initialize', callback);
	};

	var getPatientInfo = function (requestParams, callback) {
		setTimeout(function () {
			getJSON('pst/get-patient-info', callback);
		}, 500);
	};

	return {
		initialize: initialize,
		getPatientInfo: getPatientInfo
	}

})(jQuery.noConflict());