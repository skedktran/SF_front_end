JAMockController = (function ($) {
	var mockHelper = new MockHelper(''),
		getJSON = mockHelper.getJSON;


	var getScheduledAllocation = function (jobParams, callback) {
		getJSON('jam/get-schedule-allocation-model', callback);
	}

	var saveAllocations = function (allocationParams, callback) {
		getJSON('save--success', callback);
	}

	var initialize = function (requestParams, callback) {
		getJSON('rac/initialize', callback);
	};

	var sendJobOffers = function (jobParams, callback) {
		getJSON('jam/send-offers--success', callback);
	};

	var getAllocationData = function (params, callback) {
		getJSON('jam/get-allocation-data', callback);
	}

	var getResourceData = function (params, callback) {
		getJSON('jam/get-resource-data', callback);
	}

	var getResourceAvailabilitySimply = function (params, callback) {
		getJSON('jam/get-resource-availability-simply', callback);
	}

	return {
		getScheduledAllocation: getScheduledAllocation,
		saveAllocations: saveAllocations,
		initialize: initialize,
		sendJobOffers: sendJobOffers,
		getAllocationData: getAllocationData,
		getResourceData: getResourceData,
		getResourceAvailabilitySimply: getResourceAvailabilitySimply
	}

})(jQuery.noConflict());