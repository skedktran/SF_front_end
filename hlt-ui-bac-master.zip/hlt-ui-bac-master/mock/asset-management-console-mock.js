AMCMockController = (function ($) {
	var mockHelper = new MockHelper(''),
		getJSON = mockHelper.getJSON;

	var initialize = function (requestParams, callback) {
		getJSON('amc/initialize', callback);
	};

	var getAsset = function (requestParams, callback) {
		getJSON('amc/getAsset', callback)
	}

	var getResources = function (params, callback) {
		setTimeout(function () {
			getJSON('amc/search_resources', callback)
		}, 500)
	}

	var getServiceUsers = function (params, callback) {
		getJSON('amc/search_serviceUsers', callback)
	}

	var getAssetAllocations = function (params, callback) {
		getJSON('amc/search_assetAssignments', callback)
	}

	var getAssets = function (params, callback) {
		getJSON('amc/search_availableAssets', callback)
	}

	var mockSave = function (params, callback) {
		if (Math.random() >= 0.5) {
			getJSON('save--error', callback)
		} else {
			getJSON('save--success', callback)
		}
	}

	return {
		initialize: initialize,
		getAsset: getAsset,
		getResources: getResources,
		getServiceUsers: getServiceUsers,
		getAssetAllocations: getAssetAllocations,
		getAssets: getAssets,
		createResourceAssetAllocation: mockSave,
		createAccountAssetAssignment: mockSave,
		createPersonAssetAllocation: mockSave,
		returnAsset: mockSave
	}

})(jQuery.noConflict());