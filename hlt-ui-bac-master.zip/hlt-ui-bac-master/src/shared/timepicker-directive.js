(function (angular) {
    angular.module('skedApp.shared')
    .directive('skedTimePicker', [
        'dateUtil',
        'util',
        '$timeout',
        function(dateUtil, util, $timeout) {
            var DEFAULT_TIME_FORMAT = 'h:i A';

            var isValidTime = function (timeString, format) {                
                var regExString, regEx,
                    hRegEx = '(0?[0-9]|1[0-2])',
                    mRegEx = '([0-5][0-9])',
                    apRegEx = '(am|AM|pm|PM)';

                if (!format) {
                    format = DEFAULT_TIME_FORMAT;
                }

                regExString = format;
                regExString = regExString.replace(/h/g, hRegEx);
                regExString = regExString.replace(/i/g, mRegEx);
                regExString = regExString.replace(/[aA]/g, apRegEx);

                regEx = new RegExp('^' + regExString + '$');

                return regEx.test(timeString);
            };

            var getTimeValue = function (timeString, format) {
                var regExString, regEx, parsedTimeString,
                    hRegEx = '(0?[0-9]|1[0-2])',
                    mRegEx = '([0-5][0-9])',
                    apRegEx = '(am|AM|pm|PM)';
                var hIndx, mIndx, apIndx;
                var timeVal, hVal, mVal, apVal;

                if (!format) {
                    format = DEFAULT_TIME_FORMAT;
                }

                format = format.toLowerCase();
                timeString = ((timeString)?String(timeString).trim():'');

                if (isValidTime(timeString, format)) {
                    hIndx = format.indexOf('h');
                    mIndx = format.indexOf('i');
                    apIndx = format.indexOf('a');

                    regExString = format.replace(/([^hia])/g, '($1)');
                    regExString = regExString.replace(/h/g, hRegEx);
                    regExString = regExString.replace(/i/g, mRegEx);
                    regExString = regExString.replace(/a/g, apRegEx);

                    regEx = new RegExp(regExString);
                    parsedTimeString = regEx.exec(timeString);

                    hVal = parseInt(parsedTimeString[hIndx + 1], 10);
                    mVal = parseInt(parsedTimeString[mIndx + 1], 10);
                    apVal = parsedTimeString[apIndx + 1];

                    if (hVal === 12) {
                        hVal = 0;
                    }

                    timeVal = ((hVal + ((apVal.toLowerCase() === 'pm')?12:0)) * 100) + mVal;

                    return timeVal;
                }

                return null;

            };

            return {
                restrict: 'A',
                require: '?ngModel',
                link: function ($scope, $element, $attrs, controller) {
                    var getOptions = function getOptions() {
                        var defaultOpts = {
                            timeFormat: DEFAULT_TIME_FORMAT,
                            appendTo: '[ng-app]',
                            forceRoundTime: true,
                            selectOnBlur: true,
                            step: 15
                        };

                        return angular.extend({}, defaultOpts, $scope.$eval($attrs.skedTimePicker));
                    };

                    var isInitFinished = false;
                    var initDateWidget = function initDateWidget() {
                        var opts = getOptions();

                        // If we have a controller (i.e. ngModelController) then wire it up
                        if (controller && !isInitFinished) {

                            controller.$validators.skedTimeValidator = function (modelValue, viewValue) {
                                return util.isNullOrEmpty(viewValue) || isValidTime(viewValue);
                            };

                            controller.$parsers.push(function (valueToParse) {
                                return getTimeValue(valueToParse);
                            });

                            controller.$formatters.push(function (valueToFormat) {
                                var modelValue = '000' + valueToFormat;
                                $element.timepicker('setTime', modelValue.substr(-4));

                                return $element.val();
                            });

                            controller.$render = function () {
                                // Force a render to override whatever is in the input text box
                                var modelValue = '000' + controller.$modelValue;
                                $element.timepicker('setTime', modelValue.substr(-4));
                            };

                            isInitFinished = true;
                        }

                        if ($element.data('timepicker')) {
                            // Updates the timepicker options
                            $element.timepicker('option', opts);
                        } else {
                            // Creates the new timepicker widget
                            $element.timepicker(opts);

                            // Cleanup on destroy, prevent memory leaking
                            $element.on('$destroy', function () {
                                $element.timepicker('hide');
                                $element.timepicker('remove');
                            });

                            if (angular.isObject(opts.events)) {
                                angular.forEach(opts.events, function (eventHandler, eventName) {
                                    $element.on(eventName, eventHandler);
                                });
                            }
                        }

                        if (controller) {
                            controller.$render();
                            // Update the model with the value from the timepicker after parsed
                            //setVal(true);
                        }
                    };

                    // Watch for changes to the directives options
                    $scope.$watch(getOptions, initDateWidget, true);
                }
            }
        }
    ])
})(angular);