(function (angular) {
	angular.module('skedApp.core')
	.provider('lang', function () {
		var dictionary = {};

		this.define = function (langData) {
			dictionary = langData;
		};

		this.setDictionaryUrl = function () {

		};

		this.$get = [
			'$q',
			function ($q) {
				var lookup = function (key) {
					return dictionary[key] || '';
				}

				return {
					lookup: lookup
				}
			}
		];
	});
})(angular);
