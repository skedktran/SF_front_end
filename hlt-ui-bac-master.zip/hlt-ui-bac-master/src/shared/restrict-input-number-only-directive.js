(function (angular) {
    var isNullOrEmpty = function(value) {
        return angular.isUndefined(value) || value === null || value === '';
    }

    angular.module('skedApp.shared')
    .directive('skedInputNumberOnly', [
        function() {
            return {
                restrict: 'A',
                scope: {
                    minValue: '@skedInputNumberOnlyMinValue'
                },
                link: function ($scope, $el, $attr) {
                    var inputEl = angular.element('input', $el);
                    var ngModelCtrl = inputEl ? inputEl.data().$ngModelController : null;

                    if(!inputEl || !ngModelCtrl) return ;

                    function fromUser(input) {
                        if (!isNullOrEmpty(input)) {
                            input = String(input);
                            //is number
                            var transformedInput = Number(input);
                            var isNumber = input.replace(/[^0-9-]/g, '') === input;
                            if(!isNumber) {
                                transformedInput = undefined;
                            }

                            var isMinValid = true;
                            if(!isNullOrEmpty($scope.minValue)) {
                                isMinValid = isNumber && Number(input) >= Number($scope.minValue);
                            }

                            if(!isMinValid) {
                                transformedInput = Number($scope.minValue);
                            }

                            if(!isNumber || !isMinValid) {
                                ngModelCtrl.$setViewValue(transformedInput);
                                ngModelCtrl.$render();
                            }
                            
                            return transformedInput;
                        }
                        return null;
                    }
                    ngModelCtrl.$parsers.push(fromUser);
                }
            }
        }
    ])
})(angular);