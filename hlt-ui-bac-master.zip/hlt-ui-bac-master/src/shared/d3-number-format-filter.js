// this is the wrapper filter for d3.format
(function (angular, d3) {
    angular.module('skedApp.shared')
    .filter('d3Format', [
        function() {
            return function (value, format) {
                return d3.format(format)(value)
            };
        }
    ])
})(angular, d3);