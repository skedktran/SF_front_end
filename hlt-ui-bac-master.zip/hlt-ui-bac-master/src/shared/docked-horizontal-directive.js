(function (angular) {
    angular.module('skedApp.shared')
    .directive('skedDockedHorizontalTo', [
        '$timeout',
        '$window',
        function($timeout, $window) {
            return function (scope, element, attribute) {
                var elYOffset = element.offset().top;
                var parentYOffset;
                var elParent = (attribute.skedDockedHorizontalTo)?element.parents(attribute.skedDockedHorizontalTo):null;
                var elWindow = angular.element($window);
                var isDockedTop = false, // top = 0
                    isDockedBottom = false, // bottom = 0
                    currentWindowWidth = elWindow.width(),
                    windowWidthChanged = false;
                var parentTopDistance, parentBottomDistance;

                var eventHandler = function (event) {
                    windowWidthChanged = (currentWindowWidth !== elWindow.width());
                    parentTopDistance = (parentYOffset - this.pageYOffset);
                    parentBottomDistance = elWindow.height() + (this.pageYOffset - (elParent.outerHeight() + parentYOffset));

                    if (parentTopDistance <= 0) {
                        parentTopDistance = 0;
                    }

                    if (parentBottomDistance <= 0) {
                        parentBottomDistance = 0;
                    } 

                    element.css({
                        top: parentTopDistance,
                        bottom: parentBottomDistance
                    });
                    
                };
                
                if (elParent) {
                    parentYOffset = elParent.offset().top;
                    elWindow.on('scroll resize', eventHandler);

                    $timeout(function () {
                        elYOffset = element.offset().top;
                        elWindow.trigger('resize');
                    });
                }
            };
        }
    ])
})(angular);