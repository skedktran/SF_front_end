(function (angular) {
	angular.module('skedApp.core')
	.provider('api', function () {
		var debugMode = false;
		var apiController = {};
		var remotingConfiguration = {};
		var viewData = {};

		var storeViewData = function (newViewData) {
			viewData = angular.extend(viewData, newViewData)
		};

		this.setController = function (apiCtrl) {
			apiController = apiCtrl;
		};

		this.setRemotingConfiguration = function (config) {
			if (angular.isObject(config)) {
				angular.extend(remotingConfiguration, config);
			}
		};

		this.enableDebug = function () {
			debugMode = true;
		};

		this.$get = [
			'$q',
			function ($q) {
				var apiService = {};

				angular.forEach(apiController, function (value, key) {
					if (angular.isFunction(value)) {
						// wrap the function with queuing style
						apiService[key] = function () {
							var deffered = $q.defer();
							var args = [], debugArgs = [];

							if (arguments.length > 0 && angular.isObject(arguments[0])) {
								arguments[0].viewData = viewData;
							}
							
							// stringify input
							angular.forEach(arguments, function (arg) {
								//args.push(angular.toJson(arg));
								args.push(arg);
								debugArgs.push(arg);
							});

							// push callback function
							args.push(function (data, event) {
								if (event.status) {
									storeViewData(data.viewData);
									deffered.resolve(data);
								} else {
									deffered.reject(event);
								}
							});

							// remoting configuration
							args.push(remotingConfiguration);

							// call function
							value.apply(apiController, args);

							if (debugMode && console) {
								console.debug(key, debugArgs, new Date());
							}

							return deffered.promise;
						};
					} else {
						apiService[key] = value;
					}
				});

				return apiService;
			}
		];
	});
})(angular);
