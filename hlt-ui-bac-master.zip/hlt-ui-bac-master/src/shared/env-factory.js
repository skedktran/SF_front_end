(function (angular) {
	angular.module('skedApp.core')
	.provider('env', function () {
			var envVariable = {};

			this.setVariables = function (variableObj) {
				angular.extend(envVariable, variableObj);
			};

			this.$get = [
				function () {
					return envVariable;
				}
			];
		});
})(angular);
