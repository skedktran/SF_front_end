(function (angular, jQuery) {
    angular.module('skedApp.shared')
    .directive('skedContextMenu', [
        '$templateRequest',
        '$compile',
        '$window',
        '$document',
        function($templateRequest, $compile, $window, $document) {
            return {
                restrict: 'A',
                link: function ($scope, $el, $attr) {
                    var contextMenuEnabled = $scope.$eval($attr.skedContextMenu);
                    var templateUrl = $attr.skedContextMenuTemplate;
                    var dropdownContainer = $el.parents('[ng-app]');
                    var elWindow = angular.element($window);
                    var elParent = $el.parents($attr.skedContextMenuContainer);
                    var dropdownEl;
                    var onMenuHide = $attr.onContextMenuHide;

                    var clickOutsideHandler = function (event) {
                        for (var element = event.target; element; element = element.parentNode) {
                            // check if the element is the same element the directive is attached to and exit if so (props @CosticaPuntaru)
                            if (element === dropdownEl[0]) {
                                return;
                            }
                        }
                        hideContextMenu();
                    };

                    var showContextMenu = function (event) {
                        var containerOffset = dropdownContainer.offset(),
                            containerPosition = dropdownContainer.position();

                        event.preventDefault();
                        if (!dropdownEl) {
                            $templateRequest(templateUrl)
                                .then(function (template) {
                                    dropdownEl = angular.element('<div></div>');
                                    dropdownEl.append(template);
                                    dropdownEl.css({
                                        position: 'absolute',
                                        'z-index': 90001,
                                        top: event.pageY - containerOffset.top + containerPosition.top,
                                        left: event.pageX - containerOffset.left + containerPosition.left
                                    });
                                    dropdownEl.appendTo(dropdownContainer);
                                    $compile(dropdownEl)($scope);

                                    $document.on('click contextmenu', clickOutsideHandler);
                                });
                        }
                    };

                    var hideContextMenu = function () {
                        if (dropdownEl) {
                            dropdownEl.remove();
                            dropdownEl = null;
                            $document.off('click contextmenu', clickOutsideHandler);
                        }

                        if (onMenuHide) {
                            $scope.$eval(onMenuHide);
                        }
                    };

                    if (contextMenuEnabled) {
                        if (templateUrl) {
                            $el.contextmenu(showContextMenu);

                            elWindow.scroll(hideContextMenu);
                            if (elParent) {
                                elParent.scroll(hideContextMenu);
                            }
                        }

                        $scope.$contextMenu = {
                            hideContextMenu: hideContextMenu,
                            showContextMenu: showContextMenu
                        }
                    }
                }
            }
        }
    ])
})(angular, jQuery);