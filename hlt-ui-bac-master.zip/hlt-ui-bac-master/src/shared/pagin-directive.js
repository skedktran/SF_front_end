(function (angular) {
	angular.module('skedApp.shared')
	.directive('skedPagin', [
		function() {
			return {
				restrict: 'E',
				replace: true,
				templateUrl: 'src/shared/pagin-template.html',
				scope: {
					recordCountOptions: '&',
					list: '=',
					model: '=',
					recordNumberLabel: '@?',
					pageNavLabel: '@?',
					numberOfPages: '<?',
					numberOfRecords: '<?',
					hidePageSize: '<'
				},
				link: function ($scope, $el, $attr) {
					/*
					 * reset pagin info
					 */
					var resetPaginInfo = function () {
						$scope.model.noOfRecords = 0;

						if (angular.isArray($scope.list)) {
							$scope.model.noOfRecords = $scope.list.length;

							if (!angular.isArray($scope.recordCountOptions)) {
								$scope.recordCountOptions = [$scope.model.noOfRecords];
								$scope.model.recordsPerPage = $scope.recordCountOptions[0];
							}
						}

						if (angular.isNumber($scope.numberOfPages)) {
							$scope.model.numberOfPages = $scope.numberOfPages;
						} else if (angular.isNumber($scope.numberOfRecords)) {
							$scope.model.numberOfPages = Math.ceil($scope.numberOfRecords / $scope.model.recordsPerPage);
						} else if ($scope.model.recordsPerPage && $scope.model.recordsPerPage > 0) {
							$scope.model.numberOfPages = Math.ceil($scope.model.noOfRecords / $scope.model.recordsPerPage);
						}

						if ($scope.model.numberOfPages < 1) {
							$scope.model.numberOfPages = 1;
						}

						if (!angular.isNumber($scope.model.pageNumber) || $scope.model.pageNumber < 1) {
							$scope.model.pageNumber = 1;
						}

						if ($scope.model.numberOfPages < $scope.model.pageNumber) {
							$scope.model.pageNumber = $scope.model.numberOfPages;
						}

						$scope.numberOfPagesArray = [];
						for (var i = 1; i <= $scope.model.numberOfPages; i++) {
							$scope.numberOfPagesArray.push(i);
						}
					}

					/*
					 * go to specific page number
					 */
					var goToPage = function (pageNumber) {
						if (angular.isNumber(pageNumber) && pageNumber > 0 && pageNumber <= $scope.model.numberOfPages) {
							$scope.model.pageNumber = pageNumber
						} else {
							$scope.model.pageNumber = 1;
						}
					};

					/*
					 * go to next page
					 */
					var goToNextPage = function () {
						goToPage($scope.model.pageNumber + 1);
					};

					/*
					 * go to previous page
					 */
					var goToPreviousPage = function () {
						goToPage($scope.model.pageNumber - 1);
					};

					$scope.recordCountOptions = $scope.recordCountOptions();
					$scope.goToPage = goToPage;
					$scope.goToNextPage = goToNextPage;
					$scope.goToPreviousPage = goToPreviousPage;
					$scope.resetPaginInfo = resetPaginInfo;

					$scope.$watchCollection('list', resetPaginInfo, true);
				}
			}
		}
	])
})(angular);