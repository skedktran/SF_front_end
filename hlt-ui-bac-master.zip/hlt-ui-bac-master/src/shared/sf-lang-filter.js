(function (angular) {
    angular.module('skedApp.shared')
        .filter('skedSfLang', [
            'lang',
            function (lang) {
                return function (langKey) {
                    return lang.lookup(langKey);
                }
            }
        ])
})(angular);