(function (angular) {
    angular.module('skedApp.shared')
        .factory('util', [
            '$q',
            '$rootScope',
            '$templateRequest',
            '$compile',
            '$timeout',
            'dateUtil',
            'constants',
            function ($q, $rootScope, $templateRequest, $compile, $timeout, dateUtil, constants) {
                var TOAST_TYPE = {
                    DEFAULT: 0,
                    SUCCESS: 1,
                    WARNING: 2,
                    ERROR: 3
                };
                var EDIT_RECURRING_ACTION = constants.EDIT_RECURRING_ACTION;
                var WEEK_DAYS = constants.WEEK_DAYS;
            
                /**
                 * show loading spinner
                 */
                var showLoading = function () {
                    $rootScope.loading = true;
                };

                /**
                 * hide loading spinner
                 */
                var hideLoading = function () {
                    $rootScope.loading = false;
                };

                 /**
				 * show progress bar
				 */
				var showProgressBar = function (data) {
					var totalRecords = data.totalRecords || 0;
					var processedRecords = data.processedRecords || 0;
					var totalPercentage = data.totalPercentage || 100;
					var defaultPercentage = data.defaultPercentage || 0;
					$rootScope.progressBarData = {
						loadingMode: data.loadingMode,
						message: data.message,
						totalRecords: totalRecords,
						processedRecords: processedRecords,
						totalPercentage: totalPercentage,
						defaultPercentage: defaultPercentage,
						percentage: totalRecords ? (processedRecords * 100 / totalRecords) : 0
					};
					$rootScope.progressBarData.percentage = ($rootScope.progressBarData.defaultPercentage + $rootScope.progressBarData.percentage) * 100 / $rootScope.progressBarData.totalPercentage;
				};

				/**
				 * show progress bar
				 */
				var updateProgressBar = function (processedRecords, message, isLoadingMode) {
					processedRecords = processedRecords || 0;
					if(message) {
						$rootScope.progressBarData.message = message;
					}
					$rootScope.progressBarData.loadingMode = !!isLoadingMode;
					$rootScope.progressBarData.processedRecords = processedRecords;
					$rootScope.progressBarData.percentage = $rootScope.progressBarData.totalRecords ? (processedRecords * 100 / $rootScope.progressBarData.totalRecords) : 0;
					$rootScope.progressBarData.percentage = ($rootScope.progressBarData.defaultPercentage + $rootScope.progressBarData.percentage) * 100 / $rootScope.progressBarData.totalPercentage;
				};

				/**
				 * hide progress bar
				 */
				var hideProgressBar = function () {
					$rootScope.progressBarData = null;
                };
                
                var isWindows = function() {
                    return navigator && navigator.platform && navigator.platform.indexOf('Win') > -1;
                };

                var getRecurringJobsByRecurringOptions = function (currentEvent, allEvents, editRecurringOption, today, getJobsInPast) {
					return (allEvents || []).filter(function(event) {
						//remove current job from the recurring
						if(event.id === currentEvent.id) return false;

						var isInFuture = getJobsInPast || moment(dateUtil.parseDateTime(event.startDate, event.startTime)).isSameOrAfter(moment(today), 'minutes');
						if(editRecurringOption === EDIT_RECURRING_ACTION.SAME_WEEKDAY.value) {
							return isInFuture && moment(currentEvent.startDate).weekday() === moment(event.startDate).weekday();
						}

						if(editRecurringOption === EDIT_RECURRING_ACTION.FOLLOWING_EVENTS.value) {
							return isInFuture && moment(event.startDate).isSameOrAfter(moment(currentEvent.startDate), 'days');
						}

						if(editRecurringOption === EDIT_RECURRING_ACTION.ALL_EVENTS.value) {
							return isInFuture;
						}

						return false;
					});
				};

                /**
                 * open modal
                 * 
                 * @param options an object with following properties
                 *  - templateUrl | template
                 *  - scope (optional, be a direct child of rootScope if not provided)
                 *  - appendTo parent element that modal element will appended to, be [ng-app] if not provideed 
                 * 
                 * @return function to close modal
                 */
                var openModal = function (options) {
                    var appendToEl, modalScope;
                    var modalController = options.controller || {};

                    var showModal = function (tplContent) {
                        var modalElContainer = angular.element('<div class="sked-modal-container"></div>');
                        var bodyEl = angular.element('body');
                        var modalEl = angular.element('<div ></div>'),
                            modalBackdrop = angular.element('<div class="slds-backdrop"></div>');
                        var zIndex = 9010 + (angular.element('.sked-modal-container').length || 0) + 1;
                        var wrapperEl = angular.element('.hco-rac-data-content-wrapper');


                        // setup modal container
                        modalElContainer.css('z-index', zIndex);
                    
                        // setup modal element
                        modalEl.attr({
                            role: 'dialog',
                            tabindex: -1,
                            class: 'slds-modal slds-fade-in-open slds-hide slds-modal--' + options.size + ' ' + options.additionalClasses
                        });
                        modalEl.append(tplContent);
                        modalEl.appendTo(modalElContainer);
                        modalBackdrop.appendTo(modalElContainer);
                        $compile(modalEl)(modalScope); // apply modal scope

                        appendToEl.append(modalElContainer);
                    
                        // show modal
                        modalEl.addClass('slds-show')
                            .removeClass('slds-hide')
                            .attr('aria-hidden', 'false')
                            .attr('tabindex', -1);

                        if (options.noBackdrop !== true) {
                            $timeout(function() {
                                modalBackdrop.addClass('slds-backdrop--open');
                                modalEl.addClass('slds-fade-in-open');
                            }, 25);
                        }

                        // disable body scroll
                        bodyEl.css({
                            overflow: 'hidden'
                        });
                        if(wrapperEl) {
                            wrapperEl.css({
                                overflow: 'hidden'
                            });
                        }

                        // dismiss modal
                        modalController.closeModal = function (closingCallback, closedCallback) {
                            var destroyModal = function () {
                                modalElContainer.remove();
                                if (angular.isFunction (closedCallback)) {
                                    closedCallback();
                                }

                                var anyModalLeft = angular.element('.sked-modal-container');
                                if(!anyModalLeft || !anyModalLeft.length) {
                                    bodyEl.css({
                                        overflow: ''
                                    });
                                    if(wrapperEl) {
                                        wrapperEl.css({
                                            overflow: ''
                                        });
                                    }
                                }

                                // destroy modal scope
                                if (modalScope && angular.isFunction (modalScope.$destroy)) {
                                    modalScope.$destroy();
                                }
                            };

                            if (options.noBackdrop !== true) {
                                destroyModal();
                            // modalBackdrop.one('transitionend', destroyModal).removeClass('slds-backdrop--open');
                            } else {
                                destroyModal();
                            }

                            modalEl.removeClass('slds-fade-in-open')
                                .attr('aria-hidden', 'true')
                                .attr('tabindex', -1);
                    
                            if (angular.isFunction (closingCallback)) {
                                closingCallback();
                            }
                        };
                    };

                    if (options && (options.templateUrl || options.template)) {
                        appendToEl = options.appendTo || angular.element('[ng-app]');
                        modalScope = options.scope || $rootScope.$new();

                        if (options.templateUrl) {
                            $templateRequest(options.templateUrl).then(showModal);
                        } else if (options.template) {
                            showModal(options.template);
                        }
                    }

                    return modalController;
                
                };

                /**
                 * toast message
                 */
                var toast = function (options, scope) {
                    var DEFAULT_ICONS = [
                        'otification',
                        'success',
                        'warning',
                        'error'
                    ];
                    var DEFAULT_THEME = [
                        '',
                        'slds-theme--success',
                        'slds-theme--warning',
                        'slds-theme--error'
                    ];
                    var toastSettings = angular.extend({
                        templateUrl: 'src/shared/toast-template.html',
                        type: TOAST_TYPE.DEFAULT,
                        icon: DEFAULT_ICONS[options.type || 0],
                        timeout: 6000 // default timeout is 4 seconds
                    }, options);

                    var appendToEl = toastSettings.appendTo || angular.element('[ng-app]'), 
                        toastScope = scope || $rootScope.$new();

                    var showToast = function (toastEl) {
                        if (toastEl) {
                            toastEl.addClass('pc-toast-message-shown');
                        }
                    };

                    var hideToast = function (toastEl) {
                        if (toastEl) {
                            toastEl.one('transitionend', function() {
                                toastEl.remove();
                                toastEl = null;
                                if (toastScope && angular.isFunction(toastScope.$destroy)) {
                                    toastScope.$destroy();
                                }
                            }).removeClass('pc-toast-message-shown');
                        }
                    };

                    angular.extend(toastScope, toastSettings);

                    $templateRequest(toastSettings.templateUrl)
                        .then(function (tplContent) {
                            var toastElContainer = angular.element('.slds-notify_container');
                            var toastEl = angular.element('<div role="alert" class="slds-notify slds-notify--toast pc-toast-message slds-theme--alert-texture ' + DEFAULT_THEME[toastSettings.type] + '" ng-click="hideToast()"></div>');

                            toastScope.hideToast = function () {
                                hideToast(toastEl);
                            };

                            if (toastElContainer.length === 0) {
                                toastElContainer = angular.element('<div class="slds-notify_container"></div>');
                                appendToEl.append(toastElContainer);
                            }

                            toastEl.append(tplContent);
                            toastEl.prependTo(toastElContainer);

                            $compile(toastEl)(toastScope); // apply modal scope
                        
                            // show toast
                            $timeout(function () {
                                showToast(toastEl);
                            }, 0);

                            $timeout(function () {
                                hideToast(toastEl);
                            }, toastSettings.timeout);

                        });

                };

                var toastBasic = function (message) {
                    return toast({type: TOAST_TYPE.DEFAULT, message: message});
                };

                var toastSuccess = function (message) {
                    return toast({type: TOAST_TYPE.SUCCESS, message: message});
                };

                var toastWarning =function (message) {
                    return toast({type: TOAST_TYPE.WARNING, message: message});
                };

                var toastError = function (message) {
                    return toast({type: TOAST_TYPE.ERROR, message: message});
                };

                /**
                 * show confirmation dialog
                 */
                var confirm = function (options) {
                    var deferred = $q.defer();
                    var modalScope = $rootScope.$new();
                    var modalOptions = angular.extend({
                        templateUrl: 'src/shared/confirm-modal-template.html',
                        scope: modalScope
                    }, options);
                
                    var modalController = openModal(modalOptions);

                    modalScope.title = options.title || 'Confirmation';
                    modalScope.message = options.message || 'Are you sure?';
                    modalScope.confirm = function () {
                        modalController.closeModal();
                        deferred.resolve('confirmed');
                    };
                    modalScope.dismiss = function () {
                        modalController.closeModal();
                        deferred.reject('cancelled');  
                    };

                    return deferred.promise;
                };

                /**
                 * show modal
                 */
                var showModal = function (options, resolve) {
                    var deferred = $q.defer();
                    var modalScope = options.scope || $rootScope.$new();
                    var modalOptions = angular.extend({
                        scope: modalScope
                    }, options);

                    var modalController;

                    if (resolve) {
                        angular.extend(modalScope, resolve);
                    }
                
                    modalController = openModal(modalOptions);

                    modalScope.closeModal = function (action) {
                        modalController.closeModal(null, function () {
                            deferred.resolve(action);
                        });
                    };

                    return deferred.promise;
                };

                /**
                 * compare 2 values
                 */
                var compareValues = function (value1, value2) {
                    var compareArrays = function (array1, array2) {
                        if (array1.length !== array2.length) {
                            return false;
                        } else {
                            for (var i = 0; i < array1.length; i++) {

                                if (!compareValues(array1[i], array2[i])) {
                                    return false;
                                }
                            }
                        }

                        return true;
                    };

                    var compareObjects = function (object1, object2) {
                        for (var key in object1) {
                            if (Object.prototype.hasOwnProperty.call(object1, key)) {
                                if (!Object.prototype.hasOwnProperty.call(object2, key) || !compareValues(object1[key], object2[key])) {
                                    return false;
                                }
                            }
                        }

                        return true;
                    };

                
                    return value1 === value2 ||
                    (angular.isObject(value1) && angular.isObject(value2) && !angular.isArray(value1) && !angular.isArray(value2) && compareObjects(value1, value2)) ||
                    (angular.isArray(value1) && angular.isArray(value2) && compareArrays(value1, value2));
                };  

                var getMinuteValue = function (timeValue) {
                    return (Math.floor(timeValue/100) * 60) + Math.round(timeValue%100);
                };

                var getTimeValue = function (minuteValue) {
                    var tsH = Math.floor(minuteValue / 60);
                    var tsM = Math.round(minuteValue % 60);

                    return ((tsH * 100) + tsM);
                };

                var getRemValue = function (configData, timeValue, GRID_SETTINGS) {
                    return ((Math.round((timeValue / configData.consoleSettings.calendarStep) * 1000) / 1000) * GRID_SETTINGS.slotSize.h);
                };


                /**
                 * check if 2 events are overlapped
                 */
                var isEventsOverlapped = function (event1, event2) {       
                    if(!event1.timeslotData || !event2.timeslotData) return false;

                    var start1 = event1.timeslotData.y, 
                        start2 = event2.timeslotData.y, 
                        end1 = event1.timeslotData.y + event1.timeslotData.h, 
                        end2 = event2.timeslotData.y + event2.timeslotData.h;
                    
                    return (start1 < end2 && end1 > start2);
                };

                /**
                 * go through list to put overlapping information for each event
                 */
                var checkOverlappingEvent = function (checkingList, event, startLevel) {
                    var tmpEvent, maxLevel;

                    if (angular.isArray(checkingList) && checkingList.length > 1) {
                    
                        if (!event.overlapInfo) {
                            event.overlapInfo = {
                                level: startLevel,
                                maxLevel: startLevel,
                                overlappedEvents: []
                            };

                            for (var i = 0; i < checkingList.length; i++) {
                                tmpEvent = checkingList[i];

                                if (event !== tmpEvent && isEventsOverlapped(event, tmpEvent)) {
                                    event.overlapInfo.overlappedEvents.push(tmpEvent);
                                    maxLevel = checkOverlappingEvent(checkingList, tmpEvent, startLevel + 1);

                                }
                            }

                        }

                        if (maxLevel > event.overlapInfo.maxLevel) {
                            event.overlapInfo.maxLevel = maxLevel;
                        }

                        return event.overlapInfo.maxLevel;
                    }

                    return startLevel;
                };

                var processTimeslots = function (configData, timeSlots, events, acceptOutOfRange, GRID_SETTINGS) {
                    var startCalSlot = timeSlots[0],
                        endCalSlot = timeSlots[timeSlots.length - 1],
                        startCalMinuteVal = ((startCalSlot && !isNullOrEmpty(startCalSlot.start))?getMinuteValue(startCalSlot.start):-1),
                        endCalMinuteVal = ((endCalSlot && !isNullOrEmpty(endCalSlot.start))?getMinuteValue(endCalSlot.start):-1);

                    if (startCalMinuteVal >= 0 && endCalMinuteVal >= 0 && angular.isArray(events)) {
                        angular.forEach(events, function (event) {
                            var yPosition, xPosition, slotHeight, slotWidth, boxHeight;
                            var startEventMinuteVal = getMinuteValue(event.startTime),
                                endEventMinuteVal = getMinuteValue((event.endTime === 0)?2400:event.endTime),
                                travelMinuteVal = (event.travelTime || 0),
                                startSlotMinuteVal = startEventMinuteVal - travelMinuteVal;
                            var isOutTravel = false,
                                isOutStart = false,
                                isOutEnd = false,
                                isOutCal = false;

                            xPosition = 0;
                            slotWidth = 100;

                            if (acceptOutOfRange === true) {
                                if (startSlotMinuteVal < startCalMinuteVal) {
                                    startSlotMinuteVal = startCalMinuteVal;
                                    isOutTravel = true;

                                    isOutStart = (startEventMinuteVal < startCalMinuteVal);
                                }

                                if (endEventMinuteVal > endCalMinuteVal) {
                                    endEventMinuteVal = endCalMinuteVal;
                                    isOutEnd = true;
                                }
                            }

                            // identify y position
                            yPosition = getRemValue(configData, startSlotMinuteVal - startCalMinuteVal, GRID_SETTINGS);
                            // identify event height
                            slotHeight = getRemValue(configData, endEventMinuteVal - startSlotMinuteVal, GRID_SETTINGS);
                            // identify box height
                            boxHeight = getRemValue(configData, endEventMinuteVal - startEventMinuteVal, GRID_SETTINGS);

                            if (boxHeight > slotHeight) {
                                boxHeight = slotHeight;
                            }

                            isOutCal = (endEventMinuteVal <= startCalMinuteVal || startEventMinuteVal >= endCalMinuteVal);

                            if (yPosition >= 0 && !isOutCal) {
                                event.timeslotData = {
                                    y: yPosition,
                                    x: xPosition,
                                    w: slotWidth,
                                    h: slotHeight,
                                    b: boxHeight,
                                    travelBeforeGrid: isOutTravel,
                                    startBeforeGrid: isOutStart,
                                    endAfterGrid: isOutEnd
                                };
                            }
                        });
                    }
                };

                /**
                 * calculate timeslots tobe shown on calendar
                 */
                var calculateCalendarTimeslots = function (configData) {
                    var tmpTimeSlot, tmpNextTimeSlot, tsH, tsM, tsEH, tsEM, tsHN, tsMN, tsAP;
                    var interval, isShown, isTimePart;
                    var timeslots = [];
                    var tsSurplus, tsAbsolute;
                
                    if (configData && configData.calendarStart >= 0 && configData.calendarEnd >= 0) {
                        interval = configData.calendarStep; 

                        var calendarStartInMinutes = dateUtil.getMinuteValue(configData.calendarStart);
                        var calendarEndInMinutes = dateUtil.getMinuteValue(configData.calendarEnd);
                        for (tmpTimeSlot =  calendarStartInMinutes; 
                            tmpTimeSlot <= calendarEndInMinutes; 
                            tmpTimeSlot += interval) {
                            tsH = Math.floor(tmpTimeSlot / 60);
                            tsM = Math.round(tmpTimeSlot % 60);

                            tmpNextTimeSlot = tmpTimeSlot + interval;
                            tsEH = Math.floor(tmpNextTimeSlot / 60);
                            tsEM = Math.round(tmpNextTimeSlot % 60);

                            // hour name
                            tsSurplus = tsH % 12;
                            tsAbsolute = Math.floor(tsH / 12);
                            if (tsSurplus === 0) {
                                tsHN = '12'; 
                            } else {
                            //tsHN = ('00' + tsSurplus).substr(-2);
                                tsHN = tsSurplus;
                            }
                            tsAP = (tsAbsolute % 2 === 1)?'PM':'AM';

                            // minute name
                            tsMN = ('00' + tsM).substr(-2);

                            // show timeslot label
                            // isShown = (tsM === 0 || tsM % interval === 0);
                            isTimePart = (tsM !== 0);

                            timeslots.push({
                                start: (tsH * 100) + tsM,
                                end: (tsEH * 100) + tsEM,
                                key: ((tsH * 100) + tsM) + '',
                                name: tsHN + ':' + tsMN + ' ' + tsAP,
                                shown: true || isShown,
                                timePart: isTimePart
                            });
                        }
                    }

                    return timeslots;
                };

                /**
                 * event is all day when:
                 * startDate !== endDate
                 * isAllDay = true
                 * startTime <= 0 && endTime >= 2400
                 */
                var isAllDayEvent = function (event) {
                    //let BE control isAllDay logic
                    var isAllDay = !!event.isAllDay;
                    return isAllDay;
                };

                var processTimeslotsPreferredTimes = function(items, timeSlots) {
                    var startCalSlot = timeSlots[0],
                        startCalMinuteVal = ((startCalSlot && !isNullOrEmpty(startCalSlot.start)) ? getMinuteValue(startCalSlot.start) : -1);

                    items.forEach(function(item){
                        if((item.hasPreferredTimes || item.isAllTimePreferred) && item.timeslotData) {
                            var startTimeMinVal = getMinuteValue(item.startTime);
                            var preferredStartTimeMinVal = getMinuteValue(item.preferredStartTime);
                            var preferredOffsetStartDuration = preferredStartTimeMinVal - startTimeMinVal;
                            var isOutOfCal = startTimeMinVal < startCalMinuteVal;
                            var isPreferredTimeOutOfCal = preferredStartTimeMinVal < startCalMinuteVal;
                            var timeSlotHeight = item.timeslotData.h;
                            var outOfCalDuration = isOutOfCal ? startCalMinuteVal - startTimeMinVal : 0;
                            var prferredOutOfCalDuration = isPreferredTimeOutOfCal ? startCalMinuteVal - preferredStartTimeMinVal : 0;
                            item.timeSlotPreferredTimeData = {
                                t: Math.max(timeSlotHeight * (preferredOffsetStartDuration - prferredOutOfCalDuration - outOfCalDuration) / (item.duration - outOfCalDuration), 0),
                                h: timeSlotHeight * (item.preferredTimeDuration - prferredOutOfCalDuration) / (item.duration - outOfCalDuration)
                            };
                        }
                    });
                };

                var isInPast = function (date, today) {
                    return date.getTime() < today.getTime();
                };

                var calculateCalendarDays = function (calStartDate, configData, regions, today, calEndDate) {
                    var ONE_DAY_TIME = 86400000;
                    var tmpDate, startDate, endDate, dw;
                    var tmpHoliday, tmpHolidayDateTime, holidayStartDate, holidayEndDate;
                    var regionIds, tmpCalStartDate, tmpCalEndDate;
                    var yesterday = angular.copy(today);
                    var daysMap = {};
                    var regionIdx;

                    yesterday.setDate(today.getDate() - 1);
                    if (configData && configData.consoleSettings && angular.isDate(calStartDate)) {
                    //startDate = new Date(calStartDate.getFullYear(), calStartDate.getMonth(), calStartDate.getDate() - calStartDate.getDay());
                        startDate = new Date(calStartDate.getFullYear(), calStartDate.getMonth(), calStartDate.getDate());
                    
                        if (angular.isDate(calEndDate)) {
                            endDate = new Date(calEndDate.getFullYear(), calEndDate.getMonth(), calEndDate.getDate());
                        } else {
                            endDate = angular.copy(startDate);
                            endDate.setDate(endDate.getDate() + (7 * configData.consoleSettings.viewPeriod));
                        }
                    
                        for (tmpDate =  angular.copy(startDate); tmpDate < endDate; tmpDate.setDate(tmpDate.getDate() + 1)) {
                            dw = tmpDate.getDay();

                            daysMap[tmpDate.getTime()] = {
                                dateIso: dateUtil.dateToString(tmpDate),
                                date: angular.copy(tmpDate),
                                isWeekend: (dw === 0 || dw === 6),
                                isInPast: isInPast(tmpDate, today),
                                isToday: (tmpDate.getTime() === today.getTime()),
                                isYesterday: (tmpDate.getTime() === yesterday.getTime())
                            };
                        }

                        // identify holiday information
                        tmpCalStartDate = startDate.getTime();
                        tmpCalEndDate = endDate.getTime();
                        regionIds = regions ? regions.map(function (region) {
                            return region.id;
                        }) : [];
                    
                        if (configData.holidays && configData.holidays.length > 0) {
                            for (var i = 0; i < configData.holidays.length; i++) {
                                tmpHoliday = configData.holidays[i];
                                regionIdx = (tmpHoliday.regionId?regionIds.indexOf(tmpHoliday.regionId):-1);
                                if (tmpHoliday && 
                                angular.isDate(tmpHoliday.startDate) && angular.isDate(tmpHoliday.endDate) && 
                                (tmpHoliday.isGlobal || regionIds.indexOf(tmpHoliday.regionId) > -1)) {
                                    holidayStartDate = tmpHoliday.startDate.getTime();
                                    holidayEndDate = tmpHoliday.endDate.getTime();

                                    if (holidayStartDate <= tmpCalEndDate && holidayEndDate >= tmpCalStartDate) {
                                        if (holidayStartDate < tmpCalStartDate) {
                                            tmpHolidayDateTime = tmpCalStartDate;
                                        } else {
                                            tmpHolidayDateTime = holidayStartDate;
                                        }

                                        if (regionIdx > -1) {
                                            tmpHoliday.region = regions[regionIdx];
                                        }

                                        for (;tmpHolidayDateTime <= holidayEndDate && tmpHolidayDateTime <= tmpCalEndDate; tmpHolidayDateTime += ONE_DAY_TIME) {
                                            if (daysMap[tmpHolidayDateTime]) {
                                                if (!angular.isArray(daysMap[tmpHolidayDateTime].holidays)) {
                                                    daysMap[tmpHolidayDateTime].holidays = [];
                                                }

                                                daysMap[tmpHolidayDateTime].holidays.push(tmpHoliday);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    return Object.values(daysMap);
                };

                var buildCalendarWeeks = function (calendarDays, currentMonth, firstDay) {
                    var weeks = [];
                    var tmpWeek, tmpDate;

                    firstDay = firstDay || 0;

                    if (angular.isArray(calendarDays) && calendarDays.length > 0) {
                        angular.forEach(calendarDays, function (calDay, idx) {
                            tmpDate = calDay.date;

                            if (idx === 0 || tmpDate.getDay() === firstDay) {
                                tmpWeek = new Array(7);
                                weeks.push(tmpWeek);
                            }

                            // check month
                            calDay.isOutofMonth = (currentMonth >= 0 && calDay.date.getMonth() !== currentMonth);

                            tmpWeek[(7 + tmpDate.getDay() - firstDay)%7] = calDay;

                        });
                    }

                    return weeks;
                };


                var isNullOrEmpty = function(value) {
                    return angular.isUndefined(value) || value === null || value === '';
                };

                var buildDescriptionForSingleJob = function(eventType, patient) {
                    if(!eventType || !patient) return '';
                    return (angular.isString(eventType) ? eventType : eventType.label) + ' for ' + patient.name;
                };

                var isTouchDevice = function() {
                    try {
                        return !!Modernizr.touch;
                    } catch(e) {
                        return false;
                    }
                };
                var checkOvernight = function(event) {
					if(!event) return null;
					var startDate = event.startDate;
					var endDate = event.endDate;
					var startTime = event.startTime;
					var endTime = event.endTime;

					if(isNullOrEmpty(startDate) || isNullOrEmpty(endDate) || isNullOrEmpty(startTime) || isNullOrEmpty(endTime)) {
						return event;
					}

					var startDateTime = dateUtil.parseDateTime(startDate, startTime);
					var endDateTime = dateUtil.parseDateTime(endDate, endTime);

					if(moment(endDateTime).isSameOrBefore(moment(startDateTime), 'minutes')) {
						var newEndDateTime = moment(endDateTime).add(1, 'day').toDate();
						event.endDate = dateUtil.dateToString(newEndDateTime);
					};
					
					return event;
                }
                
                function serial(tasks) {
					var prevPromise;
					angular.forEach(tasks, function (task) {
						//First task
						if (!prevPromise) {
							prevPromise = task();
						} else {
							prevPromise = prevPromise.then(task);
						}
					});
					return prevPromise;
                }
                
                return {
                    TOAST_TYPE: TOAST_TYPE,
                    isWindows: isWindows,
                    showLoading: showLoading,
                    hideLoading: hideLoading,
                    showProgressBar: showProgressBar,
					updateProgressBar: updateProgressBar,
					hideProgressBar: hideProgressBar,
                    showModal: showModal,
                    confirm: confirm,
                    toast: toast,
                    toastBasic: toastBasic,
                    toastSuccess: toastSuccess,
                    toastWarning: toastWarning,
                    toastError: toastError,
                    compareValues: compareValues,
                    isNullOrEmpty: isNullOrEmpty,

                    getMinuteValue: getMinuteValue,
                    getTimeValue: getTimeValue,
                    getRemValue: getRemValue,
                    isEventsOverlapped: isEventsOverlapped,
                    checkOverlappingEvent: checkOverlappingEvent,
                    processTimeslots: processTimeslots,
                    calculateCalendarTimeslots: calculateCalendarTimeslots,
                    processTimeslotsPreferredTimes: processTimeslotsPreferredTimes,
                    calculateCalendarDays: calculateCalendarDays,
                    isInPast: isInPast,
                    isAllDayEvent: isAllDayEvent,

                    buildDescriptionForSingleJob: buildDescriptionForSingleJob,
                    buildCalendarWeeks: buildCalendarWeeks,
                    isTouchDevice: isTouchDevice,

                    getRecurringJobsByRecurringOptions: getRecurringJobsByRecurringOptions,
                    checkOvernight: checkOvernight,
                    serial: serial
                };

            }
        ]);
})(angular);