(function (angular) {
	angular.module('skedApp.core', []);
})(angular);