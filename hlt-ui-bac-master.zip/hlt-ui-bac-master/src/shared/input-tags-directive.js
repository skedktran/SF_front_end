(function (angular) {
    angular.module('skedApp.shared')
    .directive('skedInputTags', [
        '$timeout',
        '$q',
        '$filter',
        '$templateRequest',
        '$compile',
        '$document',
        '$window',
        function($timeout, $q, $filter, $templateRequest, $compile, $document, $window) {
            return {
                restrict: 'E',
                replace: true,
                templateUrl: 'src/shared/input-tags-template.html',
                scope: {
                    label: '@?',
                    imageField: '@?',
                    defaultImage: '@?',
                    iconUrl: '@?',
                    iconClass: '@?',
                    labelField: '@?',
                    metaField: '@?',
                    searchFn: '&search',
                    isReadonly: '=',
                    model: '=',
                    disabledTagIds: '=',
                    placeholder: '@?',
                    ref: '@?',
                    containerClass: '@?'
                },
                link: function ($scope, $el, $attr) {
                    var inputEl = $el.find('input[type=text]');
                    var inputContainerEl = $el.find('.slds-pill_container');
                    var lookupMenuTemplateUrl = 'src/shared/input-tags-lookup-menu-template.html';
                    var lookupMenuContainer = angular.element('[ng-app]');
                    var elWindow = angular.element($window);
                    var lookupMenuEl;

                    var clickOutsideHandler = function (event) {
                        for (var element = event.target; element; element = element.parentNode) {
                            // check if the element is the same element the directive is attached to and exit if so (props @CosticaPuntaru)
                            if (element === lookupMenuEl[0] || element === inputContainerEl[0]) {
                                return;
                            }
                        }
                        $scope.hideLookupMenu();
                    };
                    
                    $scope.isFocusing = false;

                    $scope.addTag = function (item) {
                        var filteredResults;
                        var model = $scope.model;

                        if (!angular.isArray(model)) {
                            model = $scope.model = [];
                        }  

                        if (model.indexOf(item) === -1) {
                            model.push(item);

                            /*$timeout(function () {
                                //$scope.setLookupMenuPosition();
                            });*/

                            $scope.updateLookupMenuVisibility();
                        }
                    };

                    $scope.removeTagAt = function (index) {
                        if (index < $scope.model.length) {
                            $scope.model.splice(index, 1);
                        }
                    };

                    $scope.focusLookupInput = function () {
                        if (inputEl && inputEl.length > 0) {
                            $timeout(function() {
                                inputEl.focus();
                            }, 10);
                        }
                    };

                    $scope.filterAlreadySelectedTags = function (value, index, array) {
                        var model = $scope.model;

                        if (model) {
                            for (var i = 0; i < model.length; i++) {

                                if ((model[i] === value) || 
                                    (angular.isObject(model[i]) && model[i].id === value.id)) {
                                    return false;
                                }
                            }
                        }
                        
                        return true;
                    };

                    $scope.search = function () {
                        $q.when($scope.searchFn({searchString: $scope.searchString}))
                            .then(function (results) {
                                $scope.searchResults = results;
                                $scope.updateLookupMenuVisibility();
                            })
                            .catch(function () {
                                $scope.searchResults = null;
                            });
                    };

                    $scope.showLookupMenu = function () {
                        var width = $el.outerWidth();

                        if (!lookupMenuEl) {
                            $templateRequest(lookupMenuTemplateUrl)
                                .then(function (template) {
                                    lookupMenuEl = angular.element('<div class="slds-lookup__menu" ref="' + $scope.ref + '"></div>');
                                    lookupMenuEl.append(template);
                                    lookupMenuEl.css({
                                        /*position: 'absolute',
                                        'z-index': 90002,*/
                                        'max-width': width + 'px',
                                        //top: offest.top + height - containerOffset.top + containerPosition.top,
                                        //left: offest.left - containerOffset.left + containerPosition.left
                                    });
                                    lookupMenuEl.appendTo(lookupMenuContainer);
                                    $compile(lookupMenuEl)($scope);

                                    $document.on('click', clickOutsideHandler);

                                    $timeout(function () {
                                        $scope.setLookupMenuPosition();
                                        lookupMenuEl.css({
                                            visibility: 'visible',
                                            opacity: 1
                                        });
                                    });
                                });
                        }

                        $timeout(function () {
                            $scope.setLookupMenuPosition();
                        });
                    };

                    $scope.hideLookupMenu = function () {
                        if (lookupMenuEl) {
                            lookupMenuEl.css({
                                visibility: 'hidden',
                                opacity: 0
                            });

                            $timeout(function () {
                                if (lookupMenuEl) {
                                    lookupMenuEl.remove();
                                    lookupMenuEl = null;
                                }

                                $document.off('click', clickOutsideHandler);
                            }, 150);
                        }
                    };

                    $scope.setLookupMenuPosition = function () {
                        var offest, height, width, lookupMenuHeight, containerHeight, containerOffset, containerPosition;
                        var top, left;

                        if (lookupMenuEl) {
                            offest = inputContainerEl.offset();
                            height = inputContainerEl.outerHeight();
                            width = inputContainerEl.outerWidth();
                            lookupMenuHeight = lookupMenuEl.outerHeight();
                            windowHeight = elWindow.outerHeight();
                            containerOffset = lookupMenuContainer.offset();
                            containerPosition = lookupMenuContainer.position();

                            top = offest.top + height - containerOffset.top + containerPosition.top;
                            left = offest.left - containerOffset.left + containerPosition.left;

                            if (lookupMenuHeight + top > windowHeight) {
                                top -= (lookupMenuHeight + height + 1);
                            }

                            lookupMenuEl.css({
                                top: top,
                                left: left
                            });
                        }
                    };

                    $scope.updateLookupMenuVisibility = function () {
                        var filteredResults = $filter('filter')($scope.searchResults, $scope.filterAlreadySelectedTags);

                        if (filteredResults.length > 0) {
                            $scope.showLookupMenu();
                        } else {
                            $scope.hideLookupMenu();
                        }
                    };

                    /*if (!angular.isArray($scope.model)) {
                        $scope.model = [];
                    }*/
                }
            }
        }
    ])
})(angular);