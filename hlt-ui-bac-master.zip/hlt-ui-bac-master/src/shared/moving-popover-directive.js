(function (angular) {
    angular.module('skedApp.shared')
    .directive('skedMovingPopover', [
        '$templateRequest',
        '$compile',
        '$window',
        function($templateRequest, $compile, $window) {
            return function (scope, element, attribute) {
                var beIgnored = !!scope.$eval(attribute.skedMovingPopoverIgnored),
                    popoverEl, 
                    containerEl = angular.element('[ng-app]'),
                    ctnOffset = containerEl.offset();
                    
                var distance = 20;

                if (beIgnored !== true && attribute.skedMovingPopover) {
                    element.on('mouseenter mousemove mouseleave', function (event) {
                        var eventType = event.type;
                        var elH, elW, ctH, ctW, posX, posY;

                        ctH = $window.innerHeight;
                        ctW = $window.innerWidth;

                        /*if (containerEl && containerEl.length > 0 && ctH > containerEl.height()) {
                            ctH = containerEl.height();
                        }*/

                        switch (eventType) {
                            case 'mouseenter':
                                if (!popoverEl) {
                                    $templateRequest(attribute.skedMovingPopover).then(function (template) {
                                        //popoverEl = angular.element('<div style="position: absolute;"></div>');
                                        //($compile(template)(scope)).appendTo(popoverEl);
                                        popoverEl = $compile(template)(scope);
                                        popoverEl.toggleClass('slds-popover');
                                        popoverEl.css({
                                            display: 'none',
                                            position: 'absolute'
                                        });
                                        popoverEl.appendTo(containerEl);
                                        popoverEl.on('mouseenter mousemove', function (e) {
                                            e.stopPropagation();
                                        });
                                    });
                                } else {
                                    popoverEl.css('display', 'none');
                                }
                                break;
                            case 'mousemove':
                                if (popoverEl && popoverEl.length > 0) {
                                    elH = popoverEl.height();
                                    elW = popoverEl.width();

                                    //posX = event.target.offsetLeft + event.offsetX + distance;
                                    //posY = event.target.offsetTop + event.offsetY + distance;

                                    posX = event.pageX - ctnOffset.left + distance;
                                    posY = event.pageY - ctnOffset.top + distance;

                                    if (elW + event.clientX + (distance*2) > ctW) {
                                        posX -= (elW + (distance*1.5));
                                    } 

                                    if (elH + event.clientY + (distance*2) > ctH) {
                                        posY -= (elH + (distance*1.5));
                                    }

                                    popoverEl.css({
                                        display: 'block',
                                        left: posX,
                                        top: posY
                                    });
                                }
                                break;
                            case 'mouseleave':
                                if (popoverEl) {
                                    popoverEl.css({
                                        display: 'none',
                                        left: '',
                                        top: ''
                                    });
                                }
                                break;
                        }
                    });
                }
            }
        }
    ])
})(angular);