(function (angular) {
    angular.module('skedApp.shared')
    .directive('skedDockedTopTo', [
        '$timeout',
        '$window',
        function($timeout, $window) {
            return function (scope, element, attribute) {
                var elYOffset = element.offset().top;
                //var elYOffset = 170;
                var skedDockedTopTo = attribute.skedDockedTopTo;
                var parent = (attribute.skedDockedTopTo)?element.closest(attribute.skedDockedTopTo):null;
                var elWindow = angular.element($window);
                var isDocked = false, 
                    currentWindowWidth = elWindow.width(), 
                    currentParentWidth = ((parent)?parent.width():0);
                    sizeChanged = false;
                var clonedEl;

                var eventHandler = function (event) {
                    if (clonedEl) {
                        sizeChanged = (element.width() !== clonedEl.width());
                    }

                    if ((parent ? parent.scrollTop() : this.pageYOffset) >= elYOffset && (isDocked === false || sizeChanged)) {
                        isDocked = true;

                        if (!clonedEl) {
                            clonedEl = element.clone();
                            clonedEl.appendTo(element.parent());
                        }

                        element.css({
                            position: 'fixed',
                            width: clonedEl.outerWidth(),
                            top: 0,
                            'z-index': 2
                        });
                        element.addClass('is-docked-top');
                    } else if ((parent ? parent.scrollTop() : this.pageYOffset) < elYOffset && isDocked === true){
                        isDocked = false;
                        if (clonedEl) {
                            clonedEl.remove();
                            clonedEl = null;
                        }

                        element.css({
                            position: '',
                            width: '',
                            top: '',
                            'z-index': ''
                        });
                        element.removeClass('is-docked-top');
                    }
                    
                };

                elWindow.on('scroll resize', eventHandler);
                if (parent) {
                    parent.on('scroll resize', eventHandler);
                }

                $timeout(function () {
                    elYOffset = element.offset().top;
                }, 0);

                elWindow.trigger('resize');
                
                if (parent) {
                    parent.trigger('resize');
                }

                scope.$on('$destroy', function () {
                    elWindow.off('scroll resize', eventHandler);
                    if (parent) {
                        parent.off('scroll resize', eventHandler);
                    }
                });
            };
        }
    ])
})(angular);