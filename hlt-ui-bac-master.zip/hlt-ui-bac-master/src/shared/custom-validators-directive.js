(function (angular, jQuery) {
	angular.module('skedApp.shared')
	.directive('skedCustomValidators', [
		function() {
			return {
				restrict: 'A',
				require: '?ngModel',
				link: function ($scope, $el, $attr, $ctrl) {
					var customValidators = $scope.$eval($attr.skedCustomValidators);

					if ($ctrl && angular.isObject(customValidators)) {
						angular.forEach(customValidators, function (validatorFn, validatorKey) {
							

							$ctrl.$validators[validatorKey] = function (modelValue) {
								var isValid;
								if (angular.isFunction(validatorFn)) {
									isValid = validatorFn(modelValue, $ctrl, $scope);
								} else {
									isValid = !!validatorFn;
								}

								return isValid;
							}
						});
					}
				}
			}
		}
	])
})(angular, jQuery);