(function (angular) {
	angular.module('skedApp.shared')
	.provider('ggLocationApi', function () {
		var configuration = {
			apiUrl: 'https://maps.googleapis.com/maps/api',
			sensor: true,
			outputFormat: 'json'
		};
		var API = {
			GEOCODE: {
				NAME: 'geocode',
				KEY: 'AIzaSyA83ZOeD6Gw3eRxuSlxOE-dPA3l_iLRVkY'
			},
			TIMEZONE: {
				NAME: 'timezone',
				KEY: 'AIzaSyDS5uRTjzent7MZ7dZAdkA07xTKw5LKztU'
			}
		};

		this.config = function (config) {
			if (angular.isObject(config)) {
				angular.extend(configuration, config);
			}
		};

		this.$get = [
			'$http',
			'$q',
			function ($http, $q) {
				var callApi = function (api, params) {
					params = angular.extend({}, {
						key: api.KEY,
						sensor: configuration.sensor,
						timestamp: Math.floor(Date.now()/1000)
					}, params);

					return $http({
						url: [
								configuration.apiUrl,
								api.NAME,
								configuration.outputFormat
							].join('/'),
						params: params,
						method: 'GET'
					}).then(function (response) {
						if (response.data) {
							return response.data;
						} else {
							return $q.reject(response.data);
						}
					});
				};
				
				var geocode = function (params) {
					return callApi(API.GEOCODE, params);
				};

				var timezone = function (params) {
					return callApi(API.TIMEZONE, params);
				};

				return {
					geocode: geocode,
					timezone: timezone
				}
			}
		];
	});
})(angular);
