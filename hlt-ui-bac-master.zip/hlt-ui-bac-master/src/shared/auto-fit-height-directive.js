(function (angular) {
    angular.module('skedApp.shared')
    .directive('skedAutoFitHeight', [
        '$window',
        '$timeout',
        function($window, $timeout) {
            return function (scope, element, attribute) {
                var targetEl = angular.element(element);
                var paddingBottom = 12;

                var eventHandler = function() {
                    var targetElTop = targetEl.offset().top;
                    targetEl.css('height', 'calc(100vh - ' + (targetElTop + paddingBottom)  + 'px)');
                }
                
                scope.$watch(function(){
                    return scope.$eval(attribute.offsetTop);
                }, function(){
                    eventHandler();
                })

                scope.$watch(function(){
                    return targetEl.offset().top;
                }, function(){
                    eventHandler();
                })
            };
        }
    ])
})(angular);