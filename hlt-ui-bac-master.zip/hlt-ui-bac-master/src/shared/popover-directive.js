(function (angular, jQuery) {
    angular.module('skedApp.shared')
    .directive('skedPopover', [
        '$templateRequest',
        '$compile',
        '$window',
        '$document',
        '$timeout',
        'util',
        function($templateRequest, $compile, $window, $document, $timeout, util) {
            var PADDING = 5;
            var POPOVER_POSITION = {
                TOP: 'top',
                RIGHT: 'right',
                BOTTOM: 'bottom',
                LEFT: 'left'
            }
            
            var canBeShow = function (position, params) {
                return (
                        position.top >= PADDING &&
                        position.left >= PADDING &&
                        (position.left + params.eW) <= (params.cW - PADDING) &&
                        (position.top + params.eH) <= (params.cH - PADDING)
                    );
            };
            
            var showBottom = function (element, params, forceShow) {
                var position = {
                    //top: (params.tT + (params.tH/2)),
                    top: (params.tT + (params.tH)),
                    left: (params.tL - (params.eW/2) + (params.tW/2)),
                    'margin-top': '1.25rem'
                }

                if (forceShow || canBeShow(position, params)) {
                    element.css(position);
                    element.addClass('slds-nubbin_top');
                    return true;
                }

                return false;
            };

            var showTop = function (element, params, forceShow) {
                var position = {
                    //top: (params.tT - params.eH + (params.tH/2)),
                    top: (params.tT - params.eH),
                    left: (params.tL - (params.eW/2) + (params.tW/2)),
                    'margin-top': '-1.25rem'
                }

                if (forceShow || canBeShow(position, params)) {
                    element.css(position);
                    element.addClass('slds-nubbin_bottom');
                    return true;
                }

                return false;
            };

            var showLeft = function (element, params, forceShow) {
                var position = {
                    top: (params.tT - (params.eH/2) + (params.tH/2)),
                    //left: (params.tL - params.eW + (params.tW/2)),
                    left: (params.tL - params.eW),
                    'margin-left': '-1.25rem'
                }

                if (forceShow || canBeShow(position, params)) {
                    element.css(position);
                    element.addClass('slds-nubbin_right');
                    return true;
                }

                return false;
            };

            var showRight = function (element, params, forceShow) {
                var position = {
                    top: (params.tT - (params.eH/2) + (params.tH/2)),
                    //left: (params.tL + (params.tW/2)),
                    left: (params.tL + params.tW),
                    'margin-left': '1.25rem'
                }

                if (forceShow || canBeShow(position, params)) {
                    element.css(position);
                    element.addClass('slds-nubbin_left');
                    return true;
                }

                return false;
            };

            var forceShow = function (element, params) {
                var position = {}, nubbin = [];

                if (params.tL + params.tW > params.cW - PADDING) {
                    position.left = (params.tL - params.eW + (params.tW/2));
                    position['margin-left'] = '-1.25rem';
                    nubbin.push('right');
                } else if (params.tL < PADDING) {
                    position.left = (params.tL + (params.tW/2));
                    position['margin-left'] = '1.25rem';
                    nubbin.push('left');
                } else {
                    position.left = params.tL;
                }

                if (params.tT + params.eH > params.cH - PADDING) {
                    position.top = (params.tT - params.eH + (params.tH/2));
                    position['margin-top'] = '1.25rem';
                    nubbin.push('bottom');
                } else if (params.tT - params.eH < PADDING) {
                    position.top = (params.tT + (params.tH/2));
                    position['margin-top'] = '-2.5rem';
                    nubbin.push('top');
                } else {
                    position.top = params.tT;
                }

                element.css(position);

                if (nubbin.length > 0) {
                    element.addClass('slds-nubbin_' + nubbin.join('-'));
                }

                return true;
            };

            var calculatePopoverPosition = function (targetEl, containerEl, popoverEl, popoverPosition) {
                var params = {}, 
                    targetElOffset,
                    containerOffset = containerEl.offset(),
                    containerPosition = containerEl.position();
                var fnShows = [];

                if (targetEl) {
                    targetElOffset = targetEl.offset();

                    params.tL = targetElOffset.left - containerOffset.left + containerPosition.left;
                    params.tT = targetElOffset.top - containerOffset.top + containerPosition.top;
                    params.tH = targetEl.height();
                    params.tW = targetEl.width();

                    params.eH = popoverEl.outerHeight();
                    params.eW = popoverEl.outerWidth();

                    params.cH = containerEl.height();
                    params.cW = containerEl.width();

                    switch (popoverPosition) {
                        case POPOVER_POSITION.RIGHT:
                            fnShows = [showRight, showLeft, showBottom, showTop];
                            break;
                        case POPOVER_POSITION.BOTTOM:
                            fnShows = [showBottom, showLeft, showTop, showRight];
                            break;
                        case POPOVER_POSITION.LEFT:
                            fnShows = [showLeft, showRight, showTop, showBottom];
                            break;
                        case POPOVER_POSITION.TOP:
                        default:
                            fnShows = [showTop, showRight, showBottom, showLeft];
                            break;
                    }
                    fnShows.push(forceShow);

                    for (var i = 0; i < fnShows.length; i++) {
                        if (fnShows[i](popoverEl, params)) {
                            break;
                        }
                    }
                }
            };

            return {
                restrict: 'A',
                link: function ($scope, $el, $attr) {
                    if(util.isTouchDevice()) return;
                    
                    var popoverEnabled = $scope.$eval($attr.skedPopover);
                    var templateUrl = $attr.skedPopoverTemplate;
                    var popoverContentExpression = $attr.skedPopoverContent;
                    var popoverPosition = $attr.skedPopoverPosition;
                    var popoverTheme = $attr.skedPopoverTheme;
                    var popoverStyle = $scope.$eval($attr.skedPopoverStyle);
                    var popoverContainer = $el.parents($attr.skedPopoverContainer || '[ng-app]');
                    var elWindow = angular.element($window);
                    var popoverEl;
                    var mouseHovered = false;

                    var showPopover = function (event) {
                        var popoverContent;

                        var doShowPopover = function () {
                            if (popoverContent) {
                                popoverEl = angular.element('<div class="slds-popover"></div>');
                                popoverEl.append(popoverContent);
                                popoverEl.css({
                                    position: 'absolute',
                                    width: 'auto',
                                    'z-index': 90003,
                                    top: 0,
                                    left: 0,
                                    visibility: 'hidden'
                                    //top: event.pageY - containerOffset.top + containerPosition.top,
                                    //left: event.pageX - containerOffset.left + containerPosition.left
                                });

                                if (popoverTheme) {
                                    popoverEl.addClass('slds-popover_' + popoverTheme);
                                }
                                if (popoverStyle) {
                                    popoverEl.css(popoverStyle);
                                }

                                popoverEl.appendTo(popoverContainer);
                                popoverEl.hover(hidePopover);

                                $timeout(function () {
                                    if (mouseHovered) { // workaround to check if mouse still be hovered at this moment
                                        calculatePopoverPosition($el, popoverContainer, popoverEl, popoverPosition);
                                        popoverEl.css('visibility', '');
                                    } else {
                                        hidePopover();
                                    }
                                });
                            }
                        };

                        mouseHovered = true;

                        if (!popoverEl) {
                            if (templateUrl) {
                                $templateRequest(templateUrl)
                                    .then(function (template) {
                                        popoverContent = $compile(template)($scope);;
                                        doShowPopover();
                                    });
                            } else if (popoverContentExpression) {
                                popoverContent = $compile([
                                    '<div class="slds-popover__body slds-p-around_small slds-text-body_small">{{',
                                    //$scope.$eval(popoverContentExpression),
                                    popoverContentExpression,
                                    '}}</div>'
                                ].join(''))($scope);

                                $scope.$apply(function () {
                                    doShowPopover();
                                });
                                
                            }
                        }
                    };

                    var hidePopover = function () {
                        mouseHovered = false;
                        if (popoverEl) {
                            popoverEl.remove();
                            popoverEl = null;
                        }
                    };

                    if (popoverEnabled) {
                        $el.hover(showPopover, hidePopover);
                        $el.on('$destroy', hidePopover);

                        $scope.$on('$destroy', $scope.$hidePopovers);

                        if (!angular.isArray($scope.$popoverHiddingFunctions)) {
                            $scope.$popoverHiddingFunctions = [];
                        }
                        $scope.$popoverHiddingFunctions.push(hidePopover);
                        $scope.$hidePopovers = function () {
                            if (angular.isArray($scope.$popoverHiddingFunctions)) {
                                angular.forEach($scope.$popoverHiddingFunctions, function (hiddingFunction) {
                                    hiddingFunction.call();
                                });
                            }
                        }
                    }
                }
            }
        }
    ])
})(angular, jQuery);