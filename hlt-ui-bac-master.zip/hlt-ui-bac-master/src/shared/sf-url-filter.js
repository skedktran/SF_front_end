(function (angular) {
    angular.module('skedApp.shared')
        .filter('skedSfUrl', [
            'env',
            function (env) {
                var resourcePath = angular.copy(env.RESOURCE_PATH) || '/',
                    disPath = angular.copy(env.DIST_PATH) || '/';

                if (resourcePath.charAt(resourcePath.length - 1) !== '/') {
                    resourcePath += '/';
                }

                if (disPath.charAt(disPath.length - 1) !== '/') {
                    disPath += '/';
                }

                return function (rawPath, source) {
                    var path;
                    
                    if (angular.isString(rawPath)) {
                        path = (source === 'dist')?disPath:resourcePath;

                        if (rawPath.charAt(0) === '/') {
                            rawPath = rawPath.substring(1);
                        }

                        return path + rawPath;
                    } 
                }
            }
        ])
})(angular);