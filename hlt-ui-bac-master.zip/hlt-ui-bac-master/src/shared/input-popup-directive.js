(function (angular) {
    angular.module('skedApp.shared')
    .directive('skedInputPopup', [
        'util',
        function(util) {
            return {
                restrict: 'E',
                replace: true,
                templateUrl: 'src/shared/input-popup-template.html',
                scope: {
                    label: '@?',
                    labelField: '@?',
                    model: '=',
                    resolver: '=popupResolver',
                    templateUrl: '@popupTemplateUrl'
                },
                link: function ($scope, $el, $attr) {
                    var resolver = $scope.resolver || {},
                        templateUrl = $scope.templateUrl,
                        labelField = $scope.labelField;
                    var isModalOpened = false;

                    var modelToString = function (model) {
                        if (angular.isObject(model) && labelField) {
                            return model[labelField];
                        } else if (model.toString) {
                            return model.toString();
                        }

                        return '';
                    };

                    $scope.inputView = '';

                    $scope.openPopup = function () {
                        if (templateUrl && !isModalOpened) {
                            isModalOpened = true;
                            util.showModal({templateUrl: templateUrl}, resolver)
                                .finally(function () {
                                    isModalOpened = false;
                                });
                        }
                    };

                    $scope.$watch('model', function (newVal) {
                        var modelViewList = [];

                        if (newVal) {
                            if (angular.isArray(newVal)) {
                                angular.forEach(newVal, function (model) {
                                    modelViewList.push(modelToString(model));
                                });

                                $scope.inputView = modelViewList.join(', ');
                            } else {
                                $scope.inputView = modelToString(newVal);
                            }
                        } else {
                            $scope.inputView = '';
                        }
                    });
                }
            }
        }
    ])
})(angular);