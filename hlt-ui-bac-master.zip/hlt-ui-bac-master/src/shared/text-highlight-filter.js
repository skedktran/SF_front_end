(function (angular) {
	angular.module('skedApp.shared')
		.filter('skedTextHighlight', [
				'$sce',
				function ($sce) {
					return function(text, phrase) {
						if (phrase) text = text.replace(new RegExp('(' + phrase + ')', 'gi'),
							'<span class="sked-highlighted-text">$1</span>')

						return $sce.trustAsHtml(text)
					};
				}
		]);
})(angular);