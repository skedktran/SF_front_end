(function (angular) {
	angular.module('skedApp.shared')
	.directive('skedMonthPicker', [
		'dateUtil',
		function(dateUtil) {
			return {
				restrict: 'A',
				require: '?ngModel',
				link: function ($scope, $el, $attr, ngModelCtrl) {

					var getOptions = function getOptions() {
						return angular.extend($scope.$eval($attr.skedMonthPicker), {
							Button: false,
							Duration: 'fast',
							Position: {
								collision: 'fit flip'
							},
							MonthFormat: 'MM yy'
						});
					};

					var initDateWidget = function () {
						var opts = getOptions();

						opts.OnAfterChooseMonth = function (selectedDate) {
							$scope.$apply(function () {
								ngModelCtrl.$setViewValue(selectedDate);
							});
						};

						// Creates the new MonthPicker widget
						$el.MonthPicker(opts);

						// Cleanup on destroy, prevent memory leaking
						$el.on('$destroy', function () {
							//$el.MonthPicker('Destroy');
							//$el.Destroy();
						});

						if (ngModelCtrl) {
							ngModelCtrl.$render = function () {
								// Force a render to override whatever is in the input text box
								if (!angular.isDate(ngModelCtrl.$modelValue) && angular.isString(ngModelCtrl.$modelValue)) {
									ngModelCtrl.$modelValue = dateUtil.parseDateString(controller.$ngModelCtrl);
								}

								$el.MonthPicker('option', 'SelectedMonth', ngModelCtrl.$modelValue);
							};


							ngModelCtrl.$render();
						}
					};

					// Watch for changes to the directives options
					$scope.$watch(getOptions, initDateWidget, true);
				}
			}
		}
	])
})(angular);