(function (angular) {
    angular.module('skedApp.shared')
    .directive('skedInputLookup', [
        '$timeout',
        '$q',
        '$templateRequest',
        '$compile',
        '$document',
        '$window',
        '$parse',
        function($timeout, $q, $templateRequest, $compile, $document, $window, $parse) {
            return {
                restrict: 'E',
                replace: true,
                templateUrl: 'src/shared/input-lookup-template.html',
                scope: {
                    label: '@?',
                    iconUrl: '@?',
                    iconClass: '@?',
                    imageField: '@?',
                    defaultImage: '@?',
                    labelField: '@',
                    metaField: '@',
                    required: '@?isRequired',
                    searchFn: '&search',
                    placeholder: '@?',
                    onChange: '&?',
                    model: '=',
                    isInvalid: '=',
                    isReadonly: '=',
                    searchString: '=?',
                    ref: '@?'
                },
                link: function ($scope, $el, $attr) {
                    var inputEl = $el.find('input[type=text]');
                    var lookupMenuTemplateUrl = 'src/shared/input-lookup-menu-template.html';
                    var lookupMenuContainer = angular.element('[ng-app]');
                    var elWindow = angular.element($window);
                    var lookupMenuEl;

                    var clickOutsideHandler = function (event) {
                        for (var element = event.target; element; element = element.parentNode) {
                            // check if the element is the same element the directive is attached to and exit if so
                            if (element === lookupMenuEl[0] || element === inputEl[0]) {
                                return;
                            }
                        }
                        $scope.hideLookupMenu();
                    };

                    $scope.selectLookupItem = function (item) {
                        $scope.model = item;
                        $scope.searchString = '';

                        if (angular.isFunction ($scope.onChange)) {
                            $timeout(function () {
                                $scope.onChange();
                            });
                        }
                    };

                    $scope.resetLookupItem = function () {
                        $scope.model = null;
                        
                        if (angular.isFunction ($scope.onChange)) {
                            $timeout(function () {
                                $scope.onChange();
                            });
                        }
                    };

                    $scope.focusLookupInput = function () {
                        if (inputEl && inputEl.length > 0) {
                            $timeout(function() {
                                inputEl.focus();
                            }, 10);
                        }
                    };

                    $scope.search = function () {
                        if (!$scope.isReadonly) {
                            $q.when($scope.searchFn({searchString: $scope.searchString}))
                                .then(function (results) {
                                    $scope.searchResults = results || [];

                                    if ($scope.searchResults.length > 0) {
                                        $scope.showLookupMenu();
                                    } else {
                                        $scope.hideLookupMenu();
                                    }
                                })
                                .catch(function () {
                                    $scope.searchResults = null;
                                });
                        }
                    };

                    $scope.showLookupMenu = function () {
                        var width = $el.outerWidth();

                        if (!lookupMenuEl && angular.isArray($scope.searchResults) && $scope.searchResults.length > 0) {
                            $templateRequest(lookupMenuTemplateUrl)
                                .then(function (template) {
                                    lookupMenuEl = angular.element('<div class="slds-lookup__menu" ref="' + $scope.ref + '"></div>');
                                    lookupMenuEl.append(template);
                                    lookupMenuEl.css({
                                        /*position: 'absolute',
                                        'z-index': 90002,*/
                                        'max-width': width + 'px',
                                        //top: offest.top + height - containerOffset.top + containerPosition.top,
                                        //left: offest.left - containerOffset.left + containerPosition.left
                                    });
                                    lookupMenuEl.appendTo(lookupMenuContainer);
                                    $compile(lookupMenuEl)($scope);

                                    $document.on('click', clickOutsideHandler);

                                    $timeout(function () {
                                        $scope.setLookupMenuPosition();
                                        lookupMenuEl.css({
                                            visibility: 'visible',
                                            opacity: 1
                                        });
                                    });
                                });
                        } 

                        $timeout(function () {
                            $scope.setLookupMenuPosition();
                        });
                    };

                    $scope.hideLookupMenu = function () {
                        if (lookupMenuEl) {
                            lookupMenuEl.css({
                                visibility: 'hidden',
                                opacity: 0
                            });

                            $timeout(function () {
                                lookupMenuEl.remove();
                                lookupMenuEl = null;
                                $document.off('click', clickOutsideHandler);
                            }, 150);
                        }
                    };

                    $scope.setLookupMenuPosition = function () {
                        var offest, height, width, lookupMenuHeight, containerHeight, containerOffset, containerPosition;
                        var top, left;

                        if (lookupMenuEl) {
                            offest = inputEl.offset();
                            height = inputEl.outerHeight();
                            width = inputEl.outerWidth();
                            lookupMenuHeight = lookupMenuEl.outerHeight();
                            windowHeight = elWindow.outerHeight();
                            containerOffset = lookupMenuContainer.offset();
                            containerPosition = lookupMenuContainer.position();

                            top = offest.top + height - containerOffset.top + containerPosition.top;
                            left = offest.left - containerOffset.left + containerPosition.left;

                            if (lookupMenuHeight + top > windowHeight) {
                                top -= (lookupMenuHeight + height + 1);
                            }

                            lookupMenuEl.css({
                                top: top,
                                left: left
                            });
                        }
                    };

                    $scope.getLabel = function (item) {
                        if (item && $scope.labelField) {
                            return $parse($scope.labelField)(item);
                        }
                    };

                    $scope.getMeta = function (item) {
                        if (item && $scope.metaField) {
                            return $parse($scope.metaField)(item);
                        }
                    };
                }
            }
        }
    ])
})(angular);