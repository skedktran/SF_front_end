(function (angular, jQuery) {
	angular.module('skedApp.shared')
	.directive('skedDropdownMenu', [
		'$templateRequest',
		'$compile',
		'$window',
		'$document',
		'$timeout',
		function($templateRequest, $compile, $window, $document, $timeout) {
			return {
				restrict: 'A',
				link: function ($scope, $el, $attr) {
					var templateUrl = $attr.skedDropdownMenu;
					var dropdownContainer = $el.parents($attr.skedDropdownMenuContainer || '[ng-app]');
					var elWindow = angular.element($window);
					var elParent, dropdownEl;
					var isIgnored = $scope.$eval($attr.skedDropdownMenuIgnored);
					var onMenuHide = $attr.onDropdownMenuHide;

					var showOnTop = ($attr.skedDropdownMenuOnTop === 'true');

					var initParentElement = function () {
						var parentSelectors = [];

						if ($attr.skedDropdownMenuContainer) {
							parentSelectors.push($attr.skedDropdownMenuContainer);
						}

						if ($attr.skedDropdownMenuScroller) {
							parentSelectors.push($attr.skedDropdownMenuScroller);
						}
						
						elParent = $el.parents(parentSelectors.join(','));

						if (elParent.length === 0) {
							elParent = $el.parent();
						}
					};

					var clickOutsideHandler = function (event) {
						var allowClickingEls = angular.element($attr.skedDropdownMenuAllowClicking);
						var element = event.target;

						for (; element; element = element.parentNode) {
							// check if the element is the same element the directive is attached to and exit if so (props @CosticaPuntaru)
							if (element === dropdownEl[0] || element === $el[0]) {
								return;
							}

							for (var i = 0; i < allowClickingEls.length; i++) {
								if (element === allowClickingEls[i]) {
									return;
								}
							}
						}

						hideDropdownMenu();
					};

					var showDropdownMenu = function (event) {
						var offest = $el.offset(),
							height = $el.outerHeight(),
							width = $el.outerWidth();
						var containerOffset = dropdownContainer.offset(),
							containerPosition = dropdownContainer.position(),
							containerHeight = dropdownContainer.height();

						if (!dropdownEl) {
							$templateRequest(templateUrl)
								.then(function (template) {
									var dropdownElHeight;
									var posTop = offest.top + ((!showOnTop)?height:0) - containerOffset.top + 2;

									dropdownEl = angular.element('<div></div>');
									dropdownEl.append(template);
									dropdownEl.appendTo(dropdownContainer);
									$compile(dropdownEl)($scope);

									dropdownElHeight = dropdownEl.children().outerHeight();

									if (posTop + dropdownElHeight > containerHeight - 8) {
										if (showOnTop) {
											posTop = containerHeight - (dropdownElHeight + 8)
										} else {
											posTop -= (dropdownElHeight + height + 8);
										}
									}

									dropdownEl.css({
										position: 'absolute',
										'z-index': 90002,
										//top: offest.top + ((!showOnTop)?height:0) - containerOffset.top + containerPosition.top,
										top: posTop,
										left: offest.left + width - containerOffset.left + containerPosition.left
									});

									$document.on('click', clickOutsideHandler);
									elWindow.on('scroll', triggerClickingOutside);
									if (elParent) {
										elParent.on('scroll', triggerClickingOutside);
									}
								});
								
							$document.trigger('click');
							
							event.stopPropagation();
						}
					};

					var hideDropdownMenu = function () {
						if (dropdownEl) {
							dropdownEl.remove();
							dropdownEl = null;
							$document.off('click', clickOutsideHandler);
							elWindow.off('scroll', triggerClickingOutside);
							if (elParent) {
								elParent.off('scroll', triggerClickingOutside);
							}

							if (onMenuHide) {
								$scope.$eval(onMenuHide);
							}
						}
					};

					var triggerClickingOutside = function () {
						$document.click();
					};

					initParentElement();

					if (isIgnored !== true && templateUrl) {
						$el.click(showDropdownMenu);

						$scope.$dropdownMenu = {
							hideDropdownMenu: hideDropdownMenu
						}
					}
				}
			}
		}
	])
})(angular, jQuery);