(function (angular) {
    angular.module('skedApp.shared')
    .directive('skedDraggableScrolling', [
        '$window',
        '$timeout',
        function($window, $timeout) {
            return function (scope, element, attribute) {
                var syncEl = (attribute.skedDraggableScrolling)?angular.element(attribute.skedDraggableScrolling):null;
                var elWindow = angular.element($window);
                var curXPos, curDown;

                if(syncEl) {
                    syncEl.css('cursor', 'move');
                }

                var handleScroll = function () {
                    if (syncEl && syncEl.length > 0) {
                        syncEl.scrollLeft(this.scrollLeft);
                    }
                };

                var handleDrag = function (event, mainEl, attachedEl) {
                    var eventType = event.type;
                    switch (eventType) {
                        case 'mousedown':
                            if (event.which === 1) {
                                curDown = true;
                                curXPos = event.pageX;
                                mainEl.addClass('mouse-down');
                            }
                            break;
                        case 'mousemove':
                            if (curDown === true) {
                                this.scrollLeft += (curXPos - event.pageX);
                                curXPos = event.pageX;
                                
                                if (attachedEl && attachedEl.length > 0) {
                                    attachedEl.scrollLeft(this.scrollLeft);
                                }
                            }
                            break;
                        case 'mouseup':
                            mainEl.removeClass('mouse-down');
                            curDown = false;
                            break;
                    }
                };

                element.on('scroll', handleScroll);

                if (syncEl && syncEl.length > 0) {
                    // syncEl.on('scroll', handleScroll);
                    syncEl.on('mousedown mousemove mouseup', function (event) {
                        handleDrag.call(this, event, syncEl, element);
                    });
                }

                elWindow.on('mouseup', function () {
                    element.removeClass('mouse-down');
                    curDown = false;
                });
            };
        }
    ])
})(angular);