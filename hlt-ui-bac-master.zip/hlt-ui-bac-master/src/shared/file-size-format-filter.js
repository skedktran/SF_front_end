(function (angular) {
    angular.module('skedApp.shared')
    .filter('skedFileSizeFormat', [
        function() {
            return function (bytes, precision) {
                var units = ['bytes', 'kB', 'MB', 'GB', 'TB', 'PB'];
                var unitIndex;

                if (isNaN(parseFloat(bytes)) || !isFinite(bytes)) {
                   return ''; 
                } 

                if (bytes === 0) {
                    return '0 bytes';
                }

                if (precision === undefined || precision === null || precision < 0) {
                    precision = 1;
                }

                unitIndex = Math.floor(Math.log(bytes) / Math.log(1024));
                return (bytes / Math.pow(1024, Math.floor(unitIndex))).toFixed(precision) +  ' ' + units[unitIndex];
            };
        }
    ])
})(angular);