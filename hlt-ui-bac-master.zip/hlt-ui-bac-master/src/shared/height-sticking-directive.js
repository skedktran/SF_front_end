(function (angular) {
    angular.module('skedApp.shared')
    .directive('skedHeightStickingTo', [
        function() {
            return {
                scope: {
                    stickingVal: '=skedHeightStickingTo',
                    minNoLines: '=skedHeightStickingMinLine'
                },
                link: function (scope, element) {

                    scope.$watch(function () {
                        return element.height();
                    }, function (newVal) {
                        var minNoLines = 0,
                            calVal = (newVal - 1);
                        if ((calVal % scope.stickingVal) > 0) {
                            minNoLines = Math.ceil(calVal / scope.stickingVal);
                            element.height(minNoLines * scope.stickingVal);

                            scope.minNoLines = minNoLines;
                        }
                    });
                }
            }
        }
    ])
})(angular);