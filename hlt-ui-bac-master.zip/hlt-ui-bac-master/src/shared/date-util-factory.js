(function (angular, moment) {
  angular.module('skedApp.shared')
    .factory('dateUtil', [
      '$filter',
      '$injector',
      function ($filter, $injector) {
        var GMT_TIMEZONE_SID = 'GMT';
        var DAY_TIME_VALUE = 86400000;
        var dateFilter = $filter('date');

        /**
                 * check if string valid by format 'yyyy-MM-dd'
                 */
        var isDateStringValid = function (dateString) {
          var formatReg = /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/; //yyyy-MM-dd

          return dateString && formatReg.test(dateString);
        };

        /**
                 * check if time value is a number with format hhmm
                 */
        var isValidTimeVal = function (timeVal) {
          var formatReg = /^([0-1][0-9]|2[0-4])([0-5][0-9])$/;

          return angular.isNumber(timeVal) && timeVal >= 0 &&
                        formatReg.test(('0000' + timeVal).substr(-4));
        };

        /**
                 * parse Date object from string (with format yyyy-MM-dd)
                 */
        var parseDateString = function (dateValue) {
          var dateParts;

          if (angular.isDate(dateValue)) {
            return dateValue;
          } else if (angular.isNumber(dateValue)) {
            return new Date(dateValue);
          } else if (angular.isString(dateValue) && isDateStringValid(dateValue)) {
            dateParts = dateValue.split('-');

            return new Date(parseInt(dateParts[0], 10), parseInt(dateParts[1], 10) - 1, parseInt(dateParts[2], 10));
          }

          return null;
        };

        /**
                 * parse Date to String with format 'yyyy-MM-dd'
                 */
        var dateToString = function (date, format) {
          format = format || 'yyyy-MM-dd';

          return dateFilter(date, format);
        };

        var dateToStringNative = function (date) {
					if(!date) return;
					var fullYearString = String(date.getFullYear());
					var monthString = String(date.getMonth() + 1);
					var dateString = String(date.getDate());
					if(monthString.length === 1) {
						monthString = '0' + monthString;
					}

					if(dateString.length === 1) {
						dateString = '0' + dateString;
					}

					return fullYearString + '-' + monthString + '-' + dateString;
				};

        /**
                 * add day to date
                 */
        var addDay = function (date, noDay) {
          if (angular.isDate(date) && angular.isNumber(noDay)) {
            return new Date(date.getTime() + (noDay * DAY_TIME_VALUE));
          }

          return null;
        };

        /**
                 * parse time value (number from 0 - 2400) to Date object with current date
                 */
        var parseTimeValue = function (timeVal, forDate) {
          var rtDate = null,
            parsedTimeVal, hVal, mVal;
          var timeValParser = /^([0-1][0-9]|2[0-4])([0-5][0-9])$/;

          if (isValidTimeVal(timeVal)) {
            rtDate = angular.copy(forDate) || new Date();
            parsedTimeVal = timeValParser.exec(('0000' + timeVal).substr(-4));
            hVal = parsedTimeVal[1];
            mVal = parsedTimeVal[2];

            rtDate.setHours(hVal, mVal, 0, 0);
          }

          return rtDate;
        };

        /**
                 * parse Date to String with format 'yyyy-MM-dd' then put time to date obje`c`t
                 */
        var parseDateTime = function (dateString, timeVal) {
          return parseTimeValue(timeVal, parseDateString(dateString));
        };

        var getCurrentDateTimeByTimezone = function (timezoneSidId) {
          var mm;
          if (!moment || !moment.tz || !timezoneSidId) {
            return new Date();
          } else {
            mm = moment();
            mm.tz(timezoneSidId);

            return new Date(mm.year(), mm.month(), mm.date(), mm.hour(), mm.minute(), mm.second(), 0);
          }
        };

        /**
                 * get diff between 2 days (days)
                 */
        var getDiff = function (date1, date2) {
          if (angular.isDate(date1) && angular.isDate(date2)) {
            //return Math.floor((date2.getTime() - date1.getTime()) / DAY_TIME_VALUE);
            return moment(date2).diff(moment(date1), 'd')
          }

          return 0;
        };

        var getMinuteValue = function (timeValue) {
          var util = $injector.get('util');
          if (util.isNullOrEmpty(timeValue)) return 0;

          return (Math.floor(timeValue / 100) * 60) + Math.round(timeValue % 100);
        };

        var parseTimeFromMinute = function (minute) {
          var util = $injector.get('util');
          if (util.isNullOrEmpty(minute)) return 0;

          return Math.floor(minute / 60) * 100 + Math.round(minute % 60);
        };

        var getTimeNumber = function (date) {
          return (date.getHours() * 100) + (date.getMinutes());
        };

        var getGMTDateTimeInfo = function (timestamp) {
          return getDateTimeInfo(timestamp, GMT_TIMEZONE_SID);
        };

        var getDateTimeInfo = function (timestamp, timezoneSidId) {
          var mm;
          var dateTimeInfo = {
            date: null,
            dateString: '',
            timeNumber: null
          };

          if (angular.isDate(timestamp) || angular.isNumber(timestamp)) {
            if (moment && moment.tz && timezoneSidId) {
              mm = moment(timestamp);
              mm.tz(timezoneSidId);

              dateTimeInfo.date = new Date(mm.year(), mm.month(), mm.date(), mm.hour(), mm.minute(), mm.second(), 0);
            } else {
              dateTimeInfo.date = new Date(timestamp);
            }

            dateTimeInfo.timeNumber = getTimeNumber(dateTimeInfo.date);
            dateTimeInfo.date.setHours(0, 0, 0, 0);
          }

          return dateTimeInfo;
        };

        var parseDateTimeInfo = function (dateTimeInfo, timezoneSidId, formatISOString) {
					if(!dateTimeInfo || !timezoneSidId || !moment || !moment.tz) return;

					var dateIso = dateToString(dateTimeInfo.date);
					var mm = moment.tz(dateIso, timezoneSidId);
					var timeObj = parseTimeValue(dateTimeInfo.timeNumber);
					mm = mm.add(timeObj.getHours(), 'hours');
					mm = mm.add(timeObj.getMinutes(), 'minutes');
					mm = mm.add(timeObj.getSeconds(), 'seconds');
				
					return formatISOString ? mm.utc().toISOString() : Number(String(mm.utc().unix()) + '000');
        };
        
        var parseTimeString = function (timeString) {
          var hVal = 0, mVal = 0, 
            timeStringParts = timeString.split(':');
            
          try {
            hVal = parseInt(timeStringParts[0], 10);
            mVal = parseInt(timeStringParts[1], 10);
          } catch (ex) {
            //ignore
          }

          return (hVal * 100) + mVal;
        };

        var timeToString = function (timeVal) {
          var timeString = ('0000' + timeVal).substr(-4);
          return [timeString.substr(0, 2), timeString.substr(-2)].join(':');
        };


        return {
          isDateStringValid: isDateStringValid,
          parseDateString: parseDateString,
          parseTimeString: parseTimeString,
          addDay: addDay,
          getDiff: getDiff,
          dateToString: dateToString,
          dateToStringNative: dateToStringNative,
          parseDateTime: parseDateTime,
          parseTimeValue: parseTimeValue,
          getCurrentDateTimeByTimezone: getCurrentDateTimeByTimezone,
          getMinuteValue: getMinuteValue,
          parseTimeFromMinute: parseTimeFromMinute,
          getDateTimeInfo: getDateTimeInfo,
          parseDateTimeInfo: parseDateTimeInfo,
          getGMTDateTimeInfo: getGMTDateTimeInfo,
          timeToString: timeToString
        };

      }
    ]);
})(angular, window.moment || null);