(function (angular) {
	angular.module('skedApp.shared', [
		'angular-click-outside'
	]);
})(angular);