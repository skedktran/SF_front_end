(function (angular) {
	angular.module('skedApp.shared')
	.directive('skedMultiPicklist', [
		'$timeout',
		'$window',
		'$templateRequest',
		'$compile',
		'$document',
		function($timeout, $window, $templateRequest, $compile, $document) {
			return {
				restrict: 'E',
				replace: true,
				templateUrl: 'src/shared/multi-picklist-template.html',
				scope: {
					listPosition: '@?',
					label: '@?',
					selectOptions: '@',
					selectAllOption: '@?',
					labelForMultiSelection: '@?',
					model: '=',
					isReadonly: '=',
					isRequired: '=',
					ref: '@?',
					name: '@?'
				},
				link: function ($scope, $el, $attr) {
					var parserExp = /^(.*)\s+as\s+(.*)\s+for\s+(.*)\s+in\s+(.*)$/i;
					var parsingResults = parserExp.exec($scope.selectOptions),
						select = parsingResults[1],
						label = parsingResults[2],
						item = parsingResults[3],
						list = parsingResults[4];
					var picklistTemplateUrl = 'src/shared/multi-picklist-menu-template.html';
					var picklistContainer = angular.element($attr.container || '[ng-app]');
					var picklistEl;
					var elWindow = angular.element($window);
					var inputEl = $el.find('input');

					var clickOutsideHandler = function (event) {
						for (var element = event.target; element; element = element.parentNode) {
							// check if the element is the same element the directive is attached to and exit if so (props @CosticaPuntaru)
							if (element === picklistEl[0] || element === inputEl[0]) {
								return;
							}
						}
						$scope.hidePicklist();
					};

					var getSelectionLabel = function () {
						var selectionLabel = '';

						if (angular.isArray($scope.selectedOptions) && $scope.selectedOptions.length > 0) {
							if ($scope.selectedOptions.length === $scope.optionList.length && $scope.selectAllOption) {
								selectionLabel = $scope.selectAllOption;
							} else if ($scope.selectedOptions.length === 1) {
								selectionLabel = $scope.$parent.$eval(label, {item: $scope.selectedOptions[0]});
							}  else if ($scope.selectedOptions.length > 1) {
								if ($scope.labelForMultiSelection) {
									selectionLabel = $scope.labelForMultiSelection;
								} else {
									selectionLabel = $scope.selectedOptions.length + ' Selected';
								}
							}
						}

						return selectionLabel;
					};

					var refreshListSelection = function (newList) {
						var hasKeys;

						$scope.optionList = newList;
						$scope.selectedOptions = [];

						if (angular.isArray($scope.optionList) && $scope.optionList.length > 0) {
							hasKeys = $scope.optionList.map(function (listItem) {
								return JSON.stringify(listItem);
							});

							if (angular.isArray($scope.model) && $scope.model.length > 0) {
								angular.forEach($scope.model, function (modelItem) {
									var modelItemHashKey = JSON.stringify(modelItem);
									var selectionIndex = hasKeys.indexOf(modelItemHashKey);

									if (selectionIndex > -1) {
										$scope.selectedOptions.push($scope.optionList[selectionIndex]);
									}
								});
							}
						}

						$scope.selectionLabel = getSelectionLabel();
					};

					$scope.selectionLabel = '';
					$scope.selectedOptions = [];

					$scope.toggleOptionSelection = function (option) {
						var optionIndex = $scope.selectedOptions.indexOf(option),
							modelItemIndex, modelItemHashKeys, 
							modelItemVal = $scope.$parent.$eval(select, {item: option}),
							modelItemHashKey = JSON.stringify(modelItemVal);

						// selected options
						if (optionIndex === -1) {
							$scope.selectedOptions.push(option);
						} else {
							$scope.selectedOptions.splice(optionIndex, 1);
						}

						// update model
						if (!angular.isArray($scope.model)) {
							$scope.model = [];
						}

						modelItemHashKeys = $scope.model.map(function (modelItem) {
							return JSON.stringify(modelItem);
						});

						modelItemIndex = modelItemHashKeys.indexOf(modelItemHashKey);

						if (modelItemIndex === -1) {
							$scope.model.push(modelItemVal);
						} else {
							$scope.model.splice(modelItemIndex, 1);
						}

						// update selection lable
						$scope.selectionLabel = getSelectionLabel();
					};

					$scope.getOptionLabel = function (option) {
						return $scope.$parent.$eval(label, {item: option});
					};

					$scope.showPicklist = function () {
						var width = $el.outerWidth();

						if (!picklistEl && !$scope.isReadonly) {
							$templateRequest(picklistTemplateUrl)
								.then(function (template) {
									picklistEl = angular.element('<div class="slds-lookup__menu slds-dropdown slds-dropdown_' + ($scope.listPosition || 'left') + '" ref="' + $scope.ref + '"></div>');
									picklistEl.append(template);
									picklistEl.css({
										//'z-index': 9030,
										'min-width': width + 'px',
										'max-width': 'max-content',
										//'visibility': 'hidden',
										//'opacity': 0
									});
									picklistEl.appendTo(picklistContainer);
									$compile(picklistEl)($scope);

									$document.on('click', clickOutsideHandler);

									$timeout(function () {
										$scope.setPicklistPosition();
										picklistEl.css({
											visibility: 'visible',
											opacity: 1
										});
									});
								});
						} 

						$timeout(function () {
							$scope.setPicklistPosition();
						});
					};

					$scope.hidePicklist = function () {
						if (picklistEl) {
							picklistEl.css({
								visibility: 'hidden',
								opacity: 0
							});

							$timeout(function () {
								if (picklistEl) {
									picklistEl.remove();
									picklistEl = null;
								}
								
								$document.off('click', clickOutsideHandler);
							}, 150);
						}
					};

					$scope.setPicklistPosition = function () {
						var offest, height, width, picklistHeight, picklistWidth, containerHeight, containerOffset, containerPosition;
						var top, left, right;
						var listPosition = $scope.listPosition || 'left';

						if (picklistEl) {
							offest = inputEl.offset();
							height = inputEl.outerHeight();
							width = inputEl.outerWidth();
							picklistHeight = picklistEl.outerHeight();
							picklistWidth = picklistEl.outerWidth();
							windowHeight = elWindow.outerHeight();
							containerOffset = picklistContainer.offset();
							containerPosition = picklistContainer.position();

							top = offest.top + height - containerOffset.top + containerPosition.top - 2;
							left = offest.left - containerOffset.left + containerPosition.left;

							if (picklistHeight + top > windowHeight) {
								top -= (picklistHeight + height + 1);
							}

							if (listPosition === 'right') {
								left -= (picklistWidth - width);
							}

							picklistEl.css({
								top: top,
								left: left
							});
						}
					};

					$scope.toggleSelectAll = function () {
						if ($scope.optionList.length === $scope.selectedOptions.length) {
							$scope.selectedOptions = [];
							$scope.model = [];
						} else {
							angular.forEach($scope.optionList, function (option) {
								optionIndex = $scope.selectedOptions.indexOf(option);

								if (optionIndex === -1) {
									$scope.toggleOptionSelection(option);
								}
							});
						}
					};


					/**
					 * watch changing of list
					 */
					$scope.$watchCollection(function () {
						return $scope.$parent.$eval(list);
					}, refreshListSelection , true);

					$scope.$watchCollection('model', function () {
						refreshListSelection($scope.optionList);
					});
				}
			}
		}
	])
})(angular);