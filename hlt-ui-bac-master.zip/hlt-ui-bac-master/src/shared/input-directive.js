(function (angular) {
	angular.module('skedApp.shared')
	.directive('skedInput', [
		function() {
			var INPUT_TYPE = {
				DATE_PICKER: 'date-picker',
				MONTH_PICKER: 'month-picker',
				TIME_PICKER: 'time-picker',
				COLOR_PICKER: 'color-picker',
				TEXT: 'text',
				LOOKUP: 'lookup',
				SELECT: 'select',
				TEXTAREA: 'textarea',
				CHECKBOX_TOGGLE: 'checkbox-toggle',
			};

			/**
			 * build textarea input template
			 **/
			var buildTextareaInputTemplate = function (properties) {
				var maxLengthString = '';
				var rowString = '';
				var iconString = '';
				if (properties.maxLength) {
					maxLengthString = 'maxlength="' + properties.maxLength + '" ';
				}
				if (properties.rows) {
					rowString = 'rows="' + properties.rows + '" ';
				}
				if (properties.icon) {
					var iconString = [
						'<span class="slds-icon_container">',
							'<svg class="slds-icon slds-icon_x-small" >',
								'<use xlink:href="" ng-attr-xlink:href="' + properties.icon + '" />',
							'</svg>',
						'</span>'].join('');
				}
				return ['<div class="slds-form-element__control">',
							'<div class="textarea-has-icon">',
								'<textarea class="slds-textarea" id="' + properties.id + '" name="' + properties.name + '" ' + ((properties.onChange)?(' ng-change="' + properties.onChange + '" '):'') + ' ng-model="' + properties.model + '" ' + ((properties.modelOptions)?(' ng-model-options="' + properties.modelOptions + '" '):'') + ' ng-readonly="' + properties.readonly + '" ng-required="' + properties.required + '" ' + rowString + maxLengthString + '/>',
								iconString,
							'</div>',
						'</div>'].join('');
			};


			/**
			 * build text input template
			 **/
			var buildTextInputTemplate = function (properties) {
				var patternString = '';
				if (properties.pattern) {
					patternString = 'ng-pattern="' + properties.pattern + '"';
				}
				var stepString = '';
				if (properties.step) {
					stepString = 'step="' + properties.step + '" ng-step="1"';
				}
				var maxLengthString = '';

				if (properties.maxLength) {
					maxLengthString = 'maxlength="' + properties.maxLength + '" ';
				}
				return ['<div class="slds-form-element__control">',
							'<input type="' + properties.type + ((properties.id)?('" id="' + properties.id):'') + '" name="' + properties.name + '" class="slds-input" ' + ((properties.onChange)?(' ng-change="' + properties.onChange + '" '):' ') + ((properties.onBlur)?(' ng-blur="' + properties.onBlur + '" '):' ') + ' ng-model="' + properties.model + '" ' + ((properties.modelOptions)?(' ng-model-options="' + properties.modelOptions + '" '):'') + ' ng-readonly="' + properties.readonly + '" ng-required="' + properties.required + '" ng-disabled="' + properties.disabled + '" ' + patternString + ' ' + stepString + ' ' + (properties.minValue?('ng-min="' + properties.minValue +'"'):'') + ' ' + (properties.maxValue?('ng-max="' + properties.maxValue +'"'):'') + ' ' + maxLengthString +' />',
						'</div>'].join('');

			};

			/**
			 * build color picker template
			 **/
			var buildColorPickerTemplate = function (properties) {
				var patternString = '';
				if (properties.pattern) {
					patternString = 'ng-pattern="' + properties.pattern + '"';
				}
				var stepString = '';
				if (properties.step) {
					stepString = 'step="' + properties.step + '" ng-step="1"';
				}
				return ['<div class="slds-form-element__control">',
						'<div class="slds-input-has-icon slds-input-has-icon_left" >',
							'<div style="border: solid 1px #d8dde6" class="slds-input__icon " ng-style="{\'background-color\': ' + properties.model + '}"></div>',
							'<input type="' + properties.type + ((properties.id)?('" id="' + properties.id):'') + '" name="' + properties.name + '" class="slds-input" ' + ((properties.onChange)?(' ng-change="' + properties.onChange + '" '):' ') + ((properties.onBlur)?(' ng-blur="' + properties.onBlur + '" '):' ') + ' color-picker color-picker-model="' + properties.model + '" ' +  ' ng-readonly="' + properties.readonly + '" ng-required="' + properties.required + '" />',
						'</div>',
					'</div>'].join('');
			};

			/**
			 * build dropdown input template
			 **/
			 var builDropdownListTemplate = function (properties) {
				return ['<div class="slds-form-element__control">',
							'<div class="slds-select_container">',
								'<select ' + ((properties.onChange)?(' ng-change="' + properties.onChange + '" '):'') + ((properties.id)?(' id="' + properties.id + '" '):'') + ' name="' + properties.name + '" class="slds-select" ng-model="' + properties.model + '" ng-required="' + properties.required + '" ng-disabled="' + properties.disabled + '" ng-options="' + properties.selectOptions + '">',
									(properties.selectNullOption)?('<option value="">' + properties.selectNullOption+ '</option>'):'',
								'</select>',
							'</div>',
						'</div>'].join('')
			 };

			/**
			 * build date picker input template
			 **/
			var buildDatePickerTemplate = function (properties) {
				if (!properties.dateOptions) {
					properties.dateOptions = '';
				}

				return ['<div class="slds-form-element__control">',
							'<div class="slds-input-has-icon slds-input-has-icon_left" style="position: relative;z-index: 9020">',
								'<svg  class="slds-input__icon input-text-default">',
									'<use  xlink:href="" ng-attr-xlink:href="{{\'slds/icons/utility-sprite/svg/symbols.svg#event\' | skedSfUrl}}"></use>',
								'</svg>',
								'<input name="' + properties.name + '" autocomplete="off" class="slds-input" type="text" ui-date="' + properties.dateOptions + '" ng-model="' + properties.model + '" ng-readonly="' + properties.readonly + '" ng-required="' + properties.required + '" ' +((properties.customValidators)?('sked-custom-validators="' + properties.customValidators + '" '):' ') + '/>',
							'</div>',
						'</div>'].join('');
			};

			/**
			 * build month picker input template
			 **/
			var buildMonthPickerTemplate = function (properties) {
				if (!properties.monthOptions) {
					properties.monthOptions = '{}';
				}

				return ['<div class="slds-form-element__control">',
							'<div class="slds-input-has-icon slds-input-has-icon_left" style="position: relative;z-index: 9020">',
								'<svg  class="slds-input__icon input-text-default">',
									'<use  xlink:href="" ng-attr-xlink:href="{{\'slds/icons/utility-sprite/svg/symbols.svg#monthlyview\' | skedSfUrl}}"></use>',
								'</svg>',
								'<input name="' + properties.name + '" class="slds-input" type="text" sked-month-picker="' + properties.monthOptions + '"' + ((properties.onFocus)?(' ng-focus="' + properties.onFocus + '" '):' ') + ' ng-model="' + properties.model + '" ng-readonly="' + properties.readonly + '" ng-required="' + properties.required + '" />',
							'</div>',
						'</div>'].join('');
			};

			/**
			 * build time picker input template
			 **/
			var buildTimePickerTemplate = function (properties) {
				if (!properties.timeOptions) {
					properties.timeOptions = '';
				}

				return ['<div class="slds-form-element__control">',
							'<div class="slds-input-has-icon slds-input-has-icon_left">',
								'<svg  class="slds-input__icon input-text-default">',
									'<use  xlink:href="" ng-attr-xlink:href="{{\'slds/icons/utility-sprite/svg/symbols.svg#clock\' | skedSfUrl}}"></use>',
								'</svg>',
								'<input name="' + properties.name + '" class="slds-input" type="text" sked-time-picker="' + properties.timeOptions + '" ng-model="' + properties.model + '" ng-disabled="' + properties.disabled + '" ng-readonly="' + properties.readonly + '" ' + ((properties.required)?'required="required" ':' ') + ((properties.customValidators)?('sked-custom-validators="' + properties.customValidators + '" '):' ') + ' />',
							'</div>',
						'</div>'].join('');
			};

			/**
			 * build checkbox toggle input template
			 **/
			var buildCheckboxToggleInputTemplate = function (properties) {
				return [
					'<div class="slds-form-element__control">',
						'<span style="display: inline-block; ">',
							'<label class="slds-checkbox_toggle" ' +  (properties.id ? 'for="chk_' + properties.id + '"' : '')+ '>',
								'<input ' +  (properties.id ? 'id="chk_' + properties.id + '"' : '')+ ' type="checkbox" ng-model="' + properties.model + '" ng-disabled="' + properties.disabled + '" ' +( properties.onChange ? 'ng-change="'+properties.onChange+'" ' : '')+ '/>',
								'<span class="slds-checkbox_faux_container" >',
								'<span class="slds-checkbox_faux"></span>',
							'</label>',
						'</span>',
					'</div>'
				].join('');
			};

			return {
				restrict: 'E',
				replace: true,
				template: function ($el, $attr) {
					var template = [];
					var inputType = $attr['type'] || 'text',
						label = $attr['label'],
						model = $attr['model'],
						modelOptions = $attr['modelOptions'],
						id = $attr['id'],
						name = $attr['name'],
						cssClasses = '',
						required = $attr['isRequired'],
						readonly = $attr['isReadonly'] || false,
						disabled = $attr['isDisabled'] || false,
						dateOptions = $attr['dateOptions'], // for date picker
						monthOptions = $attr['monthOptions'], // for month picker
						timeOptions = $attr['timeOptions'], // for time picker
						selectOptions = $attr['selectOptions'], // ng-option for dropdown list
						selectNullOption = $attr['selectNullOption'], // option for null for dropdown list
						pattern = $attr['pattern'],
						onChange = $attr['onChange'],
						onFocus = $attr['onFocus'],
						onBlur = $attr['onBlur'],
						minValue = $attr['minValue'],
						maxValue = $attr['maxValue'],
						rows = $attr['rows'],
						maxLength = $attr['maxLength'],
						icon = $attr['icon'],
						step = $attr['step'],
						formName = $attr['formName'],
						customValidators = $attr['customValidators'];

					var formEls = $el.parents('ng-form, [ng-form]'), 
						formEl;

					var invalidTmpl = '', 
						requiredTmpl = '';

					var inputProperties = {};

					if (!formName && formEls && formEls.length > 0) {
						formEl = angular.element(formEls.get(0));
						formName = formEl.attr((formEl.is('[ng-form]'))?'ng-form':'name');
					}

					if (formName && name) {
						invalidTmpl = 'ng-class="{\'slds-has-error\': ' + formName + '.$submitted && ' + formName + '.' + name + '.$invalid}"';
					}

					if (label && required) {
						requiredTmpl = '<abbr class="slds-required" title="required" ng-if="' + required + '">*</abbr> ';
					}

					template.push('<div class="slds-form-element ' + cssClasses + '" ' + invalidTmpl + '>');
					if (label) { // TODO: should support HTML label
						template.push('<label class="slds-form-element__label" title="' + label + '" for="' + id + '">' + requiredTmpl + label + '</label>');
					}

					inputProperties = {
						name: name,
						model: model,
						modelOptions: modelOptions,
						required: required,
						readonly: readonly,
						disabled: disabled,
						pattern: pattern,
						onChange: onChange,
						onFocus: onFocus,
						onBlur: onBlur,
						minValue: minValue,
						maxValue: maxValue,
						maxLength: maxLength,
						icon: icon,
						step: step,
						customValidators: customValidators
					};

					switch(inputType) {
						case INPUT_TYPE.DATE_PICKER:
							angular.merge(inputProperties, {
								dateOptions: dateOptions
							});

							template.push(buildDatePickerTemplate(inputProperties));
							break;
						case INPUT_TYPE.MONTH_PICKER:
							angular.merge(inputProperties, {
								monthOptions: monthOptions
							});

							template.push(buildMonthPickerTemplate(inputProperties));
							break;
						case INPUT_TYPE.TIME_PICKER:
							angular.merge(inputProperties, {
								timeOptions: timeOptions
							});

							template.push(buildTimePickerTemplate(inputProperties));
							break;
						case INPUT_TYPE.SELECT:
							angular.merge(inputProperties, {
								id: id,
								selectOptions: selectOptions,
								selectNullOption: selectNullOption
							});

							template.push(builDropdownListTemplate(inputProperties));
							break;
						case INPUT_TYPE.TEXTAREA:
							angular.merge(inputProperties, {
								id: id,
								rows: rows
							});

							template.push(buildTextareaInputTemplate(inputProperties));
							break;
						case INPUT_TYPE.CHECKBOX_TOGGLE: 
							angular.merge(inputProperties, {
								id: id
							});
							template.push(buildCheckboxToggleInputTemplate(inputProperties));
							break;
						case INPUT_TYPE.COLOR_PICKER: 
							angular.merge(inputProperties, {
								id: id
							});
							template.push(buildColorPickerTemplate(inputProperties));
							break;
						default:
							angular.merge(inputProperties, {
								id: id,
								type: inputType
							});

							template.push(buildTextInputTemplate(inputProperties))
							break;
					}

					template.push('</div>')

					return template.join('');
				}
			}
		}
	])
})(angular);