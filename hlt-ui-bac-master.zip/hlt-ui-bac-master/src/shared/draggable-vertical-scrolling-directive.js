(function (angular) {
    angular.module('skedApp.shared')
    .directive('skedDraggableVerticalScrolling', [
        '$window',
        '$timeout',
        function($window, $timeout) {
            return function (scope, element, attribute) {
                var syncEl = (attribute.skedDraggableVerticalScrolling)?angular.element(attribute.skedDraggableVerticalScrolling):null;
                var elWindow = angular.element($window);
                var curYPos, curDown;

                if(syncEl) {
                    syncEl.css('cursor', 'move');
                }
                
                var handleScroll = function () {
                    if (syncEl && syncEl.length > 0) {
                        syncEl.scrollTop(this.scrollTop);
                    }
                };

                var handleDrag = function (event, mainEl, attachedEl) {
                    var eventType = event.type;
                    switch (eventType) {
                        case 'mousedown':
                            if (event.which === 1) {
                                curDown = true;
                                curYPos = event.pageY;
                                mainEl.addClass('mouse-down');
                            }
                            break;
                        case 'mousemove':
                            if (curDown === true) {
                                this.scrollTop += (curYPos - event.pageY);
                                curYPos = event.pageY;
                                
                                if (attachedEl && attachedEl.length > 0) {
                                    attachedEl.scrollTop(this.scrollTop);
                                }
                            }
                            break;
                        case 'mouseup':
                            mainEl.removeClass('mouse-down');
                            curDown = false;
                            break;
                    }
                };

                element.on('scroll', handleScroll);

                if (syncEl && syncEl.length > 0) {
                    // syncEl.on('scroll', handleScroll);
                    syncEl.on('mousedown mousemove mouseup', function (event) {
                        handleDrag.call(this, event, syncEl, element);
                    });
                }

                elWindow.on('mouseup', function () {
                    element.removeClass('mouse-down');
                    curDown = false;
                });
            };
        }
    ])
})(angular);