(function (angular) {
    angular.module('hltApp')
    .directive('eventsTimeline', [
        '$timeout',
        '$window',
        '$filter',
        'dateUtil',
        function($timeout, $window, $filter, dateUtil) {
            var dateFilter = $filter('date');
            var MIN_CHUNK_WIDTH = 112; // in pixel, label width (48px + 32px (2rem))

            return {
                restrict: 'E',
                replace: true,
                templateUrl: 'src/app/events-timeline.tpl.html',
                scope: {
                    events: '=',
                    filteredEvents: '=',
                    model: '=',
                    infoPopoverContainer: '@',
                    markerClass: '&',
                    markerStyle: '&'
                },
                link: function ($scope, $el, $attr) {
                    var selecting = false, moving = false, resizing = false;
                    var windowEl = angular.element($window);
                    var timelineSelectionEl, timelineSelectionLeftEgdeEl, timelineSelectionRightEgdeEl;

                    var elOffset = $el.offset(), 
                        elWidth = $el.width();
                    var startPosition, endPosition;
                    var clickingPoint, mousePointerDistance, resizingEl;

                    var CHUNK_MODE = {
                        HOUR: {
                            labelFormat: 'hh:mm a',
                            threadhold: 86400000, // 1 hour - 24 hours
                            unitTimeValue: 3600000,
                            increasor: function (refDateTime, increasingStep) {
                                refDateTime.setHours(refDateTime.getHours() + increasingStep);
                            }
                        },
                        DAY: {
                            labelFormat: 'MMM dd',
                            threadhold: 1209600000, // 1 day - 14 days
                            unitTimeValue: 86400000,
                            increasor: function (refDateTime, increasingStep) {
                                refDateTime.setDate(refDateTime.getDate() + increasingStep);
                            }
                        },
                        WEEK: {
                            labelFormat: 'MMM dd',
                            threadhold: 5356800000, // 14 days - 62 days (2 months)
                            unitTimeValue: 604800000,
                            increasor: function (refDateTime, increasingStep) {
                                refDateTime.setDate(refDateTime.getDate() + (increasingStep * 7));
                            }
                        },
                        MONTH: {
                            labelFormat: 'MMM yyyy',
                            threadhold: 31622400000,  // 62 days (2 months) - 366 days (1 year)
                            unitTimeValue: 2678400000, // 31 days (1 month)
                            increasor: function (refDateTime, increasingStep) {
                                refDateTime.setMonth(refDateTime.getMonth() + increasingStep);
                            }
                        },
                        QUARTER: {
                            labelFormat: 'MMM yyyy',
                            threadhold: 63244800000,  // 366 days (1 year) - 732 days (2 years),
                            unitTimeValue: 8035200000, // 93 days (3 months)
                            increasor: function (refDateTime, increasingStep) {
                                refDateTime.setMonth(refDateTime.getMonth() + (increasingStep * 3));
                            }
                        },
                        YEAR: {
                            labelFormat: 'MMM yyyy',
                            threadhold: -1,
                            unitTimeValue: 31622400000, // 366 days (1 year)
                            increasor: function (refDateTime, increasingStep) {
                                refDateTime.setFullYear(refDateTime.getFullYear() + increasingStep);
                            }
                        }
                    };

                    var pauseEvent = function (event) {
                        if(event.stopPropagation) {
                            event.stopPropagation();
                        }
                        if(event.preventDefault) {
                            event.preventDefault();
                        }

                        event.cancelBubble = true;
                        event.returnValue = false;

                        return false;
                    };

                    var setSelectionArea = function () {
                        if (!timelineSelectionEl) {
                            timelineSelectionEl = angular.element('<div class="selection-area" ></div>');
                            timelineSelectionEl.appendTo($el);

                            timelineSelectionEl.on('mousedown', handleTimelineSelectionMouseDown);
                        }

                        timelineSelectionEl.css({
                            left: startPosition,
                            width: Math.abs(endPosition - startPosition)
                        });
                    };

                    var destroySelectionArea = function () {
                        if (timelineSelectionEl) {
                            timelineSelectionEl.off('mousedown', handleTimelineSelectionMouseDown);
                            timelineSelectionEl.remove();
                            timelineSelectionEl = null;
                        }
                    };

                    var setSelectionLeftEdge = function () {
                        if (!timelineSelectionLeftEgdeEl) {
                            timelineSelectionLeftEgdeEl = angular.element('<div class="selection-edge left-edge" ></div>');
                            timelineSelectionLeftEgdeEl.appendTo($el);

                            timelineSelectionLeftEgdeEl.on('mousedown', handleTimelineEgdeMouseDown);
                        }

                        timelineSelectionLeftEgdeEl.css({
                            left: startPosition
                        });
                    };

                    var destroySelectionLeftEdge = function () {
                        if (timelineSelectionLeftEgdeEl) {
                            timelineSelectionLeftEgdeEl.off('mousedown', handleTimelineEgdeMouseDown);
                            timelineSelectionLeftEgdeEl.remove();
                            timelineSelectionLeftEgdeEl = null;
                        }
                    };

                    var setSelectionRightEdge = function () {
                        if (!timelineSelectionRightEgdeEl) {
                            timelineSelectionRightEgdeEl = angular.element('<div class="selection-edge right-edge" ></div>');
                            timelineSelectionRightEgdeEl.appendTo($el);

                            timelineSelectionRightEgdeEl.on('mousedown', handleTimelineEgdeMouseDown);
                        }

                        timelineSelectionRightEgdeEl.css({
                            left: endPosition
                        });
                    };

                    var destroySelectionRightEdge = function () {
                        if (timelineSelectionRightEgdeEl) {
                            timelineSelectionRightEgdeEl.off('mousedown', handleTimelineEgdeMouseDown);
                            timelineSelectionRightEgdeEl.remove();
                            timelineSelectionRightEgdeEl = null;
                        }
                    };

                    var handleWindowResize = function (event) {
                        $scope.$apply(function () {
                            elOffset = $el.offset();
                            elWidth = $el.width();

                            processEventsTimeLine();
                        })
                    }

                    var identifyThreadHolds = function (chunkMode, startDateTime, endDateTime, increasingStep) {
                        var threadholds = [], tmpDateTime;
                        var startDate, endDate;
                        //var maxChunks, increasingStep, timeInterval;

                        if (chunkMode) {
                            //timeInterval = endDateTime - startDateTime;

                            for (tmpDateTime = new Date(startDateTime); tmpDateTime.getTime() < (endDateTime - ((increasingStep / 1.5) * chunkMode.unitTimeValue)); chunkMode.increasor(tmpDateTime, increasingStep)) {
                                if (tmpDateTime.getTime() > startDateTime) {
                                    threadholds.push({
                                        dateValue: angular.copy(tmpDateTime),
                                        label: dateFilter(tmpDateTime, chunkMode.labelFormat)
                                    });
                                }
                            }

                            // start point
                            startDate = new Date(startDateTime);
                            threadholds.push({
                                isStart: true,
                                dateValue: startDate,
                                label: dateFilter(startDate, chunkMode.labelFormat)
                            });

                            // end point
                            endDate = new Date(endDateTime);
                            threadholds.push({
                                isEnd: true,
                                dateValue: endDate,
                                label: dateFilter(endDate, chunkMode.labelFormat)
                            });
                        }

                        return threadholds;
                    };

                    var identifyChunkMode = function (startDateTime, endDateTime) {
                        var chunkMode = null,
                            timeInterval = endDateTime - startDateTime;
                        var stopFinding = false;

                        if (timeInterval > 0) {
                            // identify chunk mode
                            angular.forEach(CHUNK_MODE, function (tmpChunkMode) {
                                if (!stopFinding) {
                                    if (timeInterval <= tmpChunkMode.threadhold || tmpChunkMode.threadhold === -1) {
                                        chunkMode = tmpChunkMode;
                                        stopFinding = true;
                                    }
                                }
                            });
                        }

                        return chunkMode;
                    }

                    var processEventsTimeLine = function () {
                        var events, markers = [];
                        var firstEvent, lastEvent, 
                            startDateTime, endDateTime, timeInterval;

                        var chunkMode, threadholds, markers;
                        var maxChunks, increasingStep;

                        if (angular.isArray($scope.events) && $scope.events.length > 0) {
                            // sort events by date times
                            events = angular.extend([], $scope.events);
                            events.sort(function (event1, event2) {
                                return (event1.startDate.getTime() + event1.startTime) - (event2.startDate.getTime() + event2.startTime);
                            });

                            firstEvent = events[0];
                            lastEvent = events[events.length - 1];

                            startDateTime = dateUtil.parseDateTime(firstEvent.startDate, firstEvent.startTime);
                            endDateTime = dateUtil.parseDateTime(lastEvent.startDate, lastEvent.startTime);
                            
                            startDateTime = startDateTime.getTime();
                            endDateTime = endDateTime.getTime();

                            chunkMode = identifyChunkMode(startDateTime, endDateTime);
                            if (chunkMode) {
                                timeInterval = endDateTime - startDateTime;
                                maxChunks = Math.floor(elWidth / MIN_CHUNK_WIDTH);
                                increasingStep = Math.ceil(Math.floor(timeInterval / maxChunks) / chunkMode.unitTimeValue);

                                startDateTime -= ((increasingStep / 2) * chunkMode.unitTimeValue);
                                endDateTime += ((increasingStep / 2) * chunkMode.unitTimeValue);

                                threadholds = identifyThreadHolds(chunkMode, startDateTime, endDateTime, increasingStep);
                            }

                            // produce event markers
                            markers = produceEventMarkers($scope.events);
                        }

                        $scope.eventsTimeLine = {
                            startDateTime: startDateTime,
                            endDateTime: endDateTime,
                            chunkMode: chunkMode,
                            threadholds: threadholds,
                            markers: markers
                        };
                    }

                    var produceEventMarkers = function (events) {
                        var markers = [], 
                            marker;

                        angular.forEach(events, function (event) {
                            marker = {
                                data: event,
                                cssClasses: null,
                                cssStyles: null
                            };

                            // css classes
                            if (angular.isFunction($scope.markerClass)) {
                                marker.cssClasses = $scope.markerClass({event: event});
                            }

                            // css styles
                            if (angular.isFunction($scope.markerStyle)) {
                                marker.cssStyles = $scope.markerStyle({event: event});
                            }

                            markers.push(marker);
                        });

                        return markers;
                    };

                    var calculateDateTimeFromPosition = function (position) {
                        var timeInterval, timeValuePerPixel;
                        var rs = null;

                        if ($scope.eventsTimeLine) {
                            timeInterval = $scope.eventsTimeLine.endDateTime - $scope.eventsTimeLine.startDateTime;
                            timeValuePerPixel = Math.round(timeInterval / elWidth);

                            rs = new Date((position * timeValuePerPixel) + $scope.eventsTimeLine.startDateTime);
                        }

                        return rs;
                    };

                    var calculatePositionFromDateTime = function (dateValue, timeValue) {
                        var timeInterval, timeValuePerPixel;
                        var rs = null;
                        var dateTimeValue;

                        if (timeValue >= 0) {
                            dateTimeValue = dateUtil.parseDateTime(dateValue, timeValue);
                        } else {
                            dateTimeValue = dateUtil.parseDateString(dateValue);
                        }

                        if ($scope.eventsTimeLine && angular.isDate(dateTimeValue)) {
                            timeInterval = $scope.eventsTimeLine.endDateTime - $scope.eventsTimeLine.startDateTime;
                            timeValuePerPixel = Math.round(timeInterval / elWidth);

                            rs = Math.floor((dateTimeValue.getTime() - $scope.eventsTimeLine.startDateTime) / timeValuePerPixel);
                        }

                        return rs;
                    };

                    var produceEventMarkerStyles = function (marker) {
                        return angular.merge(marker.cssStyles || {}, 
                            {left: calculatePositionFromDateTime(marker.data.startDate, marker.data.startTime)});
                    };

                    var handleTimelineSelectionMouseDown = function (event) {
                        pauseEvent(event);
                        if (event.which === 1) {
                            moving = true;
                            clickingPoint = event.originalEvent.pageX - elOffset.left ;
                            mousePointerDistance = clickingPoint - timelineSelectionEl.position().left;

                            windowEl.on('mousemove', handleMouseMove);
                            windowEl.on('mouseup', handleMouseUp);
                        }
                    };

                    var handleTimelineEgdeMouseDown = function (event) {
                        var eventTarget;
                        
                        pauseEvent(event);
                        if (event.which === 1) {
                            eventTarget = event.target;

                            if (eventTarget === timelineSelectionLeftEgdeEl[0]) {
                                resizingEl = timelineSelectionLeftEgdeEl;
                                clickingPoint = endPosition;
                            } else if (eventTarget === timelineSelectionRightEgdeEl[0]) {
                                resizingEl = timelineSelectionRightEgdeEl;
                                clickingPoint = startPosition;
                            }

                            if (resizingEl) {
                                resizing = true;
                                
                                windowEl.on('mousemove', handleMouseMove);
                                windowEl.on('mouseup', handleMouseUp);
                            }
                        }
                    }

                    var handleMouseDown = function (event) {
                        if (event.which === 1) {

                            selecting = true;
                            clickingPoint = event.originalEvent.pageX - elOffset.left ;

                            if (clickingPoint < 0) {
                                clickingPoint = 0;
                            }

                            endPosition = startPosition = clickingPoint;
                            
                            destroySelectionLeftEdge();
                            destroySelectionRightEdge();
                            destroySelectionArea();

                            windowEl.on('mousemove', handleMouseMove);
                            windowEl.on('mouseup', handleMouseUp);
                        }
                    };

                    var handleMouseUp = function (event) {
                        var clonedSelectionEl;
                        if (selecting || moving || resizing) {
                            $scope.$apply(function () {
                                if (!$scope.model) {
                                    $scope.model = {
                                        start: null,
                                        end: null
                                    }
                                }

                                if (endPosition === startPosition) {
                                    destroySelectionLeftEdge();
                                    destroySelectionRightEdge();
                                    destroySelectionArea();
                                    $scope.model.start = null;
                                    $scope.model.end = null;
                                } else {
                                    $scope.model.start = calculateDateTimeFromPosition(startPosition);
                                    $scope.model.end = calculateDateTimeFromPosition(endPosition);
                                }
                            });

                            cleanupAllStates();
                        }
                    };

                    var handleMouseMove = function (event) {
                        var selectionElWidth, mousePosition;
                        var selectionAreaWidth, selectionAreaLeft;

                        pauseEvent(event);
                        mousePosition = event.originalEvent.pageX - elOffset.left ;

                        if (selecting || resizing) {
                            if (mousePosition < 0) {
                                mousePosition = 0;
                            } else if (mousePosition > elWidth) {
                                mousePosition = elWidth
                            }

                            if (mousePosition >= clickingPoint) {
                                startPosition = clickingPoint;
                                endPosition = mousePosition;
                            } else {
                                startPosition = mousePosition;
                                endPosition = clickingPoint;
                            }

                            setSelectionLeftEdge();
                            setSelectionRightEdge();
                            setSelectionArea();
                        } else if (moving && timelineSelectionEl) {
                            selectionAreaWidth = timelineSelectionEl.width();
                            
                            selectionAreaLeft = mousePosition - mousePointerDistance;

                            if (selectionAreaLeft + selectionAreaWidth > elWidth) {
                                selectionAreaLeft = elWidth - selectionAreaWidth;
                            } else if (selectionAreaLeft <= 0) {
                                selectionAreaLeft = 0;
                            }

                            startPosition = selectionAreaLeft;
                            endPosition = startPosition + selectionAreaWidth;

                            timelineSelectionEl.css({
                                left: startPosition
                            });
                            //setSelectionArea();
                            setSelectionLeftEdge();
                            setSelectionRightEdge();
                        }
                    };

                    var cleanupAllStates = function () {
                        selecting = false;
                        moving = false;
                        resizing = false;

                        windowEl.off('mousemove', handleMouseMove);
                        windowEl.off('mouseup', handleMouseUp);

                        clickingPoint = null;
                        mousePointerDistance = null;
                        resizingEl = null;
                    };

                    $el.on('mousedown', handleMouseDown);
                    windowEl.on('resize', handleWindowResize);

                    $scope.$on('$destroy', function () {
                        if (windowEl) {
                            windowEl.off('resize', handleWindowResize);
                            windowEl.off('mousemove', handleMouseMove);
                            windowEl.off('mouseup', handleMouseUp);
                        }
                    });

                    $timeout(function () {
                        windowEl.trigger('resize');
                    }, 0);

                    $scope.$watchCollection('events', processEventsTimeLine);

                    $scope.eventsTimeLine = null;
                    $scope.isEventInfoPopoverShow = $scope.$eval($attr.showEventInfo);
                    if ($scope.isEventInfoPopoverShow) {
                        $scope.eventInfoPopover = {
                            template: $attr.eventInfoTemplate
                        }
                    }

                    $scope.calculateDateTimeFromPosition = calculateDateTimeFromPosition;
                    $scope.calculatePositionFromDateTime = calculatePositionFromDateTime;
                    $scope.produceEventMarkerStyles = produceEventMarkerStyles;
                }
            };
        }
    ])
})(angular);