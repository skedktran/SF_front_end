(function (angular) {
    angular.module('hltApp')
    .filter('hcoShortTimeName', [
        function() {
            return function (timeValue) {
                var tsH, tsN;
                var tsHN, tsMN, tsAP;
                var tsSurplus, tsAbsolute;

                if (angular.isNumber(timeValue)) {
                    tsH = Math.floor(timeValue / 100);
                    tsM = Math.round(timeValue % 100);

                    // hour name
                    tsSurplus = tsH % 12;
                    tsAbsolute = Math.floor(tsH / 12);
                    if (tsSurplus === 0) {
                        tsHN = '12';
                    } else {
                        //tsHN = ('00' + tsSurplus).substr(-2);
                        tsHN = tsSurplus;
                    }
                    tsAP = (tsAbsolute % 2 === 1)?'pm':'am';

                    // minute name
                    tsMN = ('00' + tsM).substr(-2);

                    return tsHN + ((tsMN !== '00')?(':' + tsMN):'') + tsAP;
                }

                return '';
            };
        }
    ])
})(angular);