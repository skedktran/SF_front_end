(function (angular, moment) {
    angular.module('hltApp')
    .component('pstCalendarChart', {
        templateUrl: 'src/app/patient-scheduling-timeline/pst-calendar-chart.tpl.html',
        bindings: {
            startDate: '<',
            endDate: '<',
            dateSlots: '<'
        },
        controller: [
            '$timeout',
            '$scope',
            '$filter',
            'util',
            'dateUtil',
            '$element',
            function ($timeout, $scope, $filter, util, dateUtil, $element) {
                var $ctrl = this;
                var filterFn = $filter('filter');

                var currentParams = {
                    startDate: null,
                    endDate: null,
                    dateSlots: []
                };

                var isParamsReallyChanged = function (params) {
                    return !util.compareValues(params, currentParams);
                };

                var buildChartParams = function () {
                    return {
                        startDate: dateUtil.parseDateString($ctrl.startDate),
                        endDate: dateUtil.parseDateString($ctrl.endDate),
                        dateSlots: $ctrl.dateSlots || []
                    }
                };

                var buildChart = function () {
                    var params = buildChartParams();

                    if (isParamsReallyChanged(params)) {
                        currentParams = params;

                        $ctrl.chartData = processChartData(currentParams);
                        renderChart($ctrl.chartData);
                    }
                };

                var processChartData = function (chartParams) {
                    var chartData = [];

                    if (angular.isArray(chartParams.dateSlots)) {
                        angular.forEach(chartParams.dateSlots, function (dateSlot) {
                            chartData.push({
                                c: [
                                    {v: dateUtil.parseDateString(dateSlot.dateString)},
                                    {v: 1}
                                ]
                            });
                        });
                    }

                    return chartData;
                };

                var renderChart = function (chartData) {
                    $scope.myChartObject = {};
                    $scope.myChartObject.type = "Calendar";

                    $scope.myChartObject.options = {
                        height: 90,
                        tooltip: {
                            trigger: 'none'
                        },
                        legend: 'none',
                        colorAxis: {
                            display: false,
                            values: [0, 1],
                            colors: ['#f3f2f2', '#0070d2']
                        },
                        noDataPattern: {
                           backgroundColor: '#f3f2f2',
                           color: '#f3f2f2'
                        },
                        calendar: { 
                            yearLabel: {
                                fontSize: 1,
                                width: 0,
                                color: '#fff'
                            },
                            title: {
                                fontSize: 1,
                                width: 0,
                                height: 0,
                                color: '#fff'
                            },
                            cellSize: 7.5,
                            focusedCellColor: {
                                strokeOpacity: 0.4,
                                strokeWidth: 1
                            },
                            monthOutlineColor: {
                                stroke: '#d8dde6'
                            },
                            unusedMonthOutlineColor: {
                                stroke: '#d8dde6'
                            }
                        }
                    };

                    $scope.myChartObject.data = {
                        cols: [
                            { type: 'date', id: 'Date' },
                            { type: 'number', id: 'Won/Loss' }
                        ],
                        rows: chartData
                    };
                };

                var handelChartReady = function (chartWrapper) {
                    var chartCanvas = $element.find('div[dir=ltr]>div');

                    if (chartCanvas) {
                        chartCanvas.css('top', '-1.125rem')
                    }
                };

                /**
                 * scope init
                 */
                (function init() {
                    $ctrl.chartData = [];

                    $ctrl.handelChartReady = handelChartReady;

                    $scope.$watchGroup([
                        '$ctrl.startDate',
                        '$ctrl.endDate',
                        '$ctrl.dateSlots',
                    ], function (newVal) {
                        if ($ctrl.startDate && $ctrl.endDate && $ctrl.dateSlots) {
                            buildChart();
                        }
                    });
                })();
            }
        ]
    });
})(angular, moment);