(function (angular, d3) {
    angular.module('hltApp')
    .component('pstD3CalendarChart', {
        templateUrl: 'src/app/patient-scheduling-timeline/pst-d3-calendar-chart.tpl.html',
        bindings: {
            chartOptions: '<?',
            chartData: '=',
        },
        controller: [
            '$scope',
            '$filter',
            '$window',
            '$element',
            'dateUtil',
            function ($scope, $filter, $window, $element, dateUtil) {
                var $ctrl = this;
                var windowEl = angular.element($window);
                var dateFilter = $filter('date');
                var chartOptions = {};
                var WEEK_DAY = {
                    SUNDAY: 0,
                    MONDAY: 1
                };
                var COLOR = {
                    WHITE: '#fff',
                    BLACK: '#c9c7c5',
                    BLUE: '#3c97dd',
                    GRAY: '#e8e8e8'
                };
                var FONT_CELL_PERCENTAGE = 80;
                var NUMBER_OF_WEEKS_IN_YEAR = 55,
                    DEFAULT_WEEK_DAY = WEEK_DAY.SUNDAY,
                    DEFAULT_CELL_SIZE = 12,
                    DEFATUL_DATE_FORMAT = 'EEE, MMM dd yyyy';

                var timeWeek;
                var format = d3.format('+.2%');
                var formatDay = function (day) {
                    return 'SMTWTFS'[(day + chartOptions.firstDay) % 7];
                }
                var formatMonth = d3.timeFormat('%b');
                var isSunday = function () {
                    return chartOptions.firstDay === WEEK_DAY.SUNDAY
                };

                var getFontSize = function () {
                    return chartOptions.fontSize || Math.ceil((chartOptions.cellSize * (chartOptions.fontPercentage || FONT_CELL_PERCENTAGE)) / 100);
                };

                var getCellColor = function (date, dataArray) {
                    return (dataArray.indexOf(dateUtil.dateToString(date)) > -1)?COLOR.BLUE:COLOR.GRAY;
                };

                var calculateChartWidth = function (options) {
                    return (options.cellSize || DEFAULT_CELL_SIZE) * NUMBER_OF_WEEKS_IN_YEAR;
                };

                var calculateChartHeight = function (options) {
                    return (options.cellSize || DEFAULT_CELL_SIZE) * 9;
                }

                // get week day
                var countDay = function (date) {
                    return isSunday()?date.getDay():((date.getDay() + 6) % 7);
                };

                // draw a path of month
                var pathMonth = function (date, numberOfWeeks) {
                    var numberOfWeekDays = 7,
                        weekdayPosition = Math.max(0, Math.min(numberOfWeekDays, countDay(date)));

                    return ((weekdayPosition === 0)?('M' + (numberOfWeeks * chartOptions.cellSize) + ',0'):
                                    ((weekdayPosition === numberOfWeekDays)?('M' + ((numberOfWeeks + 1) * chartOptions.cellSize) + ',0'):
                                        ('M' + ((numberOfWeeks + 1) * chartOptions.cellSize) + ',0V' + (weekdayPosition * chartOptions.cellSize) + 'H' + (numberOfWeeks * chartOptions.cellSize)))) +
                        'V' + (numberOfWeekDays * chartOptions.cellSize);
                };

                var getChartOptions = function () {
                    var options = angular.extend(chartOptions, {
                        firstDay: DEFAULT_WEEK_DAY,
                        cellSize: DEFAULT_CELL_SIZE,
                        width: calculateChartWidth($ctrl.chartOptions || {}), //DEFAULT_CHART_WIDTH,
                        height: calculateChartHeight($ctrl.chartOptions || {}), //DEFAULT_CHART_HEIGHT,
                        dateFormat: DEFATUL_DATE_FORMAT
                    }, $ctrl.chartOptions);

                    if (!options.cellSize) {
                        options.cellSize = DEFAULT_CELL_SIZE;
                    }

                    return options;
                };

                var drawChart = function () {
                    var chartContainer = d3.select($element.find('.calendar-chart-container')[0]);
                    var svg = chartContainer.append('svg')
                        .style('font-size', getFontSize() + 'px')
                        .style('width', '100%')
                        .style('height', 'auto')
                        .style('overflow', 'visible');

                    var mainGroup = svg.append('g')
                        .attr('transform', 'translate(' + (chartOptions.cellSize * 1.5) + ', ' +  (chartOptions.cellSize * 1.5) + ')');
                    var monthsGroup, daysGroup;
                    
                    var dataArray = $ctrl.chartData.dateSlots.map(function (dateSlot) {
                        return dateSlot.dateString;
                    });
                    var startDate = dateUtil.parseDateString($ctrl.chartData.startDate),
                        endDate = dateUtil.parseDateString($ctrl.chartData.endDate);

                    timeWeek = isSunday()?d3.timeSunday:d3.timeMonday;

                    // week days
                    mainGroup.append('g')
                        .attr('text-anchor', 'middle')
                        .selectAll('text')
                        .data(d3.range(7))
                        .enter().append('text')
                        .attr('x', -(chartOptions.cellSize * 0.75))
                        .attr('y', function (day) {
                            return (day + 0.6) * chartOptions.cellSize
                        })
                        .attr('dy', '0.3em')
                        .text(formatDay);

                    // day groups
                    daysGroup = mainGroup.append('g')
                        .selectAll('rect')
                        //.data(chartData)
                        .data(d3.timeDays(d3.timeMonth.floor(startDate), d3.timeMonth.ceil(endDate)))
                        .enter().append('rect')
                        .attr('width', chartOptions.cellSize - 1)
                        .attr('height', chartOptions.cellSize - 1)
                        .attr('x', function (date) {
                            return timeWeek.count(d3.timeMonth(startDate), date) * chartOptions.cellSize + 0.5
                        })
                        .attr('y', function (date) {
                            return countDay(date) * chartOptions.cellSize + 0.5
                        })
                        .attr('fill', function (date) {
                            return getCellColor(date, dataArray);
                        })
                        .append('title')
                        .text(function (date) {
                            return dateFilter(date, chartOptions.dateFormat);
                        });

                    // month groups
                    monthsGroup = mainGroup.append('g')
                        .selectAll('g')
                        .data(d3.timeMonths(d3.timeMonth(startDate), endDate))
                        .enter().append('g');
                    
                    monthsGroup.filter(function (date, index) {
                            return index;
                        })
                        .append('path')
                        .attr('fill', 'none')
                        .attr('stroke', COLOR.BLACK)
                        .attr('stroke-width', 2)
                        .attr('d', function (date) {
                            return pathMonth(date, timeWeek.count(d3.timeMonth(startDate), date))
                        });

                    monthsGroup.append('text')
                        .style('font-size', '1.0625em')
                        .attr('x', function (date) {
                            return timeWeek.count(d3.timeMonth(startDate), timeWeek.ceil(date)) * chartOptions.cellSize + 2
                        })
                        .attr('y', '-0.625em')
                        .text(formatMonth);


                    transformChart(chartContainer);
                };

                var transformChart = function (chartContainer) {
                    var elWidth = $element.width(),
                        scalingRatio = elWidth / chartOptions.width;
                    if (scalingRatio > 1) {
                        scalingRatio = 1;
                    }

                    chartContainer.style('transform', 'scale(' + scalingRatio + ')');
                    chartContainer.style('transform-origin', 'top left');
                    chartContainer.style('height', (chartOptions.height * scalingRatio) + 'px');
                    //chartContainer.style('height', chartOptions.height + 'px');
                    chartContainer.style('width', chartOptions.width + 'px');
                };

                var handleWindowResize = function () {
                    var chartContainer;
                    if ($ctrl.chartData) {
                        chartContainer = d3.select($element.find('.calendar-chart-container')[0]);
                        transformChart(chartContainer);
                    }
                };

                var eraseChart = function () {
                    var chartContainer = d3.select($element.find('.calendar-chart-container')[0]);

                    if (chartContainer) {
                        chartContainer.selectAll('*').remove();
                    }
                };

                $ctrl.$onInit = function () {
                    chartOptions = getChartOptions();
                };

                /**
                 * scope init
                 */
                (function init() {
                    $scope.$watch('$ctrl.chartData', function (newVal, oldaVal) {
                        eraseChart();
                        drawChart();
                    }, true);

                    windowEl.on('resize', handleWindowResize);
                })();
            }
        ]
    });
})(angular, d3);