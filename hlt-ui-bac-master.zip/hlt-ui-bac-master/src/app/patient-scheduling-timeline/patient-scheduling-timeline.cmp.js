(function (angular, sforce) {
    angular.module('hltApp')
    .component('patientSchedulingTimeline', {
        templateUrl: 'src/app/patient-scheduling-timeline/patient-scheduling-timeline.tpl.html',
        bindings: {
            patientId: '<'
        },
        controller: [
            '$timeout',
            '$location',
            '$q',
            '$scope',
            '$filter',
            'util',
            'dateUtil',
            'api',
            'constants',
            'model',
            function ($timeout, $location, $q, $scope, $filter, util, dateUtil, api, constants, model) {
                var $ctrl = this;
                var filterFn = $filter('filter')
                var searchParams = $location.search();
                var DEFAULT_PHOTO_URL = $filter('skedSfUrl')(constants.DEFAULT_AVATAR_URL);

                var PST_REQUIRED_CONFIG_DATA = [
                    'jobTypes',
                    'eventTypeSettings'
                ];

                var commonExceptionHanlder = function (exception) {
                    util.toastError('Can not perform action due to server error.');

                    return $q.reject(exception);
                };

                var showLoading = function () {
                    util.showLoading();
                };

                var hideLoading = function () {
                    util.hideLoading();
                };

                var doInitialize = function (requestParams) {
                    return api.initialize(requestParams)
                        .catch(commonExceptionHanlder);
                };

                var doGetPatientInfo = function (requestParams) {
                    return api.getPatientInfo(requestParams)
                        .catch(commonExceptionHanlder);
                };

                var getInitialData = function () {
                    var requestParams = {
                        recordId: $ctrl.patientId,
                        configKeys: PST_REQUIRED_CONFIG_DATA
                    };

                    return doInitialize(requestParams)
                        .then(function (result) {
                            if (result.success) {
                                $ctrl.configData = model.ConfigDataModel.fromServer(result.data);

                                if (result.data.patient && result.data.patient.otherFields) {
                                    $ctrl.patientInfoFields = result.data.patient.otherFields;
                                }

                                return $ctrl.configData;
                            } else {
                                return $q.reject(result);
                            }
                        });
                };

                var fetchTabData = function (tab) {
                    if (tab && angular.isArray(tab.patientInfoList)) {
                        showLoading();
                        doGetPatientInfo({
                            recordId: $ctrl.patientId,
                            patientInfoList: tab.patientInfoList
                        })
                        .then(function (result) {
                            if (result.success) {
                                $ctrl.patientInfo = result.data;
                            } else {
                                return $q.reject(result);
                            }
                        })
                        .catch(function (exception) {
                            console.error(exception);
                            if (exception && exception.errorMessage) {
                                util.toastError(exception.errorMessage);
                            }
                        })
                        .finally(hideLoading);
                    }
                };

                var selectTab = function (tab) {
                    if ($ctrl.selectedTab !== tab) {
                        $ctrl.selectedTab = tab;

                        fetchTabData($ctrl.selectedTab);
                    }
                };

                var refreshCurrentTab = function () {
                    fetchTabData($ctrl.selectedTab);
                };

                var openHealthCloudSubTab = function (urlOrRecordId, activate, label, name) {
                    console.log(urlOrRecordId);

                    if (sforce && sforce.console) {
                        sforce.console.getEnclosingPrimaryTabId(function (primaryTab) {
                            sforce.console.openSubtab(primaryTab.id, urlOrRecordId, activate, label, null, angular.noop, name);
                        });
                    }
                };

                /**
                 * controller init
                 */
                $ctrl.$onInit = function () {
                    showLoading();

                    getInitialData()
                        .then(function () {
                            if ($ctrl.configData) {
                                if (angular.isArray($ctrl.configData.patientProfileTabs) &&
                                    $ctrl.configData.patientProfileTabs.length > 0) {
                                    selectTab($ctrl.configData.patientProfileTabs[0]);
                                }
                            }
                        })
                        .catch(function (exception) {
                            console.error(exception);
                            if (exception && exception.errorMessage) {
                                util.toastError(exception.errorMessage);
                            }
                        })
                        .finally(hideLoading);
                };

                /**
                 * scope init
                 */
                (function init() {
                    $scope.DEFAULT_PHOTO_URL = DEFAULT_PHOTO_URL;

                    $ctrl.selectedTab = null;
                    $ctrl.configData = null;
                    $ctrl.patientInfo = {};

                    $ctrl.refreshCurrentTab = refreshCurrentTab;
                    $ctrl.selectTab = selectTab;

                    $ctrl.openHealthCloudSubTab = openHealthCloudSubTab;

                    $scope.$on('hco:pst:refreshTab', refreshCurrentTab);
                })();
            }
        ]
    });
})(angular, window.sforce);