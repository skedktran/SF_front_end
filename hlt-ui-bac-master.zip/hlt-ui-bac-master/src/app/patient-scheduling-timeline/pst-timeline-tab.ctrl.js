(function (angular) {
    angular.module('hltApp')
    .controller('PstTimelineTabController', [
        '$scope',
        '$filter',
        'dateUtil',
        'model',
        function ($scope, $filter, dateUtil, model) {
            var SINGLE_JOB_SCHEDULE_OPTION = {
                id: '',
                name: 'Single Jobs' 
            };
            var DEFAULT_PHOTO_URL = $filter('skedSfUrl')('slds/images/avatar3.jpg');
            var WEEK_DAYS = [
                {
                    label: 'Sunday',
                    value: 'sun',
                    numVal: 0
                },
                {
                    label: 'Monday',
                    value: 'mon',
                    numVal: 1
                },
                {
                    label: 'Tuesday',
                    value: 'tue',
                    numVal: 2
                },
                {
                    label: 'Wednesday',
                    value: 'wed',
                    numVal: 3
                },
                {
                    label: 'Thursday',
                    value: 'thu',
                    numVal: 4
                },
                {
                    label: 'Friday',
                    value: 'fri',
                    numVal: 5
                },
                {
                    label: 'Saturday',
                    value: 'sat',
                    numVal: 6
                }
            ];

            var getArray = function (len) {
                len = len || 0;
                if (len < 0) {
                    len = 0;
                }
                return new Array(len);
            };

            var applyJobsFilters = function () {
                var jobNameFilter, eventTypesFilter, weekdayFilters, scheduleFilters;
                var filteringJobsList;

                if ($scope.timelineData && 
                    angular.isArray($scope.timelineData.jobs) &&
                    $scope.timelineData.jobs.length > 0) {
                    
                    filteringJobsList = $scope.timelineData.jobs;

                    // prepare the filters
                    jobNameFilter = $scope.jobsFilters.name.toLowerCase();
                    eventTypesFilter = $scope.jobsFilters.eventTypes.map(function (eventType) {
                        return eventType.id;
                    });
                    
                    weekdayFilters = $scope.jobsFilters.weekdays.map(function (weekday) {
                        return weekday.numVal;
                    });
                    scheduleFilters = $scope.jobsFilters.schedules.map(function (schedule) {
                        return schedule.id;
                    });

                    $scope.filteredJobsWithoutTimeRange = filteringJobsList.filter(function (job) {
                        var jobName = (job.name || '').toLowerCase();

                        return jobName.indexOf(jobNameFilter) > -1 &&
                            eventTypesFilter.indexOf(job.eventType.id) > -1 &&
                            scheduleFilters.indexOf(job.scheduleId || '') > -1 &&
                            weekdayFilters.indexOf(job.startDate.getDay()) > -1;
                    });
                    $scope.filteredJobs = $scope.filteredJobsWithoutTimeRange.filter(function (job) {
                        var jobStartDateTime = dateUtil.parseDateTime(job.startDate, job.startTime).getTime();

                        return (!angular.isDate($scope.jobsFilters.timeRange.start) || jobStartDateTime >= $scope.jobsFilters.timeRange.start.getTime()) &&
                            (!angular.isDate($scope.jobsFilters.timeRange.end) || jobStartDateTime <= $scope.jobsFilters.timeRange.end.getTime())
                    });
                } else {
                    $scope.filteredJobsWithoutTimeRange = [];
                    $scope.filteredJobs = [];
                }
            };

            (function init() {
                $scope.SINGLE_JOB_SCHEDULE_OPTION = SINGLE_JOB_SCHEDULE_OPTION;
                $scope.WEEK_DAYS = WEEK_DAYS;
                $scope.DEFAULT_PHOTO_URL = DEFAULT_PHOTO_URL;

                $scope.filteredJobs = [];
                $scope.jobsFilters = {
                    eventTypes: [],
                    schedules: [],
                    weekdays: angular.extend([], WEEK_DAYS),
                    name: '',
                    timeRange: {
                        start: null,
                        end: null
                    }
                };

                $scope.getArray = getArray;

                $scope.$watch('$ctrl.patientInfo.timeline', function (timeline) {
                    $scope.timelineData = {
                        jobs: [],
                        schedules: []
                    };

                    if (timeline) {
                        if (angular.isArray(timeline.schedules)) {
                            $scope.timelineData.schedules = model.ScheduleModel.fromServerList(timeline.schedules)
                        }

                        if (angular.isArray(timeline.jobs)) {
                            $scope.timelineData.jobs = model.EventModel.fromServerList(timeline.jobs);
                        } 
                    }

                    $scope.timelineData.schedules.push(SINGLE_JOB_SCHEDULE_OPTION);
                    $scope.jobsFilters.schedules = angular.extend([], $scope.timelineData.schedules);

                    applyJobsFilters();
                });

                $scope.$watch('$ctrl.configData', function (configData) {
                    if (configData) {
                        if (angular.isArray(configData.jobTypes)) {
                            $scope.jobsFilters.eventTypes = angular.extend([], configData.jobTypes);
                        }
                    }

                    applyJobsFilters();
                });

                $scope.$watch('jobsFilters', function (newVal) {
                    applyJobsFilters();
                }, true);
            })();
        }
    ])
})(angular);