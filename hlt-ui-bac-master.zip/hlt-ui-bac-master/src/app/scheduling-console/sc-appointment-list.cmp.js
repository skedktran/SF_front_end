(function (angular, topWindow) {
	angular.module('hltApp')
	.component('scAppointmentList', {
		templateUrl: 'src/app/scheduling-console/sc-appointment-list.tpl.html',
		bindings: {
			mainState: '=',
			configData: '='
		},
		controller: [
			'JOB_STATUS',
			'$scope',
			'$q',
			'api',
			'util',
			'dateUtil',
			'model',
			function (JOB_STATUS, $scope, $q, api, util, dateUtil, model) {
				var $ctrl = this;

				var cachedParams = {
					appointmentListQuery: null
				};

				var LIST_MODE = {
					PATIENT_GROUP: {
						label: 'Group by Service User',
						icon: 'right_align_text',
						template: 'sc-al-patient-group.tpl.html'
					},
					LIST: {
						label: 'Appoinment List',
						icon: 'rows',
						template: 'sc-al-list.tpl.html'
					}
				};
				var PRIORITY_SORT_DIRECTIONS = [
					{
						name: 'ASC',
						value: 1,
						icon: 'arrowdown'
					},
					{
						name: 'DESC',
						value: -1,
						icon: 'arrowup'
					},
					{
						name: '',
						value: 0,
						icon: 'error'
					}
				];
				var TABLE_SORT_DIRECTIONS = {
					ASC: {
						name: 'ASC',
						value: 1,
						icon: 'arrowdown'
					},
					DESC: {
						name: 'DESC',
						value: -1,
						icon: 'arrowup'
					}
				};
				var TABLE_DEFINITION = {
					PATIENT_GROUP: {
						COLUMNS: {
							PATIENT_NAME: {
								label: 'Service User',
								cssClass: 'col-patient-name',
								isSortable: false,
								apiName: null
							},
							ADDRESS: {
								label: 'Address',
								cssClass: 'col-address',
								isSortable: false,
								apiName: null
							},
							BRANCH: {
								label: 'Branch',
								cssClass: 'col-branch',
								isSortable: false,
								apiName: null
							},
							JOB_TYPE: {
								label: 'Job Type',
								cssClass: 'col-job-type',
								isSortable: false,
								apiName: null
							},
							JOB_STATUS: {
								label: 'Job Status',
								cssClass: 'col-job-status',
								isSortable: false,
								apiName: null
							},
							JOB_DATE_TIME: {
								label: 'Date / Time',
								cssClass: 'col-date-time',
								isSortable: false,
								apiName: null
							}
						}
					},
					JOB_LIST: {
						COLUMNS: {
							PATIENT_NAME: {
								label: 'Service User',
								cssClass: 'col-patient-name',
								isSortable: false,
								apiName: null
							},
							ADDRESS: {
								label: 'Address',
								cssClass: 'col-address',
								isSortable: false,
								apiName: null
							},
							BRANCH: {
								label: 'Branch',
								cssClass: 'col-branch',
								isSortable: false,
								apiName: null
							},
							JOB_TYPE: {
								label: 'Job Type',
								cssClass: 'col-job-type',
								isSortable: false,
								apiName: null
							},
							JOB_STATUS: {
								label: 'Job Status',
								cssClass: 'col-job-status',
								isSortable: false,
								apiName: null
							},
							JOB_DATE_TIME: {
								label: 'Date / Time',
								cssClass: 'col-date-time',
								isSortable: false,
								apiName: null
							}
						}
					}
				};
				var PAGE_SIZE_LIMIT = 1999,
						SF_QUERY_LIMIT = 2000;

				var doGetAppointments = function (queryParams) {
					return api.getAppointments(queryParams)
						.catch(commonExceptionHanlder);
				};

				/**
				 * common remote action error handler
				 */
				var commonExceptionHanlder = function (exception) {
					console.error(exception);
					util.toastError('Can not perform action due to server error.');

					return $q.reject();
				};

				var showLoading = function () {
					util.showLoading();
				};

				var hideLoading = function () {
					util.hideLoading();
				};

				var isParamsReallyChanged = function (params, currentParams) {
					return !util.compareValues(params, currentParams);
				};

				var sortListByPriority = function () {
					var currentIndex = PRIORITY_SORT_DIRECTIONS.indexOf($ctrl.prioritySortDir);

					$ctrl.prioritySortDir = PRIORITY_SORT_DIRECTIONS[(currentIndex + 1)%PRIORITY_SORT_DIRECTIONS.length]
				};

				var sortListByCoumn = function (list, column) {
					if (list.sortColumn === column) {
						list.sortDirection = list.sortDirection === TABLE_SORT_DIRECTIONS.ASC?TABLE_SORT_DIRECTIONS.DESC:TABLE_SORT_DIRECTIONS.ASC;
					} else {
						list.sortColumn = column;
						list.sortDirection = TABLE_SORT_DIRECTIONS.ASC;
					}
				};

				var collectJobsFromPatients = function () {
					var jobs = [];

					angular.forEach($ctrl.patients, function (patient) {
						angular.forEach(patient.appointments, function (appointments) {
							appointments.patient = patient;
						});

						jobs = jobs.concat(patient.appointments);
					});

					return jobs;
				};

				var groupJobsByPatient = function () {
					var patientsMap = {};

					if (angular.isArray($ctrl.jobs) && $ctrl.jobs.length > 0) {
						angular.forEach($ctrl.jobs, function (job) {
							var patient;

							if (job.patient) {
								patient = patientsMap[job.patient.id];

								if (!patient) {
									patient = patientsMap[job.patient.id] = job.patient;
									patient.region = job.region;
								} else {
									job.patient = patient;
								}

								patient.appointments.push(job);
							}
						});
					}

					console.log(patientsMap);

					return Object.values(patientsMap);
				};

				var mapJobToRegion = function () {
					if (angular.isArray($ctrl.jobs) && $ctrl.jobs.length > 0 &&
						angular.isArray($ctrl.configData.regions) && $ctrl.configData.regions.length > 0) {
						angular.forEach($ctrl.jobs, function (job) {
							if (job.region) {
								job.region = $ctrl.configData.regions.find(function (region) {
									return region.id === job.region.id;
								});
							} 
						});
					}
				};

				var transformData = function (appointmentsData) {
					/*angular.forEach(patientsData, function (patient) {
						patient.appointments =  model.EventModel.fromServerList(patient.appointments)
					});

					$ctrl.patients = patientsData;
					$ctrl.jobs = collectJobsFromPatients();*/
					$ctrl.jobs = model.EventModel.fromServerList(appointmentsData);
					mapJobToRegion();

					$ctrl.patients = groupJobsByPatient()
				};

				var fetchAppointmentList = function (forceFetching) {
					var query;

					var fetchAppointments = function (query, pageNumber, appointmentData) {
						var queryWithPagin;

						if (!angular.isNumber(pageNumber)) {
							pageNumber = 1;
						}
						if (!angular.isArray(appointmentData)) {
							appointmentData = [];
						}

						queryWithPagin = angular.extend({}, query, {
							pageNo: pageNumber,
							pageSize: PAGE_SIZE_LIMIT,
						});

						return doGetAppointments(queryWithPagin)
							.then(function (result) {
								if (result.success && result.data) {
									appointmentData = appointmentData.concat(result.data.appointments || []);
									if (appointmentData.length >= result.data.totalRecords || 
										appointmentData.length + PAGE_SIZE_LIMIT >= SF_QUERY_LIMIT) {
										return appointmentData;
									} else {
										return fetchAppointments(query, pageNumber + 1, appointmentData);
									}
								} else {
									return $q.reject(result);
								}
							});
					};

					if ($ctrl.configData) {
						query = {
							regionIds: $ctrl.mainState.regions.length === $ctrl.configData.regions.length?null:$ctrl.mainState.regions.map(function (region) {return region.id;}),
							jobStatuses: $ctrl.appointmentFilter.jobStatuses.map(function (jobStatus) {return jobStatus.jobStatus}),
							jobTypes: $ctrl.appointmentFilter.jobTypes.map(function (eventType) {return eventType.id}),
							startDate: dateUtil.dateToString($ctrl.mainState.startDate),
							queryText: $ctrl.appointmentFilter.searchString || '',
							searchColumns: $ctrl.appointmentFilter.searchColumns.map(function (column) {return column.apiName}),
							orderBy: $ctrl.patientGroupTableState.sortColumn?$ctrl.patientGroupTableState.sortColumn.apiName:null,
							orderDirection: $ctrl.patientGroupTableState.sortDirection?$ctrl.patientGroupTableState.sortDirection.value:null,
						}

						if (forceFetching || isParamsReallyChanged(query, cachedParams.appointmentListQuery)) {
							cachedParams.appointmentListQuery = query;

							showLoading();
							return fetchAppointments(query)
								.then(function (appointmentData) {
									transformData(appointmentData || []);
								})
								.catch(function (exception) {
									console.error(exception);
									if (exception && exception.errorMessage) {
										util.toastError(exception.errorMessage);
									}
								})
								.finally(function () {
									hideLoading();
								});
						}
					}
				};

				var mapColumnConfig = function (columnDefs, columnConfigs) {
					angular.forEach(columnDefs, function (colDef) {
						var colConfig = columnConfigs.find(function (config) {
							return config.label === colDef.label;
						});

						if (colConfig) {
							angular.extend(colDef, colConfig);
						}
					});
				};

				/**
				 * controller init
				 * used for setting initial value
				 */
				$ctrl.$onInit = function (forceFetching) {
					if ($ctrl.configData) {
						$ctrl.appointmentFilter.jobStatuses = angular.extend([], $ctrl.configData.jobStatusSettingsList);
						$ctrl.appointmentFilter.jobTypes = angular.extend([], $ctrl.configData.jobTypes);

						if (angular.isArray($ctrl.configData.appointmentColumns)) {
							$ctrl.appointmentFilter.searchableColumns = $ctrl.configData.appointmentColumns.filter(function (column) {
								return column.isSearchable;
							});
							$ctrl.appointmentFilter.searchColumns = $ctrl.appointmentFilter.searchableColumns.filter(function (column) {
								return column.isSelected;
							});

							mapColumnConfig(TABLE_DEFINITION.PATIENT_GROUP.COLUMNS, $ctrl.configData.appointmentColumns);
							mapColumnConfig(TABLE_DEFINITION.JOB_LIST.COLUMNS, $ctrl.configData.appointmentColumns);
						}
					}
				};

				/**
				 * init block
				 * used for setting up controller
				 */
				(function () {
					$scope.LIST_MODE = LIST_MODE;
					$scope.PRIORITY_SORT_DIRECTIONS = PRIORITY_SORT_DIRECTIONS;
					$scope.TABLE_DEFINITION = TABLE_DEFINITION;

					$ctrl.jobs = [];
					$ctrl.patients = [];

					$ctrl.listMode = LIST_MODE.PATIENT_GROUP;
					$ctrl.prioritySortDir = PRIORITY_SORT_DIRECTIONS[0];
					$ctrl.patientGroupTableState = {
						columns: TABLE_DEFINITION.PATIENT_GROUP.COLUMNS,
						sortColumn: null,
						sortDirection: null
					};
					$ctrl.jobListTableState = {
						columns: TABLE_DEFINITION.JOB_LIST.COLUMNS,
						sortColumn: null,
						sortDirection: null
					};

					$ctrl.sortListByPriority = sortListByPriority;
					$ctrl.sortListByCoumn = sortListByCoumn;

					$ctrl.appointmentFilter = {
						jobStatuses: [],
						jobTypes: [],
						searchColumns: [],
						searchableColumns: [],
						searchString: ''
					};

					$scope.$watchGroup([
						'$ctrl.mainState.startDate',
						'$ctrl.appointmentFilter.searchString',
						'$ctrl.patientGroupTableState.sortColumn',
						'$ctrl.patientGroupTableState.sortDirection',
						'$ctrl.jobListTableState.sortColumn',
						'$ctrl.jobListTableState.sortDirection'
					], function () {
							fetchAppointmentList();
					});

					$scope.$watchCollection('$ctrl.mainState.regions', function () {
						fetchAppointmentList();
					});
					
					$scope.$watchCollection('$ctrl.appointmentFilter.searchColumns', function () {
						fetchAppointmentList();
					});
					$scope.$watchCollection('$ctrl.appointmentFilter.jobStatuses', function () {
						fetchAppointmentList();
					});
					$scope.$watchCollection('$ctrl.appointmentFilter.jobTypes', function () {
						fetchAppointmentList();
					});
				})();
			}
		]
	});
})(angular, top);