(function (angular, topWindow) {
	angular.module('hltApp')
	.component('schedulingConsole', {
		templateUrl: 'src/app/scheduling-console/scheduling-console.tpl.html',
		controller: [
			'$scope',
			'$q',
			'model',
			'util',
			'api',
			function ($scope, $q, model, util, api) {
				var $ctrl = this;

				var TABS = {
					// APPOINTMENT_LIST: {
					// 	icon: 'event',
					// 	title: 'Appointments',
					// 	component: ''
					// },
					EXCEPTION_CONSOLE: {
						icon: 'warning',
						title: 'Exception Logs',
						component: ''
					},
				};
				var SC_REQUIRED_CONFIG_DATA = [
					'jobTypes',
					'regions',
					'jobStatusSettings',
					'appointmentColumns',
					'exceptionLogColumns'
				];

				var showLoading = function () {
					util.showLoading();
				};

				var hideLoading = function () {
					util.hideLoading();
				};

				/**
				 * common remote action error handler
				 */
				var commonExceptionHanlder = function (exception) {
					console.error(exception);
					util.toastError('Can not perform action due to server error.');

					return $q.reject();
				};

				var doInitialize = function (requestParams) {
					return api.initialize(requestParams)
						.catch(commonExceptionHanlder);
				};

				var getInitialData = function () {
					var requestParams = {
						configKeys: SC_REQUIRED_CONFIG_DATA
					};

					return doInitialize(requestParams)
						.then(function (results) {
							if (results.success) {
								$ctrl.configData = model.ConfigDataModel.fromServer(results.data);

								transformJobStatusSettings();
								
								setupDefaultValues($ctrl.configData);
							} else {
								return $q.reject(results);
							}
						});
						
				};

				var transformJobStatusSettings = function () {
					if ($ctrl.configData && angular.isArray($ctrl.configData.jobStatusSettings)) {
						$ctrl.configData.jobStatusSettingsList = $ctrl.configData.jobStatusSettings;
						$ctrl.configData.jobStatusSettingsMap = {};

						angular.forEach($ctrl.configData.jobStatusSettingsList, function (jobStatusSetting) {
							jobStatusSetting.colorStyle = {
								backgroundColor: jobStatusSetting.backgroundColor,
								color: jobStatusSetting.textColor
							};

							$ctrl.configData.jobStatusSettingsMap[jobStatusSetting.jobStatus] = jobStatusSetting;
						});
					}
				};

				var setupDefaultValues = function (configData) {
					if (configData) {
						$ctrl.tab = TABS.EXCEPTION_CONSOLE;

						$ctrl.mainState.regions = angular.extend([], configData.regions);
					}
				}

				/**
				 * controller init
				 * used for setting initial value
				 */
				$ctrl.$onInit = function () {
					return getInitialData();
				};

				/**
				 * init block
				 * used for setting up controller
				 */
				(function () {
					$scope.TABS = TABS;

					$ctrl.configData = null;
					$ctrl.tab = null;
					$ctrl.mainState = {
						regions: [],
						startDate: new Date()
					};
				})();
			}
		]
	});
})(angular, top);