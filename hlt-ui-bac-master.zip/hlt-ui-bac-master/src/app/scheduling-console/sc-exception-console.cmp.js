(function (angular, topWindow) {
	angular.module('hltApp')
	.component('scExceptionConsole', {
		templateUrl: 'src/app/scheduling-console/sc-exception-console.tpl.html',
		bindings: {
			mainState: '=',
			configData: '='
		},
		controller: [
			'$scope',
			'$filter',
			'$q',
			'api',
			'util',
			'dateUtil',
			'model',
			function ($scope, $filter, $q, api, util, dateUtil, model) {
				var $ctrl = this;

				var DEFAULT_PHOTO_URL = $filter('skedSfUrl')('slds/images/avatar3.jpg');
				var TABLE_DEFINITION = {
					EXCEPTION_LOGS: {
						COLUMNS: {
							REGION_NAME: {
								label: 'Region',
								cssClass: 'col-region-name',
								isSortable: false,
								apiName: null
							},
							PATIENT_NAME: {
								label: 'Service User Name',
								cssClass: 'col-patient-name',
								isSortable: false,
								apiName: null
							},
							CARE_PLAN: {
								label: 'Support Plan',
								cssClass: 'col-care-plan',
								isSortable: false,
								apiName: null
							},
							JOB_NO: {
								label: 'Job',
								cssClass: 'col-job-no',
								isSortable: false,
								apiName: null
							},
							JOB_TYPE: {
								label: 'Job Type',
								cssClass: 'col-job-type',
								isSortable: false,
								apiName: null
							},
							JOB_START: {
								label: 'Job Date / Time',
								cssClass: 'col-job-date-time',
								isSortable: false,
								apiName: null
							},
							CREATED_DATE: {
								label: 'Created Date / Time',
								cssClass: 'col-created-date-time',
								isSortable: false,
								apiName: null
							},
							RESOURCE: {
								label: 'Resource',
								cssClass: 'col-resource',
								isSortable: false,
								apiName: null
							},
							EXCEPTION_CODE: {
								label: 'Exception Code',
								cssClass: 'col-exception-code',
								isSortable: false,
								apiName: null
							}
						}
					}
				};

				var TABLE_SORT_DIRECTIONS = {
					ASC: {
						name: 'ASC',
						value: 1,
						icon: 'arrowdown'
					},
					DESC: {
						name: 'DESC',
						value: -1,
						icon: 'arrowup'
					}
				};

				var cachedParams = {
					exceptionLogsQuery: null
				};

				var doGetExceptionLogs = function (query) {
					return api.getExceptionLogs(query)
						.catch(commonExceptionHanlder);
				};

				/**
				 * common remote action error handler
				 */
				var commonExceptionHanlder = function (exception) {
					console.error(exception);
					util.toastError('Can not perform action due to server error.');

					return $q.reject();
				};

				var showLoading = function () {
					util.showLoading();
				};

				var hideLoading = function () {
					util.hideLoading();
				};

				var isParamsReallyChanged = function (params, currentParams) {
					return !util.compareValues(params, currentParams);
				};

				var sortListByCoumn = function (list, column) {
					if (list.sortColumn === column) {
						list.sortDirection = list.sortDirection === TABLE_SORT_DIRECTIONS.ASC?TABLE_SORT_DIRECTIONS.DESC:TABLE_SORT_DIRECTIONS.ASC;
					} else {
						list.sortColumn = column;
						list.sortDirection = TABLE_SORT_DIRECTIONS.ASC;
					}
				};

				var transformData = function (exceptionLogsData) {
					$ctrl.exceptionLogs = model.PACJobExceptionModel.fromServerList(exceptionLogsData, $ctrl.configData);
				};

				var fetchExceptionLogs = function (forceFetching) {
					var query;

					if ($ctrl.configData) {
						query = {
							regionIds: $ctrl.mainState.regions.map(function (region) {return region.id;}),
							startDate: dateUtil.dateToString($ctrl.mainState.startDate),
							jobTypes: $ctrl.exceptionLogFilter.jobTypes.map(function (eventType) {return eventType.id}),
							orderBy: $ctrl.exceptionLogsTableState.sortColumn?$ctrl.exceptionLogsTableState.sortColumn.apiName:null,
							orderDirection: $ctrl.exceptionLogsTableState.sortDirection?$ctrl.exceptionLogsTableState.sortDirection.value:null,
							pageNo: $ctrl.exceptionLogsTableState.paginModel.pageNumber,
							pageSize: $ctrl.exceptionLogsTableState.paginModel.recordsPerPage,
							queryText: $ctrl.exceptionLogFilter.searchString || '',
							searchColumns: $ctrl.exceptionLogFilter.searchColumns.map(function (column) {return column.apiName})
						}

						if (forceFetching || isParamsReallyChanged(query, cachedParams.exceptionLogsQuery)) {
							cachedParams.exceptionLogsQuery = query;

							showLoading();
							return doGetExceptionLogs(query)
								.then(function (result) {
									if (result.success && result.data) {
										transformData(result.data.exceptions || []);
										$ctrl.exceptionLogsTableState.paginModel.totalRecords = result.data.totalRecords || 0;
									} else {
										return $q.reject(result);
									}
								})
								.catch(function (exception) {
									console.error(exception);
									if (exception && exception.errorMessage) {
										util.toastError(exception.errorMessage);
									}
								})
								.finally(function () {
									hideLoading();
								});
						}
					}
				};

				var mapColumnConfig = function (columnDefs, columnConfigs) {
					angular.forEach(columnDefs, function (colDef) {
						var colConfig = columnConfigs.find(function (config) {
							return config.label === colDef.label;
						});

						if (colConfig) {
							angular.extend(colDef, colConfig);
						}
					});
				};

				/**
				 * controller init
				 * used for setting initial value
				 */
				$ctrl.$onInit = function (forceFetching) {
					if ($ctrl.configData) {
						if (angular.isArray($ctrl.configData.exceptionLogColumns)) {
							$ctrl.exceptionLogFilter.searchableColumns = $ctrl.configData.exceptionLogColumns.filter(function (column) {
								return column.isSearchable;
							});
							$ctrl.exceptionLogFilter.searchColumns = $ctrl.exceptionLogFilter.searchableColumns.filter(function (column) {
								return column.isSelected;
							});
							$ctrl.exceptionLogFilter.jobTypes = angular.extend([], $ctrl.configData.jobTypes);

							mapColumnConfig(TABLE_DEFINITION.EXCEPTION_LOGS.COLUMNS, $ctrl.configData.exceptionLogColumns);
						}
					}
				};

				/**
				 * init block
				 * used for setting up controller
				 */
				(function () {
					$scope.TABLE_DEFINITION = TABLE_DEFINITION;
					$scope.DEFAULT_PHOTO_URL = DEFAULT_PHOTO_URL;

					$ctrl.exceptionLogs = [];

					$ctrl.exceptionLogsTableState = {
						columns: TABLE_DEFINITION.EXCEPTION_LOGS.COLUMNS,
						sortColumn: null,
						sortDirection: null,
						paginModel: {
							recordCountOptions: [5, 10, 15, 20, 25],
							recordsPerPage: 25,
							pageNumber: 1,
							numberOfPages: 0,
							totalRecords: 0
						}
					};
					$ctrl.exceptionLogFilter = {
						searchableColumns: [],
						searchColumns: [],
						searchString: ''
					};

					$ctrl.sortListByCoumn = sortListByCoumn;

					$scope.$watchGroup([
						'$ctrl.mainState.startDate',
						'$ctrl.exceptionLogsTableState.paginModel.recordsPerPage',
						'$ctrl.exceptionLogsTableState.paginModel.pageNumber',
						'$ctrl.exceptionLogsTableState.sortColumn',
						'$ctrl.exceptionLogsTableState.sortDirection',
						'$ctrl.exceptionLogFilter.searchString'
					], function () {
							fetchExceptionLogs();
					});

					$scope.$watchCollection('$ctrl.mainState.regions', function () {
						fetchExceptionLogs();
					});
					$scope.$watchCollection('$ctrl.exceptionLogFilter.searchColumns', function () {
						fetchExceptionLogs();
					});
					
					$scope.$watchCollection('$ctrl.exceptionLogFilter.jobTypes', function () {
						fetchExceptionLogs();
					});
				})();
			}
		]
	});
})(angular, top);