/**
 * #from: \s?:\s?.*                             #to:  = null;
 * #from: (this)(\.[^\s]*)(\s\=\s)([^\;]*)      #to: resource$2$3serverObject$2resource$2$3serverObject$2
 */
(function (angular) {
  angular.module('hltApp.model', ['skedApp.shared']).factory('model', [
    'constants',
    'dateUtil',
    'util',
    'JOB_STATUS',
    function (constants, dateUtil, util, JOB_STATUS) {
      var ACTION_METHOD = {
        CREATE: 'Create',
        UPDATE: 'Update',
        DELETE: 'Delete'
      };

      var buildMinuteOptions = function (step) {
        var minuteOptions = [];
        step = step || 30;
        for (var i = 0; i < 60; i += step) {
          minuteOptions.push(
            PicklistItemModel.fromServer({
              id: i,
              label: i + ' min' + (i > 0 ? 's' : ''),
              selected: i === 30
            })
          );
        }

        return minuteOptions;
      };

      var buildAcceptedRatio = function (availabilityStatusColorSettings) {
        var acceptedRatios = [];
        _.keys(availabilityStatusColorSettings).forEach(function (item) {
          acceptedRatios.push({
            id: Number(availabilityStatusColorSettings[item].lowerPercentage),
            label: item
          });
          acceptedRatios.push({
            id: Number(availabilityStatusColorSettings[item].upperPercentage),
            label: item
          });
        });
        acceptedRatios = _.sortBy(_.uniqBy(acceptedRatios, 'label'), function (
          item
        ) {
          return item.id;
        }).reverse();

        //remove 0 -> last index
        acceptedRatios.splice(-1, 1);

        //add 100 -> first index
        acceptedRatios.unshift({
          id: 100,
          label: 'Available'
        });

        return _.map(acceptedRatios, function (item) {
          return PicklistItemModel.fromServer({
            id: item.id,
            name: item.label,
            selected: item.id === 100
          });
        });
      };

      var mapArray = function (array, option, optionArgs) {
        var arrRs = [];

        if (angular.isArray(array) && array.length > 0) {
          arrRs = array.map(function (item) {
            if ((angular.isString(option) && angular.isObject(item)) || (angular.isNumber(option) && angular.isArray(item))) {
              if (angular.isFunction(item[option])) {
                return item[option].apply(item, optionArgs);
              } else {
                return item[option] || null;
              }
            } else if (angular.isFunction(option)) {
              return option(item, array, optionArgs) || null;
            } else {
              return item;
            }
          });
        }

        return arrRs;
      };

      var sortByName = function (array, field) {
        field = field || 'name';
        array.sort(function (a, b) {
          var nameA = a[field].toUpperCase(); // ignore upper and lowercase
          var nameB = b[field].toUpperCase(); // ignore upper and lowercase
          if (nameA < nameB) {
            return -1;
          }
          if (nameA > nameB) {
            return 1;
          }

          // names must be equal
          return 0;
        });

        return array;
      };

      // var refineObject = function(object) {
      //   if (angular.isObject(object)) {
      //     delete object.$$hashKey;
      //   }

      //   return object;
      // };

      // var refineArray = function(array) {
      //   if (angular.isArray(array) && array.length > 0) {
      //     angular.forEach(array, refineObject);
      //   }

      //   return array;
      // };

      /**
       * PicklistItemModel
       */
      function PicklistItemModel(id, label) {
        this.id = id || null;
        this.label = label || '';
        this.name = label || '';
        this.selected = false;
      }

      PicklistItemModel.fromServer = function (serverObject) {
        var picklistItem = null;

        if (serverObject) {
          if (angular.isString(serverObject)) {
            picklistItem = PicklistItemModel.fromId(serverObject);
          } else {
            picklistItem = new PicklistItemModel(serverObject.id);

            picklistItem.label = serverObject.label || serverObject.name;
            picklistItem.name = serverObject.name || serverObject.label;
            picklistItem.selected = serverObject.selected || false;
          }
        }

        return picklistItem;
      };

      PicklistItemModel.fromId = function (id) {
        if (id) {
          return new PicklistItemModel(id, id);
        }

        return null;
      };

      PicklistItemModel.fromServerList = function (serverList) {
        return mapArray(serverList, PicklistItemModel.fromServer);
      };

      PicklistItemModel.fromServerIdList = function (serverIdList) {
        return sortByName(mapArray(serverIdList, PicklistItemModel.fromId));
      };

      PicklistItemModel.prototype.toServer = function () {
        return this.id;
      };

      /**
       * TagModel
       */
      function TagModel(id, name) {
        this.id = id || null;
        this.name = this.label = name || '';
        this.expiryDate = null;
        this.expiryTime = null;
      }

      TagModel.fromServer = function (serverObject) {
        var tag = null;

        if (serverObject) {
          tag = new TagModel(serverObject.id, serverObject.name);

          tag.expiryTime = serverObject.expiryTime || null;
          tag.expiryDate = dateUtil.parseDateString(serverObject.expiryDate);
        }

        return tag;
      };

      TagModel.fromServerList = function (serverList) {
        return sortByName(mapArray(serverList, TagModel.fromServer));
      };

      TagModel.prototype.toServer = function () {
        return this.id;
      };

      /**
       * JobTagModel
       */
      function JobTagModel(id, jobId, tagId, tag) {
        this.id = id || null;
        this.jobId = jobId || null;
        this.tagId = tagId || null;
        this.tag = tag || null;
      }

      JobTagModel.fromServer = function (serverObject) {
        var jobTag = null;

        if (serverObject) {
          jobTag = new JobTagModel(
            serverObject.id,
            serverObject.jobId,
            serverObject.tagId,
            TagModel.fromServer(serverObject.tag)
          );
        }

        return jobTag;
      };

      JobTagModel.fromServerList = function (serverList) {
        return mapArray(serverList, JobTagModel.fromServer);
      };

      /**
       * ResourceTagModel
       */
      function ResourceTagModel(resourceId, tagId, tag) {
        this.resourceId = resourceId || null;
        this.tagId = tagId || null;
        this.tag = tag || null;
        this.isPrimary = false;
        this.tagType = null;
      }

      ResourceTagModel.fromServer = function (serverObject) {
        var resourceTag = null;

        if (serverObject) {
          resourceTag = new ResourceTagModel(
            serverObject.resourceId,
            serverObject.tagId,
            TagModel.fromServer(serverObject.tag)
          );

          resourceTag.isPrimary = !!serverObject.isPrimary;
          resourceTag.tagType = serverObject.tagType || null;
        }

        return resourceTag;
      };

      ResourceTagModel.fromSObject = function (serverObject) {
        var resourceTag = null;

        if (
          serverObject &&
          serverObject.sked__Resource__c &&
          serverObject.sked__Tag__c &&
          serverObject.sked__Tag__r
        ) {
          resourceTag = new ResourceTagModel(
            serverObject.sked__Resource__c,
            serverObject.sked__Tag__c,
            new TagModel(
              serverObject.sked__Tag__r.Id,
              serverObject.sked__Tag__r.Name
            )
          );

          resourceTag.isPrimary = !!serverObject.sked_Primary_Team__c;
          resourceTag.tagType = serverObject.sked__Type__c || null;
        }

        return resourceTag;
      };

      ResourceTagModel.fromServerList = function (serverList, fromSObject) {
        return mapArray(
          serverList,
          fromSObject === true ?
          ResourceTagModel.fromSObject :
          ResourceTagModel.fromServer
        );
      };

      /**
       * JobStatusSettingModel
       */
      function JobStatusSettingModel(jobStatus) {
        this.jobStatus = jobStatus;
        this.backgroundColor = null;
        this.textColor = null;
      }

      JobStatusSettingModel.fromServer = function (serverObject) {
        var jobStatusSetting = null;

        if (serverObject && serverObject.jobStatus) {
          jobStatusSetting = new JobStatusSettingModel(serverObject.jobStatus);
          jobStatusSetting.backgroundColor = serverObject.backgroundColor;
          jobStatusSetting.textColor = serverObject.textColor;
        }

        return jobStatusSetting;
      };

      JobStatusSettingModel.fromServerList = function (serverList) {
        return mapArray(serverList, JobStatusSettingModel.fromServer);
      };

      /**
       * AccountModel
       */
      function AccountModel(id, name) {
        this.id = id || null;
        this.name = name || '';
      }

      AccountModel.fromServer = function (serverObject) {
        var account = null;

        if (serverObject) {
          account = new AccountModel(serverObject.id, serverObject.name);
        }

        return account;
      };

      AccountModel.fromServerList = function (serverList) {
        return mapArray(serverList, AccountModel.fromServer);
      };

      AccountModel.prototype.toServer = function () {
        return this.id;
      };

      /**
       * ContactModel
       */
      function ContactModel(id) {
        this.id = id || null;
        this.email = '';
        this.phone = '';
        this.birthdate = null;
        this.isPrimary = false;
        this.fullName = this.name = '';
        this.address = null;
      }

      ContactModel.fromServer = function (serverObject) {
        var contact = null;

        if (serverObject) {
          contact = new ContactModel(serverObject.id);

          contact.email = serverObject.email;
          contact.phone = serverObject.phone;
          contact.birthdate = serverObject.birthdate;
          contact.isPrimary = !!serverObject.isPrimary;
          contact.name = contact.fullName = serverObject.name;
          contact.address = AddressModel.fromServer(serverObject.address);
        }

        return contact;
      };

      ContactModel.fromServerList = function (serverList) {
        return mapArray(serverList, ContactModel.fromServer);
      };

      ContactModel.prototype.toServer = function () {
        var serverObject = {
          id: this.id,
          name: this.fullName,
          email: this.email,
          phone: this.phone
        };

        return serverObject;
      };

      /**
       * RegionModel
       */
      function RegionModel(id, name) {
        this.id = id || null;
        this.name = name || '';
        this.timezone = null;
      }

      RegionModel.fromServer = function (serverObject) {
        var region = null;

        if (serverObject) {
          region = new RegionModel(serverObject.id, serverObject.name);

          region.timezone = serverObject.timezoneSidId ?
            new PicklistItemModel(
              serverObject.timezoneSidId,
              serverObject.timezoneSidId
            ) :
            null;
        }

        return region;
      };

      RegionModel.fromServerList = function (serverList) {
        return sortByName(mapArray(serverList, RegionModel.fromServer));
      };

      RegionModel.prototype.toServer = function () {
        return this.id;
      };

      /**
       * GeometryModel
       */
      function GeometryModel(lat, lng) {
        this.lat = lat;
        this.lng = lng;
      }

      GeometryModel.fromServer = function (serverObject) {
        var geometry = null;

        if (serverObject) {
          geometry = new GeometryModel(serverObject.lat, serverObject.lng);
        }

        return geometry;
      };

      GeometryModel.prototype.toServer = function () {
        var serverObject = {
          lat: this.lat,
          lng: this.lng
        };

        return serverObject;
      };

      /**
       * AddressModel
       */
      function AddressModel(fullAddress) {
        this.fullAddress = fullAddress;
        this.geometry = null;
        this.postalCode = null;
      }

      AddressModel.fromServer = function (serverObject) {
        var address = null;

        if (serverObject) {
          address = new AddressModel(serverObject.fullAddress);
          address.geometry = GeometryModel.fromServer(serverObject.geometry);
          address.postalCode = serverObject.postalCode;
        }

        return address;
      };

      AddressModel.fromGGServer = function (serverObject) {
        var address = null;
        var streetNumber, route;

        if (serverObject) {
          address = new AddressModel(serverObject.formatted_address); // address from server maybe an object with description
          address.geometry = GeometryModel.fromServer(
            serverObject.geometry.location
          );

          if (angular.isArray(serverObject.address_components)) {
            angular.forEach(serverObject.address_components, function (
              component
            ) {
              if (component.types.indexOf('locality') > -1) {
                address.city = component.long_name;
              } else if (component.types.indexOf('postal_code') > -1) {
                address.postalCode = component.long_name;
              } else if (
                component.types.indexOf('administrative_area_level_1') > -1
              ) {
                address.state = component.long_name;
              } else if (component.types.indexOf('street_address') > -1) {
                address.address1 = component.long_name;
              } else if (component.types.indexOf('street_number') > -1) {
                streetNumber = component.long_name;
              } else if (component.types.indexOf('route') > -1) {
                route = component.long_name;
              }
            });
          }

          if (!address.address1 && streetNumber) {
            address.address1 = (streetNumber || '') + ' ' + (route || '');
          }
        }

        return address;
      };

      AddressModel.fromServerList = function (serverList) {
        return mapArray(serverList, AddressModel.fromServer);
      };

      AddressModel.fromGGServerList = function (serverList) {
        return mapArray(serverList, AddressModel.fromGGServer);
      };

      AddressModel.prototype.toServer = function () {
        var serverObject = {
          fullAddress: this.fullAddress,
          geometry: this.geometry ? this.geometry.toServer() : null,
          postalCode: this.postalCode
        };

        return serverObject;
      };

      /**
       * HolidayModel
       */
      function HolidayModel(id, name) {
        this.id = id || null;
        this.name = name || '';
        this.isGlobal = false;
        this.startDate = null;
        this.endDate = null;
        this.regionId = null;
      }

      HolidayModel.fromServer = function (serverObject) {
        var holiday = null;

        if (serverObject) {
          holiday = new PicklistItemModel(serverObject.id, serverObject.name);

          holiday.isGlobal = !!serverObject.isGlobal;
          holiday.startDate = dateUtil.parseDateString(serverObject.startDate);
          holiday.endDate = dateUtil.parseDateString(serverObject.endDate);
          holiday.regionId = serverObject.regionId;
        }

        return holiday;
      };

      HolidayModel.fromServerList = function (serverList) {
        return mapArray(serverList, HolidayModel.fromServer);
      };

      /**
       * EventTypeSettingsModel
       */
      function EventTypeSettingsModel(id, label) {
        this.id = id || '';
        this.label = label || '';
        this.availableEnd = 0;
        this.availableStart = 0;
        this.canBePreDated = false;
        this.eventType = '';
        this.eventStatus = '';
        this.shortName = '';
        this.color = null;
        this.backgroundColor = null;
        this.isAvailable = false;
        this.showLegend = false;
        this.objectType = null;
        this.step = 0;
        this.isActive = false;
      }

      EventTypeSettingsModel.fromServer = function (serverObject) {
        var eventTypeSettings = null;

        if (serverObject) {
          eventTypeSettings = new EventTypeSettingsModel(
            serverObject.id,
            serverObject.label
          );

          eventTypeSettings.availableEnd = serverObject.availableEnd;
          eventTypeSettings.availableStart = serverObject.availableStart;
          eventTypeSettings.canBePreDated = serverObject.canBePreDated;
          eventTypeSettings.eventType = serverObject.eventType;
          eventTypeSettings.shortName = serverObject.shortName;
          eventTypeSettings.color = serverObject.color;
          eventTypeSettings.backgroundColor = serverObject.backgroundColor;
          eventTypeSettings.isAvailable = !!serverObject.isAvailable;
          eventTypeSettings.showLegend = !!serverObject.showLegend;
          eventTypeSettings.objectType = serverObject.objectType;
          eventTypeSettings.eventStatus = serverObject.eventStatus;
          eventTypeSettings.step = serverObject.step;
          eventTypeSettings.isActive = !!serverObject.isActive;
        }

        return eventTypeSettings;
      };

      EventTypeSettingsModel.fromServerList = function (serverList) {
        return mapArray(serverList, EventTypeSettingsModel.fromServer);
      };

      EventTypeSettingsModel.prototype.toServer = function () {
        var serverObject = {
          id: this.id,
          //label: this.label,
          availableEnd: this.availableEnd,
          availableStart: this.availableStart,
          canBePreDated: !!this.canBePreDated,
          eventType: this.eventType,
          shortName: this.shortName,
          color: this.color,
          backgroundColor: this.backgroundColor,
          isAvailable: !!this.isAvailable,
          showLegend: !!this.showLegend,
          objectType: this.objectType,
          eventStatus: this.eventStatus,
          step: this.step,
          isActive: this.isActive
        };

        return serverObject;
      };

      /**
       * ConfigDataModel
       */
      var DEFAULT_JOB_URL = 'https://new.skedulo.com/jobdetails/';
      function ConfigDataModel() {
        this.consoleSettings = null;
        this.timesheetSettings = null;
        this.regions = [];
        this.timezones = [];
        this.activityTypes = [];
        this.availabilityTypes = [];
        this.eventTypeSettings = [];
        this.jobTypes = [];
        this.clientAvailabilityTypes = [];
        this.cancellationReasons = [];
        this.holidays = [];
        this.userPermission = null;
        this.availabilityDeclineReasons = [];

        // from booking grid and job allocation
        this.consoleSettings = null; // TODO: merge with consoleSettings
        this.tags = [];
        this.contacts = [];
        this.supportPlans = [];
        this.patient = null;

        // from pac
        this.availabilityStatusColorSettings = {};
        this.checkAvailabilityAcceptedRatios = [];
        this.serviceLocations = [];
        this.minuteOptions = [];
        this.eventServiceLocations = null;

        // from ge
        this.groupEventStatuses = [];
        this.cancellableJobStatuses = [];

        // patient profile
        this.patientProfileTabs = [];

        this.gemstoneTeams = [];

        this.couldNotScheduleReasons = [];

        this.employmentTypes = [];

        this.jobStatusSettings = [];
        this.appointmentColumns = null;
        this.exceptionLogColumns = null;

        this.resourceCategories = [];

        this.assetAllocationStatuses = [];
        this.availabilityStatuses = [];

        this.jobURL = DEFAULT_JOB_URL;
      }

      ConfigDataModel.fromServer = function (serverObject) {
        var configData = null;
        var defaultCancellableJobStatuses;

        if (serverObject) {
          configData = new ConfigDataModel();

          configData.consoleSettings = ConsoleSettingsModel.fromServer(
            serverObject.consoleSettings
          );
          configData.timesheetSettings = ConsoleSettingsModel.fromServer(
            serverObject.timesheetSettings
          );
          configData.availabilityDeclineReasons = PicklistItemModel.fromServerIdList(serverObject.availabilityDeclineReasons);

          configData.regions = RegionModel.fromServerList(serverObject.regions);
          configData.timezones = PicklistItemModel.fromServerList(
            serverObject.timezones
          );
          configData.activityTypes = PicklistItemModel.fromServerList(
            serverObject.activityTypes
          );
          configData.availabilityTypes = PicklistItemModel.fromServerList(
            serverObject.availabilityTypes
          );
          configData.eventTypeSettings = EventTypeSettingsModel.fromServerList(
            serverObject.eventTypeSettings
          );
          configData.jobTypes = PicklistItemModel.fromServerList(
            serverObject.jobTypes
          );
          configData.clientAvailabilityTypes = PicklistItemModel.fromServerList(
            serverObject.clientAvailabilityTypes
          );
          configData.cancellationReasons = PicklistItemModel.fromServerIdList(
            serverObject.jobCancellationReasons
          );

          configData.abortReasons = PicklistItemModel.fromServerIdList(
            serverObject.abortReasons
          );

          configData.holidays = HolidayModel.fromServerList(
            serverObject.holidays
          );
          configData.availabilityStatuses = PicklistItemModel.fromServerIdList(serverObject.availabilityStatuses);

          //configData.consoleSettings = ConsoleSettingsModel.fromServer(serverObject.consoleSettings);
          configData.tags = TagModel.fromServerList(serverObject.tags);
          configData.contacts = ContactModel.fromServerList(
            serverObject.patientContacts
          );
          configData.patient = PatientModel.fromServer(serverObject.patient);
          configData.supportPlans = CarePlanModel.fromServerList(
            serverObject.patientSupportPlans
          );

          if (
            serverObject.availabilityStatusColorSettings &&
            serverObject.availabilityStatusColorSettings.availabilityCapacitySettingMap
          ) {
            configData.availabilityStatusColorSettings = ColorMapModel.fromServer(
              serverObject.availabilityStatusColorSettings.availabilityCapacitySettingMap
            );
            configData.checkAvailabilityAcceptedRatios = buildAcceptedRatio(
              configData.availabilityStatusColorSettings
            );
          }

          configData.serviceLocations = LocationModel.fromServerList(
            serverObject.patientLocations
          );
          configData.minuteOptions = buildMinuteOptions(
            configData.consoleSettings ?
            configData.consoleSettings.calendarStep :
            30
          );

          configData.userPermission = UserPermissionModel.fromServer(
            serverObject.userPermission
          );

          configData.eventServiceLocations = LocationModel.fromServerList(
            serverObject.patientLocations
          );
          if (configData.eventServiceLocations) {
            configData.eventServiceLocations.push(
              PicklistItemModel.fromServer({
                id: 'Other',
                label: 'Other'
              })
            );
          }

          configData.groupEventStatuses = PicklistItemModel.fromServerIdList(
            serverObject.groupEventStatuses
          );

          defaultCancellableJobStatuses = [
            JOB_STATUS.QUEUED,
            JOB_STATUS.PENDING_ALLOCATION,
            JOB_STATUS.PENDING_DISPATCH,
            JOB_STATUS.DISPATCHED,
            JOB_STATUS.READY,
            JOB_STATUS.EN_ROUTE,
            JOB_STATUS.ON_SITE,
            JOB_STATUS.IN_PROGRESS
          ];
          configData.cancellableJobStatuses =
            serverObject.cancellableJobStatuses ||
            defaultCancellableJobStatuses;

          configData.couldNotScheduleReasons = PicklistItemModel.fromServerIdList(
            serverObject.couldNotScheduleReasons
          );

          configData.resourceEmploymentTypes = PicklistItemModel.fromServerIdList(
            serverObject.resourceEmploymentTypes
          );

          configData.jobStatusSettings = JobStatusSettingModel.fromServerList(
            serverObject.jobStatusSettings
          );
          configData.appointmentColumns = ColumnSettingsModel.fromServerList(
            serverObject.appointmentColumns
          );
          configData.exceptionLogColumns = ColumnSettingsModel.fromServerList(
            serverObject.exceptionLogColumns
          );

          configData.resourceCategories = PicklistItemModel.fromServerIdList(
            serverObject.resourceCategories
          );

          configData.patientProfileTabs = PatientProfileTabModel.fromServerList(
            serverObject.patientProfileTabs
          );

          configData.assetAllocationStatuses = PicklistItemModel.fromServerIdList(
            serverObject.assetAllocationStatuses
          );
          configData.resourcePersonCategories = PicklistItemModel.fromServerIdList(
            serverObject.resourcePersonCategories
          );
          configData.resourceAssetCategories = PicklistItemModel.fromServerIdList(
            serverObject.resourceAssetCategories
          );

          configData.jobURL = serverObject.jobURL || DEFAULT_JOB_URL;
        }

        return configData;
      };

      function ColumnSettingsModel() {
        this.label = null;
        this.apiName = null;
        this.isSelected = false;
        this.isSearchable = false;
        this.isSortable = false;
      }

      ColumnSettingsModel.fromServer = function (serverObject) {
        var model = null;

        if (serverObject) {
          model = new ColumnSettingsModel();

          model.label = serverObject.label;
          model.apiName = serverObject.apiName;
          model.isSearchable = !!serverObject.allowSearch;
          model.isSortable = !!serverObject.allowSort;
          model.isSelected = !!serverObject.selected;
        }

        return model;
      };

      ColumnSettingsModel.fromServerList = function (serverList) {
        return mapArray(serverList, ColumnSettingsModel.fromServer);
      };

      /**
       * UserPermissionModel
       */
      function UserPermissionModel() {
        this.canCancel = false;
        this.canClone = false;
        this.canCreate = false;
        this.canDelete = false;
        this.canEdit = false;
      }

      UserPermissionModel.fromServer = function (serverObject) {
        var userPermission = new UserPermissionModel();

        if (serverObject) {
          userPermission.canCancel = serverObject.canCancel || false;
          userPermission.canClone = serverObject.canClone || false;
          userPermission.canCreate = serverObject.canCreate || false;
          userPermission.canDelete = serverObject.canDelete || false;
          userPermission.canEdit = serverObject.canEdit || false;
          userPermission.canApprove = serverObject.canApprove || false;
        }

        return userPermission;
      };

      /**
       * ResourceModel
       */
      function ResourceModel(id, name) {
        this.id = id || null;
        this.name = name || '';

        this.region = null;
        this.address = null;
        this.availability = [];
        this.events = [];
        this.resourceShifts = [];
        this.photoUrl = '';
        this.tags = [];
        this.resourceTags = [];
        this.userId = '';
        this.category = '';
        this.employmentType = '';
        this.resourceRegions = [];

        this.availabilityTemplates = [];
        this.availabilityPatternResources = [];
      }

      ResourceModel.fromServer = function (serverObject) {
        var resource = null;

        if (serverObject) {
          resource = new ResourceModel(serverObject.id, serverObject.name);

          resource.region = new RegionModel(
            serverObject.regionId,
            serverObject.regionName
          );
          resource.address = AddressModel.fromServer(serverObject.address);
          resource.availability = AvailabilityModel.fromServerList(
            serverObject.availability
          );
          resource.events = EventModel.fromServerList(serverObject.events);
          resource.photoUrl = serverObject.photoUrl;

          //resource.tags = TagModel.fromServerList(serverObject.tags);
          if (serverObject.resourceTags) {
            resource.resourceTags = ResourceTagModel.fromServerList(
              serverObject.resourceTags
            );
            resource.tags = resource.resourceTags.map(function (resourceTag) {
              return resourceTag.tag;
            });
          } else if (serverObject.tags) {
            resource.tags = TagModel.fromServerList(serverObject.tags);
          }

          resource.userId = serverObject.userId;
          resource.category = serverObject.category;
          resource.employmentType = serverObject.employmentType;
          resource.resourceRegions = serverObject.resourceRegions || [];

          resource.availabilityTemplates = (
            serverObject.availabilityTemplates || []
          ).map(function (resourceTemplate) {
            return new TemplateModel(resourceTemplate.availabilityTemplateId);
          });

          // should be a junction (contain data about date range)
          resource.availabilityPatternResources = AvailabilityPatternResourceModel.fromServerList(serverObject.availabilityPatternResources);

        }

        return resource;
      };

      ResourceModel.fromSObject = function (
        serverObject,
        serverList,
        timezoneSidId
      ) {
        var resource = null;

        if (serverObject) {
          resource = new ResourceModel(serverObject.Id, serverObject.Name);

          resource.region = serverObject.sked__Primary_Region__c ?
            new RegionModel(
              serverObject.sked__Primary_Region__c,
              serverObject.sked__Primary_Region__r ?
              serverObject.sked__Primary_Region__r.Name :
              ''
            ) :
            null;

          resource.address = serverObject.sked__Home_Address__c ?
            AddressModel.fromServer({
              fullAddress: serverObject.sked__Home_Address__c,
              geometry: {
                lat: serverObject.sked__GeoLocation__Latitude__s,
                lng: serverObject.sked__GeoLocation__Longitude__s
              }
            }) :
            null;
          resource.availability = AvailabilityModel.fromServerList(
            serverObject.sked__Availabilities1__r || [],
            true,
            timezoneSidId
          );
          resource.events = EventModel.fromServerList(serverObject.events);

          resource.events = [];
          resource.events = resource.events.concat(
            mapArray(
              serverObject.sked__Activities__r,
              EventModel.fromActivitySObject,
              timezoneSidId
            )
          );
          resource.events = resource.events.concat(
            mapArray(
              serverObject.sked__Job_Allocations__r,
              EventModel.fromJobAllocationSObject,
              timezoneSidId
            )
          );

          resource.photoUrl = serverObject.sked__User__c ?
            serverObject.sked__User__r.SmallPhotoUrl :
            null;

          //resource.tags = TagModel.fromServerList(serverObject.tags);
          if (serverObject.resourceTags) {
            resource.resourceTags = ResourceTagModel.fromServerList(
              serverObject.resourceTags
            );
            resource.tags = resource.resourceTags.map(function (resourceTag) {
              return resourceTag.tag;
            });
          } else if (serverObject.tags) {
            resource.tags = TagModel.fromServerList(serverObject.tags);
          }

          resource.userId = serverObject.sked__User__c;
          resource.category = serverObject.sked__Category__c;
          resource.employmentType = serverObject.sked__Employment_Type__c;

          if (serverObject.sked__ResourceTags__r) {
            resource.resourceTags = ResourceTagModel.fromServerList(
              serverObject.sked__ResourceTags__r,
              true
            );
            resource.tags = resource.resourceTags.map(function (resourceTag) {
              return resourceTag.tag;
            });
          }

          resource.availabilityTemplates = (
            serverObject.sked__Availability_Template_Resources__r || []
          ).map(function (template) {
            return new TemplateModel(template.sked__Availability_Template__c);
          });

          // should be a junction (contain data about date range)
          resource.availabilityPatternResources = AvailabilityPatternResourceModel.fromServerList(serverObject.sked__Availability_Pattern_Resources__r, true, timezoneSidId);
        }

        return resource;
      };

      ResourceModel.fromServerList = function (
        serverList,
        fromSObject,
        timezoneSidId
      ) {
        return mapArray(
          serverList,
          fromSObject === true ?
          ResourceModel.fromSObject :
          ResourceModel.fromServer,
          timezoneSidId
        );
      };

      ResourceModel.prototype.toServer = function () {
        return this.id;
      };

      /**
       * LocationModel
       */
      function LocationModel(id, name) {
        this.id = id || null;
        this.name = this.label = name || '';
        this.region = null;
        this.address = null;
      }

      LocationModel.fromServer = function (serverObject) {
        var model = null;

        if (serverObject) {
          model = new LocationModel(serverObject.id, serverObject.name);

          model.region = serverObject.regionId ?
            new RegionModel(serverObject.regionId) :
            null;
          model.address = AddressModel.fromServer(serverObject.address);
          model.selected = serverObject.selected;
        }

        return model;
      };

      LocationModel.fromServerList = function (serverList) {
        return mapArray(serverList, LocationModel.fromServer);
      };

      LocationModel.prototype.toServer = function () {
        return this.id;
      };

      /**
       * EventModel
       */
      function EventModel(id, name) {
        this.id = id || null;
        this.name = name || '';

        this.objectType = '';
        this.eventType = '';
        this.address = null;
        this.startDate = null;
        this.endDate = null;
        this.startTime = 0;
        this.endTime = 0;
        this.notes = '';
        this.description = '';
        this.jobStatus = '';

        this.allocations = [];
        this.tags = []; // depricated
        this.jobTags = []; // will replace tags when system is stable
        this.duration = 0;
        this.region = null;
        this.contact = null;
        this.scheduleId = null;
        this.scheduleDescription = null;

        this.supportPlan = null;
        this.possibleAllocations = [];

        this.quantity = 0;
        this.jobOffers = [];

        this.patient = null;
        this.account = null;
        this.inheritAccountTasks = false;
        this.jobTasks = new JobTaskModelCollection();
        this.loneWorkerRisk = false;
      }

      EventModel.fromServer = function (serverObject) {
        var event = null;

        if (serverObject) {
          event = new EventModel(serverObject.id, serverObject.name);

          event.objectType = serverObject.objectType;
          event.eventType = PicklistItemModel.fromId(serverObject.eventType);
          event.address = AddressModel.fromServer(serverObject.address);
          event.startDate = dateUtil.parseDateString(serverObject.startDate);
          event.endDate = dateUtil.parseDateString(serverObject.endDate);
          event.startTime = serverObject.startTime;
          event.endTime = serverObject.endTime;
          event.notes = serverObject.notes;
          event.description = serverObject.description;

          event.allocations = JobAllocationModel.fromServerList(
            serverObject.jobAllocations
          );
          event.jobStatus = serverObject.jobStatus;
          event.duration = serverObject.duration;

          if (serverObject.jobTags) {
            event.jobTags = JobTagModel.fromServerList(serverObject.jobTags);
            event.tags = event.jobTags.map(function (jobTag) {
              return jobTag.tag;
            });
          } else if (serverObject.tags) {
            event.tags = TagModel.fromServerList(serverObject.tags);
          }

          event.region = new RegionModel(serverObject.regionId);
          event.contact = new ContactModel(serverObject.contactId);
          event.scheduleId = serverObject.scheduleId || null;
          event.scheduleDescription = serverObject.scheduleDescription || null;

          event.supportPlan = new PicklistItemModel(serverObject.supportPlanId);
          event.possibleAllocations = JobAllocationModel.fromServerList(
            serverObject.possibleAllocations
          );

          event.quantity = serverObject.quantity;
          event.jobOffers = JobOfferModel.fromServerList(
            serverObject.jobOffers
          );

          event.patient = event.account = PatientModel.fromServer(
            serverObject.account
          ); // patient is account
          event.inheritAccountTasks = serverObject.inheritAccountTasks;

          event.jobTasks = new JobTaskModelCollection(
            serverObject.jobTasks
          );
          event.loneWorkerRisk = serverObject.loneWorkerRisk;
        }

        return event;
      };

      EventModel.fromActivitySObject = function (
        serverObject,
        serverList,
        timezoneSidId
      ) {
        var event = null,
          startDateTime,
          endDateTime;

        if (serverObject) {
          event = new EventModel(serverObject.Id, serverObject.Name);

          event.objectType = 'activity';
          event.eventType = PicklistItemModel.fromId(
            serverObject.sked__Type__c
          );

          event.address = serverObject.sked__Address__c ?
            AddressModel.fromServer({
              fullAddress: serverObject.sked__Address__c,
              geometry: serverObject.sked__GeoLocation__c ? {
                lat: serverObject.sked__GeoLocation__c.latitude,
                lng: serverObject.sked__GeoLocation__c.longitude
              } : null
            }) :
            null;

          startDateTime = dateUtil.getDateTimeInfo(
            serverObject.sked__Start__c,
            timezoneSidId
          );
          endDateTime = dateUtil.getDateTimeInfo(
            serverObject.sked__End__c,
            timezoneSidId
          );

          event.startDate = startDateTime.date;
          event.endDate = endDateTime.date;
          event.startTime = startDateTime.timeNumber;
          event.endTime = endDateTime.timeNumber;
          event.scheduleId = serverObject.sked_Recurring_Schedule__c;

          event.notes = serverObject.sked__Notes__c;
        }

        return event;
      };

      EventModel.fromSObject = function(
				serverObject,
				serverList,
				timezoneSidId
			) {
				var event = null;
				var jobSObject, startDateTime, endDateTime;

				if (serverObject) {
					jobSObject = serverObject;

					event = new EventModel(jobSObject.Id, jobSObject.Name);

					event.objectType = 'job';
					event.eventType = PicklistItemModel.fromId(jobSObject.sked__Type__c);
					event.jobStatus = jobSObject.sked__Job_Status__c;
					event.quantity = jobSObject.sked__Quantity__c;

					event.contact = jobSObject.sked__Contact__r ? PatientModel.fromServer({
						id: jobSObject.sked__Contact__r.Id,
						name: jobSObject.sked__Contact__r.Name
					}) : null;

					event.address = (jobSObject.sked__Home_Address__c || jobSObject.sked__Address__c)
						? AddressModel.fromServer({
							fullAddress: (jobSObject.sked__Home_Address__c || jobSObject.sked__Address__c),
							geometry: {
								lat: jobSObject.sked__GeoLocation__Latitude__s,
								lng: jobSObject.sked__GeoLocation__Longitude__s
							},
							state: serverObject.state,
							city: serverObject.city,
						})
						: null;

					startDateTime = dateUtil.getDateTimeInfo(
						jobSObject.sked__Start__c,
						timezoneSidId
					);
					endDateTime = dateUtil.getDateTimeInfo(
						jobSObject.sked__Finish__c,
						timezoneSidId
					);
					
					event.startDate = startDateTime.date;
					event.endDate = endDateTime.date;
					event.startTime = startDateTime.timeNumber;
					event.endTime = endDateTime.timeNumber;
					event.inheritAccountTasks = !!jobSObject.sked_Inherit_Account_Tasks__c;
          event.loneWorkerRisk = !!jobSObject.sked_Lone_Worker_Risk__c;

					event.allocations = (serverObject.sked__Job_Allocations__r || []).map(function(item) {
						return JobAllocationModel.fromSObject(item);
					});
				}

				return event;
      };
      

      EventModel.fromJobAllocationSObject = function (
        serverObject,
        serverList,
        timezoneSidId
      ) {
        var event = null;
        var jobSObject, startDateTime, endDateTime;

        if (serverObject) {
          jobSObject = serverObject.sked__Job__r;

          event = new EventModel(jobSObject.Id, jobSObject.Name);

          event.objectType = 'job';
          event.eventType = PicklistItemModel.fromId(jobSObject.sked__Type__c);

          event.address = (jobSObject.sked__Home_Address__c || jobSObject.sked__Address__c) ?
            AddressModel.fromServer({
              fullAddress: (jobSObject.sked__Home_Address__c || jobSObject.sked__Address__c),
              geometry: {
                lat: jobSObject.sked__GeoLocation__Latitude__s,
                lng: jobSObject.sked__GeoLocation__Longitude__s
              }
            }) :
            null;

          startDateTime = dateUtil.getDateTimeInfo(
            jobSObject.sked__Start__c,
            timezoneSidId
          );
          endDateTime = dateUtil.getDateTimeInfo(
            jobSObject.sked__Finish__c,
            timezoneSidId
          );

          event.startDate = startDateTime.date;
          event.endDate = endDateTime.date;
          event.startTime = startDateTime.timeNumber;
          event.endTime = endDateTime.timeNumber;
          event.inheritAccountTasks = !!jobSObject.sked_Inherit_Account_Tasks__c;
          event.loneWorkerRisk = !!jobSObject.sked_Lone_Worker_Risk__c;
        }

        return event;
      };

      EventModel.fromServerList = function (serverList) {
        return mapArray(serverList, EventModel.fromServer);
      };

      EventModel.prototype.toActivityServer = function () {
        var serverObject = {
          id: this.id,
          eventType: this.eventType ? this.eventType.toServer() : null,
          address: this.address ? this.address.toServer() : null,
          startDate: angular.isDate(this.startDate) ?
            dateUtil.dateToString(this.startDate) : null,
          endDate: angular.isDate(this.endDate) ?
            dateUtil.dateToString(this.endDate) : null,
          startTime: this.startTime || 0,
          endTime: this.endTime || 0,
          notes: this.notes || '',
          scheduleId: this.scheduleId
        };

        return serverObject;
      };

      EventModel.prototype.toAvailabilityServer = function () {
        var serverObject = {
          id: this.id,
          eventType: this.eventType ? this.eventType.toServer() : null,
          startDate: angular.isDate(this.startDate) ?
            dateUtil.dateToString(this.startDate) : null,
          endDate: angular.isDate(this.endDate) ?
            dateUtil.dateToString(this.endDate) : null,
          startTime: this.startTime || 0,
          endTime: this.endTime || 0,
          notes: this.notes || '',
          scheduleId: this.scheduleId
        };

        return serverObject;
      };

      EventModel.prototype.toServer = function () {
        var serverObject = {
          id: this.id,
          eventType: this.eventType ?
            angular.isString(this.eventType) ?
            this.eventType :
            this.eventType.toServer() : null,
          address: this.address ? this.address.toServer() : null,
          startDate: angular.isDate(this.startDate) ?
            dateUtil.dateToString(this.startDate) : null,
          endDate: angular.isDate(this.endDate) ?
            dateUtil.dateToString(this.endDate) : null,
          startTime: this.startTime || 0,
          endTime: this.endTime || 0,
          notes: this.notes || '',
          description: this.description || '',
          //duration: this.duration, // [REMOVE_DURATION]
          //tagIds: (angular.isArray(this.tags))?this.tags.map(function (tag) {return tag.id}):[], // depricated
          jobTags: angular.isArray(this.tags) ?
            this.tags.map(function (tag) {
              return {
                tagId: tag.id
              };
            }) : [],
          regionId: this.region ? this.region.id : null,
          contactId: this.contact ? this.contact.id : null,
          supportPlanId: this.supportPlan ? this.supportPlan.id : null,
          quantity: this.quantity,
          inheritAccountTasks: this.inheritAccountTasks,
          jobTasks: this.jobTasks.toServer(),
          loneWorkerRisk: this.loneWorkerRisk
        };

        return serverObject;
      };

      /**
       * JobModel
       */
      function JobModel(id, name) {
        this.id = id || null;
        this.name = name || '';

        this.objectType = '';
        this.eventType = '';
        this.address = null;
        this.startDate = null;
        this.endDate = null;
        this.startTime = 0;
        this.endTime = 0;
        this.notes = '';
      }

      JobModel.fromServer = function (serverObject) {
        var job = null;

        if (serverObject) {
          job = new JobModel(serverObject.id, serverObject.name);

          job.objectType = serverObject.objectType;
          job.eventType = PicklistItemModel.fromId(serverObject.eventType);
          job.address = AddressModel.fromServer(serverObject.address);
          job.startDate = dateUtil.parseDateString(serverObject.startDate);
          job.endDate = dateUtil.parseDateString(serverObject.endDate);
          job.startTime = serverObject.startTime;
          job.endTime = serverObject.endTime;
          job.notes = serverObject.notes;
        }

        return job;
      };

      JobModel.fromServerList = function (serverList) {
        return mapArray(serverList, JobModel.fromServer);
      };

      JobModel.prototype.toServer = function () {
        var serverObject = {
          id: this.id,
          eventType: this.eventType ? this.eventType.toServer() : null,
          address: this.address ? this.address.toServer() : null,
          startDate: angular.isDate(this.startDate) ?
            dateUtil.dateToString(this.startDate) : null,
          endDate: angular.isDate(this.endDate) ?
            dateUtil.dateToString(this.endDate) : null,
          startTime: this.startTime || 0,
          endTime: this.endTime || 0,
          notes: this.notes || ''
        };

        return serverObject;
      };

      /**
       * AvailabilityModel
       */
      function AvailabilityModel(id, name) {
        this.id = id || null;
        this.name = name || '';

        this.objectType = '';
        this.eventType = '';
        this.address = null;
        this.startDate = null;
        this.endDate = null;
        this.startTime = 0;
        this.endTime = 0;
        this.notes = '';
        this.isAllDay = false;
        this.scheduleId = null;
        this.scheduleDescription = null;
        this.status = null;

        // this.onCallTeamId = null;
        // this.members = []; // for on-call
        this.resource = null;

        this.declineReason = null;
        this.otherDeclineReason = null;
      }

      AvailabilityModel.fromServer = function (serverObject) {
        var availability = null;

        if (serverObject) {
          availability = new AvailabilityModel(
            serverObject.id,
            serverObject.name
          );

          availability.objectType = serverObject.objectType; // availability / activity / template
          availability.eventType = PicklistItemModel.fromId(
            serverObject.eventType
          );
          availability.address = AddressModel.fromServer(serverObject.address);
          availability.startDate = dateUtil.parseDateString(
            serverObject.startDate
          );
          availability.endDate = dateUtil.parseDateString(serverObject.endDate);
          availability.startTime = serverObject.startTime;
          availability.endTime = serverObject.endTime;
          availability.notes = serverObject.notes;
          availability.isAllDay = !!serverObject.isAllDay;
          availability.scheduleId = serverObject.scheduleId || null;
          availability.scheduleDescription =
            serverObject.scheduleDescription || null;
          availability.status = serverObject.status;
          // availability.onCallTeamId = serverObject.onCallTeamId;

          if (serverObject.resource) {
            availability.resource = ResourceModel.fromServer(serverObject.resource);
          } else if (serverObject.resourceId) {
            availability.resource = new ResourceModel(serverObject.resourceId);
          }

          availability.declineReason = serverObject.declineReason;
          availability.otherDeclineReason = serverObject.otherDeclineReason;

          availability.createdDate = dateUtil.parseDateString(serverObject.createdOnDate);
          availability.createdTime = serverObject.createdOnTime;
          availability.createdBy = ResourceModel.fromServer(serverObject.createdBy);
          availability.lastModifiedDate = dateUtil.parseDateString(serverObject.lastModifiedDate);
          availability.lastModifiedTime = serverObject.lastModifiedTime;
          availability.lastModifiedBy = ResourceModel.fromServer(serverObject.lastModifiedBy);
          availability.timeOffAllowance = serverObject.timeOffAllowance;

        }

        return availability;
      };

      AvailabilityModel.fromSObject = function (
        serverObject,
        serverList,
        timezoneSidId
      ) {
        var availability = null,
          startDateTime, endDateTime,
          createdDateTime, lastModifiedDateTime;

        if (serverObject) {
          availability = new AvailabilityModel(
            serverObject.Id,
            serverObject.Name
          );

          availability.resource = ResourceModel.fromSObject(serverObject.sked__Resource__r);

          //availability.objectType = serverObject.objectType; // availability / activity / template
          availability.objectType = 'availability';
          availability.eventType = PicklistItemModel.fromId(
            serverObject.sked__Type__c
          );

          //availability.address = AddressModel.fromServer(serverObject.address);

          startDateTime = dateUtil.getDateTimeInfo(
            serverObject.sked__Start__c,
            timezoneSidId
          );
          endDateTime = dateUtil.getDateTimeInfo(
            serverObject.sked__Finish__c,
            timezoneSidId
          );

          availability.startDate = startDateTime.date;
          availability.endDate = endDateTime.date;
          availability.startTime = startDateTime.timeNumber;
          availability.endTime = endDateTime.timeNumber;

          availability.notes = serverObject.sked__Notes__c;
          availability.isAllDay = !!serverObject.sked_Is_All_Day__c;
          availability.scheduleId =
            serverObject.sked_Recurring_Schedule__c || null;
          //availability.scheduleDescription = serverObject.scheduleDescription || null;
          availability.status = serverObject.sked__Status__c;
          // availability.onCallTeamId = serverObject.sked_On_Call_Team__c;

          createdDateTime = dateUtil.getDateTimeInfo(serverObject.CreatedDate, timezoneSidId);
          lastModifiedDateTime = dateUtil.getDateTimeInfo(serverObject.LastModifiedDate, timezoneSidId);

          availability.createdDate = createdDateTime.date;
          availability.createdTime = createdDateTime.timeNumber;
          availability.createdBy = ResourceModel.fromSObject(serverObject.CreatedBy, null, timezoneSidId);
          availability.lastModifiedDate = lastModifiedDateTime.date;
          availability.lastModifiedTime = lastModifiedDateTime.timeNumber;
          availability.lastModifiedBy = ResourceModel.fromSObject(serverObject.LastModifiedBy, null, timezoneSidId);

        }

        return availability;
      };

      AvailabilityModel.fromServerList = function (
        serverList,
        fromSObject,
        timezoneSidId
      ) {
        return mapArray(
          serverList,
          fromSObject === true ?
            AvailabilityModel.fromSObject :
            AvailabilityModel.fromServer,
          timezoneSidId
        );
      };

      AvailabilityModel.prototype.toServer = function () {
        var serverObject = {
          id: this.id,
          eventType: this.eventType ? this.eventType.toServer() : null,
          startDate: angular.isDate(this.startDate) ?
            dateUtil.dateToString(this.startDate) : null,
          endDate: angular.isDate(this.endDate) ?
            dateUtil.dateToString(this.endDate) : null,
          startTime: this.startTime || 0,
          endTime: this.endTime || 0,
          notes: this.notes || '',
          isAllDay: this.isAllDay,
          scheduleId: this.scheduleId,
          resourceId: this.resource ? this.resource.id : null
          // onCallTeamId: this.onCallTeamId
        };

        return serverObject;
      };

      // /**
      //  * OncallAppointmentModel
      //  */
      // function OncallAppointmentModel (id, name) {
      // 	this.id = id || null;
      // 	this.name = name || '';

      // 	this.objectType = '';
      // 	this.eventType = '';
      // 	this.address = null;
      // 	this.startDate = null;
      // 	this.endDate = null;
      // 	this.startTime = 0;
      // 	this.endTime = 0;
      // 	this.notes = '';
      // 	this.isAllDay = false;
      // 	this.scheduleId = null;
      // 	this.scheduleDescription = null;
      // 	this.status = null;
      // }

      // OncallAppointmentModel.fromServer = function (serverObject) {
      // 	var availability = null;

      // 	if (serverObject) {
      // 		availability = new OncallAppointmentModel(serverObject.id, serverObject.name);

      // 		availability.objectType = serverObject.objectType; // availability / activity / template
      // 		availability.eventType = PicklistItemModel.fromId(serverObject.eventType);
      // 		availability.address = AddressModel.fromServer(serverObject.address);
      // 		availability.startDate = dateUtil.parseDateString(serverObject.startDate);
      // 		availability.endDate = dateUtil.parseDateString(serverObject.endDate);
      // 		availability.startTime = serverObject.startTime;
      // 		availability.endTime = serverObject.endTime;
      // 		availability.notes = serverObject.notes;
      // 		availability.isAllDay = !!serverObject.isAllDay;
      // 		availability.scheduleId = serverObject.scheduleId || null;
      // 		availability.scheduleDescription = serverObject.scheduleDescription || null;
      // 		availability.status = serverObject.status;
      // 	}

      // 	return availability;
      // };

      // OncallAppointmentModel.fromSObject = function (serverObject, serverList, timezoneSidId) {
      // 	var availability = null,
      // 		startDateTime, endDateTime;

      // 	if (serverObject) {
      // 		availability = new OncallAppointmentModel(serverObject.Id, serverObject.Name);

      // 		//availability.objectType = serverObject.objectType; // availability / activity / template
      // 		availability.objectType = 'availability';
      // 		availability.eventType = PicklistItemModel.fromId(serverObject.sked__Type__c);

      // 		//availability.address = AddressModel.fromServer(serverObject.address);

      // 		startDateTime = dateUtil.getDateTimeInfo(serverObject.sked__Start__c, timezoneSidId);
      // 		endDateTime = dateUtil.getDateTimeInfo(serverObject.sked__Finish__c, timezoneSidId);

      // 		availability.startDate = startDateTime.date;
      // 		availability.endDate = endDateTime.date;
      // 		availability.startTime = startDateTime.timeNumber;
      // 		availability.endTime = endDateTime.timeNumber;

      // 		availability.notes = serverObject.sked__Notes__c;
      // 		availability.isAllDay = !!serverObject.sked_Is_All_Day__c;
      // 		availability.scheduleId = serverObject.sked_Recurring_Schedule__c || null;
      // 		//availability.scheduleDescription = serverObject.scheduleDescription || null;
      // 		availability.status = serverObject.sked__Status__c;
      // 	}

      // 	return availability;
      // };

      // OncallAppointmentModel.fromServerList = function (serverList, fromSObject, timezoneSidId) {
      // 	return mapArray(serverList, (fromSObject === true)?OncallAppointmentModel.fromSObject:OncallAppointmentModel.fromServer, timezoneSidId);
      // };

      // OncallAppointmentModel.prototype.toServer = function () {
      // 	var serverObject = {
      // 		id: this.id,
      // 		eventType: this.eventType?this.eventType.toServer():null,
      // 		startDate: angular.isDate(this.startDate)?dateUtil.dateToString(this.startDate):null,
      // 		endDate: angular.isDate(this.endDate)?dateUtil.dateToString(this.endDate):null,
      // 		startTime: this.startTime || 0,
      // 		endTime: this.endTime || 0,
      // 		notes: this.notes || '',
      // 		isAllDay: this.isAllDay,
      // 		scheduleId: this.scheduleId
      // 	};

      // 	return serverObject;
      // };

      /**
       * OncallTeamModel
       */
      // function OncallTeamModel (id, name) {
      // 	this.id = id || null;
      // 	this.name = name || '';
      // 	this.members = [];
      // }

      // OncallTeamModel.fromServer = function (serverObject) {
      // 	var oncallTeam = null;

      // 	if (serverObject) {
      // 		oncallTeam = new OncallTeamModel(serverObject.id, serverObject.name);
      // 		oncallTeam.members = OncallTeamMemberModel.fromServerList(serverObject.resourceTeams);
      // 	}

      // 	return oncallTeam;
      // };

      // OncallTeamModel.fromSObject = function (serverObject) {
      // 	var oncallTeam = null;

      // 	if (serverObject) {
      // 		oncallTeam = new OncallTeamModel(serverObject.Id, serverObject.Name);
      // 		oncallTeam.members = OncallTeamMemberModel.fromServerList(serverObject.sked_Resource_Teams__r, true);
      // 	}

      // 	return oncallTeam;
      // };

      // OncallTeamModel.fromServerList = function (serverList, fromSObject) {
      // 	return mapArray(serverList, (fromSObject === true)?OncallTeamModel.fromSObject:OncallTeamModel.fromServer);
      // };

      // /**
      //  * OncallTeamMemberModel
      //  */
      // function OncallTeamMemberModel (id, name) {
      // 	this.id = id || null;
      // 	this.name = name || '';
      // 	this.priority = null;
      // 	this.priorityWeight = null;
      // 	this.resource = null;
      // }

      // OncallTeamMemberModel.fromServer = function (serverObject) {
      // 	var oncallTeamMember = null;

      // 	if (serverObject) {
      // 		oncallTeamMember = new OncallTeamMemberModel(serverObject.id, serverObject.name);
      // 		oncallTeamMember.priority = serverObject.prioritization;
      // 		oncallTeamMember.resource = ResourceModel.fromServer(serverObject.resource);

      // 		try {
      // 			oncallTeamMember.priorityWeight = parseInt(oncallTeamMember.priority, 10);
      // 		} catch (exception) {
      // 			oncallTeamMember.priorityWeight = 999;
      // 		}
      // 	}

      // 	return oncallTeamMember;
      // };

      // OncallTeamMemberModel.fromSObject = function (serverObject) {
      // 	var oncallTeamMember = null;

      // 	if (serverObject) {
      // 		oncallTeamMember = new OncallTeamMemberModel(serverObject.Id, serverObject.Name);
      // 		oncallTeamMember.priority = serverObject.sked_Prioritization__c;
      // 		oncallTeamMember.resource = ResourceModel.fromSObject(serverObject.sked_Resource__r);

      // 		try {
      // 			oncallTeamMember.priorityWeight = parseInt(oncallTeamMember.priority, 10);
      // 		} catch (exception) {
      // 			oncallTeamMember.priorityWeight = 999;
      // 		}
      // 	}

      // 	return oncallTeamMember;
      // };

      // OncallTeamMemberModel.fromServerList = function (serverList, fromSObject) {
      // 	return mapArray(serverList, (fromSObject === true)?OncallTeamMemberModel.fromSObject:OncallTeamMemberModel.fromServer);
      // };

      /**
       * PeriodModel
       */
      function PeriodModel(id) {
        this.id = id || null;
        this.name = null;
        this.unit = null;
        this.value = 0;
        this.selected = false;
      }

      PeriodModel.fromServer = function (serverObject) {
        var model = null;

        if (serverObject) {
          model = new PeriodModel(serverObject.id);

          model.name = serverObject.name || serverObject.label;
          model.unit = serverObject.unit || 'd';
          model.value = serverObject.value || 0;
          model.selected = !!serverObject.selected;
        }

        return model;
      };

      PeriodModel.fromServerList = function (serverList) {
        return mapArray(serverList, PeriodModel.fromServer);
      };

      PeriodModel.prototype.toServer = function () {
        return this.id;
      };

      /**
       * ConsoleSettingsModel
       */
      function ConsoleSettingsModel() {
        this.calendarEnd = 0;
        this.calendarStart = 0;
        this.calendarStep = 0;
        this.timePickerStep = 30;
        this.dateFormat = null;
        this.datePickerFormat = null;
        this.weekPickerFormat = null;
        this.monthPickerFormat = null;
        this.firstDay = 0;
        this.noOfRecurWeeks = 0;
        this.viewPeriod = 2;
        this.defaultDuration = 60;
        this.startWorkingTime = 800;

        // from console settings
        this.autoApproveAvailability = false;
        this.enableActivity = false;
        this.enableAvailabilityTemplate = false;
        this.enableShift = false;
        this.respectResourceTimezone = false;

        // from patient calendar settings
        this.cellSize = null;

        this.showLegend = false;

        this.filters = null;
      }

      ConsoleSettingsModel.fromServer = function (serverObject) {
        var consoleSettings = null;

        if (serverObject) {
          consoleSettings = new ConsoleSettingsModel();

          consoleSettings.calendarEnd = serverObject.calendarEnd;
          consoleSettings.calendarStart = serverObject.calendarStart;
          consoleSettings.calendarStep = serverObject.calendarStep;
          consoleSettings.timePickerStep = serverObject.timePickerStep || 30;
          consoleSettings.dateFormat = serverObject.dateFormat;
          consoleSettings.datePickerFormat = serverObject.datePickerFormat;
          consoleSettings.weekPickerFormat = serverObject.weekPickerFormat;
          consoleSettings.monthPickerFormat = serverObject.monthPickerFormat;
          consoleSettings.firstDay = serverObject.firstDay || 0;
          consoleSettings.noOfRecurWeeks = serverObject.noOfRecurWeeks;
          consoleSettings.viewPeriod = serverObject.viewPeriod;
          consoleSettings.defaultDuration = serverObject.defaultDuration || 60;
          consoleSettings.startWorkingTime =
            serverObject.startWorkingTime || 800;
          consoleSettings.respectResourceTimezone =
            serverObject.respectResourceTimezone;

          // from console settings
          consoleSettings.autoApproveAvailability = !!serverObject.autoApproveAvailability;
          consoleSettings.enableActivity = !!serverObject.enableActivity;
          consoleSettings.enableAvailabilityTemplate = !!serverObject.enableAvailabilityTemplate;
          consoleSettings.enableShift = !!serverObject.enableShift;

          consoleSettings.cellSize = serverObject.cellSize;

          consoleSettings.showLegend = !!serverObject.showLegend;

          consoleSettings.filters = FilterSavingModel.fromServer(
            serverObject.filters
          );
        }

        return consoleSettings;
      };

      ConsoleSettingsModel.prototype.toServer = function () {
        var serverObject = {
          autoApproveAvailability: !!this.autoApproveAvailability,
          calendarEnd: this.calendarEnd,
          calendarStart: this.calendarStart,
          calendarStep: this.calendarStep,
          timePickerStep: this.timePickerStep,
          dateFormat: this.dateFormat,
          datePickerFormat: this.datePickerFormat,
          enableActivity: !!this.enableActivity,
          enableAvailabilityTemplate: !!this.enableAvailabilityTemplate,
          enableShift: !!this.enableShift,
          firstDay: this.firstDay,
          monthPickerFormat: this.monthPickerFormat,
          noOfRecurWeeks: this.noOfRecurWeeks,
          respectResourceTimezone: !!this.respectResourceTimezone,
          showLegend: !!this.showLegend,
          viewPeriod: this.viewPeriod,
          weekPickerFormat: this.weekPickerFormat
        };

        return serverObject;
      };

      ConsoleSettingsModel.prototype.toRACServer = function () {
        var serverObject = {
          autoApproveAvailability: this.autoApproveAvailability,
          calendarEnd: this.calendarEnd,
          calendarStart: this.calendarStart,
          calendarStep: this.calendarStep,
          timePickerStep: this.timePickerStep,
          dateFormat: this.dateFormat,
          datePickerFormat: this.datePickerFormat,
          enableActivity: this.enableActivity,
          enableAvailabilityTemplate: this.enableAvailabilityTemplate,
          enableShift: this.enableShift,
          firstDay: this.firstDay,
          monthPickerFormat: this.monthPickerFormat,
          noOfRecurWeeks: this.noOfRecurWeeks,
          respectResourceTimezone: this.respectResourceTimezone,
          showLegend: this.showLegend,
          viewPeriod: this.viewPeriod,
          weekPickerFormat: this.weekPickerFormat
        };

        return serverObject;
      };

      ConsoleSettingsModel.prototype.toPACServer = function () {
        var serverObject = {
          defaultDuration: this.defaultDuration,
          startWorkingTime: this.startWorkingTime,
          calendarEnd: this.calendarEnd,
          calendarStart: this.calendarStart,
          calendarStep: this.calendarStep,
          timePickerStep: this.timePickerStep,
          dateFormat: this.dateFormat,
          datePickerFormat: this.datePickerFormat,
          firstDay: this.firstDay,
          noOfRecurWeeks: this.noOfRecurWeeks,
          viewPeriod: this.viewPeriod
        };

        return serverObject;
      };

      /**
       * AdminSettingsModel
       */
      function AdminSettingsModel() {
        this.distanceMeasurementUnit = null;
        this.enableObjectSync = false;
        this.enableShift = false;
        this.jobURL = null;
        this.schedulersGroupEmail = null;
        this.smsCountryCodeAbbreviation = null;
        this.velocity = 0;
      }

      AdminSettingsModel.fromServer = function (serverObject) {
        var adminSettings = null;

        if (serverObject) {
          adminSettings = new AdminSettingsModel();

          adminSettings.distanceMeasurementUnit =
            serverObject.distanceMeasurementUnit;
          adminSettings.enableObjectSync = !!serverObject.enableObjectSync;
          adminSettings.enableShift = !!serverObject.enableShift;
          adminSettings.jobURL = serverObject.jobURL;
          adminSettings.schedulersGroupEmail =
            serverObject.schedulersGroupEmail;
          adminSettings.smsCountryCodeAbbreviation =
            serverObject.smsCountryCodeAbbreviation;
          adminSettings.velocity = serverObject.velocity || 0;
        }

        return adminSettings;
      };

      AdminSettingsModel.prototype.toServer = function () {
        var serverObject = {
          distanceMeasurementUnit: this.distanceMeasurementUnit,
          enableObjectSync: this.enableObjectSync,
          enableShift: this.enableShift,
          jobURL: this.jobURL,
          schedulersGroupEmail: this.schedulersGroupEmail,
          smsCountryCodeAbbreviation: this.smsCountryCodeAbbreviation,
          velocity: this.velocity || 0
        };

        return serverObject;
      };

      function FilterSavingModel() {
        this.category = null;
        this.jsonData = '';
      }

      FilterSavingModel.fromServer = function (serverObject) {
        var model = null;

        if (serverObject) {
          model = new FilterSavingModel();

          model.category = serverObject.category;
          model.jsonData = serverObject.jsonData;
        }

        return model;
      };

      /**
       * AccountTaskMmodel
       */
      function AccountTaskModel(data) {
        this.id = data.id;
        this.name = data.name;
        this.description = data.description;
        this.endDate = data.endDate;
        this.sequence = data.sequence;
        this.startDate = data.startDate;
      }

      AccountTaskModel.fromServer = function (serverObject) {
        var accountTask;
        if (serverObject) {
          accountTask = new AccountTaskModel(serverObject);
        }

        return accountTask;
      };

      AccountTaskModel.fromServerList = function (serverList) {
        return mapArray(serverList, AccountTaskModel.fromServer);
      };

      /**
       * JobTaskModel
       */
      function JobTaskModel(data) {
        this.id = data.id;
        this.name = data.name;
        this.description = data.description;
        this.sourceAccountTaskId = data.sourceAccountTaskId;
        this.isEditMode = false;
      }

      JobTaskModel.prototype.switchToEdit = function () {
        this.isEditMode = true;
        this.backup = {
          name: this.name,
          description: this.description
        };
      };

      JobTaskModel.prototype.reverseChange = function () {
        this.isEditMode = false;
        this.name = this.backup.name;
        this.description = this.backup.description;
      };

      JobTaskModel.prototype.commitChange = function () {
        this.isEditMode = false;
        this.backup = null;
      };

      JobTaskModel.prototype.toServer = function () {
        return {
          id: this.id.startsWith('jobTask_') ? null : this.id,
          name: this.name,
          description: this.description,
          sourceAccountTaskId: this.sourceAccountTaskId
        };
      };

      JobTaskModel.fromServer = function (serverObject) {
        var jobTask;
        if (serverObject) {
          jobTask = new JobTaskModel(serverObject);
        }

        return jobTask;
      };

      JobTaskModel.fromServerList = function (serverList) {
        return mapArray(serverList, JobTaskModel.fromServer);
      };

      /**
       * JobTaskModelCollection
       */

      function JobTaskModelCollection(jobTasks) {
        this._list = mapArray(jobTasks, JobTaskModel.fromServer);
      }

      JobTaskModelCollection.prototype.inheritAccountTasks = function (
        filteredAccountTasks
      ) {
        this._list = [];
        filteredAccountTasks.forEach(
          function (accountTask) {
            this.addTask({
              name: accountTask.name,
              description: accountTask.description,
              sourceAccountTaskId: accountTask.id
            });
          }.bind(this)
        );
      };

      JobTaskModelCollection.prototype.getList = function () {
        return this._list;
      };

      JobTaskModelCollection.prototype.clear = function () {
        this._list = [];
      };

      JobTaskModelCollection.prototype.deleteTask = function (taskIndex) {
        this._list.splice(taskIndex, 1);
      };

      JobTaskModelCollection.prototype.changeSequence = function (
        taskIndex,
        action
      ) {
        var newIndex = action === 'UP' ? taskIndex - 1 : taskIndex + 1;
        var firstItem = this._list[taskIndex];
        this._list[taskIndex] = this._list[newIndex];
        this._list[newIndex] = firstItem;
      };

      JobTaskModelCollection.prototype.addTask = function (data) {
        var newJobTask = new JobTaskModel(data);
        newJobTask.id = _.uniqueId('jobTask_');

        this._list.push(newJobTask);
      };

      JobTaskModelCollection.prototype.toServer = function () {
        return this._list.map(function (jobTask, index) {
          var serverObj = jobTask.toServer();
          serverObj.sequence = index + 1;

          return serverObj;
        });
      };

      /**
       * PatientModel
       */
      function PatientModel(id, name) {
        this.id = id || null;
        this.name = name || null;
        this.photoUrl = null;
        this.email = null;
        this.region = null;
        this.phone = null;
        this.birthdate = null;
        this.address = null;
        this.appointments = [];
        this.accountTasks = [];
      }

      PatientModel.fromServer = function (serverObject) {
        var model = null;
        if (serverObject) {
          model = new PatientModel(serverObject.id);
          model.name = serverObject.name;
          model.photoUrl = serverObject.photoUrl;
          model.email = serverObject.email;
          model.region = PicklistItemModel.fromId(serverObject.regionId);
          model.accountTasks = AccountTaskModel.fromServerList(
            serverObject.accountTasks
          );
          model.availabilityType =
            serverObject.availabilityType ||
            constants.DEFAULT_SERVICE_USER_AVAIBILITY_TYPE;

          model.phone = serverObject.phone;
          model.birthdate = serverObject.birthdate;
          model.address = AddressModel.fromServer(serverObject.address);
        }

        return model;
      };

      PatientModel.fromServerList = function (serverList) {
        return mapArray(serverList, PatientModel.fromServer);
      };

      /**
       * ColorModel
       */
      function ColorModel() {
        this.backgroundColor = null;
        this.color = null;
        this.objectType = null;
        this.lowerPercentage = 0;
        this.upperPercentage = 0;
        this.showLegend = false;
      }

      ColorModel.fromServer = function (serverObject) {
        var model = {};

        if (serverObject) {
          model.backgroundColor = serverObject.backgroundColor;
          model.color = serverObject.color;
          model.objectType = serverObject.objectType;
          model.lowerPercentage = serverObject.lowerPercentage;
          model.upperPercentage = serverObject.upperPercentage;
          model.showLegend = !!serverObject.showLegend;
        }

        return model;
      };

      /**
       * ColorMapModel
       */
      function ColorMapModel() {}

      ColorMapModel.fromServer = function (serverObject) {
        var model = {};

        if (serverObject) {
          Object.keys(serverObject).forEach(function (key) {
            model[key] = ColorModel.fromServer(serverObject[key]);
          });
        }

        return model;
      };

      /**
       * PACFilterModel
       */
      function PACFilterModel() {
        this.region = null;
      }

      PACFilterModel.fromServer = function (serverObject) {
        var model = null;

        if (serverObject) {
          model = new PACFilterModel();
        }

        return model;
      };

      PACFilterModel.prototype.toServer = function () {
        var serverObject = {
          regionId: this.region ? this.region.toServer() : null
        };

        return serverObject;
      };

      /**
       * PACAvailabilityModel
       */
      function PACAvailabilityModel(id) {
        this.id = id || null;
        this.isAvailable = null;
        this.name = null;
        this.startTime = null;
        this.endTime = null;
        this.preferredStartDate = null;
        this.preferredEndDate = null;
        this.preferredStartTime = null;
        this.preferredEndTime = null;
        this.startDate = null;
        this.endDate = null;
        this.eventType = null;
        this.objectType = null;
        this.serviceLocation = null;
        this.notes = null;
        this.isAllDay = false;
        this.scheduleId = null;
        this.schedule = null;
        //this.patientId = null;
        this.region = null;

        this.hasPreferredTimes = false;
        this.isAllTimePreferred = false;

        this.originalStartDate = null;
        this.duration = 0;
        this.preferredTimeDuration = 0;
        this.objectTypeString = null;
      }

      PACAvailabilityModel.fromServer = function (serverObject, configData) {
        var model = null;

        if (serverObject) {
          model = new PACAvailabilityModel(serverObject.id);

          model.name = serverObject.name;
          model.startTime = serverObject.startTime;
          model.endTime = serverObject.endTime;
          model.preferredStartDate = dateUtil.parseDateString(
            serverObject.preferredStartDate
          );
          model.preferredEndDate = dateUtil.parseDateString(
            serverObject.preferredEndDate
          );
          model.preferredStartTime = serverObject.preferredStartTime;
          model.preferredEndTime = serverObject.preferredEndTime;
          model.startDate = dateUtil.parseDateString(serverObject.startDate);
          model.endDate = dateUtil.parseDateString(serverObject.endDate);
          model.eventType = serverObject.eventType;
          model.objectType = serverObject.objectType;
          model.notes = serverObject.notes;
          model.isAllDay = !!serverObject.isAllDay;
          model.scheduleId = serverObject.scheduleId;
          model.schedule = ScheduleModel.fromServer(
            serverObject.recurringSchedule
          );
          //model.patientId = serverObject.patientId;
          model.isAllTimePreferred = !!serverObject.isAllTimePreferred;
          model.isAvailable = !!serverObject.isAvailable;

          model.serviceLocation = serverObject.serviceLocationId ?
            _.find(configData.serviceLocations, {
              id: serverObject.serviceLocationId
            }) :
            null;

          /*model.region = serverObject.regionId ? _.find(configData.regions, {
						id: serverObject.regionId
					}) : null;*/

          if (
            !util.isNullOrEmpty(model.preferredStartTime) &&
            model.preferredStartTime < model.startTime
          ) {
            model.preferredStartTime = model.startTime;
          }

          if (
            !util.isNullOrEmpty(model.preferredEndTime) &&
            model.preferredEndTime >
            (model.endTime === 0 ? 2400 : model.endTime)
          ) {
            model.preferredEndTime = model.endTime;
          }

          model.originalStartDate = model.startDate;
          model.hasPreferredTimes = !util.isNullOrEmpty(model.preferredStartTime) &&
            !util.isNullOrEmpty(model.preferredEndTime);

          if (model.isAllTimePreferred) {
            model.hasPreferredTimes = false;
            model.preferredStartTime = model.startTime;
            model.preferredEndTime = model.endTime;
          }

          model.duration = moment(
            dateUtil.parseTimeValue(model.endTime === 0 ? 2400 : model.endTime)
          ).diff(moment(dateUtil.parseTimeValue(model.startTime)), 'minutes');
          model.preferredTimeDuration = moment(
            dateUtil.parseTimeValue(
              model.preferredEndTime === 0 ? 2400 : model.preferredEndTime
            )
          ).diff(
            moment(dateUtil.parseTimeValue(model.preferredStartTime)),
            'minutes'
          );

          model.objectTypeString = model.objectType ?
            model.objectType.split(/(?=[A-Z])/).join(' ') :
            '';
          model.objectTypeString =
            model.objectTypeString.charAt(0).toUpperCase() +
            model.objectTypeString.substring(1);
          model.objectTypeString = model.objectTypeString
            .replace('Client', '')
            .trim();
        }

        return model;
      };

      PACAvailabilityModel.fromServerList = function (serverList, configData) {
        return serverList.map(function (item) {
          return PACAvailabilityModel.fromServer(item, configData);
        });
      };

      PACAvailabilityModel.prototype.toServer = function () {
        var serverObject = {
          id: this.id,
          eventType: this.eventType,
          serviceLocationId: this.serviceLocation ?
            this.serviceLocation.toServer() : null,
          //regionId: this.region?this.region.toServer():null,
          startDate: angular.isDate(this.startDate) ?
            dateUtil.dateToString(this.startDate) : null,
          startTime: this.startTime || 0,
          endTime: this.endTime || 0,
          preferredStartTime: util.isNullOrEmpty(this.preferredStartTime) ?
            null : this.preferredStartTime,
          preferredEndTime: util.isNullOrEmpty(this.preferredEndTime) ?
            null : this.preferredEndTime,
          isAllTimePreferred: !!this.isAllTimePreferred,
          notes: this.notes || '',
          scheduleId: this.scheduleId,
          isAvailable: !!this.isAvailable

          //patientId: this.patientId
        };

        serverObject.preferredStartDate = serverObject.startDate;
        serverObject.preferredEndDate = serverObject.startDate;
        serverObject.endDate = serverObject.startDate;

        if (!this.hasPreferredTimes && !this.isAllTimePreferred) {
          serverObject.preferredStartTime = null;
          serverObject.preferredEndTime = null;
        }

        if (this.isAllTimePreferred) {
          serverObject.preferredStartTime = serverObject.startTime;
          serverObject.preferredEndTime = serverObject.endTime;
        }

        return serverObject;
      };

      /**
       * PACJobModel
       */
      function PACJobModel(id) {
        this.id = id || null;
        this.name = null;
        this.startTime = null;
        this.endTime = null;
        this.startDate = null;
        this.endDate = null;
        this.eventType = null;
        this.serviceLocation = null;
        this.notes = null;
        this.description = null;
        this.contact = null;
        this.contactId = null;
        this.contactName = null;
        this.isAllDay = false;
        this.isCareTeam = false;
        this.jobTags = [];
        this.tags = [];
        this.hasError = false;
        this.errorMessages = [];
        this.cancellationReason = null;
        this.region = null;
        this.supportPlan = null;
        this.supportPlanId = null;
        this.supportPlanName = null;
        this.scheduleId = null;
        this.schedule = null;
        this.objectType = null;
        this.patientId = null;
        this.groupEvent = null;
        //this.groupEventId = null;
        //this.groupEventName = null;
        this.address = null;
        this.jobStatus = null;
        this.status = null;
        this.address = null;
        this.clients = [];
        this.noOfResources = 0;
        this.noOfAttendees = 0;

        this.originalStartDate = null;
        this.colorSetting = null;
        this.duration = 0;
        this.objectTypeString = null;
        this.contacts = [];
        this.quantity = null;

        this.timestamp = null;
        this.inheritAccountTasks = false;
        this.jobTasks = new JobTaskModelCollection();
        this.loneWorkerRisk = false;
      }

      PACJobModel.fromServer = function (serverObject, configData) {
        var model = null,
          tagIds;

        if (serverObject) {
          model = new PACJobModel(serverObject.id);

          model.name = serverObject.name;
          model.startTime = serverObject.startTime;
          model.endTime = serverObject.endTime;
          model.startDate = dateUtil.parseDateString(serverObject.startDate);
          model.endDate = dateUtil.parseDateString(serverObject.endDate);
          model.eventType = serverObject.eventType;
          model.notes = serverObject.notes;
          model.description = serverObject.description;
          model.isAllDay = !!serverObject.isAllDay;
          model.isCareTeam = !!serverObject.isCareTeam;
          model.hasError = !!serverObject.hasError;
          model.errorMessages = serverObject.errorMessages;
          model.cancellationReason = serverObject.cancellationReason;
          model.scheduleId = serverObject.scheduleId;
          model.inheritAccountTasks = !!serverObject.inheritAccountTasks;
          model.jobTasks = new JobTaskModelCollection(serverObject.jobTasks);
          model.loneWorkerRisk = !!serverObject.loneWorkerRisk;
          if (serverObject.recurringSchedule) {
            model.schedule = ScheduleModel.fromServer(
              serverObject.recurringSchedule
            );
          } else if (serverObject.scheduleId) {
            model.schedule = ScheduleModel.fromServer({
              id: serverObject.scheduleId,
              description: serverObject.scheduleDescription
            });
          }

          //model.patientId = serverObject.patientId;
          if (serverObject.accountId) {
            model.patientId = serverObject.accountId;
          } else if (serverObject.account) {
            model.patientId = serverObject.account.id;
          }

          //model.groupEvent = GroupEventModel.fromServer(serverObject.groupEvent, configData);
          //model.groupEventId = serverObject.groupEventId;
          //model.groupEventName = serverObject.groupEventName;
          model.objectType = serverObject.objectType;
          model.address = AddressModel.fromServer(serverObject.address);
          model.jobStatus = serverObject.jobStatus;
          model.status = serverObject.status;
          model.address = AddressModel.fromServer(serverObject.address);
          //model.clients = ClientModel.fromServerList(serverObject.jobAttendees);
          model.noOfResources = serverObject.jobAllocationCount || 0;
          model.noOfAttendees = serverObject.jobAttendeeCount || 0;
          model.quantity = serverObject.quantity;
          model.duration = serverObject.duration || 0;

          model.jobTags = JobTagModel.fromServerList(serverObject.jobTags);
          tagIds = model.jobTags.map(function (jobTag) {
            return jobTag.tagId;
          });
          model.tags = _.filter(configData.tags, function (item) {
            return _.find(tagIds, function (id) {
              return id === item.id;
            });
          });

          if (serverObject.contact) {
            model.contact = ContactModel.fromServer(serverObject.contact);
            model.contactId = model.contact.id;
            model.contactName = model.contact.name;
          } else if (serverObject.contactId && serverObject.contactName) {
            model.contactId = serverObject.contactId;
            model.contactName = serverObject.contactName;
            if (configData && configData.contacts) {
              model.contact = serverObject.contactId ?
                _.find(configData.contacts, {
                  id: serverObject.contactId
                }) :
                null;
            }
          }

          model.serviceLocation = serverObject.serviceLocationId ?
            _.find(configData.eventServiceLocations, {
              id: serverObject.serviceLocationId
            }) :
            null;

          if (!model.serviceLocation) {
            model.serviceLocation = _.find(configData.eventServiceLocations, {
              id: 'Other'
            });
          }

          model.supportPlan = serverObject.supportPlanId ?
            _.find(configData.supportPlans, {
              id: serverObject.supportPlanId
            }) :
            null;
          model.supportPlanId = serverObject.supportPlanId;
          model.supportPlanName = serverObject.supportPlanName;

          model.region = serverObject.regionId ?
            _.find(configData.regions, {
              id: serverObject.regionId
            }) :
            null;

          model.originalStartDate = model.startDate;
          model.duration = moment(dateUtil.parseTimeValue(model.endTime)).diff(
            moment(dateUtil.parseTimeValue(model.startTime)),
            'minutes'
          );

          if (configData && configData.colorMap) {
            model.colorSetting = configData.colorMap[model.eventType];
          }

          model.objectTypeString = model.objectType ?
            model.objectType.split(/(?=[A-Z])/).join(' ') :
            '';
          model.objectTypeString =
            model.objectTypeString.charAt(0).toUpperCase() +
            model.objectTypeString.substring(1);
          model.objectTypeString = model.objectTypeString
            .replace('Client', '')
            .trim();

          model.timestamp = dateUtil
            .parseDateTime(model.startDate, model.startTime)
            .getTime();

          
          model.originalJobTasks = angular.copy(model.jobTasks._list);
          model.originalJobTags = angular.copy(model.jobTags);
        }

        return model;
      };

      PACJobModel.fromServerList = function (serverList, configData) {
        return serverList.map(function (item) {
          return PACJobModel.fromServer(item, configData);
        });
      };

      PACJobModel.prototype.toServer = function () {
        var serverObject = {
          id: this.id,
          eventType: this.eventType ?
            angular.isString(this.eventType) ?
            this.eventType :
            this.eventType.toServer() : null,
          address: this.address ? this.address.toServer() : null,
          startDate: angular.isDate(this.startDate) ?
            dateUtil.dateToString(this.startDate) : null,
          startTime: this.startTime || 0,
          endTime: this.endTime || 0,
          isCareTeam: this.isCareTeam,
          regionId: this.region ? this.region.toServer() : null,
          supportPlanId: this.supportPlan ? this.supportPlan.toServer() : null,
          contactId: this.contact ? this.contact.id : null, // depricated
          /*tagIds: this.tags.map(function(item){
						return item.toServer();
					}),*/
          jobTags: angular.isArray(
              this.tags
            ) ?
            this.tags.map(function (tag) {
              return {
                tagId: tag.id
              };
            }) : [],
          scheduleId: this.scheduleId,
          //patientId: this.patientId,
          accountId: this.patientId,
          groupEventId: this.groupEventId,
          cancellationReason: this.cancellationReason || '',
          notes: this.notes || '',
          description: this.description || '',
          //jobAttendees: mapArray(this.clients, 'toServer'),
          //duration: this.duration || null, //[REMOVE_DURATION]
          quantity: this.quantity,
          inheritAccountTasks: this.inheritAccountTasks,
          jobTasks: this.jobTasks.toServer(),
          loneWorkerRisk: this.loneWorkerRisk
        };

        if (this.serviceLocation) {
          if (this.serviceLocation.id === 'Other') {
            serverObject.serviceLocationId = null;
          } else {
            serverObject.serviceLocationId = this.serviceLocation.toServer();
            serverObject.address = this.serviceLocation.address;
          }
        } else {
          //based on patient availability
          serverObject.serviceLocationId = null;
          serverObject.address = null;
        }

        // //create
        // if(!serverObject.id) {
        //     serverObject.serviceLocationId = null;
        // }

        serverObject.endDate = serverObject.startDate;

        return serverObject;
      };

      PACJobModel.prototype.toServerSObject = function() {
				var timezone = this.region ? this.region.timezone.id : null;
				var dateInfo = {
					startDate: this.startDate,
					endDate: this.endDate,
					startTime: this.startTime || 0,
					endTime: this.endTime || 0,
				}

				if(this.endTime === 2400) {
					dateInfo.endDate = moment(dateInfo.endDate).add(1, 'd').toDate();
					dateInfo.endTime = 0;
				}

				dateInfo = util.checkOvernight(dateInfo);

        var originalJobTags = this.originalJobTags;
        var originalJobTasks = this.originalJobTasks;
				var $this = this;
				var serverObject = {
					Id: this.id,
					sked__Type__c: this.eventType
						? angular.isString(this.eventType)
							? this.eventType
							: this.eventType.id
						: null,
					sked__Address__c: this.address ? this.address.fullAddress : null,
					sked__GeoLocation__Latitude__s: (this.address && this.address.geometry) ? this.address.geometry.lat : null,
					sked__GeoLocation__Longitude__s: (this.address && this.address.geometry) ? this.address.geometry.lng : null,
					sked__Start__c: dateUtil.parseDateTimeInfo({
						date: dateInfo.startDate,
						timeNumber: dateInfo.startTime
					}, timezone),
					sked__Finish__c: dateUtil.parseDateTimeInfo({
						date: dateInfo.endDate,
						timeNumber: dateInfo.endTime
					}, timezone),
					sked__Region__c: this.region ? this.region.id : null,
          sked__Contact__c: this.contact ? this.contact.id : null,
          sked__Account__c: this.patientId,
          sked_Support_Plan__c: this.supportPlan ? this.supportPlan.id : null,
          sked_Lone_Worker_Risk__c: this.loneWorkerRisk,
          sked_Inherit_Account_Tasks__c: this.inheritAccountTasks,
          sked_Group_Event__c: this.groupEventId,
					sked__JobTags__r: angular.isArray(
						this.tags
					)	
						? this.tags.map(function(tag) {
							var originalJobTag = _.find(originalJobTags, {tagId: tag.id});
							return {
								Id: originalJobTag ? originalJobTag.id : null,
								sked__Job__c: $this.id,
								sked__Tag__c: tag.id
							};
						})
						: [],
					sked__Recurring_Schedule__c: this.scheduleId,
					sked__Notes_Comments__c: this.notes || '',
					sked__Description__c: this.description || '',
          sked__Quantity__c: this.quantity,
  
          sked__JobTasks__r: angular.isArray(
						this.jobTasks._list
					)	
						? this.jobTasks._list.map(function(item, index) {
              var originalJobTask = _.find(originalJobTasks, {id: item.id});
							return {
                Id: originalJobTask ? originalJobTask.id : null,
                sked__Job__c: $this.id,
                Name: item.name,
                sked__Description__c: item.description,
                sked_Source_account_Task__c: item.sourceAccountTaskId,
                sked__Seq__c: index + 1
							};
						})
						: [],
				};

        if (this.serviceLocation) {
          if (this.serviceLocation.id === 'Other') {
            serverObject.sked__Location__c = null;
          } else {
            serverObject.sked__Location__c = this.serviceLocation ? this.serviceLocation.id : null;
            serverObject.sked__Address__c = null;
            serverObject.sked__GeoLocation__Latitude__s = null;
            serverObject.sked__GeoLocation__Longitude__s = null;

            if(this.serviceLocation.address) {
              serverObject.sked__Address__c = this.serviceLocation.address ? this.serviceLocation.address.fullAddress : null;
              serverObject.sked__GeoLocation__Latitude__s = (this.serviceLocation.address && this.serviceLocation.address.geometry) ? this.serviceLocation.address.geometry.lat : null;
              serverObject.sked__GeoLocation__Longitude__s = (this.serviceLocation.address && this.serviceLocation.address.geometry) ? this.serviceLocation.address.geometry.lng : null;
            }
          }
        } else {
          //based on patient availability
          serverObject.sked__Location__c = null;
          serverObject.sked__Address__c = null;
          serverObject.sked__GeoLocation__Latitude__s = null;
          serverObject.sked__GeoLocation__Longitude__s = null;
        }

				serverObject.sked__Duration__c = (serverObject.sked__Finish__c - serverObject.sked__Start__c) / 60 / 1000;
				
				return serverObject;
			};

      /**
       * PACJobExceptionModel
       */
      function PACJobExceptionModel() {
        this.supportPlanName = null;
        this.exceptionCode = null;
        this.job = null;
        this.resource = null;
        this.patientName = null;

        this.createdTimestamp = null;
        this.createdOnDate = null;
        this.createdOnTime = null;
      }

      PACJobExceptionModel.fromServer = function (serverObject, configData) {
        var model = null;

        if (serverObject) {
          model = new PACJobExceptionModel();

          model.supportPlanName = serverObject.supportPlanName;
          model.exceptionCode = serverObject.exceptionCode;
          model.patientName = serverObject.patientName;
          model.job = PACJobModel.fromServer(serverObject.job, configData);
          model.resource = ResourceModel.fromServer(serverObject.resource);

          model.createdOnDate = dateUtil.parseDateString(
            serverObject.createdOnDate
          );
          model.createdOnTime = serverObject.createdOnTime;
          model.createdTimestamp = dateUtil.parseDateTime(
            model.createdOnDate,
            model.createdOnTime
          );

          if (angular.isDate(model.createdTimestamp)) {
            model.createdTimestamp = model.createdTimestamp.getTime();
          }
        }

        return model;
      };

      PACJobExceptionModel.fromServerList = function (serverList, configData) {
        return serverList.map(function (item) {
          return PACJobExceptionModel.fromServer(item, configData);
        });
      };

      /**
       * PACGridDataModel
       */
      function PACGridDataModel() {
        this.availabilities = [];
        this.events = [];
        this.clientEvents = [];
        this.schedules = [];
        this.timezone = null;
        this.today = null;
      }

      PACGridDataModel.fromServer = function (serverObject, configData) {
        var model = null;

        if (serverObject) {
          model = new PACGridDataModel();

          model.availabilities = PACAvailabilityModel.fromServerList(
            serverObject.availabilities || [],
            configData
          );
          model.events = PACJobModel.fromServerList(
            serverObject.events || [],
            configData
          );
          model.clientEvents = serverObject.clientEvents;
          model.schedules = ScheduleModel.fromServerList(
            serverObject.recurringSchedules
          );
          model.timezone = serverObject.timezone;
          model.today = dateUtil.parseDateString(serverObject.today);
        }

        return model;
      };

      /**
       * JobAllocationModel
       */
      function JobAllocationModel(id) {
        this.id = id || null;
        this.startFromLocation = null; // Location/AddressModel
        this.travelDistanceFrom = 0;
        this.travelTimeFrom = 0;
        this.isAvailable = false;
        this.isQualified = false;
        this.noOfAvailableClasses = 0;
        this.status = null;
        this.resource = null;
      }

      JobAllocationModel.fromSObject = function(
				serverObject,
				serverList,
				timezoneSidId
			) {
				var allocation = null;
				if (serverObject) {
					allocation = new JobAllocationModel();

					allocation.id = serverObject.Id;
					if(serverObject.sked__Resource__r) {
						allocation.resource = ResourceModel.fromSObject(serverObject.sked__Resource__r);
					} else if (serverObject.sked__Resource__c) {
						allocation.resource = ResourceModel.fromServer({
							id: serverObject.sked__Resource__c
						})
					}
				}

				return allocation;
      };
      
      JobAllocationModel.fromServer = function (serverObject) {
        var jobAllocation = null;

        if (serverObject) {
          jobAllocation = new JobAllocationModel(serverObject.id);

          jobAllocation.startFromLocation = AddressModel.fromServer(
            serverObject.startFromLocation
          );
          //jobAllocation.distance = (angular.isNumber(serverObject.distance))?serverObject.distance.toFixed(2):0;
          jobAllocation.travelDistanceFrom = serverObject.travelDistanceFrom;
          jobAllocation.travelTimeFrom = serverObject.travelTimeFrom;
          jobAllocation.isAvailable = serverObject.isAvailable || false;
          jobAllocation.isQualified = serverObject.isQualified || false;
          jobAllocation.noOfAvailableClasses =
            serverObject.noOfAvailableClasses || 0;
          jobAllocation.status = serverObject.status;

          if (serverObject.resource) {
            jobAllocation.resource = ResourceModel.fromServer(
              serverObject.resource
            );
          } else if (serverObject.resourceId) {
            jobAllocation.resource = new ResourceModel(serverObject.resourceId);
          }
        }

        return jobAllocation;
      };

      JobAllocationModel.fromServerList = function (serverList) {
        return mapArray(serverList, JobAllocationModel.fromServer);
      };

      /**
       * JobOfferModel
       */
      function JobOfferModel(id) {
        this.id = id || null;
        this.startFromLocation = null; // Location/AddressModel
        this.travelDistanceFrom = 0;
        this.travelTimeFrom = 0;
        this.isAvailable = false;
        this.isQualified = false;
        this.noOfAvailableClasses = 0;
        this.status = null;
        this.resource = null;
      }

      JobOfferModel.fromServer = function (serverObject) {
        var jobOffer = null;

        if (serverObject) {
          jobOffer = new JobOfferModel(serverObject.id);

          jobOffer.startFromLocation = AddressModel.fromServer(
            serverObject.startFromLocation
          );
          //jobOffer.distance = (angular.isNumber(serverObject.distance))?serverObject.distance.toFixed(2):0;
          jobOffer.travelDistanceFrom = serverObject.travelDistanceFrom;
          jobOffer.travelTimeFrom = serverObject.travelTimeFrom;
          jobOffer.isAvailable = serverObject.isAvailable || false;
          jobOffer.isQualified = serverObject.isQualified || false;
          jobOffer.noOfAvailableClasses =
            serverObject.noOfAvailableClasses || 0;
          jobOffer.status = serverObject.status;
          jobOffer.response = serverObject.response;

          if (serverObject.resource) {
            jobOffer.resource = ResourceModel.fromServer(serverObject.resource);
          } else if (serverObject.resourceId) {
            jobOffer.resource = new ResourceModel(serverObject.resourceId);
          }
        }

        return jobOffer;
      };

      JobOfferModel.fromResourceJobOfferSObject = function(serverObject) {
				var jobOffer = null;

				if (serverObject) {
					jobOffer = new JobOfferModel(serverObject.Id);
				
					jobOffer.status = serverObject.sked__Status__c;
					jobOffer.response = serverObject.sked__Response__c;
					if (serverObject.sked__Resource__r) {
						jobOffer.resource = ResourceModel.fromSObject(serverObject.sked__Resource__c);
					} else if (serverObject.sked__Resource__c) {
						jobOffer.resource = new ResourceModel(serverObject.sked__Resource__c);
					}
				}

				return jobOffer;
      };
      
      JobOfferModel.fromServerList = function (serverList) {
        return mapArray(serverList, JobOfferModel.fromServer);
      };

      /**
       * ScheduleModel
       */
      function ScheduleModel(id, name) {
        this.id = id || null;

        this.name = name || '';
        this.description = '';
        this.template = null;
        this.skipHolidays = false;
      }

      ScheduleModel.fromServer = function (serverObject) {
        var schedule = null;

        if (serverObject) {
          schedule = new ScheduleModel(serverObject.id, serverObject.name);

          schedule.description = serverObject.description;
          schedule.template = TemplateModel.fromServer(
            serverObject.availabilityTemplate
          );
          schedule.skipHolidays = !!serverObject.skipHolidays;
        }

        return schedule;
      };

      ScheduleModel.fromServerList = function (serverList) {
        return mapArray(serverList, ScheduleModel.fromServer);
      };

      /**
       * TemplateModel
       */
      function TemplateModel(id, name) {
        this.id = id || null;

        this.name = name || '';
        this.startDate = null;
        this.endDate = null;
        this.entries = [];
        this.timezoneSidId = '';
      }

      TemplateModel.fromServer = function (serverObject) {
        var template = null;

        if (serverObject) {
          template = new TemplateModel(serverObject.id, serverObject.name);

          template.startDate = dateUtil.parseDateString(serverObject.startDate);
          template.endDate = dateUtil.parseDateString(serverObject.endDate);
          template.entries = TemplateEntryModel.fromServerList(
            serverObject.availabilityTemplateEntries
          );
          template.timezoneSidId = serverObject.timezoneSidId;
        }

        return template;
      };

      TemplateModel.fromSObject = function (
        serverObject,
        serverList,
        timezoneSidId
      ) {
        var template = null,
          startDateTime,
          endDateTime;

        if (serverObject) {
          template = new TemplateModel(serverObject.Id, serverObject.Name);

          startDateTime = dateUtil.getDateTimeInfo(
            serverObject.sked__Start__c,
            timezoneSidId
          );
          endDateTime = dateUtil.getDateTimeInfo(
            serverObject.sked__End__c,
            timezoneSidId
          );

          template.startDate = startDateTime.date;
          template.endDate = endDateTime.date;
          template.entries = TemplateEntryModel.fromServerList(
            serverObject.sked__Availability_Template_Entries__r,
            true,
            timezoneSidId
          );
          template.timezoneSidId = serverObject.timezoneSidId;
        }

        return template;
      };

      TemplateModel.fromServerList = function (
        serverList,
        fromSObject,
        timezoneSidId
      ) {
        return mapArray(
          serverList,
          fromSObject === true ?
          TemplateModel.fromSObject :
          TemplateModel.fromServer,
          timezoneSidId
        );
      };

      /**
       * TemplateEntryModel
       */
      function TemplateEntryModel(id) {
        this.id = id || null;

        this.weekNo = 0;
        this.weekday = '';
        this.startTime = 0;
        this.endTime = 0;
        this.isAvailable = false;
      }

      TemplateEntryModel.fromServer = function (serverObject) {
        var templateEntry = null;

        if (serverObject) {
          templateEntry = new TemplateEntryModel(serverObject.id);

          templateEntry.weekNo = serverObject.weekNo;
          templateEntry.weekday = serverObject.weekday;
          templateEntry.startTime = serverObject.startTime;
          templateEntry.endTime = serverObject.endTime;
          templateEntry.isAvailable = !!serverObject.isAvailable;
        }

        return templateEntry;
      };

      TemplateEntryModel.fromSObject = function (serverObject) {
        var templateEntry = null;

        if (serverObject) {
          templateEntry = new TemplateEntryModel(serverObject.Id);

          templateEntry.weekNo = serverObject.sked__Week_No__c;
          templateEntry.weekday = serverObject.sked__Weekday__c;
          templateEntry.startTime = serverObject.sked__Start_Time__c;
          templateEntry.endTime = serverObject.sked__Finish_Time__c;
          templateEntry.isAvailable = !!serverObject.sked__Is_Available__c;
        }

        return templateEntry;
      };

      TemplateEntryModel.fromServerList = function (
        serverList,
        fromSObject,
        timezoneSidId
      ) {
        return mapArray(
          serverList,
          fromSObject === true ?
          TemplateEntryModel.fromSObject :
          TemplateEntryModel.fromServer,
          timezoneSidId
        );
      };

      /**
       * ELCFilterModel
       */
      function ELCFilterModel() {
        this.regions = [];
        this.jobTypes = [];
      }

      ELCFilterModel.fromServer = function (serverObject) {
        var model = null;

        if (serverObject) {
          model = new ELCFilterModel();
        }

        return model;
      };

      ELCFilterModel.prototype.toServer = function () {
        var serverObject = {
          regionIds: _.map(this.regions, 'id'),
          jobTypes: _.map(this.jobTypes, 'id')
        };

        return serverObject;
      };

      // TODO: CaseSchedulingModel is not using in any code
      // should we remove this?
      function CaseSchedulingModel() {
        this.address = null;
        this.appointments = [];
        this.timeSinceReferralAcceptance = '';
      }

      CaseSchedulingModel.fromServer = function (serverObject) {
        var caseScheduling = null;

        if (serverObject) {
          caseScheduling = new CaseSchedulingModel();
          caseScheduling.address = AddressModel.fromServer(
            serverObject.address
          );
          caseScheduling.timeSinceReferralAcceptance =
            serverObject.timeSinceReferralAcceptance;
          caseScheduling.appointments = CaseSchedulingAppointmentModel.fromServerList(
            serverObject.appointments
          );
        }

        return caseScheduling;
      };

      // TODO: CaseSchedulingAppointmentModel is only use for CaseSchedulingModel
      // should we remove this?
      function CaseSchedulingAppointmentModel(id) {
        this.id = id;
        this.appointmentType = '';
        this.discipline = '';
        this.requestedDate = null;
        this.appointmentDate = null;
        this.duration = '';
        this.couldNotSchedule = false;
        this.isConfirmed = false;
        this.associatedResources = null;
      }

      CaseSchedulingAppointmentModel.fromServer = function (serverObject) {
        var caseSchedulingAppointment = null;

        if (serverObject) {
          caseSchedulingAppointment = new CaseSchedulingAppointmentModel(
            serverObject.id
          );

          caseSchedulingAppointment.appointmentType = PicklistItemModel.fromId(
            serverObject.eventType
          );
          caseSchedulingAppointment.discipline = serverObject.discipline;
          caseSchedulingAppointment.requestedDate = dateUtil.parseDateString(
            serverObject.requestedDate
          );
          caseSchedulingAppointment.appointmentDate = dateUtil.parseDateString(
            serverObject.startDate
          );
          caseSchedulingAppointment.duration = serverObject.duration;
          caseSchedulingAppointment.couldNotSchedule = !!serverObject.couldNotSchedule;
          caseSchedulingAppointment.isConfirmed = !!serverObject.isConfirmed;
          caseSchedulingAppointment.associatedResources = CaseSchedulingAppointmentEmployeeModel.fromServerList(
            serverObject.jobAllocations
          );
        }

        return caseSchedulingAppointment;
      };

      CaseSchedulingAppointmentModel.fromServerList = function (serverList) {
        return mapArray(serverList, CaseSchedulingAppointmentModel.fromServer);
      };

      // TODO: CaseSchedulingAppointmentEmployeeModel is only use for CaseSchedulingAppointmentModel
      // should we remove this?
      function CaseSchedulingAppointmentEmployeeModel(id) {
        this.id = id;
        this.resource = null;
        this.priority = null;
        this.estimatedTimeOfArrival = '';
        this.startTime = null;
        this.endTime = null;
        this.startDate = null;
        this.endDate = null;
      }

      CaseSchedulingAppointmentEmployeeModel.fromServer = function (
        serverObject
      ) {
        var model = null;

        if (serverObject) {
          model = new CaseSchedulingAppointmentEmployeeModel(serverObject.id);

          model.resource = ResourceModel.fromServer(serverObject.resource);
          model.priority = serverObject.priority;
          model.estimatedTimeOfArrival = serverObject.estimatedTimeOfArrival;

          model.startTime = serverObject.startTime;
          model.endTime = serverObject.endTime;
          model.startDate = dateUtil.parseDateString(serverObject.startDate);
          model.endDate = dateUtil.parseDateString(serverObject.endDate);
        }

        return model;
      };

      CaseSchedulingAppointmentEmployeeModel.fromServerList = function (
        serverList
      ) {
        return mapArray(
          serverList,
          CaseSchedulingAppointmentEmployeeModel.fromServer
        );
      };

      CaseSchedulingAppointmentEmployeeModel.prototype.toServer = function () {
        var serverObject = {
          id: this.id,
          resourceId: this.resource.id,
          startTime: this.startTime,
          endTime: this.endTime,
          startDate: dateUtil.dateToString(this.startDate),
          endDate: dateUtil.dateToString(this.endDate)
        };

        return serverObject;
      };

      /**
       * CarePlanModel
       */
      function CarePlanModel(id, name) {
        this.id = id || null;
        this.name = this.label = name || '';
        this.contact = null;
        this.selected = false;
      }

      CarePlanModel.fromServer = function (serverObject) {
        var carePlan = null;

        if (serverObject) {
          carePlan = new CarePlanModel(
            serverObject.id,
            serverObject.name + ' (' + serverObject.status + ')'
          );

          carePlan.contact = serverObject.contactId ?
            new ContactModel(serverObject.contactId) :
            null;
          carePlan.selected = serverObject.selected || false;
        }

        return carePlan;
      };

      CarePlanModel.fromServerList = function (serverList) {
        return mapArray(serverList, CarePlanModel.fromServer);
      };

      CarePlanModel.prototype.toServer = function () {
        return this.id;
      };

      function PermissionSetAssignmentRuleModel(id, name) {
        this.id = id;
        this.name = name;
        this._permissionSetIds = [];
        this.permissionSets = [];
        this.profile = null;
        this.skeduloUserType = null;
        this.action = null;
      }

      PermissionSetAssignmentRuleModel.fromServer = function (serverObject) {
        var permissionSetAssignmentRule = null;

        if (serverObject) {
          permissionSetAssignmentRule = new PermissionSetAssignmentRuleModel(
            serverObject.id,
            serverObject.name
          );
          // temporary stor this list, wait for the full list to update real array
          permissionSetAssignmentRule._permissionSetIds = serverObject.permissionSetIds;
          permissionSetAssignmentRule.profile = PicklistItemModel.fromId(
            serverObject.profileId
          );
          permissionSetAssignmentRule.skeduloUserType = serverObject.skeduloUserType;
          permissionSetAssignmentRule.action = ACTION_METHOD.UPDATE;
        }

        return permissionSetAssignmentRule;
      };

      PermissionSetAssignmentRuleModel.fromServerList = function (serverList) {
        return mapArray(
          serverList,
          PermissionSetAssignmentRuleModel.fromServer
        );
      };

      PermissionSetAssignmentRuleModel.prototype.delete = function () {
        this.action = ACTION_METHOD.DELETE;
      };

      // TODO: move this function to a getter
      PermissionSetAssignmentRuleModel.prototype.canShow = function () {
        return this.action !== ACTION_METHOD.DELETE;
      };

      PermissionSetAssignmentRuleModel.prototype.toServer = function () {
        return {
          id: this.isNew() ? null : this.id,
          action: this.action,
          name: this.name,
          permissionSetIds: _.map(this.permissionSets, 'id'),
          profileId: _.get(this, 'profile.id', ''),
          skeduloUserType: this.skeduloUserType
        };
      };

      PermissionSetAssignmentRuleModel.prototype.delete = function () {
        this.action = ACTION_METHOD.DELETE;
      };

      PermissionSetAssignmentRuleModel.prototype.isNew = function () {
        return this.action === ACTION_METHOD.CREATE;
      };

      PermissionSetAssignmentRuleModel.prototype.generatePermssionSets = function (
        skeduloPermissionSets
      ) {
        this.permissionSets = _.filter(
          skeduloPermissionSets,
          function (skedduloPermissionSet) {
            return (
              _.indexOf(this._permissionSetIds, skedduloPermissionSet.id) >= 0
            );
          }.bind(this)
        );
      };

      /**
       *  PermissionSettingModel
       *  Use in admin to control Permission settings
       */

      function PermissionSettingModel() {
        this.autoApplySkeduloLicense = null;
        this.permissionSetAssignmentRules = [];
      }

      PermissionSettingModel.fromServer = function (serverObject) {
        var permissionSetting = null;

        if (serverObject) {
          permissionSetting = new PermissionSettingModel();
          permissionSetting.autoApplySkeduloLicense =
            serverObject.autoApplySkeduloLicense;
          permissionSetting.permissionSetAssignmentRules = PermissionSetAssignmentRuleModel.fromServerList(
            serverObject.permissionSetAssignmentRules
          );
        }

        return permissionSetting;
      };

      PermissionSettingModel.prototype.addNewPermissionRule = function () {
        var permissionSetAssignmentRule = new PermissionSetAssignmentRuleModel(
          _.uniqueId('permissionSetAssignmentRule') // temporary id to make sure every record have an unique identification
        );
        permissionSetAssignmentRule.action = ACTION_METHOD.CREATE;
        this.permissionSetAssignmentRules.push(permissionSetAssignmentRule);
      };

      PermissionSettingModel.prototype.deletePermissionRule = function (
        permissionSetAssignmentRule
      ) {
        if (permissionSetAssignmentRule.isNew()) {
          _.pull(
            this.permissionSetAssignmentRules,
            permissionSetAssignmentRule
          );
        } else {
          permissionSetAssignmentRule.delete();
        }
      };

      PermissionSettingModel.prototype.updatePermissionSetsOptions = function (
        skeduloPermissionSets
      ) {
        _.forEach(this.permissionSetAssignmentRules, function (
          permissionSetAssignmentRule
        ) {
          permissionSetAssignmentRule.generatePermssionSets(
            skeduloPermissionSets
          );
        });
      };

      PermissionSettingModel.prototype.toServer = function () {
        return {
          autoApplySkeduloLicense: this.autoApplySkeduloLicense,
          permissionSetAssignmentRules: mapArray(
            this.permissionSetAssignmentRules,
            'toServer'
          )
        };
      };

      /**
       *  PermissionSettingsConfigModel
       *  Use in admin to provide data for dropdown
       */

      function PermissionSettingsConfigModel() {
        this.profiles = [];
        this.skeduloPermissionSets = [];
        this.skeduloUserTypes = [];
      }

      PermissionSettingsConfigModel.fromServer = function (serverObject) {
        var permissionSettingsConfig = null;

        if (serverObject) {
          permissionSettingsConfig = new PermissionSettingsConfigModel();
          permissionSettingsConfig.profiles = serverObject.profiles;
          permissionSettingsConfig.skeduloPermissionSets = PicklistItemModel.fromServerList(
            serverObject.skeduloPermissionSets
          );
          permissionSettingsConfig.skeduloUserTypes =
            serverObject.skeduloUserTypes;
        }

        return permissionSettingsConfig;
      };

      function AssessmentSettingConfigModel() {
        this.supportPlanCustomFields = [];
      }

      AssessmentSettingConfigModel.fromServer = function (serverObject) {
        var assessmentSettingConfig = null;

        if (serverObject) {
          assessmentSettingConfig = new AssessmentSettingConfigModel();
          assessmentSettingConfig.supportPlanCustomFields = PicklistItemModel.fromServerList(
            serverObject.supportPlanCustomFields
          );
        }

        return assessmentSettingConfig;
      };

      function AssessmentHelpTextModel(data) {
        this.id = data.id;
        this.name = data.fieldApiName;
        this.fieldApiName = data.fieldApiName;
        this.helpText = data.helpText;
      }

      AssessmentHelpTextModel.fromServer = function (serverObject) {
        var assessmentHelpText = null;

        if (serverObject) {
          assessmentHelpText = new AssessmentHelpTextModel(serverObject);
        }

        return assessmentHelpText;
      };
      AssessmentHelpTextModel.prototype.markDirty = function () {
        this.action = ACTION_METHOD.UPDATE;
      };

      AssessmentHelpTextModel.fromServerList = function (serverList) {
        return mapArray(serverList, AssessmentHelpTextModel.fromServer);
      };

      AssessmentHelpTextModel.prototype.toServer = function () {
        return {
          id: this.id,
          name: this.fieldApiName,
          fieldApiName: this.fieldApiName,
          helpText: this.helpText,
          action: this.action
        };
      };

      function AssessmentHelpTextSettingModel() {
        this.assessmentHelpTexts = [];
        this.deletedItems = [];
      }

      AssessmentHelpTextSettingModel.fromServer = function (serverObject) {
        var assessmentHelpTextSetting = new AssessmentHelpTextSettingModel();
        assessmentHelpTextSetting.assessmentHelpTexts = AssessmentHelpTextModel.fromServerList(
          serverObject
        );

        return assessmentHelpTextSetting;
      };

      AssessmentHelpTextSettingModel.prototype.addNewItem = function () {
        var newAssessmentHelpText = new AssessmentHelpTextModel({});
        newAssessmentHelpText.action = ACTION_METHOD.CREATE;
        this.assessmentHelpTexts.push(newAssessmentHelpText);
      };

      AssessmentHelpTextSettingModel.prototype.deleteItem = function (item) {
        this.assessmentHelpTexts.splice(
          this.assessmentHelpTexts.indexOf(item),
          1
        );
        if (item.action !== ACTION_METHOD.CREATE) {
          item.action = ACTION_METHOD.DELETE;
          this.deletedItems.push(item);
        }
      };

      AssessmentHelpTextSettingModel.prototype.toServer = function () {
        return []
          .concat(
            this.assessmentHelpTexts.filter(function (item) {
              return !!item.action;
            }),
            this.deletedItems
          )
          .map(function (item) {
            return item.toServer();
          });
      };

      /**
       *  ExpenseSettingModel
       *  Use in admin to control Expanese and Millage settings
       */
      function ExpenseSettingModel() {
        this.multiplePassengerClaimRate = 0;
        this.singlePassengerClaimRate = 0;
      }

      ExpenseSettingModel.fromServer = function (serverObject) {
        var expenseSetting = null;
        if (serverObject) {
          expenseSetting = new ExpenseSettingModel();
          expenseSetting.singlePassengerClaimRate =
            serverObject.singlePassengerClaimRate;
          expenseSetting.multiplePassengerClaimRate =
            serverObject.multiplePassengerClaimRate;
        }

        return expenseSetting;
      };

      ExpenseSettingModel.prototype.toServer = function () {
        return {
          singlePassengerClaimRate: this.singlePassengerClaimRate,
          multiplePassengerClaimRate: this.multiplePassengerClaimRate
        };
      };

      /**
       * LocationSettingModel
       * use in admin console to controll location settings
       */
      function LocationSettingModel() {
        this.automaticCreateLocation = false;
        this.automaticUpdateLocation = false;
        this.makeNewLocationDefault = false;
        this.defaultLocationType = '';
      }

      LocationSettingModel.fromServer = function (serverObject) {
        var locationSetting;
        if (serverObject) {
          locationSetting = new LocationSettingModel();
          locationSetting.automaticCreateLocation = serverObject.automaticCreateLocation;
          locationSetting.automaticUpdateLocation =
            serverObject.automaticUpdateLocation;
          locationSetting.makeNewLocationDefault =
            serverObject.makeNewLocationDefault;
          locationSetting.defaultLocationType =
            serverObject.defaultLocationType;
        }

        return locationSetting;
      };

      LocationSettingModel.prototype.toServer = function () {
        return {
          automaticCreateLocation: this.automaticCreateLocation,
          automaticUpdateLocation: this.automaticUpdateLocation,
          makeNewLocationDefault: this.makeNewLocationDefault,
          defaultLocationType: this.defaultLocationType
        };
      };

      /**
       * AuditSettingModel
       * use in admin console to controll audit score band settings
       */
      function AuditSettingModel(data) {
        this.blueBandMinScore = data.blueBandMinScore;
        this.greenBandMinScore = data.greenBandMinScore;
        this.amberBandMinScore = data.amberBandMinScore;
      }

      AuditSettingModel.fromServer = function (serverObject) {
        var auditSetting;
        if (serverObject) {
          auditSetting = new AuditSettingModel(serverObject);
        }

        return auditSetting;
      };

      AuditSettingModel.prototype.toServer = function () {
        return {
          blueBandMinScore: this.blueBandMinScore,
          greenBandMinScore: this.greenBandMinScore,
          amberBandMinScore: this.amberBandMinScore
        };
      };

      /**
       * MobileSettingModel
       * use in admin console to controll audit mobile display settings
       */
      function MobileSettingModel(data) {
        this.displayAccidentsIncidentsWithin = data.displayAccidentsIncidentsWithin;
        this.displayActivitiesObservationsWithin = data.displayActivitiesObservationsWithin;
        this.displayAuditsWithin = data.displayAuditsWithin;
        this.showActiveAuditsOnly = data.showActiveAuditsOnly;
        this.hideClosedOutcomes = data.hideClosedOutcomes;
        this.hideClosedSupportGuidance = data.hideClosedSupportGuidance;
        this.showActiveTasksOnly = data.showActiveTasksOnly;
      }

      MobileSettingModel.fromServer = function (serverObj) {
        var mobileSetting;
        if (serverObj) {
          mobileSetting = new MobileSettingModel(serverObj);
        }

        return mobileSetting;
      };

      MobileSettingModel.prototype.toServer = function () {
        return {
          displayAccidentsIncidentsWithin: this.displayAccidentsIncidentsWithin,
          displayActivitiesObservationsWithin: this.displayActivitiesObservationsWithin,
          displayAuditsWithin: this.displayAuditsWithin,
          showActiveAuditsOnly: this.showActiveAuditsOnly,
          hideClosedOutcomes: this.hideClosedOutcomes,
          hideClosedSupportGuidance: this.hideClosedSupportGuidance,
          showActiveTasksOnly: this.showActiveTasksOnly
        };
      };

      /**
       * LoneWorkerSettingModel
       * use in admin console to controll audit lone worker alert settings
       */
      function LoneWorkerSettingModel(data) {
        this.maximumElapsedMinutes = data.maximumElapsedMinutes;
        this.alertEmail = data.alertEmail;

        this.sendCheckInReminder = data.sendCheckInReminder;
        this.maximumElapsedMinutesResource = data.maximumElapsedMinutesResource;
        this.maximumElapsedMinutesBetweenNotification = data.maximumElapsedMinutesBetweenNotification;
        this.maximumNotification = data.maximumNotification;
      }

      LoneWorkerSettingModel.fromServer = function (serverObject) {
        var loneWorkerSetting;
        if (serverObject) {
          loneWorkerSetting = new LoneWorkerSettingModel(serverObject);
        }

        return loneWorkerSetting;
      };

      LoneWorkerSettingModel.prototype.toServer = function () {
        return {
          maximumElapsedMinutes: this.maximumElapsedMinutes,
          alertEmail: this.alertEmail,
          sendCheckInReminder: this.sendCheckInReminder,
          maximumElapsedMinutesResource: this.maximumElapsedMinutesResource,
          maximumElapsedMinutesBetweenNotification: this.maximumElapsedMinutesBetweenNotification,
          maximumNotification: this.maximumNotification
        };
      };

      /**
       * Service User Field Mapping Config, store all possible value for referralCustomFields and serviceUserCustomFields
       */
      function ServiceUserFieldMappingConfigModel() {
        this.referralCustomFields = [];
        this.serviceUserCustomFields = [];
      }

      ServiceUserFieldMappingConfigModel.fromServer = function (serverObject) {
        var assessmentSettingConfig = null;

        if (serverObject) {
          assessmentSettingConfig = new ServiceUserFieldMappingConfigModel();
          assessmentSettingConfig.referralCustomFields = PicklistItemModel.fromServerList(
            serverObject.referralCustomFields
          );
          assessmentSettingConfig.serviceUserCustomFields = PicklistItemModel.fromServerList(
            serverObject.serviceUserCustomFields
          );
        }

        return assessmentSettingConfig;
      };

      /**
       * Service User Field Mapping Model
       */
      function ServiceUserFieldMappingModel(data) {
        this.id = data.id;
        this.name = data.name;
        this.referalFieldApi = data.referalFieldApi;
        this.serviceUserFieldApi = data.serviceUserFieldApi;
      }

      ServiceUserFieldMappingModel.fromServer = function (serverObject) {
        var serviceUserFieldMapping = null;

        if (serverObject) {
          serviceUserFieldMapping = new ServiceUserFieldMappingModel(serverObject);
        }

        return serviceUserFieldMapping;
      };

      ServiceUserFieldMappingModel.prototype.markDirty = function () {
        this.action = ACTION_METHOD.UPDATE;
      };

      ServiceUserFieldMappingModel.fromServerList = function (serverList) {
        return mapArray(serverList, ServiceUserFieldMappingModel.fromServer);
      };

      ServiceUserFieldMappingModel.prototype.toServer = function () {
        return {
          id: this.id,
          name: this.referalFieldApi,
          referalFieldApi: this.referalFieldApi,
          serviceUserFieldApi: this.serviceUserFieldApi,
          action: this.action
        };
      };


      /**
       * Service User Field Mapping Setting Model, handle setting as an collection so we can easy handle edit and remmove etc...
       */
      function ServiceUserFieldMappingSettingModel() {
        this.serviceUserFieldMappings = [];
        this.deletedItems = [];
      }

      ServiceUserFieldMappingSettingModel.fromServer = function (serverObject) {
        var serviceUserFieldMappingSettingModel = new ServiceUserFieldMappingSettingModel();
        serviceUserFieldMappingSettingModel.serviceUserFieldMappings = ServiceUserFieldMappingModel.fromServerList(
          serverObject
        );

        return serviceUserFieldMappingSettingModel;
      };

      ServiceUserFieldMappingSettingModel.prototype.addNewItem = function () {
        var newServiceUserFieldMapping = new ServiceUserFieldMappingModel({});
        newServiceUserFieldMapping.action = ACTION_METHOD.CREATE;
        this.serviceUserFieldMappings.push(newServiceUserFieldMapping);
      };

      ServiceUserFieldMappingSettingModel.prototype.deleteItem = function (item) {
        this.serviceUserFieldMappings.splice(
          this.serviceUserFieldMappings.indexOf(item),
          1
        );
        if (item.action !== ACTION_METHOD.CREATE) {
          item.action = ACTION_METHOD.DELETE;
          this.deletedItems.push(item);
        }
      };

      ServiceUserFieldMappingSettingModel.prototype.toServer = function () {
        return []
          .concat(
            this.serviceUserFieldMappings.filter(function (item) {
              return !!item.action;
            }),
            this.deletedItems
          )
          .map(function (item) {
            return item.toServer();
          });
      };

      /**
       * Service User Field Mapping Model
       */
      function MobileLookupFieldModel(data) {
        this.id = data.id;
        this.name = data.name;
        this.objectApi = data.objectApi;
        this.labelFieldApi = data.labelFieldApi;
      }

      MobileLookupFieldModel.fromServer = function (serverObject) {
        var mobileLookupField = null;

        if (serverObject) {
          mobileLookupField = new MobileLookupFieldModel(serverObject);
        }

        return mobileLookupField;
      };

      MobileLookupFieldModel.prototype.markDirty = function () {
        this.action = ACTION_METHOD.UPDATE;
      };

      MobileLookupFieldModel.fromServerList = function (serverList) {
        return mapArray(serverList, MobileLookupFieldModel.fromServer);
      };

      MobileLookupFieldModel.prototype.toServer = function () {
        return {
          id: this.id,
          name: this.objectApi,
          objectApi: this.objectApi,
          labelFieldApi: this.labelFieldApi,
          action: this.action
        };
      };
      /**
       * Service User Field Mapping Setting Model, handle setting as an collection so we can easy handle edit and remmove etc...
       */
      function MobileLookupFieldSettingModel() {
        this.mobileLookupFields = [];
        this.deletedItems = [];
      }

      MobileLookupFieldSettingModel.fromServer = function (serverObject) {
        var mobileLookupFieldSetting = new MobileLookupFieldSettingModel();
        mobileLookupFieldSetting.mobileLookupFields = MobileLookupFieldModel.fromServerList(
          serverObject
        );

        return mobileLookupFieldSetting;
      };

      MobileLookupFieldSettingModel.prototype.addNewItem = function () {
        var mobileLookupField = new MobileLookupFieldModel({});
        mobileLookupField.action = ACTION_METHOD.CREATE;
        this.mobileLookupFields.push(mobileLookupField);
      };

      MobileLookupFieldSettingModel.prototype.deleteItem = function (item) {
        this.mobileLookupFields.splice(
          this.mobileLookupFields.indexOf(item),
          1
        );
        if (item.action !== ACTION_METHOD.CREATE) {
          item.action = ACTION_METHOD.DELETE;
          this.deletedItems.push(item);
        }
      };

      MobileLookupFieldSettingModel.prototype.toServer = function () {
        return []
          .concat(
            this.mobileLookupFields.filter(function (item) {
              return !!item.action;
            }),
            this.deletedItems
          )
          .map(function (item) {
            return item.toServer();
          });
      };

      /**
       * AppSettingModel
       */
      function AppSettingModel() {
        this.adminSetting = null;
        this.racSetting = null;
        this.pacSetting = null;
        this.eventTypeSettings = [];
        this.permissionSetting = null;
        this.expenseSetting = null;
        this.locationSetting = null;
        this.auditSetting = null;
        this.mobileSetting = null;
        this.loneWorkerSetting = null;
        this.serviceUserFieldMappings = null;
        this.mobileLookupFields = null;
      }

      AppSettingModel.fromServer = function (serverObject) {
        var setting = null;

        if (serverObject) {
          setting = new AppSettingModel();

          setting.adminSetting = AdminSettingsModel.fromServer(
            serverObject.adminSetting
          );
          setting.racSetting = ConsoleSettingsModel.fromServer(
            serverObject.racSetting
          );
          setting.pacSetting = ConsoleSettingsModel.fromServer(
            serverObject.pacSetting
          );
          setting.eventTypeSettings = EventTypeSettingsModel.fromServerList(
            serverObject.eventTypeSettings
          );
          setting.permissionSetting = PermissionSettingModel.fromServer(
            serverObject.permissionSetting
          );
          setting.expenseSetting = ExpenseSettingModel.fromServer(
            serverObject.expenseSetting
          );
          setting.locationSetting = LocationSettingModel.fromServer(
            serverObject.locationSetting
          );
          setting.auditSetting = AuditSettingModel.fromServer(
            serverObject.auditSetting
          );
          setting.assessmentHelpTexts = AssessmentHelpTextSettingModel.fromServer(
            serverObject.assessmentHelpTexts
          );
          setting.mobileSetting = MobileSettingModel.fromServer(
            serverObject.mobileSetting
          );

          setting.loneWorkerSetting = LoneWorkerSettingModel.fromServer(
            serverObject.loneWorkerSetting
          );

          setting.serviceUserFieldMappings = ServiceUserFieldMappingSettingModel.fromServer(
            serverObject.serviceUserFieldMappings
          );
          setting.mobileLookupFields = MobileLookupFieldSettingModel.fromServer(
            serverObject.mobileLookupFields
          );
        }

        return setting;
      };

      AppSettingModel.fromServerList = function (serverList) {
        return mapArray(serverList, AppSettingModel.fromServer);
      };

      AppSettingModel.prototype.toServer = function () {
        return this.id;
      };

      function PatientProfileTabModel() {
        this.label = '';
        this.patientInfoList = [];
        this.templateUrls = [];
        this.config = {};
      }

      PatientProfileTabModel.fromServer = function (serverObject) {
        var patientProfileTab = null;

        if (serverObject) {
          patientProfileTab = new PatientProfileTabModel();

          patientProfileTab.label = serverObject.label;
          patientProfileTab.patientInfoList = serverObject.patientInfoList;
          patientProfileTab.templateUrls = serverObject.templateUrls;
          patientProfileTab.configs = serverObject.configs;
        }

        return patientProfileTab;
      };

      PatientProfileTabModel.fromServerList = function (serverList) {
        return mapArray(serverList, PatientProfileTabModel.fromServer);
      };

      function AssetModel(data) {
        this.id = data.id;
        this.name = data.name;
        this.status = data.status;
        this.assignmentCount = data.assignmentCount;
        this.allowConcurrentAssignment = data.allowConcurrentAssignment;
        this.allowAssetAllocations = data.allowAssetAllocations;
        this.allowAssignmentTo =
          data.allowAssignmentTo || constants.PERSON_TYPES.PLURAL;
      }

      AssetModel.fromServer = function (serverObject) {
        var asset = null;
        if (serverObject) {
          asset = new AssetModel(serverObject);
        }

        return asset;
      };

      /**
       * AvailabilityPatternModel
       */
      function AvailabilityPatternModel(id, name) {
        this.id = id || null;
        this.name = name || '';
        this.pattern = null;
        this.availabilityPatternResources = [];

        this.createdDate = null;
        this.createdTime = null;
        this.createdBy = null;
        this.lastModifiedDate = null;
        this.lastModifiedTime = null;
        this.lastModifiedBy = null;
      }

      AvailabilityPatternModel.fromServer = function (serverObject) {
        var model = null;

        if (serverObject) {
          model = new AvailabilityPatternModel(serverObject.id, serverObject.name);

          if (serverObject.patternData) {
            model.pattern = PatternModel.fromServer(serverObject.patternData);
          } else if (serverObject.pattern) {
            model.pattern = PatternModel.fromServer(JSON.parse(serverObject.pattern));
          }

          model.availabilityPatternResources = AvailabilityPatternResourceModel.fromServerList(serverObject.availabilityPatternResources);

          model.createdDate = dateUtil.parseDateString(serverObject.createdOnDate);
          model.createdTime = serverObject.createdOnTime;
          model.createdBy = ResourceModel.fromServer(serverObject.createdBy);
          model.lastModifiedDate = dateUtil.parseDateString(serverObject.lastModifiedDate);
          model.lastModifiedTime = serverObject.lastModifiedTime;
          model.lastModifiedBy = ResourceModel.fromServer(serverObject.lastModifiedBy);
        }

        return model;
      };

      AvailabilityPatternModel.fromSObject = function (serverObject, serverList, timezoneSidId) {
        var model = null;

        if (serverObject) {
          model = new AvailabilityPatternModel(serverObject.Id, serverObject.Name);
          model.pattern = serverObject.sked__Pattern__c ? PatternModel.fromServer(JSON.parse(serverObject.sked__Pattern__c), serverList, timezoneSidId) : null;
        }

        return model;
      };

      AvailabilityPatternModel.fromServerList = function (serverList, fromSObject, timezoneSidId) {
        return mapArray(serverList, (fromSObject === true) ? AvailabilityPatternModel.fromSObject : AvailabilityPatternModel.fromServer, timezoneSidId);
      };

      AvailabilityPatternModel.prototype.toServer = function () {
        var serverObject = {
          id: this.id,
          name: this.name,
          patternData: JSON.stringify(this.pattern)
        };

        return serverObject;
      };

      /**
       * PatternModel
       */
      function PatternModel(type) {
        this.days = [];
        this.lengthDays = null;
        this.repeatWeeks = null;
        this.type = type || null;
      }

      PatternModel.fromServer = function (serverObject) {
        var model = null;

        if (serverObject) {
          model = new PatternModel(serverObject.type);

          model.days = PatternDayModel.fromServerList(serverObject.days);
          model.lengthDays = serverObject.lengthDays || null;
          model.repeatWeeks = serverObject.repeatWeeks || null;
        }

        return model;
      };

      PatternModel.prototype.toServer = function () {
        var serverObject = {
          type: this.id,
          lengthDays: this.name,
          repeatWeeks: this.name,
          days: angular.isArray(this.days) ? this.days.map(function (day) {
            return day.toServer();
          }) : null
        };

        return serverObject;
      };

      /**
       * PatternDayModel
       */
      function PatternDayModel() {
        this.day = null;
        this.weekday = null;
        this.intervals = [];
      }

      PatternDayModel.fromServer = function (serverObject) {
        var model = null;

        if (serverObject) {
          model = new PatternDayModel(serverObject.type);

          model.day = serverObject.day;
          model.weekday = serverObject.weekday;
          model.intervals = PatternDayIntervalModel.fromServerList(serverObject.intervals);
        }

        return model;
      };

      PatternDayModel.fromServerList = function (serverList) {
        return mapArray(serverList, PatternDayModel.fromServer);
      };

      PatternDayModel.prototype.toServer = function () {
        var serverObject = {
          day: this.day,
          weekday: this.weekday,
          intervals: angular.isArray(this.intervals) ? this.intervals.map(function (interval) {
            return interval.toServer();
          }) : null
        };

        return serverObject;
      };

      /**
       * PatternDayIntervalModel
       */
      function PatternDayIntervalModel(startTime, endTime) {
        this.startTime = startTime || null;
        this.endTime = endTime || null;
      }

      PatternDayIntervalModel.fromServer = function (serverObject) {
        var model = null;

        if (serverObject) {
          model = new PatternDayIntervalModel();

          model.startTime = dateUtil.parseTimeString(serverObject.startTime);
          model.endTime = dateUtil.parseTimeString(serverObject.endTime);
        }

        return model;
      };

      PatternDayIntervalModel.fromServerList = function (serverList) {
        return mapArray(serverList, PatternDayIntervalModel.fromServer);
      };

      PatternDayIntervalModel.prototype.toServer = function () {
        var serverObject = {
          startTime: this.startTime,
          endTime: this.endTime
        };

        return serverObject;
      };

      /**
       * AvailabilityPatternResourceModel
       */
      function AvailabilityPatternResourceModel(id) {
        this.id = id || null;
        this.resource = null;
        this.availabilityPattern = null;
        this.startDate = null;
        this.endDate = null;
      }

      AvailabilityPatternResourceModel.fromServer = function (serverObject) {
        var model = null;

        if (serverObject) {
          model = new AvailabilityPatternResourceModel(serverObject.id);

          model.resource = ResourceModel.fromServer(serverObject.resource);
          if (serverObject.availabilityPattern) {
            model.availabilityPattern = AvailabilityPatternModel.fromServer(serverObject.availabilityPattern);
          } else if (serverObject.availabilityPatternId) {
            model.availabilityPattern = new AvailabilityPatternModel(serverObject.availabilityPatternId);
          }

          model.startDate = dateUtil.parseDateString(serverObject.startDate);
          model.endDate = dateUtil.parseDateString(serverObject.endDate);
        }

        return model;
      };

      AvailabilityPatternResourceModel.fromSObject = function (serverObject, serverList, timezoneSidId) {
        var model = null,
          startDateTime, endDateTime;

        if (serverObject) {
          model = new AvailabilityPatternResourceModel();

          model.resource = ResourceModel.fromSObject(serverObject.sked__Resource__r);
          if (serverObject.sked__Availability_Pattern__r) {
            model.availabilityPattern = AvailabilityPatternModel.fromSObject(serverObject.sked__Availability_Pattern__r);
          } else if (serverObject.sked__Availability_Pattern__c) {
            model.availabilityPattern = new AvailabilityPatternModel(serverObject.sked__Availability_Pattern__c);
          }

          startDateTime = dateUtil.getDateTimeInfo(serverObject.sked__Start__c, timezoneSidId);
          endDateTime = dateUtil.getDateTimeInfo(serverObject.sked__End__c, timezoneSidId);
          model.startDate = startDateTime ? startDateTime.date : null;
          model.endDate = endDateTime ? endDateTime.date : null;
        }

        return model;
      };

      AvailabilityPatternResourceModel.fromServerList = function (serverList, fromSObject, timezoneSidId) {
        return mapArray(serverList, (fromSObject === true) ? AvailabilityPatternResourceModel.fromSObject : AvailabilityPatternResourceModel.fromServer, timezoneSidId);
      };

      AvailabilityPatternResourceModel.prototype.toServer = function () {
        var serverObject = {
          resourceId: this.resource.id,
          startDate: dateUtil.datetoString(this.startDate),
          endDate: dateUtil.datetoString(this.endDate)
        };

        return serverObject;
      };

      return {
        PatientModel: PatientModel,
        AccountModel: AccountModel,
        ContactModel: ContactModel,
        AddressModel: AddressModel,
        PicklistItemModel: PicklistItemModel,
        ConfigDataModel: ConfigDataModel,
        ResourceModel: ResourceModel,
        AvailabilityModel: AvailabilityModel,
        // OncallAppointmentModel: OncallAppointmentModel,
        EventModel: EventModel,
        ColorModel: ColorModel,
        ColorMapModel: ColorMapModel,
        ConsoleSettingsModel: ConsoleSettingsModel,
        JobAllocationModel: JobAllocationModel,
        JobOfferModel: JobOfferModel,

        PeriodModel: PeriodModel,

        PACFilterModel: PACFilterModel,
        PACAvailabilityModel: PACAvailabilityModel,
        PACJobModel: PACJobModel,
        PACGridDataModel: PACGridDataModel,
        PACJobExceptionModel: PACJobExceptionModel,
        ScheduleModel: ScheduleModel,
        TagModel: TagModel,
        ELCFilterModel: ELCFilterModel,

        // OncallTeamModel: OncallTeamModel,
        CaseSchedulingModel: CaseSchedulingModel,
        CaseSchedulingAppointmentEmployeeModel: CaseSchedulingAppointmentEmployeeModel,
        CarePlanModel: CarePlanModel,
        AppSettingModel: AppSettingModel,
        TemplateModel: TemplateModel,

        PatientProfileTabModel: PatientProfileTabModel,
        PermissionSettingsConfigModel: PermissionSettingsConfigModel,
        AssessmentSettingConfigModel: AssessmentSettingConfigModel,
        ServiceUserFieldMappingConfigModel: ServiceUserFieldMappingConfigModel,

        AssetModel: AssetModel,

        AvailabilityPatternModel: AvailabilityPatternModel,
        AvailabilityPatternResourceModel: AvailabilityPatternResourceModel
      };
    }
  ]);
})(angular);