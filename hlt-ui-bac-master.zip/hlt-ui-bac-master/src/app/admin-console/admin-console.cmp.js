(function (angular, topWindow) {
  angular.module('hltApp')
    .component('adminConsole', {
      templateUrl: 'src/app/admin-console/admin-console.tpl.html',
      controller: [
        '$scope',
        '$q',
        'model',
        'util',
        'api',
        'constants',
        function ($scope, $q, model, util, api, constants) {
          var $ctrl = this;
          var SETTINGS_MAIN_EVENT = {
            RELOAD: 'ac:reload',
            SAVE: 'ac:save'
          };
          var CUSTOM_ACTION = {
            EMIT_EVENT: 'emit',
            BROADCAST_EVENT: 'broadcast'
          };
          var SETTINGS_DEF = {
            ADMIN: {
              key: constants.SETTING_KEY.ADMIN,
              field: 'adminSetting'
            },
            RAC: {
              key: constants.SETTING_KEY.RAC,
              field: 'racSetting',
              paramsBuilder: 'toRACServer'
            },
            PAC: {
              key: constants.SETTING_KEY.PAC,
              field: 'pacSetting',
              paramsBuilder: 'toPACServer'
            },
            EVENT_TYPE: {
              key: constants.SETTING_KEY.EVENT_TYPE,
              field: 'eventTypeSettings'
            },
            PERMISSION: {
              key: constants.SETTING_KEY.PERMISSION,
              field: 'permissionSetting'
            },
            EXPENSE: {
              key: constants.SETTING_KEY.EXPENSE,
              field: 'expenseSetting'
            },
            LOCATION: {
              key: constants.SETTING_KEY.LOCATION,
              field: 'locationSetting'
            },
            AUDIT: {
              key: constants.SETTING_KEY.AUDIT,
              field: 'auditSetting'
            },
            ASSESSMENT_HELP_TEXTS: {
              key: constants.SETTING_KEY.ASSESSMENT_HELP_TEXTS,
              field: 'assessmentHelpTexts'
            },
            MOBILE: {
              key: constants.SETTING_KEY.MOBILE,
              field: 'mobileSetting'
            },
            LONE_WORKER: {
              key: constants.SETTING_KEY.LONE_WORKER,
              field: 'loneWorkerSetting'
            },
            SERVICE_USER_FIELD_MAPPING: {
              key: constants.SETTING_KEY.SERVICE_USER_FIELD_MAPPING,
              field: 'serviceUserFieldMappings'
            },
            MOBILE_LOOKUP_FIELDS : {
              key: constants.SETTING_KEY.MOBILE_LOOKUP_FIELDS,
              field: 'mobileLookupFields'
            }
          };

          var MENU = {
            ADMINISTRATION: {
              label: 'Administration',
              items: [
                {
                  label: 'Admin Settings',
                  templateUrl: 'sked/ac-admin-settings-component',
                  settingDef: SETTINGS_DEF.ADMIN
                },
                {
                  /*customActions: [
									{
										icon: 'add',
										buttonType: 'neutral',
										label: 'Add Availability Type',
										action: CUSTOM_ACTION.BROADCAST_EVENT,
										event: 'ac:rac:addAvailabilityType'
									}
								],*/
                  title: 'Resource Availability Console Settings',
                  label: 'Resource Availability Console Settings',
                  templateUrl: 'sked/ac-rac-settings-component',
                  settingDef: SETTINGS_DEF.RAC
                },
                {
                  title: 'Account Availability Console Settings',
                  label: 'Account Availability Console Settings',
                  templateUrl: 'sked/ac-pac-settings-component',
                  settingDef: SETTINGS_DEF.PAC
                },
                {
                  label: 'Event Type Settings',
                  templateUrl: 'sked/ac-event-type-settings-component',
                  settingDef: SETTINGS_DEF.EVENT_TYPE
                },
                {
                  label: 'Permission Settings',
                  templateUrl: 'sked/ac-permissions-settings-component',
                  settingDef: SETTINGS_DEF.PERMISSION
                },
                {
                  label: 'Expense Settings',
                  templateUrl: 'sked/ac-expense-settings-component',
                  settingDef: SETTINGS_DEF.EXPENSE
                },
                {
                  label: 'Location Settings',
                  templateUrl: 'sked/ac-location-settings-component',
                  settingDef: SETTINGS_DEF.LOCATION
                },
                {
                  label: 'Audit Settings',
                  templateUrl: 'sked/ac-audit-settings-component',
                  settingDef: SETTINGS_DEF.AUDIT
                },
                {
                  label: 'Assessment Help Text (Skedulo Mobile)',
                  templateUrl: 'sked/ac-assessment-settings-component',
                  settingDef: SETTINGS_DEF.ASSESSMENT_HELP_TEXTS
                },
                {
                  label: 'Mobile Sync Settings',
                  templateUrl: 'sked/ac-mobile-sync-settings-component',
                  settingDef: SETTINGS_DEF.MOBILE
                },
                {
                  label: 'Lone Worker Alert Settings',
                  templateUrl: 'sked/ac-lone-worker-settings-component',
                  settingDef: SETTINGS_DEF.LONE_WORKER
                },
                {
                  label: 'Service User Field Mapping',
                  templateUrl: 'sked/ac-service-user-field-mapping-component',
                  settingDef: SETTINGS_DEF.SERVICE_USER_FIELD_MAPPING
                },
                {
                  label: 'Mobile Lookup Field Settings',
                  templateUrl: 'sked/ac-mobile-lookup-fields-component',
                  settingDef: SETTINGS_DEF.MOBILE_LOOKUP_FIELDS
                }
              ]
            }
          };

          var showLoading = function () {
            util.showLoading();
          };

          var hideLoading = function () {
            util.hideLoading();
          };

          /**
				 * common remote action error handler
				 */
          var serverErrorHandlder = function (exception) {
            console.error(exception);
            util.toastError('Can not perform action due to server error.');

            return $q.reject();
          };

          var apiExceptionHandler = function (exception) {
            console.error(exception);
            if (exception && exception.errorMessage) {
              util.toastError(exception.errorMessage);
            }
          };

          var doGetSettings = function (keys) {
            return api.getSettings(keys)
              .catch(serverErrorHandlder);
          };

          var doSaveSettings = function (keys, settingParams) {
            return api.saveSettings(keys, settingParams)
              .catch(serverErrorHandlder);
          };

          var reloadSettings = function (isForced) {
            if (isForced === true && 
						$ctrl.selectedMenuItem &&
						$ctrl.selectedMenuItem.settingDef) {

              showLoading();
              doGetSettings([$ctrl.selectedMenuItem.settingDef.key])
                .then(function (result) {
                  if (result.success && result.data) {
                    transformSettingData(result.data);
                  } else {
                    return $q.reject(result);
                  }
                })
                .catch(apiExceptionHandler)
                .finally(hideLoading);
            }
          };

          var saveSettings = function (isForced) {
            var settingsParams;
            var event = $scope.$broadcast(SETTINGS_MAIN_EVENT.SAVE);

            if (isForced || !event.defaultPrevented) {
              settingsParams = buildSettingParams();

              if (settingsParams) {
                doSaveSettings([$ctrl.selectedMenuItem.settingDef.key], settingsParams)
                  .then(function (result) {
                    if (result.success) {
                      util.toastSuccess(($ctrl.selectedMenuItem.title || $ctrl.selectedMenuItem.label) + ' has been saved successfully.');
                      reloadSettings(true);
                    } else {
                      return $q.reject(result);
                    }
                  })
                  .catch(apiExceptionHandler)
                  .finally(hideLoading);
              }						
            }
          };

          var performCustomAction = function (customAction) {

          };

          var buildSettingParams = function () {
            var field = $ctrl.selectedMenuItem.settingDef.field,
              paramsBuilder = $ctrl.selectedMenuItem.settingDef.paramsBuilder || 'toServer',
              settings = $ctrl.settings[field],
              rt = {}, settingsParams;

            var runParamsBuilder = function (setting) {
              if (angular.isFunction(setting[paramsBuilder])) {
                return setting[paramsBuilder]();
              }

              return null;
            };

            if (angular.isArray(settings)) {
              settingsParams = settings.map(function (setting) {
                return runParamsBuilder(setting);
              });
            } else {
              settingsParams = runParamsBuilder(settings);
            }

            rt[field] = settingsParams;

            return rt;
          };

          var transformSettingData = function (settingData) {
            var settings = model.AppSettingModel.fromServer(settingData),
              field = $ctrl.selectedMenuItem.settingDef.field;

            if (settings) {
              $ctrl.settings[field] = settings[field] || null;
            }
          };

          var selectMenu = function (menuItem, menuGroup) {
            $ctrl.selectedMenuGroup = menuGroup;
            $ctrl.selectedMenuItem = menuItem;
          };


          /**
				 * init block
				 * used for setting up controller
				 */
          (function () {
            $scope.MENU = MENU;
            $scope.SETTINGS_DEF = SETTINGS_DEF;
            $scope.SETTINGS_MAIN_EVENT = SETTINGS_MAIN_EVENT;

            $ctrl.quickFindText = '';
            $ctrl.configData = null;
            $ctrl.selectedMenuGroup = MENU.ADMINISTRATION;
            $ctrl.selectedMenuItem = MENU.ADMINISTRATION.items[0];

            $ctrl.settings = {};
            $ctrl.reloadSettings = reloadSettings;
            $ctrl.saveSettings = saveSettings;
            $ctrl.performCustomAction = performCustomAction;
            $ctrl.selectMenu = selectMenu;

            $scope.$on(SETTINGS_MAIN_EVENT.RELOAD, function () {
              reloadSettings(true);
            });
          })();
        }
      ]
    });
})(angular, top);