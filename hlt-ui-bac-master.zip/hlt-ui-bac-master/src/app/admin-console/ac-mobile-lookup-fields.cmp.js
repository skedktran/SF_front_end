(function(angular) {
  angular.module('hltApp').component('acMobileLookupFields', {
    templateUrl: 'src/app/admin-console/ac-mobile-lookup-fields.tpl.html',
    bindings: {
      settings: '=',
      mainEventNames: '<'
    },
    controller: [
      '$scope',
      function($scope) {
        var $ctrl = this;

        var markFormDirty = function() {
          $ctrl.mobileLookupFieldsForm.$setDirty(true);
        };

        var onDeleteItem = function(item) {
          $ctrl.settings.deleteItem(item);
          markFormDirty();
        };
        var onAddItem = function() {
          $ctrl.settings.addNewItem();
          markFormDirty();
        };

        var COLUMN_DEFINITION = {
          OBJECT_API: {
            title: 'Object API Name',
            name: 'objectApi',
            cssClasses: ['skedUserType__col'],
            templateUrl:
              'src/app/admin-console/ac-mobile-lookup-fields-cell-objectApi.tpl.html'
          },
          LABEL_FIELD_API: {
            title: 'Label Field API Name',
            name: 'labelFieldApi',
            cssClasses: ['profile__col'],
            templateUrl:
              'src/app/admin-console/ac-mobile-lookup-fields-cell-labelFieldApi.tpl.html'
          },
          ACTIONS: {
            name: '',
            title: '',
            cssClasses: ['action__col'],
            templateUrl:
              'src/app/admin-console/ac-mobile-lookup-fields-cell-action.tpl.html'
          }
        };

        var SETTINGS_TABLE_COLUMNS = [
          COLUMN_DEFINITION.OBJECT_API,
          COLUMN_DEFINITION.LABEL_FIELD_API,
          COLUMN_DEFINITION.ACTIONS
        ];

        var clearError = function() {
          var form = $ctrl.mobileLookupFieldsForm;
          // clean all previus error
          form.$setUntouched();
          form.$setPristine();
        };
        /**
         * init block
         * used for setting up controller
         */
        (function() {
          $scope.SETTINGS_TABLE_COLUMNS = SETTINGS_TABLE_COLUMNS;

          $ctrl.mobileLookupFieldsForm = null;
          $ctrl.errors = {
            isError: false,
            reasons: {}
          };
          $ctrl.onDeleteItem = onDeleteItem;
          $ctrl.onAddItem = onAddItem;

          /**
           * controller init
           * used for setting initial value
           */
          
          $scope.$watch('$ctrl.settings', function() {
            clearError();
          });
        })();
      }
    ]
  });
})(angular);
