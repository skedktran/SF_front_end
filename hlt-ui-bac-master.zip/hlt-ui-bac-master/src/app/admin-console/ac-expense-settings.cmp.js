(function (angular) {
	angular.module('hltApp')
	.component('acExpenseSettings', {
		templateUrl: 'src/app/admin-console/ac-expense-settings.tpl.html',
		bindings: {
			settings: '=',
			mainEventNames: '<'
		},
		controller: [
			'$scope',
			'util',
			function ($scope, util) {
				var $ctrl = this;

				/**
				 * init block
				 * used for setting up controller
				 */
				(function () {					
					$ctrl.expenseSettingsForm = null;
				})();
			}
		]
	});
})(angular);