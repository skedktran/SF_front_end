(function (angular, topWindow) {
    angular.module('hltApp')
        .component('acPermissionsSettings', {
            templateUrl: 'src/app/admin-console/ac-permissions-settings.tpl.html',
            bindings: {
                settings: '=',
                mainEventNames: '<'
            },
            controller: [
                '$scope',
                '$q',
                'util',
                'api',		
                'model',
                function ($scope, $q, util, api, model) {
                    var $ctrl = this;

                    var markFormDirty = function () {
                        $ctrl.permissionSettingsForm.$setDirty(true);
                    };

                    var onDeleteItem = function (item) {
                        $ctrl.settings.deletePermissionRule(item);
                        markFormDirty();
                    };
                    var onAddItem = function () {
                        $ctrl.settings.addNewPermissionRule();
                        markFormDirty();
                    };

                    var reapplyRule = function () {

                        util.showLoading();
                        return api.reapplyPermissionSets()
                            .then(function() {
                                util.toastSuccess('Reapply permission sets has been saved successfully.');
                            })
                            .catch(function() {
							
                                util.toastError('Can not reapply permission sets.');
                            })
                            .finally(function () {
                                util.hideLoading();
                            });
                    };
				
                    var COLUMN_DEFINITION = {
                        RULE_NAME: {
                            name: 'name',
                            title: 'Name',
                            cssClasses: ['name__col'],
                            templateUrl: 'src/app/admin-console/ac-permissions-settings-cell-name.tpl.html'
                        },
                        SKED_USER_TYPE: {
                            name: 'skeduloUserType',
                            title: 'User Type',
                            cssClasses: ['skedUserType__col'],
                            templateUrl: 'src/app/admin-console/ac-permissions-settings-cell-skedUserType.tpl.html'
                        },
                        PROFILE: {
                            name: 'profile',
                            title: 'Profile',
                            cssClasses: ['profile__col'],
                            templateUrl: 'src/app/admin-console/ac-permissions-settings-cell-profile.tpl.html'
                        },
                        PERMISSION_SETS: {
                            name: 'permissionSets',
                            title: 'Permission Sets',
                            cssClasses: ['permission-sets__col'],
                            templateUrl: 'src/app/admin-console/ac-permissions-settings-cell-permissionSets.tpl.html'
                        },
                        ACTIONS: {
                            name: '',
                            title: '',
                            cssClasses: ['action__col'],
                            templateUrl: 'src/app/admin-console/ac-permissions-settings-cell-action.tpl.html'
                        }
                    };

                    var SETTINGS_TABLE_COLUMNS = [
                        COLUMN_DEFINITION.RULE_NAME,
                        COLUMN_DEFINITION.SKED_USER_TYPE,
                        COLUMN_DEFINITION.PROFILE,
                        COLUMN_DEFINITION.PERMISSION_SETS,
                        COLUMN_DEFINITION.ACTIONS
                    ];

                    var SC_REQUIRED_CONFIG_DATA = ['profiles', 'skeduloPermissionSets', 'skeduloUserTypes'];


                    var doInitialize = function (requestParams) {
                        return api.initialize(requestParams)
                            .catch(serverErrorHandlder);
                    };

                    var updateSettingsModelPicklist = function () {
                        if ($ctrl.settings && $ctrl.configData) {
                            $ctrl.settings.updatePermissionSetsOptions($ctrl.configData.skeduloPermissionSets);
                        }
                    };

                    var getInitialData = function () {
                        var requestParams = {
                            configKeys: SC_REQUIRED_CONFIG_DATA
                        };

                        return doInitialize(requestParams)
                            .then(function (results) {
                                if (results.success) {
                                    $ctrl.configData = model.PermissionSettingsConfigModel.fromServer(results.data);
                                    updateSettingsModelPicklist();
                                } else {
                                    return $q.reject(results);
                                }
                            });
                    };

                    var clearError = function () {
                        var form = $ctrl.permissionSettingsForm;
                        // clean all previus error  
                        form.$setUntouched();
                        form.$setPristine();
                    };

                    var filterPermissionSets = function (permissionSet) {
                        return permissionSet.canShow();
                    };

                    var validateSettings = function () {
                        clearError();
					
                        if (form) {
                            // auto validate required
                            form.$setSubmitted();
                            var nameDict = {};
                            var combineKeyDict = {};
                            var existingPermissionSetRules = _.filter($ctrl.settings.permissionSetAssignmentRules, filterPermissionSets);

                            _.forEach(existingPermissionSetRules, function (permissionSet) {
                                var name = permissionSet.name;
                                var combineKey = permissionSet.skeduloUserType + '<>' + _.get(permissionSet, 'profile.id');
                                if (nameDict[name]) {
                                    var previousItem = nameDict[name];
                                    form[previousItem.id + '_name'].$setValidity('unique name', false);
                                    form[permissionSet.id + '_name'].$setValidity('unique name', false);
                                } else {
                                    nameDict[name] = permissionSet;
                                    form[permissionSet.id + '_name'].$setValidity('unique name', true);
                                }							
                                if (combineKeyDict[combineKey]) {
                                    var previousItem = combineKeyDict[combineKey];
                                    form[previousItem.id + '_profile'].$setValidity('unique combination key', false);
                                    form[permissionSet.id + '_profile'].$setValidity('unique combination key', false);
                                    form[previousItem.id + '_skeduloUserType'].$setValidity('unique combination key', false);
                                    form[permissionSet.id + '_skeduloUserType'].$setValidity('unique combination key', false);
                                } else {
                                    combineKeyDict[combineKey] = permissionSet;
                                    form[permissionSet.id + '_profile'].$setValidity('unique combination key', true);
                                    form[permissionSet.id + '_skeduloUserType'].$setValidity('unique combination key', true);
                                }

                                if (_.isEmpty(permissionSet.permissionSets)) {
                                    form[permissionSet.id + '_permissionSets'].$setValidity('must select at least one permission set', false);
                                }
                            });
                        }
					
                        return form.$valid;
                    };

                    var serverErrorHandlder = function (exception) {
                        console.error(exception);
                        util.toastError('Can not perform action due to server error.');

                        return $q.reject();
                    };

                    var handleSettingsSaving = function ($event) {
                        if (!validateSettings()) {
                            util.toastError('Invalid settings input.');
                            $event.preventDefault();
                        }
                    };

                    /**
				 * init block
				 * used for setting up controller
				 */
                    (function () {
                        $scope.SETTINGS_TABLE_COLUMNS = SETTINGS_TABLE_COLUMNS;

                        $ctrl.permissionSettingsForm = null;
                        $ctrl.errors = {
                            isError: false,
                            reasons: {}
                        };
                        $ctrl.onDeleteItem = onDeleteItem;
                        $ctrl.onAddItem = onAddItem;
                        $ctrl.reapplyRule = reapplyRule;

                        $ctrl.filterPermissionSets = filterPermissionSets;

                        /**
					 * controller init
					 * used for setting initial value
					 */
                        $ctrl.$onInit = function () {					
                            $scope.$on($ctrl.mainEventNames.SAVE, handleSettingsSaving);
                            return getInitialData();
                        };
                        $scope.$watch('$ctrl.settings', function () {
                            updateSettingsModelPicklist();
                            clearError();
                        });

                    })();
                }
            ]
        });
})(angular, top);