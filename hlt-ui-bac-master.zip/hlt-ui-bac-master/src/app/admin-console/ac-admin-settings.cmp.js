(function (angular, topWindow) {
	angular.module('hltApp')
	.component('acAdminSettings', {
		templateUrl: 'src/app/admin-console/ac-admin-settings.tpl.html',
		bindings: {
			settings: '=',
			mainEventNames: '<'
		},
		controller: [
			'$scope',
			'util',
			function ($scope, util) {
				var $ctrl = this;

				var INTEGER_PATTERN = /^([0-9]*)$/;
				var EMAIL_PATTERN = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				var URL_PATTERN = /((([A-Za-z]{3,9}:(?:\/\/)?)(?:[\-;:&=\+\$,\w]+@)?[A-Za-z0-9\.\-]+|(?:www\.|[\-;:&=\+\$,\w]+@)[A-Za-z0-9\.\-]+)((?:\/[\+~%\/\.\w\-_]*)?\??(?:[\-\+=&;%@\.\w_]*)#?(?:[\.\!\/\\\w]*))?)/;
				var DISTANCE_MEASUREMENT_UNIT_OPTIONS = [
					{value: 'mi', label: 'Miles'},
					{value: 'm', label: 'Meters'},
					{value: 'km', label: 'Kilometers'}
				];
				var SMS_COUNTRY_CODE_OPTIONS = [
					{code: 'au', name: 'Australia - AU'},
					{code: 'gb', name: 'United Kingdom - GB'},
					{code: 'us', name: 'United States - US'}
				];

				var validateSettings = function () {
					var form = $ctrl.adminSettingsForm;
					var errorMessage;

					if (form) {
						form.$setSubmitted();

						if (form.$invalid) {
							if (form.$error.required) {
								errorMessage = 'Please check all required fields.'
							} else if (form.$error.number || form.$error.pattern) {
	              errorMessage = 'Invalid data format, please check all number, url, email fields.';
	            } else {
								errorMessage = 'Invalid admin settings, please check the inputs again.'
							}

							util.toastError(errorMessage);
							return false;
						}
					}

					return true;
				};

				var handleSettingsSaving = function ($event) {
					if (!validateSettings()) {
						$event.preventDefault();
					}
				};

				/**
				 * controller init
				 * used for setting initial value
				 */
				$ctrl.$onInit = function () {					
					$scope.$on($ctrl.mainEventNames.SAVE, handleSettingsSaving);
				};

				/**
				 * init block
				 * used for setting up controller
				 */
				(function () {
					$scope.INTEGER_PATTERN = INTEGER_PATTERN;
					$scope.EMAIL_PATTERN = EMAIL_PATTERN;
					$scope.URL_PATTERN = URL_PATTERN;
					$scope.DISTANCE_MEASUREMENT_UNIT_OPTIONS = DISTANCE_MEASUREMENT_UNIT_OPTIONS;
					$scope.SMS_COUNTRY_CODE_OPTIONS = SMS_COUNTRY_CODE_OPTIONS;
					
					$ctrl.adminSettingsForm = null;
				})();
			}
		]
	});
})(angular, top);