(function (angular) {
  angular.module('hltApp')
    .component('acLoneWorkerSettings', {
      templateUrl: 'src/app/admin-console/ac-lone-worker-settings.tpl.html',
      bindings: {
        settings: '=',
        mainEventNames: '<'
      },
      controller: [
        '$scope', 'util',
        function ($scope, util) {
          var $ctrl = this;
          var EMAIL_PATTERN = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
          var validateSettings = function () {
            var form = $ctrl.loneWokerSettingForm;
            var errorMessage;

            if (form) {
              form.$setSubmitted();

              if (form.$invalid) {
                if (form.$error.required) {
                  errorMessage = 'Please check all required fields.';
                } else if (form.$error.number || form.$error.pattern) {
                  errorMessage = 'Invalid data format, please check all number, url, email fields.';
                } else {
                  errorMessage = 'Invalid admin settings, please check the inputs again.';
                }

                util.toastError(errorMessage);
                return false;
              }
            }

            return true;
          };

          var handleSettingsSaving = function ($event) {
            if (!validateSettings()) {
              $event.preventDefault();
            }
          };
          

            
          $ctrl.$onInit = function () {					
            $scope.$on($ctrl.mainEventNames.SAVE, handleSettingsSaving);
          };
          /**
					 * init block
					 * used for setting up controller
					 */
          (function () {
            $ctrl.EMAIL_PATTERN = EMAIL_PATTERN;
            $ctrl.loneWokerSettingForm = null;
          })();
        }
      ]
    });
})(angular);