(function (angular, topWindow) {
	angular.module('hltApp')
	.component('acPacSettings', {
		templateUrl: 'src/app/admin-console/ac-pac-settings.tpl.html',
		bindings: {
			settings: '=',
			mainEventNames: '<'
		},
		controller: [
			'$scope',
			'util',
			function ($scope, util) {
				var $ctrl = this;

				var INTEGER_PATTERN = /^([0-9]*)$/;
				var CAL_STEP_OPTIONS = [5, 10, 15, 20, 30, 45, 60];
				var CAL_VIEW_PERIOD_OPTIONS = [1, 2, 3, 4];
				var DEFAULT_TIME_PICKER_OPTIONS = {
					step: 15
				};
				var FIRST_DAY_OPTIONS = [
					{value: 0, label: 'Sunday'},
					{value: 1, label: 'Monday'}
				];
				var MAX_NO_OF_RECURRING_WEEK = 52;

				var getArray = function (len) {
					var arr = [];
					len = len || 0;
					for (var i = 1; i <= len; i++) {
						arr.push(i);
					}
					return arr;
				};

				var validateSettings = function () {
					var form = $ctrl.pacSettingsForm;
					var errorMessage;

					if (form) {
						form.$setSubmitted();

						if (form.$invalid) {
							if (form.$error.required) {
								errorMessage = 'Please check all required fields.'
							} else if (form.$error.number || form.$error.pattern) {
								errorMessage = 'Invalid data format, please check all number fields.';
							} else if (form.$error.timeRange) {
								errorMessage = 'Calendar start time should before calendar end time.'
							} else {
								errorMessage = 'Invalid RAC settings, please check.'
							}

							util.toastError(errorMessage);
							return false;
						}
					}

					return true;
				};

				var handleSettingsSaving = function ($event) {
					if (!validateSettings()) {
						$event.preventDefault();
					}
				};

				var timeRangeValidator = {
					timeRange: function (modelValue, modelController) {
						var modelName = modelController.$name;
						var isValid = false;

						if (modelName === 'calendarStart') {
							isValid = !angular.isNumber($ctrl.settings.calendarEnd) || modelValue < $ctrl.settings.calendarEnd;
							modelController.$$parentForm.calendarEnd.$setValidity('timeRange', isValid);
						} else if (modelName === 'calendarEnd') {
							isValid = !angular.isNumber($ctrl.settings.calendarStart) || $ctrl.settings.calendarStart < modelValue;
							modelController.$$parentForm.calendarStart.$setValidity('timeRange', isValid);
						}

						return isValid;
					}
				};

				/**
				 * controller init
				 * used for setting initial value
				 */
				$ctrl.$onInit = function () {					
					$scope.$on($ctrl.mainEventNames.SAVE, handleSettingsSaving);
				};

				/**
				 * init block
				 * used for setting up controller
				 */
				(function () {
					$scope.INTEGER_PATTERN = INTEGER_PATTERN;
					$scope.CAL_STEP_OPTIONS = CAL_STEP_OPTIONS;
					$scope.CAL_VIEW_PERIOD_OPTIONS = CAL_VIEW_PERIOD_OPTIONS;
					$scope.DEFAULT_TIME_PICKER_OPTIONS = DEFAULT_TIME_PICKER_OPTIONS;
					$scope.FIRST_DAY_OPTIONS = FIRST_DAY_OPTIONS;
					$scope.MAX_NO_OF_RECURRING_WEEK = MAX_NO_OF_RECURRING_WEEK;

					$ctrl.pacSettingsForm = null;
					$ctrl.timeRangeValidator = timeRangeValidator;
					$ctrl.getArray = getArray;
				})();
			}
		]
	});
})(angular, top);