(function (angular) {
  angular.module('hltApp')
    .component('acMobileSyncSettings', {
      templateUrl: 'src/app/admin-console/ac-mobile-sync-settings.tpl.html',
      bindings: {
        settings: '=',
        mainEventNames: '<'
      },
      controller: [
        '$scope', 'util',
        function ($scope, util) {
          var $ctrl = this;
          
          var validateSettings = function () {
            var form = $ctrl.mobileSyncSettingForm;
          
            if (form) {
              form.$setSubmitted();
          
              return form.$valid;
            }
          
            return true;
          };
          
          var handleSettingsSaving = function ($event) {
            if (!validateSettings()) {
              util.toastError('Invalid Mobile Sync Settings');
              $event.preventDefault();
            }
          };
          /**
           * controller init
           * used for setting initial value
           */
          $ctrl.$onInit = function () {					
            $scope.$on($ctrl.mainEventNames.SAVE, handleSettingsSaving);
          };
          /**
					 * init block
					 * used for setting up controller
					 */
          (function () {
					
            $ctrl.minDay = 0;
            $ctrl.maxDay = 90;
            $ctrl.modelOptions = {
              allowInvalid: true
            };
            $ctrl.mobileSyncSettingForm = null;
          })();
        }
      ]
    });
})(angular);