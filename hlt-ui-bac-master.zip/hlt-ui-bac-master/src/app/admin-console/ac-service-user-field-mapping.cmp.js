(function(angular) {
  angular.module('hltApp').component('acServiceUserFieldMapping', {
    templateUrl: 'src/app/admin-console/ac-service-user-field-mapping.tpl.html',
    bindings: {
      settings: '=',
      mainEventNames: '<'
    },
    controller: [
      '$scope',
      '$q',
      'util',
      'api',
      'model',
      function($scope, $q, util, api, model) {
        var $ctrl = this;

        var markFormDirty = function() {
          $ctrl.serviceUserFieldMappingForm.$setDirty(true);
        };

        var onDeleteItem = function(item) {
          $ctrl.settings.deleteItem(item);
          markFormDirty();
        };
        var onAddItem = function() {
          $ctrl.settings.addNewItem();
          markFormDirty();
        };

        var COLUMN_DEFINITION = {
          FiELD_LABEL: {
            title: 'Referral Field API Name',
            name: 'referalFieldApi',
            cssClasses: ['skedUserType__col'],
            templateUrl:
              'src/app/admin-console/ac-service-user-field-mapping-cell-referalFieldApi.tpl.html'
          },
          HELP_TEXT: {
            title: 'Service User Field API Name',
            name: 'serviceUserFieldApi',
            cssClasses: ['profile__col'],
            templateUrl:
              'src/app/admin-console/ac-service-user-field-mapping-cell-serviceUserFieldApi.tpl.html'
          },
          ACTIONS: {
            name: '',
            title: '',
            cssClasses: ['action__col'],
            templateUrl:
              'src/app/admin-console/ac-service-user-field-mapping-cell-action.tpl.html'
          }
        };

        var SETTINGS_TABLE_COLUMNS = [
          COLUMN_DEFINITION.FiELD_LABEL,
          COLUMN_DEFINITION.HELP_TEXT,
          COLUMN_DEFINITION.ACTIONS
        ];

        var SC_REQUIRED_CONFIG_DATA = [
          'referralCustomFields',
          'serviceUserCustomFields'
        ];

        var doInitialize = function(requestParams) {
          return api.initialize(requestParams).catch(serverErrorHandlder);
        };

        var getInitialData = function() {
          var requestParams = {
            configKeys: SC_REQUIRED_CONFIG_DATA
          };

          return doInitialize(requestParams).then(function(results) {
            if (results.success) {
              $ctrl.configData = model.ServiceUserFieldMappingConfigModel.fromServer(
                results.data
              );
            } else {
              return $q.reject(results);
            }
          });
        };

        var clearError = function() {
          var form = $ctrl.serviceUserFieldMappingForm;
          // clean all previus error
          form.$setUntouched();
          form.$setPristine();
        };

        var serverErrorHandlder = function(exception) {
          console.error(exception);
          util.toastError('Can not perform action due to server error.');

          return $q.reject();
        };

        /**
         * init block
         * used for setting up controller
         */
        (function() {
          $scope.SETTINGS_TABLE_COLUMNS = SETTINGS_TABLE_COLUMNS;

          $ctrl.serviceUserFieldMappingForm = null;
          $ctrl.errors = {
            isError: false,
            reasons: {}
          };
          $ctrl.onDeleteItem = onDeleteItem;
          $ctrl.onAddItem = onAddItem;

          /**
           * controller init
           * used for setting initial value
           */
          $ctrl.$onInit = function() {
            return getInitialData();
          };
          $scope.$watch('$ctrl.settings', function() {
            clearError();
          });
        })();
      }
    ]
  });
})(angular);
