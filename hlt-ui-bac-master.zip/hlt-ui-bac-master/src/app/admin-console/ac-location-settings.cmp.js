(function (angular) {
	angular.module('hltApp')
	.component('acLocationSettings', {
		templateUrl: 'src/app/admin-console/ac-location-settings.tpl.html',
		bindings: {
			settings: '=',
			mainEventNames: '<'
		},
		controller: [
			'$scope',
			'$q',
			'util',
			'api',
			function ($scope, $q, util, api) {
				var $ctrl = this;

				var serverErrorHandlder = function (exception) {
					console.error(exception);
					util.toastError('Can not perform action due to server error.');

					return $q.reject();
				};

				var SC_REQUIRED_CONFIG_DATA = ['locationTypes'];


				var doInitialize = function (requestParams) {
					return api.initialize(requestParams)
						.catch(serverErrorHandlder);
				};


				var getInitialData = function () {
					var requestParams = {
						configKeys: SC_REQUIRED_CONFIG_DATA
					};

					return doInitialize(requestParams)
						.then(function (results) {
							if (results.success) {
								$ctrl.LOCATION_TYPES = _.get(results, 'data.locationTypes');
							} else {
								return $q.reject(results);
							}
						});
				};
				/**
				 * controller init
				 * used for setting initial value
				 */
				$ctrl.$onInit = function () {					
					getInitialData();
				};

				/**
				 * init block
				 * used for setting up controller
				 */
				(function () {					
					$ctrl.locationSettingsForm = null;
					$ctrl.LOCATION_TYPES = [];
				})();
			}
		]
	});
})(angular);