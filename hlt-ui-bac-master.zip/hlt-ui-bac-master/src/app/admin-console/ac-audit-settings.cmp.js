(function (angular) {
  angular.module('hltApp')
    .component('acAuditSettings', {
      templateUrl: 'src/app/admin-console/ac-audit-settings.tpl.html',
      bindings: {
        settings: '=',
        mainEventNames: '<'
      },
      controller: [
        '$scope',
        'util',
        function ($scope, util) {
          var $ctrl = this;

          var validateSettings = function () {
            var form = $ctrl.auditSettingsForm;

            if (form) {
              form.$setSubmitted();

              return form.$valid;
            }

            return true;
          };

          var handleSettingsSaving = function ($event) {
            if (!validateSettings()) {
              util.toastError('Invalid Score Band Settings');
              $event.preventDefault();
            }
          };
          /**
           * controller init
           * used for setting initial value
           */
          $ctrl.$onInit = function () {					
            $scope.$on($ctrl.mainEventNames.SAVE, handleSettingsSaving);
          };

          /**
           * init block
           * used for setting up controller
           */
          (function () {					
            $ctrl.auditSettingsForm = null;
            $ctrl.max = 100;
            $ctrl.min = 0;
            $ctrl.modelOptions = {
              allowInvalid: true
            };
          })();
        }
      ]
    });
})(angular);