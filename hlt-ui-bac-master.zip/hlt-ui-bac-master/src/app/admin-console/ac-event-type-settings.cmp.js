(function (angular, topWindow) {
	angular.module('hltApp')
	.component('acEventTypeSettings', {
		templateUrl: 'src/app/admin-console/ac-event-type-settings.tpl.html',
		bindings: {
			settings: '=',
			mainEventNames: '<'
		},
		controller: [
			'$scope',
			'$timeout',
			'util',
			function ($scope, $timeout, util) {
				var $ctrl = this;

				var DEFAULT_TIME_PICKER_OPTIONS = {
					step: 15
				};

				var SETTINGS_INPUT_TYPE = {
					TEXT: 'text',
					SELECT: 'select',
					TIME_PICKER: 'time-picker',
					COLOR_PICKER: 'color-picker',
					CHECKBOX_TOGGLE: 'checkbox-toggle'
				};

				var EVENT_TYPE_SETTINGS_GROUP = {
					JOB: {
						name: 'jobTypes',
						title: 'Job Type',
						objectType: 'job'
					},
					ACTIVITY: {
						name: 'activityTypes',
						title: 'Activity Type',
						objectType: 'activity'
					},
					AVAILABILITY: {
						name: 'availabilityTypes',
						title: 'Availability Type',
						objectType: 'availability'
					},
					CLIENT_AVAILABILITY: {
						name: 'clientAvailabilityTypes',
						title: 'Service User Availability Type',
						objectType: 'clientAvailability'
					}
				};

				var SETTINGS_TABLE_COLUMNS = {
					EVENT_TYPE: {
						name: 'eventType',
						title: 'Event Type',
						cssClasses: ['event-type__col'],
						inputType: SETTINGS_INPUT_TYPE.TEXT
					},
					SHORT_NAME: {
						name: 'shortName',
						title: 'Short Name',
						cssClasses: ['short-name__col'],
						inputType: SETTINGS_INPUT_TYPE.TEXT
					},
					AVAILABLE_START: {
						name: 'availableStart',
						title: 'Available Start',
						cssClasses: ['avail-start__col'],
						inputType: SETTINGS_INPUT_TYPE.TIME_PICKER
					},
					AVAILABLE_END: {
						name: 'availableEnd',
						title: 'Available End',
						cssClasses: ['avail-end__col'],
						inputType: SETTINGS_INPUT_TYPE.TIME_PICKER
					},
					/* EVENT_STATUS: {
						name: 'eventStatus',
						title: 'Event Status',
						cssClasses: ['avail-end__col'],
						inputType: SETTINGS_INPUT_TYPE.TIME_PICKER
					}, */
					BACKGROUND_COLOR: {
						name: 'backgroundColor',
						title: 'Background Color',
						cssClasses: ['background-color__col'],
						inputType: SETTINGS_INPUT_TYPE.COLOR_PICKER
					},
					COLOR: {
						name: 'color',
						title: 'Color',
						cssClasses: ['color__col'],
						inputType: SETTINGS_INPUT_TYPE.COLOR_PICKER
					},
					// STEP: {
					// 	name: 'step',
					// 	title: 'Step',
					// 	cssClasses: ['step__col'],
					// 	inputType: SETTINGS_INPUT_TYPE.TEXT
					// },
					IS_AVAILABLE: {
						name: 'isAvailable',
						title: 'Is Available',
						cssClasses: ['is-available__col'],
						inputType: SETTINGS_INPUT_TYPE.CHECKBOX_TOGGLE
					},
					SHOW_LEGEND: {
						name: 'showLegend',
						title: 'Show Legend',
						cssClasses: ['show-legend__col'],
						inputType: SETTINGS_INPUT_TYPE.CHECKBOX_TOGGLE
					},
					CAN_BE_PREDATED: {
						name: 'canBePreDated',
						title: 'Can Be Pre-Dated',
						cssClasses: ['can-be-pre-dated__col'],
						inputType: SETTINGS_INPUT_TYPE.CHECKBOX_TOGGLE
					},
					IS_ACTIVE: {
						name: 'isActive',
						title: 'Is Active',
						cssClasses: ['is-active__col'],
						inputType: SETTINGS_INPUT_TYPE.CHECKBOX_TOGGLE
					}
				};

				var clearError = function () {
					$ctrl.errors = {
						isError: false
					};
				};

				var setError = function (group, settings, field, error) {
					var errorGroup, errorSettings, errorField;

					$ctrl.errors.isError = true;
					if (group) {
						errorGroup = $ctrl.errors[group];
						if (!errorGroup) {
							errorGroup = $ctrl.errors[group] = {};
						} 

						errorGroup.isError = true;

						if (settings) {
							errorSettings = errorGroup[settings];
							if (!errorSettings) {
								errorSettings = errorGroup[settings] = {
									errors: []
								};
							} 

							errorSettings.isError = true;
							if (error) {
								errorSettings.errors.push(error);
							}
							
							if (field) {
								errorField = errorSettings[field];
								if (!errorField) {
									errorField = errorSettings[field] = {};
								} 

								errorField.isError = true;
								errorField.errorMessage = error;
							}
						}
					}
				};

				var validateSettings = function () {
					var form = $ctrl.eventTypeSettingsForm;
					clearError();
					
					if (form) {
						form.$setSubmitted();

						angular.forEach($ctrl.eventTypeSettingsGroup, function (settingsList, groupName) {
							angular.forEach(settingsList, function (settings) {
								/* angular.forEach(SETTINGS_TABLE_COLUMNS, function (field) {

								}); */
								if (!settings.eventType || settings.eventType.trim().length === 0) {
									setError(groupName, settings.id, 'eventType', 'Event type required.');
								}
								if (angular.isNumber(settings.availableStart) && angular.isNumber(settings.availableEnd) &&
									settings.availableStart >= settings.availableEnd) {
									setError(groupName, settings.id, 'availableStart', 'Available start should be before available end.')
									setError(groupName, settings.id, 'availableEnd')
								}
							});
						});
					}
					
					return !$ctrl.errors.isError;
				};

				var handleSettingsSaving = function ($event) {
					if (!validateSettings()) {
						util.toastError('Invalid settings input.');
						$event.preventDefault();
					}
				};

				var groupEventTypeSettingsByObjectType = function () {
					$ctrl.eventTypeSettingsGroup = {};
					if (angular.isArray($ctrl.settings)) {
						angular.forEach($ctrl.settings, function (eventTypeSetting) {
							var objectType = eventTypeSetting.objectType;

							if (!angular.isArray($ctrl.eventTypeSettingsGroup[objectType])) {
								$ctrl.eventTypeSettingsGroup[objectType] = [];
							}

							$ctrl.eventTypeSettingsGroup[objectType].push(eventTypeSetting);
						});
					}
				};

				var selectGroup = function (group) {
					util.showLoading();
					$timeout(function () {
						$ctrl.selectedGroup = group;

						$timeout(function () {
							util.hideLoading();
						}, 10);
					});
				};

				/**
				 * controller init
				 * used for setting initial value
				 */
				$ctrl.$onInit = function () {					
					$scope.$on($ctrl.mainEventNames.SAVE, handleSettingsSaving);
				};

				/**
				 * init block
				 * used for setting up controller
				 */
				(function () {
					$scope.EVENT_TYPE_SETTINGS_GROUP = EVENT_TYPE_SETTINGS_GROUP;
					$scope.DEFAULT_TIME_PICKER_OPTIONS = DEFAULT_TIME_PICKER_OPTIONS;
					$scope.SETTINGS_TABLE_COLUMNS = SETTINGS_TABLE_COLUMNS;
					$scope.SETTINGS_INPUT_TYPE = SETTINGS_INPUT_TYPE;

					$ctrl.eventTypeSettingsForm = null;
					$ctrl.eventTypeSettingsGroup = {};
					$ctrl.errors = {};
					$ctrl.selectedGroup = EVENT_TYPE_SETTINGS_GROUP.JOB;

					$ctrl.selectGroup = selectGroup;

					$scope.$watch('$ctrl.settings', function () {
						groupEventTypeSettingsByObjectType();
					});
				})();
			}
		]
	});
})(angular, top);