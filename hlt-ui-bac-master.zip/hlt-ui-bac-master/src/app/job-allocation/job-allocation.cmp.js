(function (angular, topWindow) {
	angular.module('hltApp')
	.component('jobAllocation', {
		templateUrl: 'src/app/job-allocation/job-allocation.tpl.html',
		bindings: {
			job: '<',
			jobPinning: '<?',
			isSingleJob: '<?',
			allowPostingMessage: '<?',
			allowGoingBack: '<?',
			rootRecordId: '<?',
			configData: '<?',
			onClose: '&?'
		},
		controller: [
			'JOB_STATUS',
			'constants',
			'$scope',
			'$timeout',
			'$window',
			'$location',
			'$q',
			'$filter',
			'api',
			'util',
			'dateUtil',
			'model',
			'uiGmapGoogleMapApi',
			'availatorUtil',
			function (JOB_STATUS, constants, $scope, $timeout, $window, $location, $q, $filter, api, util, dateUtil, model, uiGmapGoogleMapApi, availatorUtil) {
				var $ctrl = this;
				var initializingData = true;
				var mapsApi = null;
				var now = new Date();
				var DEFAULT_JOB_PAGE_SIZE = 50;
				var TABS = {
					ALLOCATED_RESOURCES: 'allocatedResources',
					OFFERED_RESOURCES: 'offeredResources'
				}

				var SINGLE_JOB_SCHEDULE_OPTION = {
					id: '',
					description: 'Single Jobs' 
				};
				var DEFAULT_PHOTO_URL = $filter('skedSfUrl')('slds/images/avatar3.jpg');
				var WEEK_DAYS = [
					{
						label: 'Sunday',
						value: 'sun',
						numVal: 0
					},
					{
						label: 'Monday',
						value: 'mon',
						numVal: 1
					},
					{
						label: 'Tuesday',
						value: 'tue',
						numVal: 2
					},
					{
						label: 'Wednesday',
						value: 'wed',
						numVal: 3
					},
					{
						label: 'Thursday',
						value: 'thu',
						numVal: 4
					},
					{
						label: 'Friday',
						value: 'fri',
						numVal: 5
					},
					{
						label: 'Saturday',
						value: 'sat',
						numVal: 6
					}
				];
				var COMMON_DATE_FORMAT = 'EEE, MMM d, yyyy';
				var JOB_ALLOCATION_REQUIRED_CONFIG_DATA = [
					'jobCancellationReasons',
					'patientSupportPlans',
					'patientContacts',
					'jobTypes',
					'resourceCategories',
					//'clientAvailabilityTypes',
					'holidays',
					'patientLocations',
					'regions',
					'timezones',
					'tags'
				];
				var currentParams = {};
				var searchParams = $location.search();

				var nameFilter = $filter('filter');

				var getArray = function (len) {
					len = len || 0;
					if (len < 0) {
						len = 0;
					}
					return new Array(len);
				};
				
				/**
				 * common remote action error handler
				 */
				var commonExceptionHanlder = function (exception) {
					console.error(exception);
					util.toastError('Can not perform action due to server error.');

					return $q.reject();
				};

				/**
				 * show content loading
				 */
				var showLoading = function () {
					$ctrl.contentLoading = true;
				};

				/**
				 * hide content loading
				 */
				var hideLoading = function () {
					$ctrl.contentLoading = false;
				};

				/**
				 * communicate with parent since page will be loaded on an iframe
				 */
				var postMessageToParent = function (message, data) {
					if (topWindow && topWindow.postMessage) {
						topWindow.postMessage(angular.extend({
							message: message
						}, data), $ctrl.parentDomain);
					}
				};

				/**
				 * close main modal
				 */
				var closeModal = function (message) {
					$ctrl.isModalOpen = false;
					postMessageToParent(message);

					// run onClose expression
					if (angular.isFunction ($ctrl.onClose)) {
						$ctrl.onClose({
							message: message
						});
					}
				};

				var isParamsReallyChanged = function (params, currentParams) {
					return !util.compareValues(params, currentParams);
				};

				var showErrorPrompt = function (errorMessage, noBackdrop) {
					util.showModal({
						templateUrl: 'src/app/error-prompt-template.html',
						noBackdrop: !!noBackdrop
					}, {
						message: errorMessage,
						closePrompt: function (scope) {
							scope.closeModal();
							closeModal('cancel');
						}
					});
				};

				var unassignResource = function (allocation, job) {
					var allocationIdx, resourceIdx, jobOfferIdx, jobOffer;

					if (job) {
						for (var i = 0; i < job.allocations.length; i++) {
							if (job.allocations[i].resource.id === allocation.resource.id) {
								allocationIdx = i;
								break;
							}
						}
						if (allocationIdx > -1) {
							job.allocations.splice(allocationIdx, 1);
						}

						resourceIdx = job.assignedResourcesIds.indexOf(allocation.resource.id);
						if (resourceIdx > -1) {
							job.assignedResourcesIds.splice(resourceIdx, 1);
						}

						angular.forEach(job.conflictedJobs, function (conflictedJob) {
							var resourceIdIndex = conflictedJob.conflictedJobAssignedResourceIds.indexOf(allocation.resource.id);
							// add resource id to assigned resources id list of conflicted jobs
							if (resourceIdIndex > -1) {
								conflictedJob.conflictedJobAssignedResourceIds.splice(resourceIdIndex, 1);
							}
							// cancel all job offer of conflicted jobs
						});
					} else {
						angular.forEach($ctrl.filteredJobs, function (job) {
							unassignResource(allocation, job);
						});
					}
				};

				var assignResource = function (resource, job) {
					var jobAllocation, possibleResourceIndx, possibleJobAllocation;
					var jobOfferIdx, jobOffer;

					if (job) {
						if (resourceCanBeAllocatedToJob(resource, job)) {
							jobAllocation = new model.JobAllocationModel();
							jobAllocation.resource = resource;

							possibleResourceIndx = job.assignableResourcesIds.indexOf(resource.id);
							if (possibleResourceIndx > -1) {
								possibleJobAllocation = job.possibleAllocations[possibleResourceIndx];

								jobAllocation.travelDistanceFrom = possibleJobAllocation.travelDistanceFrom;
								jobAllocation.travelTimeFrom = possibleJobAllocation.travelTimeFrom;
							}
							
							job.allocations.push(jobAllocation);

							if (job.assignedResourcesIds.indexOf(resource.id) === -1) {
								job.assignedResourcesIds.push(resource.id);
							}

							// cancel job offer
							jobOfferIdx = job.offeringResourcesIds.indexOf(resource.id);
							if (jobOfferIdx > -1) {
								for (var i = 0; i < job.jobOffers.length; i++) {
									if (job.jobOffers[i].resource.id === resource.id) {
										jobOffer = job.jobOffers[i];
										break;
									}
								}

								if (jobOffer) {
									cancelResourceOffer(jobOffer, job);
								}
							}

							angular.forEach(job.conflictedJobs, function (conflictedJob) {
								// add resource id to assigned resources id list of conflicted jobs
								if (conflictedJob.conflictedJobAssignedResourceIds.indexOf(resource.id) === -1) {
									conflictedJob.conflictedJobAssignedResourceIds.push(resource.id);
								}
								// cancel all job offer of conflicted jobs
							});
						}
					} else {
						angular.forEach($ctrl.filteredJobs, function (job) {
							assignResource(resource, job);
						});
					}
				};

				var cancelResourceOffer = function (jobOffer, job) {
					var jobOfferIdx, resourceIdx;

					if (job) {
						for (var i = 0; i < job.jobOffers.length; i++) {
							if (job.jobOffers[i].resource.id === jobOffer.resource.id) {
								jobOfferIdx = i;
								break;
							}
						}
						if (jobOfferIdx > -1) {
							job.jobOffers.splice(jobOfferIdx, 1);
						}

						resourceIdx = job.offeringResourcesIds.indexOf(jobOffer.resource.id);
						if (resourceIdx > -1) {
							job.offeringResourcesIds.splice(resourceIdx, 1);
						}
					} else {
						angular.forEach($ctrl.filteredJobs, function (job) {
							cancelResourceOffer(jobOffer, job);
						});
					}
				};

				var offerResource = function (resource, job) {
					var jobOffer, possibleResourceIndx, possibleJobAllocation;

					if (job) {
						if (resourceCanBeAllocatedToJob(resource, job)) {
							jobOffer = new model.JobOfferModel();
							jobOffer.resource = resource;

							possibleResourceIndx = job.assignableResourcesIds.indexOf(resource.id);
							if (possibleResourceIndx > -1) {
								possibleJobAllocation = job.possibleAllocations[possibleResourceIndx];

								jobOffer.travelDistanceFrom = possibleJobAllocation.travelDistanceFrom;
								jobOffer.travelTimeFrom = possibleJobAllocation.travelTimeFrom;
							}
							
							job.jobOffers.push(jobOffer);

							if (job.offeringResourcesIds.indexOf(resource.id) === -1) {
								job.offeringResourcesIds.push(resource.id);
							}
						}
					} else {
						angular.forEach($ctrl.filteredJobs, function (job) {
							offerResource(resource, job);
						});
					}
				};

				var assignDraggingResource = function (job) {
					if (!$ctrl.pinnedJob || $ctrl.pinnedJob === job) {
						assignResource($ctrl.draggingResource, job);
					}
				};

				var findResource = function (resourceId, resources) {
					var resource = null;

					if (resourceId && angular.isArray(resources) && resources.length > 0) {
						for (var i = 0; i < resources.length; i++) {
							if (resourceId == resources[i].id) {
								resource = resources[i];
								break;
							}
						}
					}

					return resource;
				};

				var processJobOffers = function (job, resources) {
					if (angular.isArray(job.jobOffers)) {
						job.offeringResourcesIds = job.jobOffers.map(function (jobOffer) {
							var resource = findResource(jobOffer.resource.id, resources);
							if (resource) {
								jobOffer.resource = resource;
							}

							return jobOffer.resource.id;
						});
					} else {
						job.offeringResourcesIds = [];
					}
					job.originalJobOffers = angular.extend([], job.jobOffers);
				};

				var processJobAllocations = function (job, resources) {
					if (angular.isArray(job.allocations)) {
						job.assignedResourcesIds = job.allocations.map(function (allocation) {
							var resource = findResource(allocation.resource.id, resources);
							if (resource) {
								allocation.resource = resource;
							}

							return allocation.resource.id;
						});
					} else {
						job.assignedResourcesIds = [];
					}
					job.originalAllocations = angular.extend([], job.allocations);
				};

				var processJobPossibleAllocations = function (job, resources) {
					job.assignableResourcesIds = [];
					job.assignableResourcesMap = {};
					if (angular.isArray(job.possibleAllocations)) {
						angular.forEach(job.possibleAllocations, function (allocation) {
							allocation.travelTimeName = getTravelTimeName(allocation.travelTimeFrom || 0);

							job.assignableResourcesIds.push(allocation.resource.id);
							job.assignableResourcesMap[allocation.resource.id] = allocation;
						}); 
					}
				};

				var processJobsConfliction = function (jobs) {
					if (angular.isArray(jobs) && jobs.length > 0) {
						angular.forEach(jobs, function (job) {
							job.conflictedJobs = identifyConflictedJobs($ctrl.scheduleAllocation.jobs, job);
							job.conflictedJobAssignedResourceIds = [];

							// collect assigned resources ids from conflicted jobs
							if (job.conflictedJobs.length > 0) {
								angular.forEach(job.conflictedJobs, function (confictedJob) {
									angular.extend(job.conflictedJobAssignedResourceIds, confictedJob.assignedResourcesIds);
								});
							}
						});
					}
				};

				var mapJobTypes = function (jobs, jobTypes) {
					var jobTypeIds = jobTypes.map(function (jobType) {
						return jobType.id
					});

					angular.forEach(jobs, function (job) {
						var jobTypeInd = jobTypeIds.indexOf(job.eventType.id);

						if (jobTypeInd === -1) {
							job.eventType = null;
						} else {
							job.eventType = jobTypes[jobTypeInd];
						}
					});
				};

				var mapResourcesAllocation = function (scheduleAllocation) {
					var resources = scheduleAllocation.resources,
						jobs = scheduleAllocation.jobs;
						//numberOfInstructors = scheduleAllocation.numberOfInstructors || 0;
					/*var resourceIds = [];

					if (angular.isArray(resources) && resources.length > 0) {
						resourceIds = resources.map(function (resource) {
							return resource.id;
						});
					}*/

					if (angular.isArray(jobs) && jobs.length > 0) {
						angular.forEach(jobs, function (job) {
							// process job allocations
							processJobAllocations(job, resources);

							// process job offers
							processJobOffers(job, resources);

							// process job possible allocations
							processJobPossibleAllocations(job, resources);
						});
					}
				};

				var getTravelTimeName = function (timeInMinute) {
					var h = Math.floor(timeInMinute/60),
						m = timeInMinute%60;

					return  ((h > 0)?(h + 'h '):'') + m + 'm';
				};

				var doGetScheduledAllocation = function (requestParams) { 
					return api.getScheduledAllocation(requestParams)
						.catch(commonExceptionHanlder);
				};

				var doSaveAllocations = function (requestParams) {
					var jobsPerCall = 50;
					var processedJobs = 0;

					util.updateProgressBar(0);
					var promises = _.chunk(requestParams.jobs, jobsPerCall).map(function (events) {
						return function() {
							return api.saveAllocations(_.extend({}, requestParams, {
								jobs: events
							}))
								.then(function(result) {
									if(!result.success) {
										return $q.reject(result);
									}

									processedJobs = processedJobs + jobsPerCall;
									util.updateProgressBar(processedJobs);
									return result;
								});
						};
					});

					return util.serial(promises)
						.catch(commonExceptionHanlder);
				};

				var doInitialize = function (requestParams) {
					return api.initialize(requestParams)
						.catch(commonExceptionHanlder);
				};

				var doSendJobOffers = function (requestParams) {
					return api.sendJobOffers(requestParams)
						.catch(commonExceptionHanlder);
				};

				var produceResourcesActions = function (job, mergedResourcesActions, originalResourcesIds, currentResourcesIds) {
					var processedResourceIds = [];
					var resourcesActions = [];

					angular.forEach(mergedResourcesActions, function (resourceAction) {
						var action = '', 
							resourceId = resourceAction.resource.id;

						if (processedResourceIds.indexOf(resourceId) === -1) {

							if (currentResourcesIds.indexOf(resourceId) === -1) {
								action = 'delete';
							} else if (originalResourcesIds.indexOf(resourceId) === -1) {
								action = 'create';
							}

							resourcesActions.push({
								id: resourceAction.id,
								jobId: job.id,
								resourceId: resourceId,
								action: action,
								travelDistanceFrom: resourceAction.travelDistanceFrom || null,
								travelTimeFrom: resourceAction.travelTimeFrom || null
							});

							processedResourceIds.push(resourceId);
						}
					});

					return resourcesActions;
				};

				var produceJobParams = function (job) {
					var rtJob, allocations, jobOffers, 
						allocatedResourcesIds, offeringResourcesIds,
						originalAllocatedResourceIds, originalOfferingResourceIds;

					originalAllocatedResourceIds = job.originalAllocations.map(function (allocation) {
						return allocation.resource.id;
					}),

					allocatedResourcesIds = job.assignedResourcesIds || [];


					// produce allocation actions
					allocations = produceResourcesActions(job, job.originalAllocations.concat(job.allocations), originalAllocatedResourceIds, allocatedResourcesIds);

					rtJob = {
						id: job.id,
						jobAllocations: allocations,
						//jobOffers: jobOffers
					};

					if ($ctrl.scheduleAllocation.enableJobOffer) {
						originalOfferingResourceIds = job.originalJobOffers.map(function (jobOffer) {
							return jobOffer.resource.id;
						});

						offeringResourcesIds = job.offeringResourcesIds || [];

						// produce job offers actions
						jobOffers = produceResourcesActions(job, job.originalJobOffers.concat(job.jobOffers), originalOfferingResourceIds, offeringResourcesIds);

						rtJob.jobOffers = jobOffers;
					}

					return rtJob;
				};

				var performSavingJobAllocations = function (isDispatching) {
					var jobParams = $ctrl.scheduleAllocation.jobs.map(produceJobParams);
					var requestParams = {
						jobs: jobParams,
						notifyResources: isDispatching
					}

					util.showProgressBar({
						message: 'Processing...',
						totalRecords: requestParams.jobs.length
					});
					return doSaveAllocations(requestParams)
						.then(function (result) {
							if (result.success) {
								util.toastSuccess('Resource allocations updated successfully.');
								return true;
							} else{
								return $q.reject(result);
							}
						})
						.catch(function (exception) {
							if (exception && exception.errorMessage) {
								util.toastError(exception.errorMessage);
							}
						})
						.finally(function () {
							util.hideProgressBar();
						});
				};

				var saveAllocations = function (isDispatching) {
					var requiringTLJobs = [];
					var tmpJob;

					performSavingJobAllocations(isDispatching)
						.then(function () {
							closeModal('done');
						});
				};

				var isJobConflicting = function (job, otherJob) {
					var otherJob, isConflict = false;

					return (otherJob !== job &&
							job.startDate.getTime() === otherJob.startDate.getTime() && // same date
							job.startTime < otherJob.endTime && job.endTime > otherJob.startTime); // conflict time

				};

				var identifyConflictedJobs = function (jobs, job) {
					var conflictedJobs = [];

					angular.forEach(jobs, function (jobItem) {
						if (isJobConflicting(job, jobItem)) {
							conflictedJobs.push(jobItem);
						}
					});

					return conflictedJobs;
				};

				var needToRefreshResources = function() {
					if(!$ctrl.resourcesFilters) return false;

					var currentFilters = {
						regionId: ($ctrl.resourcesFilters.region || {}).id,
						resourceCategories: _.map($ctrl.resourcesFilters.categories, 'id'),
						tags: _.map($ctrl.resourcesFilters.tags, 'id')
					};

					var lastFilters = currentParams.resourcesFilters ? {
						regionId: (currentParams.resourcesFilters.region || {}).id,
						resourceCategories: _.map(currentParams.resourcesFilters.categories, 'id'),
						tags: _.map(currentParams.resourcesFilters.tags, 'id')
					} : null;
					
					return isParamsReallyChanged(currentFilters, lastFilters);
				};

				var refreshResources = function() {
					showLoading();
					$timeout(function(){
						getJobs();
					})
				};

				var latestAllocationData = null;
				var latestSimplyAvailabilityData = null;
				var getJobs = function () {
					var requestParams = null;
					var enableJobOffer = true;
					var currentJobs = [];
					var resources = [];
					var resourceAvailabilitySimply = [];
					
					var populateDateTimeToSObject = function(sObject, timezoneSidId) {
						var startDateTime = dateUtil.getDateTimeInfo(sObject.sked__Start__c || sObject.sked_Start_Date__c, timezoneSidId);
						sObject.start = startDateTime.dateTime;
						sObject.startDate = startDateTime.date;
						sObject.startTime = startDateTime.timeNumber

						var endDateTime = dateUtil.getDateTimeInfo(sObject.sked__Finish__c || sObject.sked__End__c || sObject.sked_End_Date__c, timezoneSidId);
						sObject.finish = endDateTime.dateTime;
						sObject.endDate = endDateTime.date;
						sObject.endTime = endDateTime.timeNumber

						return sObject;
					}

					var doGetResourceData = function(requestParams, pageNo, totalRecords) {
						return api.getResourceData(_.extend({}, requestParams, {
							pageNo: pageNo || 1,
							pageSize: 200
						})).then(function (result) {
							if (result.success && result.data) {
								var resultData = result.data;
								resources = resources.concat(resultData.resources);

								util.updateProgressBar(resources.length);

								if (totalRecords > resources.length) {
									return doGetResourceData(requestParams, pageNo + 1, totalRecords);
								} else {
									return {
										resources: resources
									};
								}
							} else {
								return $q.reject(result);
							}
						});
					}

					var doGetResourceAvailabilitySimply = function(requestParams) {
						var resourcesPerCall = 200;

						var promises = _.chunk(requestParams.resourceIds, resourcesPerCall).map(function (resourceIds) {
							return function() {
								return api.getResourceAvailabilitySimply(_.extend({}, requestParams, {
									resourceIds: resourceIds
								}))
									.then(function(result) {
										if(!result.success) {
											return $q.reject(result);
										}

										resourceAvailabilitySimply = resourceAvailabilitySimply.concat((result.data || {}).result || []);
										util.updateProgressBar(resourceAvailabilitySimply.length);
										return {
											success: true,
											data: resourceAvailabilitySimply || []
										};
									});
							};
						});

						return $q.when()
						.then(function() {
							if(!promises.length) {
								return {
									success: true,
									data: []
								};
							}

							return util.serial(promises);
						})
						.catch(commonExceptionHanlder);
					} 

					var doTransformAvailabilitySimply = function(data, timezoneSidId) {
						var result = [];
						data.forEach(function(resourceAvailability) {
							var resource = {};
							resource.id = resourceAvailability.resourceId;
							var events = [];
							(resourceAvailability.mergedAvailabilities || []).forEach(function(simplifiedAvailability) {
								var startDateInfo = dateUtil.getDateTimeInfo(simplifiedAvailability.start, timezoneSidId);
								var endDateInfo = dateUtil.getDateTimeInfo(simplifiedAvailability.end_x, timezoneSidId);
								if (startDateInfo.date < endDateInfo.date) {
									var firstEvent = {};
									firstEvent.start = startDateInfo.dateTime;
									firstEvent.finish = endDateInfo.dateTime;
									events.push(firstEvent);

									var indexDate = moment(startDateInfo.date).add(1, 'day').toDate();
									while (indexDate < endDateInfo.date) {
										var event = {};
										event.start = moment(indexDate).startOf('day').toDate();
										event.finish = endDateInfo.dateTime;
										events.push(event);
										indexDate = moment(indexDate).add(1, 'day').toDate();
									}
									var lastEvent = {};
									lastEvent.start = moment(endDateInfo.date).startOf('day').toDate();
									lastEvent.finish = endDateInfo.dateTime;
									events.push(lastEvent);
								} else {
									var event = {};
									event.start = startDateInfo.dateTime;
									event.finish = endDateInfo.dateTime;
									events.push(event);
								}
							})
							resource.events = events;

							result.push(resource);
						})

						return result;
					}

					var doGetJobs = function (requestParams) {
						var allocationData = null;
						var simplyAvailabilityData = null;
						var timezoneSidId = null;
						var latestParams = currentParams.getJobs;
						var promise;
						//if is region changed, call API again
						if(!_.isEqual(_.pick(requestParams, ['regionId']), _.pick(latestParams, ['regionId']))) {
							util.showProgressBar({
								message: 'Loading resource data...',
								loadingMode: true
							});
							promise = $q.when()
							.then(function() {
								console.log('>>> Start get allocation data: ', new Date());
								var allocationData, resourceData;
								return api.getAllocationData(angular.extend(requestParams, {
									pageNo: 1,
									pageSize: 200
								}))
								.then(function(result) {
									if(!result || !result.success) return $q.reject(result);
									var resultData = result.data;
									allocationData = resultData;
									resources = resources.concat(resultData.resources || []);

									util.showProgressBar({
										message: 'Loading resource data...',
										totalRecords: resultData.totalRecords, 
										totalPercentage: 240,
										processedRecords: resources.length
									});

									if(resultData.totalRecords > resources.length) {
										return doGetResourceData(_.extend({}, requestParams, {
											inputDates: resultData.inputDates,
											expiryTagDate: resultData.expiryTagDate,
											jobIds: resultData.jobIds,
											assignedResourceIds: resultData.assignedResourceIds,
											startOfWeekDates: resultData.startOfWeekDates,
										}), 2, resultData.totalRecords);
									}
								})
								.then(function() {
									util.updateProgressBar(resources.length, 'Processing data...', true);
									return {
										jobOffers: allocationData.jobOffers,
										jobs: allocationData.jobs,
										resources: resources || []
									}
								})
							})
							.then(function(result) {
								var data = result || {};
								timezoneSidId = data.jobs[0].sked__Timezone__c;
								data.jobs = data.jobs.map(function(item) {
									item.objectType = 'jobAllocation';
									return populateDateTimeToSObject(item, timezoneSidId);
								})
								data.jobs = _.orderBy(data.jobs, ['start'], ['asc']);
								data.resources.map(function(resource) {
									var activities = (resource.sked__Activities__r || []).map(function(activity) {
										activity.objectType = 'activity';
										return activity;
									});
									var jobs = _.compact((resource.sked__Job_Allocations__r || []).map(function(ja) {
										var job = ja.sked__Job__r;
										job.objectType = 'jobAllocation';
										return job;
									}));
									resource.events = activities.concat(jobs).map(function(item) {
										return populateDateTimeToSObject(item, timezoneSidId);
									});
									resource.events = _.orderBy(resource.events, ['start'], ['asc']);

									return resource;
								})
								allocationData = data;
								console.log('>>> Finished get allocation data: ', new Date());
							})
							.then(function() {
								//get simple availability
								var minStart = _.first(allocationData.jobs);
								var maxFinish = _.last(allocationData.jobs);

								console.log('>>> Start get simply availability data: ', new Date());
								util.showProgressBar({
									message: 'Loading availability data...',
									totalRecords: allocationData.resources.length, 
									totalPercentage: 240,
									defaultPercentage: 100,
									processedRecords: 0
								});
								return doGetResourceAvailabilitySimply({
									startDate: dateUtil.dateToString(minStart.startDate),
									startTime: minStart.startTime,
									endDate: dateUtil.dateToString(maxFinish.endDate),
									endTime: maxFinish.endTime,
									resourceIds: _.map((allocationData.resources || []), 'Id')
								});
							})
							.then(function(result) {
								util.updateProgressBar(resources.length, 'Processing data...', true);
								return $timeout(500)
								.then(function() {
									return result;
								})
							})
							.then(function(result) {
								if(!result || !result.success) return $q.reject(result);

								simplyAvailabilityData = result.data;
								console.log('>>> Finished get simply availability data: ', new Date());
								simplyAvailabilityData = doTransformAvailabilitySimply(simplyAvailabilityData || [], timezoneSidId);

								console.log('>>> Finished build simply availability data: ', new Date());

								//backup latest data
								latestAllocationData = _.cloneDeep(allocationData);
								latestSimplyAvailabilityData = _.cloneDeep(simplyAvailabilityData);

								var skedAvailator = availatorUtil.getInstance($ctrl.configData, requestParams, mapsApi);
								var scheduledAllocation = skedAvailator.buildScheduledAllocations(allocationData, simplyAvailabilityData);
								
								console.log('>>> Finished build data data: ', new Date());

								return scheduledAllocation;
							})
						}
						else {//if not, rebuild data
							showLoading();
							promise = $q.when()
							.then(function() {
								var skedAvailator = availatorUtil.getInstance($ctrl.configData, requestParams, mapsApi);
								var scheduledAllocation = skedAvailator.buildScheduledAllocations(latestAllocationData, latestSimplyAvailabilityData);
								return scheduledAllocation;
							})
						}
						
						return promise.then(function(scheduledAllocation) {
							$ctrl.resources = scheduledAllocation.resources;
							currentJobs = scheduledAllocation.jobs;

							//old logic
							return {
								jobs: scheduledAllocation.jobs,
								resources: scheduledAllocation.resources,
								schedules: [],
								enableJobOffer: enableJobOffer
							};
						})
					};

					var restoreCurrentJobs = function () {
						var jobs = $ctrl.scheduleAllocation.jobs;
						//update allocations and offers
						if (angular.isArray(currentJobs) && currentJobs.length > 0) {
							angular.forEach(jobs, function (job) {
								var currentJobFound = currentJobs.find(function (currentJob) {
									return currentJob.id === job.id;
								});

								if (currentJobFound) {
									job.jobOffers = angular.extend([], currentJobFound.jobOffers);
									job.allocations = angular.extend([], currentJobFound.allocations);
								}
							});
						}
					};

					var restorePinnedJob = function () {
						if ($ctrl.pinnedJob) {
							$ctrl.pinnedJob = $ctrl.scheduleAllocation.jobs.find(function (job) {
								return job.id === $ctrl.pinnedJob.id;
							});

							$ctrl.pinnedJobAssignableResources = $ctrl.scheduleAllocation.resources.filter(function (resource) {
								return $ctrl.pinnedJob.assignableResourcesIds.indexOf(resource.id) > -1;
							});

							// sort assignable resources by travel distance and time
							$ctrl.pinnedJobAssignableResources.sort(function (resource1, resource2) {
								var resourceAllocation1 = $ctrl.pinnedJob.assignableResourcesMap[resource1.id],
									resourceAllocation2 = $ctrl.pinnedJob.assignableResourcesMap[resource2.id];

								return ((resourceAllocation1.travelDistanceFrom || 0) - (resourceAllocation2.travelDistanceFrom || 0)) || 
								((resourceAllocation1.travelTimeFrom || 0) - (resourceAllocation2.travelTimeFrom || 0));
							});
						}
					};

					if ($ctrl.resourcesFilters.region) {
						requestParams = {
							regionId: $ctrl.resourcesFilters.region.id,
							job: $ctrl.jobParams,
							resourceCategories: _.map($ctrl.resourcesFilters.categories, 'id'),
							tags: ($ctrl.resourcesFilters.tags || []).map(function(item) {
								return {
									id: item.id
								}
							})
						};

						if (isParamsReallyChanged(requestParams, currentParams.getJobs)) {
							return doGetJobs(requestParams, 1)
								.then(function (scheduleAllocation) {
									$ctrl.scheduleAllocation = scheduleAllocation;
								})
								.then(function() {
									var configData = $ctrl.configData,
									scheduleAllocation = $ctrl.scheduleAllocation;

									// map job types
									mapJobTypes(scheduleAllocation.jobs, $ctrl.jobsFilters.eventTypes);

									// map resources
									mapResourcesAllocation(scheduleAllocation);

									// identify job confliction
									processJobsConfliction(scheduleAllocation.jobs);
								})
								.then(restoreCurrentJobs)
								.then(restorePinnedJob)
								.then(function () {
									applyResourcesFilters();
									applyJobsFilters();
									pinResource();

									currentParams.getJobs = _.omit(angular.copy(requestParams), ['viewData', 'pageNo', 'pageSize']);
									console.log('>>> Finished all: ', new Date());
								})
								.catch(function (exception) {
									console.log(exception)
									if (exception && exception.errorMessage) {
										console.error(exception);
										util.toastError(exception.errorMessage);
									}
								})
								.finally(function(){
									hideLoading();
									util.hideProgressBar();
								})
						}
					} else {
						currentParams.getJobs = null;
						$ctrl.scheduleAllocation = null;
					}
				};

				var getInitialData = function () {
					var requestParams = {
						configKeys: JOB_ALLOCATION_REQUIRED_CONFIG_DATA
					};

					if ($ctrl.configData) {
						return $q.resolve($ctrl.configData);
					} else {
						return doInitialize(requestParams)
							.then(function (result) {
								var jobStatusSettings = {}, natClassTypeSettings = {};

								if (result.success) {
									$ctrl.configData = model.ConfigDataModel.fromServer(result.data);

									// convert job status settings to map (to easy retreive)
									if (angular.isArray($ctrl.configData.jobStatusSettings)) {
										angular.forEach($ctrl.configData.jobStatusSettings, function (jobStatusSetting) {
											jobStatusSettings[jobStatusSetting.jobStatus] = jobStatusSetting;
										});
									}

									$ctrl.configData.jobStatusSettings = jobStatusSettings;

									return $ctrl.configData;
								} else {
									return $q.reject(result);
								}
							});
					}
					
				};

				var isInPast = function (date) {
					return date < now;
				};

				var jobCanBeAllocated = function (job) {
					//var jobDate = dateUtil.parseDateString(job.jobDate);
					var allowedJobStatuses = [
						JOB_STATUS.QUEUED,
						JOB_STATUS.PENDING_ALLOCATION,
						JOB_STATUS.PENDING_DISPATCH,
						JOB_STATUS.DISPATCHED,
						JOB_STATUS.READY,
						JOB_STATUS.EN_ROUTE,
						JOB_STATUS.ON_SITE,
						JOB_STATUS.IN_PROGRESS
					];

					return allowedJobStatuses.indexOf(job.jobStatus) > -1 &&
						(!job.quantity || job.quantity <= 0 || job.quantity > job.allocations.length);
				};

				var resourceCanBeAllocatedToJob = function (resource, job) {
					return resource && job &&
						jobCanBeAllocated(job) && 
						job.assignedResourcesIds.indexOf(resource.id) === -1 &&
						job.assignableResourcesIds.indexOf(resource.id) > -1 &&
						job.conflictedJobAssignedResourceIds.indexOf(resource.id) === -1
				};

				var resourceCanBeOfferedToJob = function (resource, job) {
					return resource && job &&
						jobCanBeAllocated(job) && 
						job.offeringResourcesIds.indexOf(resource.id) === -1 &&
						job.assignedResourcesIds.indexOf(resource.id) === -1 &&
						job.assignableResourcesIds.indexOf(resource.id) > -1 &&
						job.conflictedJobAssignedResourceIds.indexOf(resource.id) === -1
				};

				var draggingResourceCanBeAllocatedToJob = function (job) {
					return resourceCanBeAllocatedToJob($ctrl.draggingResource, job);
				};

				var isResourceTagsMatched = function (resourceTagIds, filteringTagIds) {
					var tagsMatched = true;

					if (angular.isArray(filteringTagIds) && filteringTagIds.length > 0) {
						if (!angular.isArray(resourceTagIds) || resourceTagIds.length === 0) {
							tagsMatched = false;
						} else {
							for (var i = 0; i < filteringTagIds.length; i++) {
								if (resourceTagIds.indexOf(filteringTagIds[i]) === -1) {
									tagsMatched = false;
									break;
								}
							}
						}
					} 

					return tagsMatched;
				};

				var collectFilteringResourcesList = function (resources, jobs) {
					var filteringResourcesList = [];

					angular.forEach(jobs, function (job) {
						var allocations = job.possibleAllocations;
						var resourceIds = allocations.map(function (allocation) {
							return allocation.resource.id;
						});
						filteringResourcesList = filteringResourcesList.concat(resources.filter(function (resource) {
							return resourceIds.indexOf(resource.id) > -1 && filteringResourcesList.indexOf(resource) === -1;
						}));
					});

					return filteringResourcesList;
				};

				var sortResources = function (resources, resourceAllocationMap) {
					if (resourceAllocationMap) {
						return _.orderBy(resources, [function (item) {
							//travel distance
							var allocation = resourceAllocationMap[item.id];
							return allocation.travelDistanceFrom || 0;
						}], ['asc']);
					} else {
						return resources;
					}
				};
				
				var applyResourcesFilters = function () {
					var resourceNameFilter;

					showLoading();
					$timeout(function(){
						var filteringResourcesList = collectFilteringResourcesList($ctrl.resources || [], ($ctrl.pinnedJob) ? [$ctrl.pinnedJob] : ($ctrl.scheduleAllocation.jobs || []));

						if (angular.isArray(filteringResourcesList) && filteringResourcesList.length > 0) {
							resourceNameFilter = $ctrl.resourcesFilters.name.toLowerCase();
							$ctrl.filteredResources = filteringResourcesList.filter(function(resource) {
								var resourceName = (resource.name || '').toLowerCase();
								return resourceName.indexOf(resourceNameFilter) > -1;
							});
							var allocationsMap = $ctrl.pinnedJob ? $ctrl.pinnedJob.assignableResourcesMap : null;
							$ctrl.filteredResources = sortResources($ctrl.filteredResources, allocationsMap);
						} else {
							$ctrl.filteredResources = [];
						}

						currentParams.resourcesFilters = angular.copy($ctrl.resourcesFilters);
						hideLoading();
					});
				};

				var applyJobsFilters = function () {
					var jobNameFilter, eventTypesFilter, weekdayFilters, scheduleFilters;
					var filteringJobsList;

					if ($ctrl.scheduleAllocation && 
						angular.isArray($ctrl.scheduleAllocation.jobs) &&
						$ctrl.scheduleAllocation.jobs.length > 0) {

						if ($ctrl.pinnedResource) {
							filteringJobsList = $ctrl.pinnedResourceAssignableJobs;
						} else {
							filteringJobsList = $ctrl.scheduleAllocation.jobs;
						}

						// prepare the filters
						jobNameFilter = $ctrl.jobsFilters.name.toLowerCase();
						eventTypesFilter = $ctrl.jobsFilters.eventTypes;
						
						weekdayFilters = $ctrl.jobsFilters.weekdays.map(function (weekday) {
							return weekday.numVal;
						});
						/* scheduleFilters = $ctrl.jobsFilters.schedules.map(function (schedule) {
							return schedule.id;
						}); */

						$ctrl.filteredJobsWithoutTimeRange = filteringJobsList.filter(function (job) {
							var jobName = (job.name || '').toLowerCase();

							return jobName.indexOf(jobNameFilter) > -1 &&
								eventTypesFilter.indexOf(job.eventType) > -1 &&
								//scheduleFilters.indexOf(job.scheduleId || '') > -1 &&
								weekdayFilters.indexOf(job.startDate.getDay()) > -1;
						});
						$ctrl.filteredJobs = $ctrl.filteredJobsWithoutTimeRange.filter(function (job) {
							var jobStartDateTime = dateUtil.parseDateTime(job.startDate, job.startTime).getTime();

							return (!angular.isDate($ctrl.jobsFilters.timeRange.start) || jobStartDateTime >= $ctrl.jobsFilters.timeRange.start.getTime()) &&
								(!angular.isDate($ctrl.jobsFilters.timeRange.end) || jobStartDateTime <= $ctrl.jobsFilters.timeRange.end.getTime())
						});
					} else {
						$ctrl.filteredJobsWithoutTimeRange = [];
						$ctrl.filteredJobs = [];
					}
				};

				var handleDraggingResource = function (resource) {
					$ctrl.draggingResource = resource;
				};

				var handleStopDraggingResource = function (resource) {
					$ctrl.draggingResource = null;
				};

				var pinJob = function (job) {
					var filteredTags;

					if (job && $ctrl.pinnedJob !== job) {
						$ctrl.pinnedJob = job;
						$ctrl.filteredJobs = [job];

						filteredTags = angular.extend([], job.tags) || [];

						$ctrl.pinnedJobAssignableResources = $ctrl.scheduleAllocation.resources.filter(function (resource) {
							return job.assignableResourcesIds.indexOf(resource.id) > -1;
						});

						// sort assignable resources by travel distance and time
						$ctrl.pinnedJobAssignableResources.sort(function (resource1, resource2) {
							var resourceAllocation1 = job.assignableResourcesMap[resource1.id],
								resourceAllocation2 = job.assignableResourcesMap[resource2.id];

							return ((resourceAllocation1.travelDistanceFrom || 0) - (resourceAllocation2.travelDistanceFrom || 0)) || 
								((resourceAllocation1.travelTimeFrom || 0) - (resourceAllocation2.travelTimeFrom || 0));
						});

					} else {
						$ctrl.pinnedJob = null;
						$ctrl.pinnedJobAssignableResources = null;

						filteredTags = [];

						applyJobsFilters();
					}

					$ctrl.offeringResourceNameFilter = '';
					$ctrl.allocatedResourceNameFilter = '';
					applyResourcesFilters();
					getJobs();
				};

				var pinSchedule = function (job) {
					var tmpSchedule, selectedSchedule = null;

					if (job && job.scheduleId ) {
						if ($ctrl.jobsFilters.schedules.length === 1 && 
							$ctrl.jobsFilters.schedules[0].id === job.scheduleId) {
							$ctrl.jobsFilters.schedules = angular.extend([], $ctrl.scheduleAllocation.schedules);
						} else {
							for (var i = 0; i < $ctrl.scheduleAllocation.schedules.length; i++) {
								tmpSchedule = $ctrl.scheduleAllocation.schedules[i];

								if (tmpSchedule.id === job.scheduleId) {
									selectedSchedule = tmpSchedule;
									break;
								} 
							}

							if (selectedSchedule) {
								$ctrl.jobsFilters.schedules = [selectedSchedule];
							}
						}
					}
				};

				var pinResource = function (resource) {
					if (resource && $ctrl.pinnedResource !== resource) {
						$ctrl.pinnedResource = resource;
						$ctrl.filteredResources = [resource];

						$ctrl.pinnedResourceAssignableJobs = $ctrl.scheduleAllocation.jobs.filter(function (job) {
							return job.assignableResourcesIds.indexOf(resource.id) > -1;
						});

						// sort assignable resources by travel distance and time
						$ctrl.pinnedResourceAssignableJobs.sort(function (job1, job2) {
							var resourceAllocation1 = job1.assignableResourcesMap[resource.id],
								resourceAllocation2 = job2.assignableResourcesMap[resource.id];

							return ((resourceAllocation1.travelDistanceFrom || 0) - (resourceAllocation2.travelDistanceFrom || 0)) || 
								((resourceAllocation1.travelTimeFrom || 0) - (resourceAllocation2.travelTimeFrom || 0));
						});
					} else {
						$ctrl.pinnedResource = null;
						$ctrl.pinnedResourceAssignableJobs = null;

						applyResourcesFilters();
					}

					applyJobsFilters();
				};

				var searchTags = function (searchString) {
					var results = [];
					if ($ctrl.configData && $ctrl.configData.tags) {
						results = $ctrl.configData.tags;

						if (searchString) {
							results = nameFilter(results, {label: searchString});
						}
					}

					return results;
				};

				var sendJobOffers = function () {
					var requestParams;

					if ($ctrl.pinnedJob) {
						requestParams = {
							job: produceJobParams($ctrl.pinnedJob)
						}

						showLoading();
						doSendJobOffers(requestParams)
							.then(function (result) {
								var job;
								if (result.success && result.data) {
									util.toastSuccess('Offers have been sent.');
									job = model.EventModel.fromServer(result.data.job);

									// update job offer
									$ctrl.pinnedJob.jobOffers = job.jobOffers;
									processJobOffers($ctrl.pinnedJob, $ctrl.scheduleAllocation.resources);

									return true;
								} else{
									return $q.reject(result);
								}
							})
							.catch(function (exception) {
								console.error(exception);
								if (exception && exception.errorMessage) {
									showErrorPrompt(exception.errorMessage);
								}
							})
							.finally(hideLoading);
					}
				};  

				var changeTab = function(newTab) {
					$ctrl.tab = newTab;
				}

				/**
				 * controller init
				 * used for setting initial value
				 */
				$ctrl.$onInit = function () {
					if ($ctrl.job) {
						uiGmapGoogleMapApi.then(function (maps) {
							mapsApi = maps;

							$ctrl.jobParams = (angular.isFunction($ctrl.job.toServer))?$ctrl.job.toServer():$ctrl.job;

							/*if ($ctrl.job.patient) {
								$ctrl.jobParams.patientId = $ctrl.job.patient.id;
							} else if ($ctrl.job.patientId) {
								$ctrl.jobParams.patientId = $ctrl.job.patientId;
							}*/
							initializingData = true;
							showLoading();
							
							getInitialData()
								.then(function () {
									$ctrl.resourcesFilters.region = $ctrl.configData.regions.find(function (region) {
										return region.id === $ctrl.jobParams.regionId;
									});
									$ctrl.jobsFilters.eventTypes = angular.extend([], $ctrl.configData.jobTypes);
								
									// setup filters
									$ctrl.resourcesFilters.categories = angular.extend([], $ctrl.configData.resourceCategories);
										
									return getJobs();
								})
								.then(function () {
									var pinningJob;
									var scheduleAllocation = $ctrl.scheduleAllocation;
									$ctrl.tab = ($ctrl.scheduleAllocation && $ctrl.scheduleAllocation.enableJobOffer) ? TABS.OFFERED_RESOURCES : TABS.ALLOCATED_RESOURCES;

									// apply job filters
									if (scheduleAllocation && scheduleAllocation.jobs && scheduleAllocation.jobs.length === 1) {
										pinJob(scheduleAllocation.jobs[0]);
									} else {
										if (!!$ctrl.jobPinning && $ctrl.job.id) {
											for (var i = 0; i < scheduleAllocation.jobs.length; i++) {
												if (scheduleAllocation.jobs[i].id === $ctrl.job.id) {
													pinningJob = scheduleAllocation.jobs[i];
												}
											}
										}

										if (pinningJob) {
											pinJob(pinningJob);
										} else {
											applyJobsFilters();
										}
									}
								})
								.catch(function (exception) {
									console.error(exception);
									if (exception && exception.errorMessage) {
										showErrorPrompt(exception.errorMessage);
									}
								})
								.finally(function () {
									initializingData = false;
									hideLoading();
								});
						});
					} else {
						showErrorPrompt('Invalid input params');
					}

					postMessageToParent('loaded');
					$timeout(function() {
						$ctrl.isModalOpen = true;
					}, 0);
				};

				/**
				 * init block
				 * used for setting up controller
				 */
				(function () {
					now.setHours(0, 0, 0, 0);

					$scope.EVENT_TYPE = constants.EVENT_TYPE;
					$scope.COMMON_DATE_FORMAT = COMMON_DATE_FORMAT;
					$scope.WEEK_DAYS = WEEK_DAYS;
					$scope.DEFAULT_PHOTO_URL = DEFAULT_PHOTO_URL;
					$scope.TABS = TABS;

					$ctrl.resourcesFilters = {
						tags: [],
						region: null,
						categories: [],
						name: ''
					};

					$ctrl.jobsFilters = {
						eventTypes: [],
						schedules: [],
						weekdays: angular.extend([], WEEK_DAYS),
						name: '',
						timeRange: {
							start: null,
							end: null
						}
					};

					$ctrl.changeTab = changeTab;

					$ctrl.filteredResources = [];
					$ctrl.filteredJobs = [];
					$ctrl.draggingResource = null;
					$ctrl.pinnedJob = null;
					$ctrl.pinnedJobAssignableResources = null;
					$ctrl.pinnedResource = null;
					$ctrl.pinnedResourceAssignableJobs = null;
					
					$ctrl.unassignResource = unassignResource;
					$ctrl.assignResource = assignResource;
					$ctrl.cancelResourceOffer = cancelResourceOffer;
					$ctrl.offerResource = offerResource;
					$ctrl.closeModal = closeModal;
					$ctrl.saveAllocations = saveAllocations;
					$ctrl.jobCanBeAllocated = jobCanBeAllocated;
					$ctrl.savedWithoutFullyAssigned = false;

					$ctrl.getArray = getArray;

					$ctrl.handleDraggingResource = handleDraggingResource;
					$ctrl.handleStopDraggingResource = handleStopDraggingResource;
					$ctrl.draggingResourceCanBeAllocatedToJob = draggingResourceCanBeAllocatedToJob;
					$ctrl.assignDraggingResource = assignDraggingResource;
					$ctrl.pinResource = pinResource;
					$ctrl.pinJob = pinJob;
					$ctrl.pinSchedule = pinSchedule;

					$ctrl.searchTags = searchTags;

					$ctrl.sendJobOffers = sendJobOffers;

					$ctrl.resourceCanBeAllocatedToJob = resourceCanBeAllocatedToJob;
					$ctrl.resourceCanBeOfferedToJob = resourceCanBeOfferedToJob;
					$ctrl.applyResourcesFilters = applyResourcesFilters;
					$ctrl.rootRecordId = $ctrl.rootRecordId || searchParams.rootRecordId;
					$ctrl.parentDomain = searchParams.parent_domain || '*';
					$ctrl.needToRefreshResources = needToRefreshResources;
					$ctrl.refreshResources = refreshResources;

					$ctrl.offeringResourceNameFilter = '';
					$ctrl.allocatedResourceNameFilter = '';

					// $scope.$watch('$ctrl.resourcesFilters', function (newVal) {
					// 	applyResourcesFilters();
					// }, true);

					$scope.$watch('$ctrl.jobsFilters', function (newVal) {
						if (!initializingData) {
							showLoading();
							$timeout(function(){
								applyJobsFilters();
								hideLoading();
							})
						}
					}, true);
				})();
			}
		]
	});
})(angular, top);
