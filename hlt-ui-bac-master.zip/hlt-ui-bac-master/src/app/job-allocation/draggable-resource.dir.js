(function (angular) {
    angular.module('hltApp')
    .directive('draggableResource', [
        '$window',
        '$timeout',
        '$document',
        function($window, $timeout, $document) {
            var windowEl = angular.element($window),
                documentEl = angular.element($document);

            return function ($scope, $el, $attrs) {
                var handleDragStart = function (event) {
                    event.originalEvent.allowedEffect = 'move';
                    $scope.$apply($scope.$eval($attrs.draggableResourceStart));

                    event.originalEvent.dataTransfer.setDragImage($el[0], event.offsetX, event.offsetY);
                };

                var handleDrag = function (event) {
                };

                var handleDragEnd = function (event) {
                    $scope.$apply($scope.$eval($attrs.draggableResourceEnd));
                };

                $el.attr('draggable', true);
                
                $el.on('dragstart', handleDragStart);
                //$el.on('drag', handleDrag);
                $el.on('dragend', handleDragEnd);
            };
        }
    ])
})(angular);