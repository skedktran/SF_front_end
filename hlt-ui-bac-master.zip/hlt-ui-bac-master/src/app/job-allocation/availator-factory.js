(function (angular, moment) {
    angular.module('skedApp.shared')
      .factory('availatorUtil', [
        '$filter',
        '$injector',
        'dateUtil',
        'model',
        function ($filter, $injector, dateUtil, model) {
          var METRES_TO_MILES_CONSTANT = 0.000621371;
  
          function dateslotModel() {
            this.start = null;
            this.finish = null;
            this.events = [];
          }
  
          dateslotModel.prototype.addEvent = function (startTime, endTime, objectType, isAvailable, relatedId) {
            var $this = this;
            var _addAvailableBlock = function (startTime, endTime) {
              var newEvents = [];
              var removedEvents = [];
  
              $this.events.forEach(function (eventItem) {
                if (eventItem.start < startTime && startTime < eventItem.finish) {
                  if (endTime < eventItem.finish) {
                    var newEvent = {};
                    newEvent.start = endTime;
                    newEvent.finish = eventItem.finish;
                    newEvent.objectType = eventItem.objectType;
                    newEvents.push(newEvent);
                  }
                  eventItem.finish = startTime;
                }
                else if (startTime == eventItem.start && endTime == eventItem.finish) {
                  removedEvents.push(eventItem.start);
                  var newEvent = {};
                  newEvent.start = startTime;
                  newEvent.finish = endTime;
                  newEvent.objectType = 'availability';
                  newEvents.push(newEvent);
                }
                else if (startTime <= eventItem.start) {
                  if (endTime >= eventItem.finish) {
                    removedEvents.push(eventItem.start);
                  }
                  else if (eventItem.start < endTime && endTime < eventItem.finish) {
                    eventItem.start = endTime;
                  }
                }
              });
  
              _.remove($this.events, function (event) {
                return removedEvents.indexOf(event.start) > -1;
              });
  
              $this.events = $this.events.concat(newEvents);
            };
  
            if (isAvailable == true) {
              _addAvailableBlock(startTime, endTime);
            }
            else {
              var newEvent = {};
              newEvent.start = startTime;
              newEvent.finish = endTime;
              newEvent.objectType = objectType;
              $this.events.push(newEvent);
              return newEvent;
            }
            return null;
          }
          
          function SkedAvailator(configData, requestParams, mapsApi) {
            this.travelTimeVelocity = 35;
            this.configData = configData;
            this.requestParams = requestParams;
            this.mapsApi = mapsApi;
          }
  
          function loadWorkingTime(simplyAvailabilityData, resourcesMap, inputDates) {
            simplyAvailabilityData.forEach(function (item) {
              var resource = resourcesMap[item.id];
              if(!resource) return;
              
              for (var i = 0; i < inputDates.length; i++) {
                var inputDate = inputDates[i];
                var dateslot = new dateslotModel();
                dateslot.start = inputDate;
                dateslot.finish = moment(inputDate).add(1, 'd').toDate();
                dateslot.addEvent(dateslot.start, dateslot.finish, 'non-working', false, null);
                var key = dateUtil.dateToStringNative(inputDate);
                if (!resource.mapDateslot) {
                  resource.mapDateslot = {};
                }
                resource.mapDateslot[key] = dateslot;
  
                // if (this.holidays.contains(inputDate)) {
                //     continue;
                // }
                for (var j = 0; j < item.events.length; j++) {
                  var event = item.events[j];
                  var eventDate = dateUtil.dateToStringNative(event.start);
                  var inputDateString = dateUtil.dateToStringNative(inputDate);
                  if (eventDate === inputDateString) {
                    dateslot.addEvent(event.start, event.finish, 'availability', true, null);
                  }
                  else if (eventDate > inputDateString) {
                    break;
                  }
                }
              }
            });
          }
  
          function loadResourceEvents(resourcesMap) {
            Object.keys(resourcesMap).forEach(function(resourceId) {
              var resource = resourcesMap[resourceId];
              resource.events.forEach(function(event) {
                  var startDateKey = dateUtil.dateToStringNative(event.startDate);
                  var endDateKey = dateUtil.dateToStringNative(event.endDate);
                  var dateSlot = resource.mapDateslot[startDateKey] || resource.mapDateslot[endDateKey];
                  if(dateSlot) {
                      dateSlot.events.push(event);
                  }
              });
            })
          }
  
          function validateTags(resource, job, requestParams) {
            if (requestParams.tags && requestParams.tags.length > 0) {
              if (!resource.sked__ResourceTags__r) {
                  return false;
              }
              else {
                  var resourceTagIds = [];
                  resource.sked__ResourceTags__r.forEach(function(resourceTag) {
                    if (!resourceTag.sked__Expiry_Date__c || resourceTag.sked__Expiry_Date__c > job.sked__Finish__c) {
                      resourceTagIds.push(resourceTag.sked__Tag__c);
                    }
                  });
                  var unmatchTag = requestParams.tags.find(function(tag) {
                    return resourceTagIds.indexOf(tag.id) === -1;
                  });
                  if (unmatchTag) {
                    return false;
                  }
              }
            }
            return true;
          }
  
          function validateRoles(resource, job, requestParams) {
            var selectedRoles = requestParams.resourceCategories || [];
            return selectedRoles.indexOf(resource.sked__Category__c) > -1;
          }
  
          function getTravelTime(location1, location2, travelTimeVelocity, mapsApi) {
            if (travelTimeVelocity <= 0) {
              return 0;
            }
            var travelTime = -1;
            if (!location1 || !location2) {
                return travelTime;
            }
            var dist = calculateDistance(location1, location2, mapsApi);
            travelTime = +Number((dist / travelTimeVelocity) * 60).toFixed(0);
            return travelTime;
          }
  
          function calculateDistance(loc1, loc2, mapsApi) {
            var distance = 0, point1, point2;
            if (loc1 && loc1.lat && loc1.lng) {
                point1 = new mapsApi.LatLng(loc1.lat, loc1.lng);
            }
            if (loc2 && loc2.lat && loc2.lng) {
                point2 = new mapsApi.LatLng(loc2.lat, loc2.lng);
            }
            if (point1 && point2) {
                distance = mapsApi.geometry.spherical.computeDistanceBetween(point1, point2); // in metres
                distance = distance * METRES_TO_MILES_CONSTANT; // convert to miles
            }
            return distance;
          };
  
          SkedAvailator.prototype.buildScheduledAllocations = function (allocationData, simplyAvailabilityData) {
            var $this = this;
            var resourcesMap = _.keyBy(allocationData.resources, "Id");
  
            var inputDates = _.uniq(allocationData.jobs.map(function (job) {
              return job.startDate;
            }));
            var inputJobIds = _.uniq(allocationData.jobs.map(function (job) {
              return job.Id;
            }));
            
            loadWorkingTime(simplyAvailabilityData, resourcesMap, inputDates);
            loadResourceEvents(resourcesMap);
  
            allocationData.jobs.forEach(function (job) {
              job.possibleAllocations = [];
              job.excludedAllocations = [];
            });
            
            allocationData.resources.forEach(function (resource) {
              allocationData.jobs.forEach(function (job) {
                if (!job.possibleAllocations) {
                  job.possibleAllocations = [];
                }
                if (!job.excludedAllocations) {
                  job.excludedAllocations = [];
                }
              var jobDateStr = dateUtil.dateToStringNative(job.startDate);
                if (!resource.mapDateslot || !resource.mapDateslot[jobDateStr]) {
                  return;
                }
                if (!validateTags(resource, job, $this.requestParams)) {
                  return;
                }
                if (!validateRoles(resource, job, $this.requestParams)) {
                  return;
                }
  
                var isResourceAvailable = true;
                var isResourceQualified = true;
  
                var dateslot = resource.mapDateslot[jobDateStr];
                var previousEvent, nextEvent;
  
                for (var i = 0; i < dateslot.events.length; i++) {
                  var event = dateslot.events[i];
                  if (event.objectType === 'jobAllocation') {
                    if (inputJobIds.indexOf(event.jobId) > -1 || event.status === "Declined") {
                      continue;
                    }
                  }
                  if (job.finish < event.start && nextEvent != null) {
                    break;
                  }
  
                  if (event.start < job.finish && event.finish > job.start && event.objectType != 'availability') {
                    isResourceAvailable = false;
                    if (event.eventType == 'non-working') {
                      isResourceQualified = false;
                    }
                    break;
                  }
  
                  if (job.finish < event.start && nextEvent) {
                    break;
                  }
                  if (event.finish <= job.start) {
                    previousEvent = event;
                  }
                  if (event.start >= job.finish) {
                    nextEvent = event;
                  }
                }
  
                var travelTimeFrom, travelTimeTo;
                var travelDistanceFrom;
                var startFromLocation, goToLocation;
  
                if (isResourceAvailable === true) {
                  if (job.sked__GeoLocation__Longitude__s) {
                    if (previousEvent && previousEvent.sked__GeoLocation__Longitude__s) {
                      var location1 = {lat: previousEvent.sked__GeoLocation__Latitude__s, lng: previousEvent.sked__GeoLocation__Longitude__s};
                      var location2 = {lat: job.sked__GeoLocation__Latitude__s, lng: job.sked__GeoLocation__Longitude__s};
                      travelTimeFrom = getTravelTime(location1, location2, $this.travelTimeVelocity, $this.mapsApi);
                      startFromLocation = location1;
                      travelDistanceFrom = calculateDistance(location1, location2, $this.mapsApi);
  
                      if (moment(previousEvent.finish).add(travelTimeFrom, 'm').toDate() > job.start) {
                        isResourceAvailable = false;
                      }
                    } 
                    else {
                      if (resource.sked__GeoLocation__Latitude__s) {
                        var location1 = {lat: resource.sked__GeoLocation__Latitude__s, lng: resource.sked__GeoLocation__Longitude__s};
                        var location2 = {lat: job.sked__GeoLocation__Latitude__s, lng: job.sked__GeoLocation__Longitude__s};
                        startFromLocation = location1;
                        travelTimeFrom = getTravelTime(location1, location2, $this.travelTimeVelocity, $this.mapsApi);
                        travelDistanceFrom = calculateDistance(location1, location2, $this.mapsApi);
                      }
                    }
                    if (nextEvent && nextEvent.sked__GeoLocation__Latitude__s) {
                      var location1 = {lat: job.sked__GeoLocation__Latitude__s, lng: job.sked__GeoLocation__Longitude__s};
                      var location2 = {lat: nextEvent.sked__GeoLocation__Latitude__s, lng: nextEvent.sked__GeoLocation__Longitude__s};
                      travelTimeTo = getTravelTime(location1, location2, $this.travelTimeVelocity, $this.mapsApi);
                      if (moment(job.finish).add(travelTimeTo, 'm').toDate() > nextEvent.start) {
                        isResourceAvailable = false;
                      }
                    }
                  }
                }
  
                if ($this.requestParams.keepAllAllocations === true || isResourceAvailable === true) {
                  var possibleAllocation = {};
                  possibleAllocation.resourceId = resource.Id;
                  possibleAllocation.jobId = job.Id;
                  possibleAllocation.startFromLocation = startFromLocation;
                  possibleAllocation.travelTimeFrom = travelTimeFrom;
                  possibleAllocation.travelDistanceFrom = travelDistanceFrom;
                  possibleAllocation.isAvailable = isResourceAvailable;
                  possibleAllocation.isQualified = isResourceQualified;
                  possibleAllocation.previousEvent = previousEvent;
                  possibleAllocation.nextEvent = nextEvent;
                  if (possibleAllocation.nextEvent) {
                    possibleAllocation.travelTimeTo = travelTimeTo;
                    possibleAllocation.goToLocation = goToLocation;
                  }
                  job.possibleAllocations.push(possibleAllocation);
                }
              });
            });
  
            var result = {jobs: [], resources: [], enableJobOffer: true};
            allocationData.jobs.forEach(function(job){
              var jobModel = model.EventModel.fromSObject(job, [], job.sked__Timezone__c);
              jobModel.possibleAllocations = model.JobAllocationModel.fromServerList(job.possibleAllocations);
              jobModel.excludedAllocations = model.JobAllocationModel.fromServerList(job.excludedAllocations);
              jobModel.jobOffers = []; 
  
              allocationData.jobOffers.forEach(function(jobOffer) {
                if(jobOffer.sked__Job__c === job.Id) {
                  (jobOffer.sked__Resource_Job_Offers__r || []).forEach(function(jobOfferResource) {
                    jobModel.jobOffers.push(model.JobOfferModel.fromResourceJobOfferSObject(_.extend({}, jobOfferResource, {
                      sked__Job__c: jobOffer.sked__Job__c,
                      sked__Job__r: jobOffer.sked__Job__r
                    })));
                  });
                }
              });
  
              result.jobs.push(jobModel);
            });
            
            var timezone = allocationData.jobs[0].sked__Timezone__c;
            result.resources = allocationData.resources.map(function(resource) {
              resource = model.ResourceModel.fromSObject(resource, [], timezone);
              return resource;
            });
  
            return result;
          }
  
          return {
            getInstance: function (configData, requestParams, mapsApi) {
              return new SkedAvailator(configData, requestParams, mapsApi);
            }
          };
        }
      ]);
  })(angular, window.moment || null);