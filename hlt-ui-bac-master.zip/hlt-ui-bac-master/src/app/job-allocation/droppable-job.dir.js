(function (angular) {
    angular.module('hltApp')
    .directive('droppableJob', [
        '$window',
        '$timeout',
        '$document',
        function($window, $timeout, $document) {
            return function ($scope, $el, $attrs) {
                var currentJobItemEl = null;
                var dragEnterCounter = 0;

                var cancelEvent = function (event) {
                    event.preventDefault();  
                    event.stopPropagation();
                };

                var handleDrop = function (event) {
                    var jobScope = angular.element(event.target).scope();
                    
                    cancelEvent(event);

                    if (jobScope) {
                        $scope.$apply($scope.$eval($attrs.droppableJob, {job: jobScope.job}));
                    }

                    if (currentJobItemEl) {
                        dragEnterCounter = 0
                        currentJobItemEl.classList.remove('hco-job-droppable_hover');
                        currentJobItemEl = null;
                    }
                };

                var handleDragEnter = function (event) {
                    var jobItemEl = null;

                    cancelEvent(event);
                    dragEnterCounter++;
                    for (var element = event.target; element; element = element.parentNode) {
                        if (element.classList && element.classList.contains('job-item')) {
                            jobItemEl = element;
                            break;
                        }
                    }

                    if (jobItemEl !== currentJobItemEl) {
                        if (currentJobItemEl) {
                            currentJobItemEl.classList.remove('hco-job-droppable_hover');
                        }
                        if (jobItemEl) {
                            jobItemEl.classList.add('hco-job-droppable_hover');
                            currentJobItemEl = jobItemEl;
                        }
                    }

                    return false;
                };

                var handleDragLeave = function (event) {
                    cancelEvent(event);
                    dragEnterCounter--;

                    if (dragEnterCounter === 0 && currentJobItemEl) {
                        currentJobItemEl.classList.remove('hco-job-droppable_hover');
                        currentJobItemEl = null;
                    }

                    return false;
                };

                $el.on('dragover', false);
                $el.on('drop', handleDrop);
                $el.on('dragenter', handleDragEnter);
                $el.on('dragleave', handleDragLeave);
            };
        }
    ])
})(angular);