(function (angular, moment) {
    angular.module('skedApp.shared')
        .factory('recurringUtil', [
            '$filter',
            '$injector',
            'dateUtil',
            'model',
            function ($filter, $injector, dateUtil, model) {

                var mapWeekdayIndex = {
                    'mon': 0,
                    'tue': 1,
                    'wed': 2,
                    'thu': 3,
                    'fri': 4,
                    'sat': 5,
                    'sun': 6,
                };

                function identifyNoWeek(template) {
                    var noOfWeeks = 1;
                    template.availabilityTemplateEntries.forEach(function (entry) {
                        noOfWeeks = entry.weekNo > noOfWeeks ? entry.weekNo : noOfWeeks;
                    });
                    return noOfWeeks;
                }

                function buildHolidays(holidays, regionId) {
                    if(!holidays) return [];

                    var result = [];
                    var validHolidays = holidays.filter(function(item) {
                        var isDateRangeValid = item.startDate && item.endDate;
                        var isRegionValid = item.isGlobal || item.regionId === regionId;
                        return isDateRangeValid && isRegionValid;
                    })

                    validHolidays.forEach(function(item) {
                        var diff = dateUtil.getDiff(item.endDate, item.startDate);
                        for(var i = 0; i <= diff; i++) {
                            var tempDateIso = dateUtil.dateToString(moment(item.startDate).add(i, 'days').toDate());
                            if(result.indexOf(tempDateIso) === -1) {
                                result.push(tempDateIso)
                            }
                        }
                    })
                    return result;
                }

                function SkedRecurringUtil(configData) {
                    this.configData = configData;
                }
                
                SkedRecurringUtil.prototype.generateRecurringJobs = function (event, recurringOptions) {
                    var $this = this;
                    var result = [];

                    if (!recurringOptions) {
                        return [event];
                    }

                    var startDateDt = dateUtil.parseDateString(recurringOptions.availabilityTemplate.startDate);
                    var endDateDt = dateUtil.parseDateString(recurringOptions.availabilityTemplate.endDate);
                    var startDateWeekday = moment(startDateDt).format('ddd').toLowerCase();
                    var startDateWeekdayIndex = mapWeekdayIndex[startDateWeekday];
                    var startEndDaysDifference = moment(endDateDt).diff(moment(startDateDt), 'd');
                    var noOfWeeks = identifyNoWeek(recurringOptions.availabilityTemplate);
                    var skippedDates = [];
                    if(recurringOptions.skipHolidays) {
                        skippedDates = skippedDates.concat(buildHolidays(this.configData.holidays, event.region ? event.region.id : null));
                        console.log(skippedDates)
                    }
                    recurringOptions.availabilityTemplate.availabilityTemplateEntries.forEach(function (entry) {
                        var startTimeInMinutes = dateUtil.getMinuteValue(entry.startTime);
                        var endTimeInMinutes = dateUtil.getMinuteValue(entry.endTime);
                        var weekdayIndex = mapWeekdayIndex[entry.weekday];
                        var daysDifference = weekdayIndex - startDateWeekdayIndex + 7 * (entry.weekNo - 1);

                        while (daysDifference <= startEndDaysDifference) {
                            if (daysDifference >= 0) {
                                var recurringDate = moment(startDateDt).add(daysDifference, 'd').toDate();
                                if (skippedDates.indexOf(dateUtil.dateToString(recurringDate)) === -1) {
                                    var recurringDateStart = moment(startDateDt).add(daysDifference, 'd').toDate();
                                    var newEventStart = moment(recurringDateStart).add(startTimeInMinutes, 'm').toDate();
                                    var newEventEnd = moment(recurringDateStart).add(endTimeInMinutes, 'm').toDate();
                                    if (endTimeInMinutes <= startTimeInMinutes) {
                                        newEventEnd = moment(newEventEnd).add(1, 'd').toDate();
                                    }

                                    var newEvent = _.cloneDeep(event);
                                    newEvent.startDate = _.cloneDeep(newEventStart);
                                    newEvent.endDate = _.cloneDeep(newEventEnd);
                                    newEvent.startTime = +moment(newEventStart).format('Hmm');
                                    newEvent.endTime = +moment(newEventEnd).format('Hmm');;

                                    result.push(newEvent);
                                }
                            }
                            daysDifference += 7 * noOfWeeks;
                        }
                    });

                    return _.orderBy(result, ['startDate', 'startTime'], ['asc', 'asc']);
                }

                SkedRecurringUtil.prototype.generateRecurringSchedule = function (recurringOptions) {
                    if (!recurringOptions) return null;
                    return {
                        skipHolidays: recurringOptions.skipHolidays
                    };
                }

                return {
                    getInstance: function (configData) {
                        return new SkedRecurringUtil(configData);
                    }
                };
            }
        ]);
})(angular, window.moment || null);