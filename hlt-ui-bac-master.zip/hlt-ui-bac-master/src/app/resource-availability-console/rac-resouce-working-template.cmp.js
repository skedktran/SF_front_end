(function (angular, topWindow) {
    angular.module('hltApp')
    .component('resource-working-template', {
        templateUrl: 'src/app/resource-availability-console/rac-resource-working-template.tpl.html',
        bindings: {
            configData: '<',
            resource: '<',
            onClose: '&',
            region: '<',
            timezone: '<'
        },
        controller: [
            '$scope',
            '$q',
            
            'api',
            'util',
            'dateUtil',
            'model',
            function ($scope, $timeout, $window, $location, $q, $filter, api, util, dateUtil, model) {
                var $ctrl = this;

                /**
                 * common remote action error handler
                 */
                var commonExceptionHanlder = function (exception) {
                    console.error(exception);
                    util.toastError('Can not perform action due to server error.');

                    return $q.reject();
                };

                /**
                 * show content loading
                 */
                var showLoading = function () {
                    $ctrl.contentLoading = true;
                };

                /**
                 * hide content loading
                 */
                var hideLoading = function () {
                    $ctrl.contentLoading = false;
                };

                /**
                 * close main modal
                 */
                var closeModal = function (message) {
                    $ctrl.isModalOpen = false;
                    // run onClose expression
                    if (angular.isFunction ($ctrl.onClose)) {
                        $ctrl.onClose({
                            message: message
                        });
                    }
                };
                

                var loadResourceTemplate = function () {

                };

                var saveResourceTemplate = function () {

                };

                /**
                 * controller init
                 * used for setting initial value
                 */
                $ctrl.$onInit = function () {
                    $ctrl.isModalOpen = true;

                    loadResourceTemplate();
                };

                /**
                 * init block
                 * used for setting up controller
                 */
                (function () {
                    $ctrl.resourceTemplate = {};
                    $ctrl.saveResourceTemplate = saveResourceTemplate;
                })();
            }
        ]
    });
})(angular, top);