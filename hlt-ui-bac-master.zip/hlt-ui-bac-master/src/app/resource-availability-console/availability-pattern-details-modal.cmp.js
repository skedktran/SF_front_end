(function (angular) {
  angular.module('hltApp').component('availabilityPatternDetails', {
    templateUrl: 'src/app/resource-availability-console/availability-pattern-details-modal.tpl.html',
    bindings: {
      configData: '<',
      regions: '=',
      availabilityPattern: '<',
      onClose: '&',
      onLoad: '&',
      onSave: '&',
      timezone: '<'
    },
    controller: [
      '$scope',
      '$q',
      'model',
      'util',
      'dateUtil',
      'constants',
      function (
        $scope,
        $q,
        model,
        util,
        dateUtil,
        constants
      ) {
        var $ctrl = this;

        var MAX_PATTERN_LENGTH = 28;
        var PAGE_MODE = {
          CREATE: 'CREATE',
          EDIT: 'EDIT'
        };
        var REPEAT_WEEKLY_OPTIONS = {
          ONE_WEEK: {
            value: 1,
            label: 'Week'
          },
          TWO_WEEK: {
            value: 2,
            label: 'Two Week'
          },
          FOUR_WEEK: {
            value: 4,
            label: 'Four Week'
          },
        };
        var INTEGER_PATTERN = /^(-)?([0-9]*)$/;

        var WEEK_DAYS = constants.WEEK_DAYS;

        var getArray = function (len) {
          var newArray = [];
          len = len || 0;

          for (var i = 1; i <= len; i++) {
            newArray.push(i);
          }

          return newArray;
        };

        var defaultTimePickerOptions = {
          step: 30
        };

        var patternItemTimePickerOptions = {
          step: 30,
          events: {
            hideTimepicker: function (event) {
              var timePickerInput, inputScope;

              if (event && event.target) {
                timePickerInput = angular.element(event.target);

                if (timePickerInput) {
                  inputScope = timePickerInput.scope();

                  if (inputScope && inputScope.item) {
                    inputScope.$apply(function () {
                      verifyWeeklyPatternItemErrors(inputScope.item);
                    });
                  }
                }
              }
            }
          }
        };

        /**
         * show content loading
         */
        var showLoading = function () {
          $ctrl.contentLoading = true;
        };

        /**
         * hide content loading
         */
        var hideLoading = function () {
          $ctrl.contentLoading = false;
        };

        /**
         * close main modal
         */
        var closeModal = function (message) {
          $ctrl.isModalOpen = false;
          // run onClose expression
          if (angular.isFunction($ctrl.onClose)) {
            $ctrl.onClose({
              message: message
            });
          }
        };

        var verifyWeeklyPatternItemErrors = function (item) {
          if (item) {
            item.errors = {
              timeRange: item.startTime >= item.endTime,
              startTime: (!angular.isNumber(item.startTime) || item.startTime < 0 || item.startTime > 2400),
              endTime: (!angular.isNumber(item.endTime) || item.endTime < 0 || item.endTime > 2400)
            };

            item.hasErrors = item.errors.timeRange ||
              item.errors.startTime ||
              item.errors.endTime;
          }
        };

        var isAllWeeklyPatternItemsSelected = function () {
          var weeklyPattern = $ctrl.weeklyPattern;

          return weeklyPattern &&
            angular.isArray(weeklyPattern.items) &&
            angular.isArray(weeklyPattern.selectedItems) &&
            weeklyPattern.items.length === weeklyPattern.selectedItems.length;
        };

        var isAnyWeeklyPatternItemSelected = function () {
          var weeklyPattern = $ctrl.weeklyPattern;

          return weeklyPattern &&
            angular.isArray(weeklyPattern.selectedItems) &&
            weeklyPattern.selectedItems.length > 0;
        };

        var toggleAllWeeklyPatternItemsSelection = function () {
          var weeklyPattern = $ctrl.weeklyPattern;
          var isAllSelected = isAllWeeklyPatternItemsSelected();

          if (weeklyPattern &&
            angular.isArray(weeklyPattern.items)) {

            angular.forEach(weeklyPattern.items, function (item) {
              toggleWeeklyPatternItemSelection(item, !isAllSelected);
            });
          }
        };

        var toggleWeeklyPatternItemSelection = function (item, isSelected) {
          var weeklyPattern = $ctrl.weeklyPattern;
          var index = weeklyPattern.selectedItems.indexOf(item);

          if (index === -1 && isSelected !== false) {
            weeklyPattern.selectedItems.push(item);
            item.startTime = $ctrl.configData.consoleSettings.calendarStart;
            item.endTime = $ctrl.configData.consoleSettings.calendarEnd;
            item.isAllDay = false;
          } else if (index > -1 && isSelected !== true) {
            weeklyPattern.selectedItems.splice(index, 1);
            item.startTime = 0;
            item.endTime = 0;
            item.isAllDay = false;
          }
        };

        var isWeeklyPatternItemSelected = function (item) {
          var weeklyPattern = $ctrl.weeklyPattern;

          return angular.isArray(weeklyPattern.selectedItems) && weeklyPattern.selectedItems.indexOf(item) > -1;
        };

        var toggleWeeklyPatternItemAllDay = function (item) {
          item.isAllDay = !item.isAllDay;

          if (item.isAllDay) {
            item.startTime = 0;
            item.endTime = 0;
          }
        };

        var isAvailabilityPatternValid = function () {
          var form = $ctrl.availabilityPatternDetailsForm;

          var isPatternValid = function () {
            var isValid = false;

            if ($ctrl.patternType === constants.AVAILABILITY_PATTERN_TYPE.WEEKLY) {
              isValid = ($ctrl.weeklyPattern &&
                angular.isArray($ctrl.weeklyPattern.selectedItems) &&
                $ctrl.weeklyPattern.selectedItems.length > 0 &&
                !$ctrl.weeklyPattern.selectedItems.find(function (item) {
                  return (!item.isAllDay && item.hasErrors);
                }));
            } else if ($ctrl.patternType === constants.AVAILABILITY_PATTERN_TYPE.CUSTOM) {
              isValid = ($ctrl.customPattern &&
                angular.isArray($ctrl.customPattern.items) &&
                $ctrl.customPattern.items.length > 0 &&
                !$ctrl.customPattern.items.find(function (item) {
                  return (!item.isSelected && !item.isAllDay && item.hasErrors);
                }));
            }

            return isValid;
          };

          if (form) {
            form.$setSubmitted(true);
          }

          if (!form.$valid) {
            if (form.$error.required) {
              util.toastError('Please enter all required fields.');
            }

            return false;
          }
          if (!isPatternValid()) {
            util.toastError('Template pattern is invalid.');
            return false;
          }

          return true;
        };

        var isResourceAllocatedToThePattern = function () {
          var patternResourcesCount = countPatternResources();
          if (patternResourcesCount === 0) {
            util.toastError('Please allocate resources.');
            return false;
          }

          return true;
        };

        var buildAvailabilityPatternSavingParams = function () {
          var params = {
            id: $ctrl.availabilityPattern.id,
            name: $ctrl.availabilityPattern.name
          };

          var producePatternData = function () {
            var pattern = {
              type: $ctrl.patternType
            };

            if (pattern.type === constants.AVAILABILITY_PATTERN_TYPE.WEEKLY) {
              pattern.days = $ctrl.weeklyPattern.selectedItems.map(function (item) {
                return {
                  weekday: item.weekday.toUpperCase(),
                  intervals: [{
                    startTime: dateUtil.timeToString(item.isAllDay ? 0 : item.startTime),
                    endTime: dateUtil.timeToString(item.isAllDay ? 0 : item.endTime)
                  }]
                };
              });
              pattern.repeatWeeks = $ctrl.weeklyPattern.repeatWeeks;
            } else if (pattern.type === constants.AVAILABILITY_PATTERN_TYPE.CUSTOM) {
              pattern.days = $ctrl.customPattern.items.filter(function (item) {
                return item.isSelected;
              }).map(function (item) {
                return {
                  day: item.dayNo,
                  intervals: [{
                    startTime: dateUtil.timeToString(item.isAllDay ? 0 : item.startTime),
                    endTime: dateUtil.timeToString(item.isAllDay ? 0 : item.endTime)
                  }]
                };
              });
              pattern.lengthDays = $ctrl.customPattern.lengthDays;
            }

            return JSON.stringify(pattern);
          };

          var producePatternResources = function () {
            var currentPatternResources = angular.extend([], $ctrl.availabilityPattern.availabilityPatternResources);
            var availabilityPatternResources = Object.values($ctrl.patternResources).map(function (patternResource) {
              // var action = '',
              var  patternResourceId = null;
              var resource = patternResource.resource,
                resourceId = resource.id;
              var currentPatternResource = currentPatternResources.find(function (item) {
                return item.resource.id === resourceId;
              });

              if (currentPatternResource) {
                // action = 'update';
                patternResourceId = currentPatternResource.id;
                currentPatternResources.splice(currentPatternResources.indexOf(currentPatternResource), 1);
              } else {
                // action = 'create';
              }

              return {
                id: patternResourceId,
                resourceId: resourceId,
                startDate: dateUtil.dateToString(patternResource.startDate),
                endDate: dateUtil.dateToString(patternResource.endDate),
                // action: action // no need action at the moment
              };

            });
            /* availabilityPatternResources = availabilityPatternResources.concat(currentPatternResources.map(function (currentPatternResource) {
              return {
                id: currentPatternResource.id,
                resourceId: currentPatternResource.resource.id,
                startDate: dateUtil.dateToString(currentPatternResource.startDate),
                endDate: dateUtil.dateToString(currentPatternResource.endDate),
                action: 'delete'
              };
            })); */

            return availabilityPatternResources;
          };

          params.pattern = producePatternData();
          params.availabilityPatternResources = producePatternResources();

          return {
            availabilityPattern: params
          };
        };

        var saveAvailabilityPattern = function () {
          var params;
          if (isAvailabilityPatternValid() && isResourceAllocatedToThePattern()) {
            params = buildAvailabilityPatternSavingParams();
            showLoading();
            $q.when(function () {
              if (angular.isFunction($ctrl.onSave)) {
                return $ctrl.onSave({
                  params: params
                });
              } else {
                return true;
              }
            }())
              .then(function (isClosing) {
                if (isClosing) {
                  closeModal('done');
                }
              })
              .finally(hideLoading);
          }
        };

        var showResourceAllocationModal = function () {
          util.showModal({
            template: [
              '<pattern-resource-allocation-modal',
              'class="sked-modal-container"',
              'on-close="onClose(this, message)"',
              'on-save="onSave(this, patternResources)"',
              'config-data="configData"',
              'pattern-resources="patternResources"',
              'selected-region-ids="selectedRegionIds">',
              '</pattern-resource-allocation-modal>'
            ].join(' ')
          }, {
            configData: $ctrl.configData,
            patternResources: angular.extend({}, $ctrl.patternResources),
            selectedRegionIds: $ctrl.regions.map(function (item) {
              return item.id;
            }),
            onClose: function (modalScope
              // , message
            ) {
              modalScope.closeModal();
            },
            onSave: function (modalScope, patternResources) {
              $ctrl.patternResources = angular.extend({}, patternResources);
              return true; // close modal
            }
          });
        };

        var isAllCustomPatternItemsSelected = function () {
          var customPattern = $ctrl.customPattern;

          return customPattern && angular.isArray(customPattern.items) && customPattern.items.length > 0 &&
            !customPattern.items.find(function (item) {
              return !item.isSelected;
            });
        };

        var toggleAllCustomPatternItemsSelection = function (
          // item
        ) {
          var customPattern = $ctrl.customPattern;
          var isAllSelected = isAllCustomPatternItemsSelected();

          if (customPattern && angular.isArray(customPattern.items)) {
            angular.forEach(customPattern.items, function (item) {
              toggleCustomPatternItemSelection(item, !isAllSelected);
            });
          }
        };

        var toggleCustomPatternItemSelection = function (item, isSelected) {
          item.isSelected = isSelected;

          if (!item.isSelected) {
            item.isAllDay = false;
            item.startTime = 0;
            item.endTime = 0;
          } else {
            item.startTime = $ctrl.configData.consoleSettings.calendarStart;
            item.endTime = $ctrl.configData.consoleSettings.calendarEnd;
            item.isAllDay = false;
          }
        };

        var toggleCustomPatternItemAllDay = function (item) {
          item.isAllDay = !item.isAllDay;

          if (item.isAllDay) {
            item.startTime = 0;
            item.endTime = 0;
          }
        };

        var setupWeekdaysOrder = function () {
          var WEEK_DAYS_ORDER = [
            WEEK_DAYS.MON,
            WEEK_DAYS.TUE,
            WEEK_DAYS.WED,
            WEEK_DAYS.THU,
            WEEK_DAYS.FRI,
            WEEK_DAYS.SAT
          ];

          if ($ctrl.configData.consoleSettings.firstDay) {
            WEEK_DAYS_ORDER.push(WEEK_DAYS.SUN);
          } else {
            WEEK_DAYS_ORDER.unshift(WEEK_DAYS.SUN);
          }

          $ctrl.WEEK_DAYS_ORDER = WEEK_DAYS_ORDER;
        };

        var setupPageConfiguration = function () {
          if ($ctrl.configData.consoleSettings.calendarStep) {
            defaultTimePickerOptions.step = $ctrl.configData.consoleSettings.calendarStep || 30;
            patternItemTimePickerOptions.step = $ctrl.configData.consoleSettings.calendarStep || 30;
          }
        };

        var identifyPageMode = function () {
          if ($ctrl.availabilityPattern && $ctrl.availabilityPattern.id) {
            $ctrl.pageMode = PAGE_MODE.EDIT;
          } else {
            $ctrl.pageMode = PAGE_MODE.CREATE;
          }
        };

        var setupWeeklyPattern = function (availabilityPattern) {
          var weeklyPattern = {
            items: [],
            repeatWeeks: 1,
            selectedItems: []
          };
          var patternDays = [];

          var produceWeeklyPatternItem = function (weekday) {
            return {
              fullLabel: weekday.fullLabel,
              weekday: weekday.value,
              isAllDay: false,
              startTime: 0,
              endTime: 0
            };
          };

          if (availabilityPattern &&
            availabilityPattern.pattern) {
            weeklyPattern.repeatWeeks = availabilityPattern.pattern.repeatWeeks || 1;

            if (availabilityPattern.pattern.type === constants.AVAILABILITY_PATTERN_TYPE.WEEKLY &&
              angular.isArray(availabilityPattern.pattern.days)) {
              patternDays = availabilityPattern.pattern.days;
            }
          }

          angular.forEach($ctrl.WEEK_DAYS_ORDER, function (weekday) {
            var dayItem;
            var firstInterval;
            var matchedDay = patternDays.find(function (day) {
              return day.weekday && day.weekday.toLowerCase() === weekday.value;
            });

            dayItem = produceWeeklyPatternItem(weekday);
            weeklyPattern.items.push(dayItem);

            if (matchedDay) {
              firstInterval = matchedDay.intervals[0];
              dayItem.startTime = firstInterval.startTime;
              dayItem.endTime = firstInterval.endTime;
              dayItem.isAllDay = (dayItem.startTime === 0 && dayItem.endTime === 0);

              weeklyPattern.selectedItems.push(dayItem);
            }
          });

          $ctrl.weeklyPattern = weeklyPattern;
        };

        var setupCustomPattern = function (availabilityPattern) {
          $ctrl.customPattern = {
            items: [],
            lengthDays: (availabilityPattern && availabilityPattern.pattern) ? (availabilityPattern.pattern.lengthDays || 1) : 1
          };

          adjustCustomPatternItems();
          applyCurrentCustomPattern(availabilityPattern);
        };

        var applyCurrentCustomPattern = function (availabilityPattern) {
          var patternDays;
          var customPattern = $ctrl.customPattern;

          if (availabilityPattern &&
            availabilityPattern.pattern) {


            if (availabilityPattern.pattern.type === constants.AVAILABILITY_PATTERN_TYPE.CUSTOM &&
              angular.isArray(availabilityPattern.pattern.days)) {
              patternDays = availabilityPattern.pattern.days;

              if (patternDays.length > 0) {
                angular.forEach(customPattern.items, function (item) {
                  var firstInterval;
                  var matchedDay = patternDays.find(function (day) {
                    return day.day === item.dayNo;
                  });

                  if (matchedDay) {
                    item.isAllDay = !!matchedDay.isAllDay;

                    if (angular.isArray(matchedDay.intervals) && matchedDay.intervals.length > 0) {
                      firstInterval = matchedDay.intervals[0];
                      item.startTime = firstInterval.startTime || 0;
                      item.endTime = firstInterval.endTime || 0;
                      item.isSelected = true;
                      item.isAllDay = (item.startTime === 0 && item.endTime === 0);
                    }
                  }
                });
              }
            }
          }
        };

        var adjustCustomPatternItems = function () {
          var customPattern = $ctrl.customPattern;
          var produceCustomPatternItem = function (ind) {
            return {
              dayNo: ind,
              startTime: 0,
              endTime: 0,
              isAllDay: false,
              isSelected: false
            };
          };

          if (customPattern) {
            if (!angular.isArray(customPattern.items)) {
              customPattern.items = [];
            }
            if (!angular.isNumber(customPattern.lengthDays) || customPattern.lengthDays < 0) {
              customPattern.lengthDays = 1;
            }

            if (customPattern.items.length > customPattern.lengthDays) {
              customPattern.items.length = customPattern.lengthDays;
            } else if (customPattern.items.length < customPattern.lengthDays) {
              for (var i = customPattern.items.length + 1; i <= customPattern.lengthDays; i++) {
                customPattern.items.push(produceCustomPatternItem(i));
              }
            }
          }
        };

        var setupPattern = function (availabilityPattern) {
          $ctrl.patternType = constants.AVAILABILITY_PATTERN_TYPE.WEEKLY; // default type when creating

          if (availabilityPattern &&
            availabilityPattern.pattern &&
            availabilityPattern.pattern.type && [constants.AVAILABILITY_PATTERN_TYPE.WEEKLY, constants.AVAILABILITY_PATTERN_TYPE.CUSTOM].indexOf(availabilityPattern.pattern.type) > -1) {
            $ctrl.patternType = availabilityPattern.pattern.type;
          }

          setupWeeklyPattern($ctrl.availabilityPattern);
          setupCustomPattern($ctrl.availabilityPattern);
        };

        var setupPatternResources = function (availabilityPattern) {
          var patternResources = {};

          if (availabilityPattern &&
            angular.isArray(availabilityPattern.availabilityPatternResources)) {
            angular.forEach(availabilityPattern.availabilityPatternResources, function (availabilityPatternResource) {
              var resource = availabilityPatternResource.resource;
              if (resource && resource.id)
                patternResources[resource.id] = availabilityPatternResource;
            });
          }

          $ctrl.patternResources = patternResources;
        };

        var countPatternResources = function () {
          var count = 0;
          var patternResources = $ctrl.patternResources;

          if (patternResources) {
            count = Object.keys(patternResources).length;
          }

          return count;
        };

        /**
         * controller init
         * used for setting initial value
         */
        $ctrl.$onInit = function () {
          $ctrl.isModalOpen = true;

          setupWeekdaysOrder();
          setupPageConfiguration();
          identifyPageMode();

          setupPattern($ctrl.availabilityPattern);
          setupPatternResources($ctrl.availabilityPattern);

          //$ctrl.availabilityTemplate.weekTemplates = produceAvailabilityWeekTemplates($ctrl.availabilityTemplate.entries);
          //$ctrl.availabilityTemplate.resourceIds = produceAvailabilityResources($ctrl.availabilityTemplate.availabilityTemplateResources);
        };

        /**
         * init block
         * used for setting up controller
         */
        (function () {
          $scope.AVAILABILITY_PATTERN_TYPE = constants.AVAILABILITY_PATTERN_TYPE;
          $scope.MAX_PATTERN_LENGTH = MAX_PATTERN_LENGTH;
          $scope.REPEAT_WEEKLY_OPTIONS = REPEAT_WEEKLY_OPTIONS;
          $scope.INTEGER_PATTERN = INTEGER_PATTERN;
          $scope.WEEK_DAYS = WEEK_DAYS;
          $scope.PAGE_MODE = PAGE_MODE;

          $ctrl.isModalOpen = false;
          $ctrl.contentLoading = false;

          $ctrl.closeModal = closeModal;
          $ctrl.pageMode = PAGE_MODE.CREATE;

          $ctrl.patternType = constants.AVAILABILITY_PATTERN_TYPE.WEEKLY;
          $ctrl.customPattern = null;
          $ctrl.weeklyPattern = null;
          $ctrl.patternResources = null;

          $ctrl.defaultTimePickerOptions = defaultTimePickerOptions;
          $ctrl.patternItemTimePickerOptions = patternItemTimePickerOptions;

          $ctrl.saveAvailabilityPattern = saveAvailabilityPattern;

          $ctrl.showResourceAllocationModal = showResourceAllocationModal;

          $ctrl.getArray = getArray;
          $ctrl.countPatternResources = countPatternResources;

          $ctrl.isAllWeeklyPatternItemsSelected = isAllWeeklyPatternItemsSelected;
          $ctrl.isAnyWeeklyPatternItemSelected = isAnyWeeklyPatternItemSelected;
          $ctrl.toggleAllWeeklyPatternItemsSelection = toggleAllWeeklyPatternItemsSelection;
          $ctrl.toggleWeeklyPatternItemAllDay = toggleWeeklyPatternItemAllDay;
          $ctrl.toggleWeeklyPatternItemSelection = toggleWeeklyPatternItemSelection;
          $ctrl.isWeeklyPatternItemSelected = isWeeklyPatternItemSelected;

          $ctrl.isAllCustomPatternItemsSelected = isAllCustomPatternItemsSelected;
          $ctrl.toggleAllCustomPatternItemsSelection = toggleAllCustomPatternItemsSelection;
          $ctrl.toggleCustomPatternItemSelection = toggleCustomPatternItemSelection;
          $ctrl.toggleCustomPatternItemAllDay = toggleCustomPatternItemAllDay;

          $scope.$watch('$ctrl.customPattern.lengthDays', function () {
            adjustCustomPatternItems();
          });
        })();
      }
    ]
  });
})(angular, top);