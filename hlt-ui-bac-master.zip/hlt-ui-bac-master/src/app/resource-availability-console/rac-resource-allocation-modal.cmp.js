(function (angular, topWindow) {
	angular.module('hltApp')
	.component('resourceAllocationModal', {
		templateUrl: 'src/app/resource-availability-console/rac-resource-allocation-modal.tpl.html',
		bindings: {
			availability: '=',
			resource: '=',
			configData: '<',
			onClose: '&'
		},
		controller: [
			'$filter',
			'$scope',
			'$q',
			'util',
			'api',
			'model',
			'constants',
			function ($filter, $scope, $q, util, api, model, constants) {
				var $ctrl = this;

				var DEFAULT_PHOTO_URL = $filter('skedSfUrl')('slds/images/avatar3.jpg');

				var ORDER_OPTIONS = {
					RESOURCE: 'name',
					CATEGORY: 'category',
					REGION: 'region.name'
				};
				var PRIORITY_OPTIONS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];

				var closeModal = function (message) {
					$ctrl.isModalOpen = false;
					// run onClose expression
					if (angular.isFunction ($ctrl.onClose)) {
						$ctrl.onClose({
							message: message
						});
					}
				};

				/**
				 * common remote action error handler
				 */
				var commonExceptionHanlder = function (exception) {
					console.error(exception);
					util.toastError('Can not perform action due to server error.');

					return $q.reject();
				};

				/**
				 * show content loading
				 */
				var showLoading = function () {
					$ctrl.contentLoading = true;
				};

				/**
				 * hide content loading
				 */
				var hideLoading = function () {
					$ctrl.contentLoading = false;
				};

				var doSearchResources = function () {
					return api.search({
							objectType: constants.OBJECT_TYPE.RESOURCE,
							queryText: '',
							subQueryIndicator: "sked__Resource_Region__c"
						})
						.catch(commonExceptionHanlder);
				};

				var getResources = function () {
					showLoading();
					doSearchResources()
						.then(function (result) {
							$ctrl.resources = (result.success && result.data)?model.ResourceModel.fromServerList(result.data):[];

							setupResources();
							initSelectedResources();
							filterResources();
							sortResourcesByDefault();
						})
						.catch(function (exception) {
							console.error(exception);
							if (exception && exception.errorMessage) {
								util.toastError(exception.errorMessage);
							}
						})
						.finally(hideLoading);
				};

				var setupResources = function () {
					angular.forEach($ctrl.resources, function (resource) {
						resource.priority = '1';

						mapResourcesRegions(resource);
					});
				};

				var mapResourcesRegions = function (resource) {
					resource.regionIds = [];

					if ($ctrl.configData && $ctrl.configData.regions) {
						if (resource.region && resource.region.id) {
							resource.region = $ctrl.configData.regions.find(function (region) {
								return region.id === resource.region.id;
							});

							resource.regionIds.push(resource.region.id);
						}

						if (angular.isArray(resource.resourceRegions) && resource.resourceRegions.length > 0) {
							angular.forEach(resource.resourceRegions, function (resourceRegion) {
								resource.regionIds.push(resourceRegion.regionId)
							});
						}
					}
				};

				var sortResourceList = function (sortExpression) {
					if ($ctrl.orderBy === sortExpression) {
						$ctrl.orderDir *= -1;
					} else {
						$ctrl.orderBy = sortExpression;
						$ctrl.orderDir = 1;
					}
				};

				var filterResources = function () {
					var filterString = $ctrl.filterString.toLowerCase();
					var selectedRegionId = $ctrl.region?$ctrl.region.id:null;

					$ctrl.filteredResources = $ctrl.resources.filter(function (resource) {
						return resource.name.toLowerCase().indexOf(filterString) > -1 &&
							//(!selectedRegionId ||  (resource.region && resource.region.id === selectedRegionId)) &&
							(!selectedRegionId ||  (resource.regionIds.indexOf(selectedRegionId) > -1)) &&
							(!$ctrl.showSelectedOnly || $ctrl.selectedResources.indexOf(resource) > -1)
					});
				};

				var toggleResourceSelection = function (resource) {
					var selectingIndex = $ctrl.selectedResources.indexOf(resource);

					if (resource.id !== $ctrl.resource.id) {
						if (selectingIndex > -1) {
							$ctrl.selectedResources.splice(selectingIndex, 1);
						} else if ($ctrl.selectedResources.length >= 25) {
							util.toastWarning('Unable to select more than 25 members.')
						} else {
							$ctrl.selectedResources.push(resource);
						}
					}
				};

				var initSelectedResources = function () {
					var onCallTeamMembers = $ctrl.availability.members;

					if (onCallTeamMembers.length > 0 && $ctrl.resources.length > 0) {
						$ctrl.selectedResources = $ctrl.resources.filter(function (resource) {
							var memberFound = onCallTeamMembers.find(function (member) {
								return member.id === resource.id;
							});

							if (memberFound) {
								resource.priority = memberFound.priority || '1';
							}

							return memberFound;
						});
					} else {
						$ctrl.selectedResources = [];
					}
				};

				var sortResourcesByDefault = function () {
					$ctrl.orderBy = null;
					$ctrl.orderDir = null;
					$ctrl.filteredResources = $ctrl.filteredResources.sort(function (rs1, rs2) {
						var priority1 = ('00' + (rs1.priority || '')).substr(-2),
							priority2 = ('00' + (rs2.priority || '')).substr(-2);
						var name1 = rs1.name || '',
							name2 = rs2.name || '';

						if ($ctrl.selectedResources.indexOf(rs1) > -1 && 
							$ctrl.selectedResources.indexOf(rs2) > -1) {
							return priority1 - priority2;
						} else if ($ctrl.selectedResources.indexOf(rs1) > -1 && 
							$ctrl.selectedResources.indexOf(rs2) === -1) {
							return -1;
						} else if ($ctrl.selectedResources.indexOf(rs1) === -1 && 
							$ctrl.selectedResources.indexOf(rs2) > -1) {
							return 1;
						} 

						return ((name1 < name2)?-1:((name1 > name2)?1:0));
					});
				};

				var updateAvailabilityMembers = function () {
					$ctrl.availability.members = angular.extend([], $ctrl.selectedResources);
					closeModal('done');
				};

				/**
				 * controller init
				 * used for setting initial value
				 */
				$ctrl.$onInit = function () {
					$ctrl.isModalOpen = true;
					getResources();
				};

				/**
				 * init block
				 * used for setting up controller
				 */
				(function () {
					$scope.ORDER_OPTIONS = ORDER_OPTIONS;
					$scope.DEFAULT_PHOTO_URL = DEFAULT_PHOTO_URL;
					$scope.PRIORITY_OPTIONS = PRIORITY_OPTIONS;

					$ctrl.filterString = '';
					$ctrl.region = null;
					$ctrl.showSelectedOnly = false;
					$ctrl.orderBy = null;
					$ctrl.orderDir = null;

					$ctrl.resources = [];
					$ctrl.filteredResources = [];
					$ctrl.selectedResources = [];

					$ctrl.sortResourceList = sortResourceList;
					$ctrl.filterResources = filterResources;
					$ctrl.sortResourcesByDefault = sortResourcesByDefault;

					$ctrl.toggleResourceSelection = toggleResourceSelection;
					$ctrl.updateAvailabilityMembers = updateAvailabilityMembers;
					
					$ctrl.closeModal = closeModal;
				})();
			}
		]
	});
})(angular, top);