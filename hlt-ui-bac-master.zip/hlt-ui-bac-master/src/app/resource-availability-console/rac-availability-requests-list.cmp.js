(function (angular, topWindow) {
  angular.module('hltApp')
    .component('availabilityRequestsList', {
      templateUrl: 'src/app/resource-availability-console/rac-availability-requests-list.tpl.html',
      bindings: {
        configData: '=',
        timezone: '=',
        regions: '=',
        resource: '<',
        onMenuItemClick: '&'
      },
      controller: [
        'JOB_STATUS',
        'constants',
        '$timeout',
        '$location',
        '$q',
        '$scope',
        '$filter',
        'util',
        'dateUtil',
        'api',
        'model',
        function (JOB_STATUS, constants, $timeout, $location, $q, $scope, $filter, util, dateUtil, api, model) {
          var $ctrl = this;

          var ORDER_DIR_OPTIONS = {
            ASC: {dirVal: 1, label: 'ASC', reverse: false},
            DESC: {dirVal: -1, label: 'DESC', reverse: true}
          };
          var LIST_COLUMNS = {
            RESOURCE: {label: 'Resource', cssClass: 'col-resource', sortExp: 'resource.name', isSortable: true, visible: true},
            SUBMITTED: {label: 'Submitted', cssClass: 'col-submitted', sortExp: 'createdOn', isSortable: true, visible: true},
            MODIFIED: {label: 'Modified', cssClass: 'col-modified', sortExp: 'lastModified', isSortable: true, visible: true},
            REQUEST_DATE_TIME: {label: 'Request', cssClass: 'col-request-date-time', sortExp: 'start', isSortable: true, visible: true},
            TYPE: {label: 'Type', cssClass: 'col-type', sortExp: 'eventType', isSortable: true, visible: true},
            STATUS: {label: 'Status', cssClass: 'col-status', sortExp: 'status', isSortable: true, visible: true},
            NOTES: {label: 'Notes', cssClass: 'col-notes', sortExp: 'notes', isSortable: false, visible: true}
          };
  
          var OBJECT_TYPE = {
            AVAILABILITY: 'availability',
            ACTIVITY: 'activity',
            JOB: 'job'
          };
          var DEFAULT_EVENT_STATUS = 'DEFAULT_EVENT_STATUS';

          var cachedQuery = {};

          var isParamsReallyChanged = function (params, currentParams) {
            return !util.compareValues(params, currentParams);
          };

          var showLoading = function () {
            util.showLoading();
          };

          var hideLoading = function () {
            util.hideLoading();
          };

          var doGetPendingAvailability = function (query) {
            return api.getPendingAvailability(query)
              .catch(api.commonExceptionHanlder);
          };

          var fetchJobList = function (forceFetching) {
            var query;

            if ($ctrl.configData &&
              angular.isArray($ctrl.regions) && $ctrl.regions.length > 0) {

              query = {
                regionIds: $ctrl.regions.map(function (region) {
                  return region.id;
                }),
                pageNo: $ctrl.paginModel.pageNumber,
                pageSize: $ctrl.paginModel.recordsPerPage,
                orderBy: $ctrl.orderModel.by.sortExp,
                orderDirection: $ctrl.orderModel.dir.dirVal,
                timezoneSidId: $ctrl.timezone.label,
                queryText: $ctrl.filterModel.searchString || '',
                availabilityStatuses: $ctrl.filterModel.availabilityStatuses.map(function (status) {
                  return status.id;
                }),
                startDate: dateUtil.dateToString($ctrl.filterModel.startDate),
                endDate: dateUtil.dateToString($ctrl.filterModel.endDate)
              };

              if ($ctrl.resource) {
                query.resourceId = $ctrl.resource.id;
                delete query.regionIds;
                delete query.roleIds;
              }

              if (forceFetching || isParamsReallyChanged(query, cachedQuery)) {
                cachedQuery = query;

                showLoading();
                return doGetPendingAvailability(query)
                  .then(function (result) {
                    if (result.success) {
                      $ctrl.list = model.AvailabilityModel.fromServerList(result.data.availabilityData || []);
                      $ctrl.paginModel.numberOfPages = result.data.totalPages || 0;
                      $ctrl.paginModel.numberOfRecords = result.data.totalRecords || 0;

                      // pre-process jobs
                      processAvailabilityData($ctrl.list);
                    } else {
                      return $q.reject(result);
                    }
                  })
                  .catch(function (exception) {
                    if (exception && exception.errorMessage) {
                      util.toastError(exception.errorMessage);
                    }
                  })
                  .finally(function () {
                    hideLoading();
                  });
              }
            } else if ($ctrl.list.length > 0) {
              $ctrl.list = [];
            }
          };

          var processAvailabilityData = function (availability) {
            var processEvent = function (event) {
              var eventTypes;
              var objectType = event.objectType;
              var resource = event.resource;
              var staffingBudgets = event.staffingBudgets;

              if ($ctrl.configData) {
                switch (objectType) {
                case OBJECT_TYPE.AVAILABILITY:
                  eventTypes = ($ctrl.configData.availabilityTypes.concat($ctrl.configData.otherEventTypes)) || [];
                  break;
                case OBJECT_TYPE.ACTIVITY:
                  eventTypes = ($ctrl.configData.activityTypes.concat($ctrl.configData.otherEventTypes)) || [];
                  break;
                case OBJECT_TYPE.JOB:
                  eventTypes = ($ctrl.configData.jobTypes.concat($ctrl.configData.otherEventTypes)) || [];
                  break;
                default:
                  eventTypes = [];
                  break;
                }

                // identify event type
                if (event.eventType) {
                  for (var i = 0; i < eventTypes.length; i++) {
                    if (eventTypes[i].id === event.eventType.id) {
                      event.eventType = eventTypes[i];
                      event.eventTypeSettings = event.eventType.eventTypeSettings[event.jobStatus || event.status];

                      if (!event.eventTypeSettings) {
                        event.eventTypeSettings = event.eventType.eventTypeSettings[DEFAULT_EVENT_STATUS];
                      }

                      break;
                    }
                  }
                }

                // identify resource type
                if (resource) {
                  if (resource.resourceType && $ctrl.configData && angular.isArray($ctrl.configData.resourceTypes)) {
                    resource.resourceType = $ctrl.configData.resourceTypes.find(function (resourceType) {
                      return resourceType.id === resource.resourceType.id;
                    });
                  } else {
                    resource.resourceType = null;
                  }
                }

                event.approvalRequired = (event.status === constants.AVAILABILITY_STATUS.PENDING &&
                  event.objectType === OBJECT_TYPE.AVAILABILITY);

                // process staffing budget data
                if (angular.isArray(staffingBudgets) && staffingBudgets.length > 0) {
                  angular.forEach(staffingBudgets, function (staffingBudget) {
                    staffingBudget.roleName = staffingBudget.roles.map(function (role) {
                      return role.label;
                    }).join(' / ');
                    staffingBudget.isAvailable = staffingBudget.availableSlots > 0;
                  });
                }
              }
            };

            angular.forEach(availability, processEvent);
          };

          var sortList = function (col) {
            if (col.isSortable) {
              if ($ctrl.orderModel.by !== col) {
                $ctrl.orderModel.by = col;
                $ctrl.orderModel.dir = ORDER_DIR_OPTIONS.ASC;
              } else {
                $ctrl.orderModel.dir = ($ctrl.orderModel.dir === ORDER_DIR_OPTIONS.ASC) ? ORDER_DIR_OPTIONS.DESC : ORDER_DIR_OPTIONS.ASC;
              }
            }
          };

          var resetFilters = function () {
            if ($ctrl.configData) {
              $ctrl.filterModel = {
                roles: angular.isArray($ctrl.configData.roles) ? angular.extend([], $ctrl.configData.roles) : [],
                availabilityStatuses: angular.isArray($ctrl.configData.availabilityStatuses) ? angular.extend([], $ctrl.configData.availabilityStatuses) : [],
                startDate: new Date,
                endDate: null,
                searchString: ''
              };
            }
          };

          var initList = function () {};

          $ctrl.$onInit = function () {
            resetFilters();
            initList();

            $ctrl.COMMON_DATE_FORMAT = _.get($ctrl, 'configData.consoleSettings.dateFormat', 'MM/dd/yy');
          };

          /**
           * init block
           * used for setting up controller
           */
          (function () {
            $scope.ORDER_DIR_OPTIONS = ORDER_DIR_OPTIONS;
            $scope.LIST_COLUMNS = LIST_COLUMNS;
            $scope.AVAILABILITY_STATUS = constants.AVAILABILITY_STATUS;

            $ctrl.list = [];

            $ctrl.sortList = sortList;
            $ctrl.resetFilters = resetFilters;

            $ctrl.paginModel = {
              recordCountOptions: [5, 10, 15, 20, 25],
              recordsPerPage: 25,
              pageNumber: 1,
              numberOfPages: 0,
              numberOfRecords: 0
            };
            $ctrl.orderModel = {
              by: LIST_COLUMNS.REQUEST_DATE_TIME,
              dir: ORDER_DIR_OPTIONS.ASC
            };
            $ctrl.filterModel = {
              roles: [],
              availabilityStatuses: [],
              startDate: null,
              endDate: null,
              searchString: ''
            };

            $scope.$watchGroup([
              '$ctrl.paginModel.recordsPerPage',
              '$ctrl.paginModel.pageNumber',
              '$ctrl.orderModel.by',
              '$ctrl.orderModel.dir',
              '$ctrl.filterModel.searchString',
              '$ctrl.filterModel.startDate',
              '$ctrl.filterModel.endDate'
            ], function () {
              fetchJobList();
            });
            $scope.$watchCollection(
              '$ctrl.filterModel.availabilityStatuses',
              function () {
                fetchJobList();
              }
            );
            $scope.$watchCollection(
              '$ctrl.filterModel.roles',
              function () {
                fetchJobList();
              }
            );

            // $scope.$watchCollection(
            //   // '$ctrl.regions', 
            //   '$ctrl.biomedCollectionOps',
            //   function () {
            //     fetchJobList();
            //   }
            // );

            $scope.$watch(
              '$ctrl.timezone',
              function () {
                fetchJobList();
              }
            );

            $scope.$on('rac:refreshConsole', function () {
              fetchJobList(true);
            });
          })();
        }
      ]
    });
})(angular, top);