(function (angular, topWindow) {
    angular.module('hltApp')
    .component('scheduleDetails', {
        templateUrl: 'src/app/resource-availability-console/schedule-details-modal.tpl.html',
        bindings: {
            event: '<',
            configData: '<',
            resource: '<',
            scheduleId: '<',
            onClose: '&',
            timezone: '<'
        },
        controller: [
            '$scope',
            '$timeout',
            '$window',
            '$location',
            '$q',
            '$filter',
            'api',
            'util',
            'dateUtil',
            'model',
            function ($scope, $timeout, $window, $location, $q, $filter, api, util, dateUtil, model) {
                var $ctrl = this;
                var MANAGE_SCHEDULE_OPTIONS = {
                    ENTIRE_SCHEDULE: {
                        value: 'entire_schedule',
                        label: 'Entire Schedule'
                    },
                    SPECIFIC_PERIOD: {
                        value: 'specific_period',
                        label: 'Specific Period'
                    }
                };
                
                var WEEK_DAYS = {
                    SUN: {
                        label: 'Sun',
                        fullLabel: 'Sunday',
                        value: 'sun'
                    },
                    MON: {
                        label: 'Mon',
                        fullLabel: 'Monday',
                        value: 'mon'
                    },
                    TUE: {
                        label: 'Tue',
                        fullLabel: 'Tuesday',
                        value: 'tue'
                    },
                    WED: {
                        label: 'Wed',
                        fullLabel: 'Wednesday',
                        value: 'wed'
                    },
                    THU: {
                        label: 'Thu',
                        fullLabel: 'Thursday',
                        value: 'thu'
                    },
                    FRI: {
                        label: 'Fri',
                        fullLabel: 'Friday',
                        value: 'fri'
                    },
                    SAT: {
                        label: 'Sat',
                        fullLabel: 'Saturday',
                        value: 'sat'
                    },
                };

                var templateDateOptions = {
                    minDate: null,
                    maxDate: null
                };

                var cachedEntryValue = {};

                var nameFilter = $filter('filter');
                var dateFilter = $filter('date');
                var getArray = function (len) {
                    len = len || 0;
                    return new Array(len);
                };

                /**
                 * common remote action error handler
                 */
                var commonExceptionHanlder = function (exception) {
                    console.error(exception);
                    util.toastError('Can not perform action due to server error.');

                    return $q.reject();
                };

                /**
                 * show content loading
                 */
                var showLoading = function () {
                    $ctrl.contentLoading = true;
                };

                /**
                 * hide content loading
                 */
                var hideLoading = function () {
                    $ctrl.contentLoading = false;
                };

                /**
                 * close main modal
                 */
                var closeModal = function (message) {
                    $ctrl.isModalOpen = false;
                    // run onClose expression
                    if (angular.isFunction ($ctrl.onClose)) {
                        $ctrl.onClose({
                            message: message
                        });
                    }
                };

                var doGetSchedule = function (requestParams) {
                    return api.getSchedule(requestParams)
                        .catch(commonExceptionHanlder);
                };

                var doSaveSchedule = function (requestParams) {
                    return api.saveSchedule(requestParams)
                        .catch(commonExceptionHanlder);
                };

                var showAvailabilityConflictsModal = function (data) {
                    util.showModal({
                        template: '<availability-conflicts-modal class="sked-modal-container" mode="mode" data="data" patient="patient" config-data="configData" on-close="onClose(this, message)"></availability-conflicts-modal>',
                    }, {
                        mode: 'Schedule',
                        data: data,
                        configData: $ctrl.configData,
                        onClose: function (modalScope, message) {
                            modalScope.closeModal();

                            if (message === 'done') {
                                util.toastSuccess('Schedule has been updated successfully.');
                                closeModal('done');
                            }
                        }
                    });
                };

                var saveSchedule = function () {
                    var requestParams;
                    var savingCallback = function (result) {
                        if (result.success) {
                            if (result.data && result.data.hasConflict) {
                                showAvailabilityConflictsModal(result.data);
                            } else {
                                util.toastSuccess('Schedule has been updated successfully.');
                                closeModal('done');
                            }
                        } else{
                            return $q.reject(result);
                        }
                    };

                    if (validateSchedule()) {
                        requestParams = {
                            recurringSchedule: buildScheduleSavingParams()
                        };

                        showLoading();
                        doSaveSchedule(requestParams, false)
                            .then(savingCallback)
                            .then(function (message) {
                                if (message === 'confirmed') {
                                    showLoading();
                                    return doSaveSchedule(requestParams, true).then(savingCallback);
                                } else {
                                    return message;
                                }
                            })
                            .then(function (message) {
                                if (message !== 'back' && message !== 'no') {
                                    closeModal('done');
                                }
                            })
                            .catch(function (exception) {
                                console.error(exception);
                                if (exception && exception.errorMessage) {
                                    util.toastError(exception.errorMessage);
                                }
                            })
                            .finally(function () {
                                hideLoading();
                            });
                    }
                };

                var validateSchedule = function () {
                    var form = $ctrl.scheduleDetailsForm;
                    var checkingTemplate, checkingEntry;
 
                    form.$setSubmitted(true);

                    if (!form.$valid && form.$error.required) {
                        util.toastError('Please check all required fields.');
                        return false;
                    } else if (!form.$valid && (form.$error.pattern || form.$error.number || form.$error.skedTimeValidator)) {
                        util.toastError('Invalid data format, please check date/time and number fields.');
                        return false;
                    } else if (!form.$valid && form.$error.timeRange) {
                        util.toastError('Schedule start date (Recurring from) should before end date (Recurring to).');
                        return false;
                    } else {
                        if (!angular.isArray($ctrl.schedule.weekTemplates) || $ctrl.schedule.weekTemplates.length === 0) {
                            util.toastError('Please setup atleast one week template.');
                            return false;
                        } else {
                            for (var j = 0; j < $ctrl.schedule.weekTemplates.length; j++) {
                                checkingTemplate = $ctrl.schedule.weekTemplates[j];
                                if (checkingTemplate.entries.length === 0) {
                                    util.toastError('Week template requires atleast a date entry.');
                                    return false;
                                } else {
                                    for (var k = 0; k < checkingTemplate.entries.length; k++) {
                                        checkingEntry = checkingTemplate.entries[k]
                                        if (!!checkingEntry.hasErrors) {
                                            util.toastError('Please check template errors before saving.');
                                            return false;
                                        }
                                    }
                                }
                            }
                        }
                    } 

                    return true;
                };

                var buildScheduleSavingParams = function () {
                    var scheduleParams;
                    var strStartDate = dateUtil.dateToString($ctrl.schedule.startDate),
                        strEndDate = dateUtil.dateToString($ctrl.schedule.endDate);

                    // recurring options
                    scheduleParams = {
                        id: $ctrl.scheduleData.id,
                        description: $ctrl.schedule.description,
                        skipHolidays: $ctrl.schedule.skipHolidays,
                        availabilityTemplate: {
                            id: $ctrl.schedule.id,
                            startDate: strStartDate,
                            endDate: strEndDate,
                            availabilityTemplateEntries: []
                        }, 
                        isEditSpecificPeriod: ($ctrl.manageScheduleOption === MANAGE_SCHEDULE_OPTIONS.SPECIFIC_PERIOD)
                    };

                    // produce template entries
                    angular.forEach($ctrl.schedule.weekTemplates, function (weekTemplate, weekInd) {
                        angular.forEach(weekTemplate.entries, function (templateEntry) {
                            scheduleParams.availabilityTemplate.availabilityTemplateEntries.push({
                                id: templateEntry.id,
                                weekNo: weekInd + 1,
                                weekday: templateEntry.weekday.value,
                                startTime: templateEntry.startTime,
                                endTime: templateEntry.endTime,
                                //isAllDay: templateEntry.isAllDay
                                action: identifyAction(templateEntry)
                            });
                        });
                    });

                    return scheduleParams;
                };

                var storeEntryToCache = function (entry) {
                    if (!cachedEntryValue) {
                        cachedEntryValue = {};
                    }

                    cachedEntryValue[entry.id] = produceEntryValue(entry);
                };

                var produceEntryValue = function (entry) {
                    return [entry.weekNo, entry.weekday.value, entry.startTime, entry.endTime].join(';');
                };

                var isEntryChanged = function (entry) {
                    return cachedEntryValue[entry.id] !== produceEntryValue(entry);
                };

                var identifyAction = function (actionTarget) {
                    var action = '';

                    if (!actionTarget.id) {
                        action = 'create';
                    } else if (!!actionTarget.isDeleted) {
                        action = 'delete';
                    } else if (actionTarget.id && isEntryChanged(actionTarget)) {
                        action = 'update';
                    }

                    return action;
                };

                var addWeekTemplate = function () {
                    var weekTemplates = $ctrl.schedule.weekTemplates;

                    if (!angular.isArray(weekTemplates)) {
                        weekTemplates = $ctrl.schedule.weekTemplates = [];
                    }

                    weekTemplates.push({
                        isAllDay: false,
                        entries: []
                    });
                };

                var copyWeekTemplate = function (index) {
                    var weekTemplates = $ctrl.schedule.weekTemplates,
                        weekTemplate, filteredTemplateEntries,clonedWeekTemplate;
                    var isDeletedFilter = function (entry) {
                        return !entry.isDeleted;
                    };

                    if (angular.isArray(weekTemplates) && weekTemplates.length > index) {
                        weekTemplate = weekTemplates[index];
                        filteredTemplateEntries = weekTemplate.entries.filter(isDeletedFilter);

                        if (filteredTemplateEntries.length > 0) {
                            clonedWeekTemplate = angular.copy(weekTemplate);

                            clonedWeekTemplate.entries = clonedWeekTemplate.entries.filter(isDeletedFilter);
                            clonedWeekTemplate.entries.map(function (entry) {
                                delete entry.id;

                                if (entry.weekday) {
                                    entry.weekday = identifyWeekday(entry.weekday.value)
                                }
                            });

                            weekTemplates.splice(index + 1, 0, clonedWeekTemplate);
                        }                        
                    }
                };

                var removeWeekTemplate = function (index) {
                    var weekTemplates = $ctrl.schedule.weekTemplates,
                        weekTemplate;

                    if (angular.isArray(weekTemplates) && weekTemplates.length > index) {
                        weekTemplate = weekTemplates[index];
                        removeWeekTemplateEntry(weekTemplate);

                        if (weekTemplate.entries.length === 0) {
                            weekTemplates.splice(index, 1);
                        }
                    }
                };

                var addWeekTemplateEntry = function (weekTemplate) {
                    var entries, defaultStartTime, defaultEndTime;

                    if (weekTemplate) {
                        entries = weekTemplate.entries;

                        if (!angular.isArray(entries)) {
                            entries = weekTemplate.entries = [];
                        }

                        if ($ctrl.event) {
                            defaultStartTime = $ctrl.event.startTime;
                            defaultEndTime = $ctrl.event.endTime;
                        } else {
                            defaultStartTime = $ctrl.configData.consoleSettings.calendarStart;
                            defaultEndTime = $ctrl.configData.consoleSettings.calendarEnd;
                        }

                        if (defaultEndTime === 2400 || defaultEndTime === 0) {
                            defaultEndTime = 2330;
                        }

                        entries.push({
                            weekday: null,
                            startTime: defaultStartTime,
                            endTime: defaultEndTime,
                            isAllDay: weekTemplate.isAllDay
                        });

                        verifyWeekTemplateErrors(weekTemplate);
                    }
                };

                var removeWeekTemplateEntry = function (weekTemplate, index) {
                    var entries;
                    var doRemoveWeekTemplateEntry = function (entries, idx) {
                        var entry = entries[idx];
                        if (entry.id) {
                            entry.isDeleted = true;
                            return true;
                        } else {
                            entries.splice(idx, 1);
                            return false;
                        }
                    };

                    if (weekTemplate) {
                        entries = weekTemplate.entries;

                        if (angular.isArray(entries)) {
                            if (angular.isNumber(index) && entries.length > index) {
                                doRemoveWeekTemplateEntry(entries, index);
                            } else if (!angular.isNumber(index)) {
                                for (var i = 0; i < entries.length; i++) {
                                    if (!doRemoveWeekTemplateEntry(entries, i)) {
                                        i--;
                                    }
                                }
                            }

                            verifyWeekTemplateErrors(weekTemplate);
                        }
                    }
                };

                var restoreWeekTemplateEntry = function (weekTemplate, entry) {
                    entry.isDeleted = false;

                    verifyWeekTemplateErrors(weekTemplate);
                };

                var verifyWeekTemplateErrors = function (weekTemplate) {
                    if (weekTemplate && angular.isArray(weekTemplate.entries) && weekTemplate.entries.length > 0) {
                        angular.forEach(weekTemplate.entries, function (entry) {
                            if (!entry.isDeleted) {
                                    entry.errors = {
                                    weekday: !entry.weekday,
                                    timeRange: entry.startTime >= entry.endTime,
                                    startTime: (!angular.isNumber(entry.startTime) || entry.startTime < 0 || entry.startTime > 2400),
                                    endTime: (!angular.isNumber(entry.endTime) || entry.endTime < 0 || entry.endTime > 2400),
                                    conflict: checkEntryConflict(entry, weekTemplate.entries)
                                }

                                entry.hasErrors = entry.errors.weekday || entry.errors.timeRange || entry.errors.startTime || entry.errors.endTime || entry.errors.conflict;
                            } else {
                                entry.errors = null;
                                entry.hasErrors = false;
                            }
                            
                        });
                    }
                };

                var checkEntryConflict = function (entry, entries) {
                    var otherEntry, isConflict = false;

                    if (angular.isArray(entries) && entries.length > 0 ) {
                        for (var i = 0; i < entries.length; i++) {
                            otherEntry = entries[i];

                            if (entry && otherEntry && !entry.isDeleted && !otherEntry.isDeleted && otherEntry !== entry &&
                                otherEntry.weekday && entry.weekday && otherEntry.weekday === entry.weekday && // same date
                                entry.startTime <= otherEntry.endTime && entry.endTime >= otherEntry.startTime) {
                                isConflict = true;
                                break;
                            }
                        }
                    }

                    return isConflict;
                };

                var handleTemplateEntryWeekdayChanged = function (weekTemplate, entry) {
                    verifyWeekTemplateErrors(weekTemplate);
                };

                var toggleTemplateEntryAllDay = function (weekTemplate, entry) {
                    var isAllDay = true;

                    if (entry) {
                        if (entry.isAllDay) {
                            entry.startTime = 0;
                            entry.endTime = 2400;
                        } else {
                            entry.startTime = $ctrl.configData.consoleSettings.calendarStart;
                            entry.endTime = $ctrl.configData.consoleSettings.calendarEnd;
                        }
                    }

                    for (var i = 0; i < weekTemplate.entries.length; i++) {
                        if (!weekTemplate.entries[i].isAllDay) {
                            isAllDay = false;
                            break;
                        }
                    }

                    weekTemplate.isAllDay = isAllDay;

                    verifyWeekTemplateErrors(weekTemplate);
                };

                var toggleWeekTemplateAllDay = function (weekTemplate) {
                    angular.forEach(weekTemplate.entries, function (entry) {
                        if (entry.isAllDay !== weekTemplate.isAllDay) {
                            if (weekTemplate.isAllDay) {
                                entry.startTime = 0;
                                entry.endTime = 2400;
                            } else {
                                entry.startTime = $ctrl.configData.consoleSettings.calendarStart;
                                entry.endTime = $ctrl.configData.consoleSettings.calendarEnd;
                            }
                        }

                        entry.isAllDay = weekTemplate.isAllDay;
                    });

                    verifyWeekTemplateErrors(weekTemplate);
                };

                var getSchedule = function () {
                    return doGetSchedule({recordId: $ctrl.scheduleId})
                        .then(function (result) {
                            if (result.success) {
                                //$ctrl.scheduleData = result.data;
                                $ctrl.scheduleData = model.ScheduleModel.fromServer(result.data)

                                return $ctrl.scheduleData;
                            } else{
                                return $q.reject(result);
                            }
                        })
                        .catch(function (exception) {
                            console.error(exception);
                            if (exception && exception.errorMessage) {
                                util.toastError(exception.errorMessage);
                            }
                        })
                };

                var identifyWeekday = function (weekdayVal) {
                    var weekday = null;

                    if (weekdayVal) {
                        weekday = WEEK_DAYS[weekdayVal.toUpperCase()];
                    }

                    return weekday;
                };

                var populateScheduleData = function (scheduleData) {
                    var scheduleTemplate; 

                    if (scheduleData && scheduleData.template) {
                        scheduleTemplate = scheduleData.template;
                        $ctrl.schedule = {
                            id: scheduleTemplate.id,
                            description: scheduleData.description,
                            startDate: dateUtil.parseDateString(scheduleTemplate.startDate),
                            endDate: dateUtil.parseDateString(scheduleTemplate.endDate),
                            timezoneSidId: scheduleTemplate.timezoneSidId,
                            skipHolidays: !!scheduleData.skipHolidays,
                            weekTemplates: []
                        };

                        if (angular.isArray(scheduleTemplate.entries)) {
                            angular.forEach(scheduleTemplate.entries, function (entry) {
                                var weekTemplate, templateEntry;

                                if (angular.isNumber(entry.weekNo) && entry.weekNo > 0) {
                                    weekTemplate = $ctrl.schedule.weekTemplates[entry.weekNo - 1];
                                    templateEntry = {
                                        id: entry.id,
                                        weekday: identifyWeekday(entry.weekday),
                                        startTime: entry.startTime,
                                        endTime: entry.endTime,
                                        isAllDay: false//(entry.startTime === 0 && entry.endTime === 2400)

                                    };

                                    if (!weekTemplate) {
                                        weekTemplate = $ctrl.schedule.weekTemplates[entry.weekNo - 1] = {
                                            isAllDay: false,
                                            entries: []
                                        };
                                    }

                                    weekTemplate.entries.push(templateEntry);
                                    storeEntryToCache(templateEntry);
                                }
                            });
                        }

                        angular.forEach($ctrl.schedule.weekTemplates, function (weekTemplate) {
                            toggleTemplateEntryAllDay(weekTemplate)
                        })
                    }
                };
                
                /**
                 * controller init
                 * used for setting initial value
                 */
                $ctrl.$onInit = function () {
                    $ctrl.isModalOpen = true;


                    $ctrl.entryTimepickerOptions = {
                        step: $ctrl.configData.consoleSettings.timePickerStep || 30,
                        events: {
                            hideTimepicker: function (event) {
                                var timePickerInput, inputScope;

                                if (event && event.target) {
                                    timePickerInput = angular.element(event.target);

                                    if (timePickerInput) {
                                        inputScope = timePickerInput.scope();

                                        if (inputScope && inputScope.weekTemplate) {
                                            inputScope.$apply(function () {
                                                verifyWeekTemplateErrors(inputScope.weekTemplate);
                                            });
                                        }
                                    }
                                }
                            }
                        }
                    };
                    showLoading();
                    getSchedule()
                        .then(populateScheduleData)
                        .then(function () {
                            $ctrl.templateDateOptions.minDate = angular.copy($ctrl.schedule.startDate);
                            $ctrl.templateDateOptions.maxDate = angular.copy($ctrl.schedule.endDate);
                        })
                        .finally(hideLoading);
                };

                /**
                 * init block
                 * used for setting up controller
                 */
                (function () {
                    $scope.WEEK_DAYS = WEEK_DAYS;
                    $scope.MANAGE_SCHEDULE_OPTIONS = MANAGE_SCHEDULE_OPTIONS;
                    
                    $ctrl.isModalOpen = false;
                    $ctrl.contentLoading = false;
                    $ctrl.closeModal = closeModal;

                    $ctrl.saveSchedule = saveSchedule;
                    $ctrl.getArray = getArray;

                    $ctrl.scheduleData = null;
                    $ctrl.schedule = {
                        id: null,
                        startDate: null,
                        endDate: null,
                        skipHolidays: false,
                        weekTemplates: null
                    };

                    $ctrl.addWeekTemplate = addWeekTemplate;
                    $ctrl.removeWeekTemplate = removeWeekTemplate;
                    $ctrl.addWeekTemplateEntry = addWeekTemplateEntry;
                    $ctrl.removeWeekTemplateEntry = removeWeekTemplateEntry;
                    $ctrl.restoreWeekTemplateEntry = restoreWeekTemplateEntry;
                    $ctrl.copyWeekTemplate = copyWeekTemplate;
                    $ctrl.handleTemplateEntryWeekdayChanged = handleTemplateEntryWeekdayChanged;

                    $ctrl.entryTimepickerOptions = entryTimepickerOptions;
                    $ctrl.templateDateOptions = templateDateOptions;
                    $ctrl.toggleTemplateEntryAllDay = toggleTemplateEntryAllDay;
                    $ctrl.toggleWeekTemplateAllDay = toggleWeekTemplateAllDay;

                    $ctrl.manageScheduleOption = MANAGE_SCHEDULE_OPTIONS.ENTIRE_SCHEDULE;

                    $scope.$watchGroup([
                        '$ctrl.schedule.startDate', 
                        '$ctrl.schedule.endDate'
                        ], function () {
                        var startDate = $ctrl.schedule.startDate, 
                            endDate = $ctrl.schedule.endDate;
                        var rangeValidity = false;
                        var form = $ctrl.scheduleDetailsForm;

                        if (form) {
                            if (angular.isDate(startDate) && angular.isDate(endDate)) {
                                rangeValidity = endDate > startDate;
                            }

                            if (form.startDate) {
                                form.startDate.$setValidity('timeRange', rangeValidity);
                            }

                            if (form.endDate) {
                                form.endDate.$setValidity('timeRange', rangeValidity);
                            }
                        }
                    });
                })();
            }
        ]
    });
})(angular, top);