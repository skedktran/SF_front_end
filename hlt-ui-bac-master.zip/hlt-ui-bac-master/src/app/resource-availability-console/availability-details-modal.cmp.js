(function (angular, topWindow) {
	angular.module('hltApp')
	.component('availabilityDetails', {
		templateUrl: 'src/app/resource-availability-console/availability-details-modal.tpl.html',
		bindings: {
			configData: '<',
			isAvailable: '<',
			resource: '<',
			availability: '<',
			onClose: '&',
			timezone: '<'
		},
		controller: [
			'$scope',
			'$timeout',
			'$window',
			'$location',
			'$q',
			'$filter',
			'api',
			'util',
			'dateUtil',
			'model',
			'constants',
			function ($scope, $timeout, $window, $location, $q, $filter, api, util, dateUtil, model, constants) {
				var $ctrl = this;
				
				var PAGE_MODE = {
					CREATE: 'CREATE',
					EDIT: 'EDIT'
				};
				var RECURRING_PATTERN = {
					WEEKLY: {
						value: 1,
						label: 'Weekly'
					},
					FORTNIGHTLY: {
						value: 2,
						label: 'Every 2 Weeks'
					}
				};
				var SCHEDULE_MODE = {
					SINGLE: 0,
					REPEAT: 1,
					SCHEDULE: 2
				}
				var INTEGER_PATTERN = /^(\-)?([0-9]*)$/;
				
				var WEEK_DAYS = {
					SUN: {
						label: 'Sun',
						fullLabel: 'Sunday',
						value: 'sun'
					},
					MON: {
						label: 'Mon',
						fullLabel: 'Monday',
						value: 'mon'
					},
					TUE: {
						label: 'Tue',
						fullLabel: 'Tuesday',
						value: 'tue'
					},
					WED: {
						label: 'Wed',
						fullLabel: 'Wednesday',
						value: 'wed'
					},
					THU: {
						label: 'Thu',
						fullLabel: 'Thursday',
						value: 'thu'
					},
					FRI: {
						label: 'Fri',
						fullLabel: 'Friday',
						value: 'fri'
					},
					SAT: {
						label: 'Sat',
						fullLabel: 'Saturday',
						value: 'sat'
					},
				};
				var EDIT_RECURRING_ACTION = {
					ONLY_ME: {
						value: 'only_me',
						getLabel: function () {
							return 'Only this ' + (($ctrl.isAvailable)?'Availability':'Unavailability')
						}
					},
					SAME_WEEKDAY: {
						value: 'same_weekday',
						getLabel: function () {
							return 'Same Weekday (' + originWeekday + ')'
						}
					},
					FOLLOWING_EVENTS: {
						value: 'following_events',
						label: 'Following Events'
					},
					ALL_EVENTS: {
						value: 'all_events',
						label: 'All Events'
					}
				};
				var UNCREATABLE_AVAILABILITY = [
					//constants.AVAILABILITY_TYPE.OTHER,
					//constants.AVAILABILITY_TYPE.PTO
				];

				var originWeekday = null;
				var nameFilter = $filter('filter');
				var dateFilter = $filter('date');
				var getArray = function (len) {
					len = len || 0;
					return new Array(len);
				};

				/**
				 * common remote action error handler
				 */
				var commonExceptionHanlder = function (exception) {
					console.error(exception);
					util.toastError('Can not perform action due to server error.');

					return $q.reject();
				};

				/**
				 * show content loading
				 */
				var showLoading = function () {
					$ctrl.contentLoading = true;
				};

				/**
				 * hide content loading
				 */
				var hideLoading = function () {
					$ctrl.contentLoading = false;
				};

				/**
				 * close main modal
				 */
				var closeModal = function (message) {
					$ctrl.isModalOpen = false;
					// run onClose expression
					if (angular.isFunction ($ctrl.onClose)) {
						$ctrl.onClose({
							message: message
						});
					}
				};

				var doSaveAvailability = function (availabilityParams, isConfirmed) {
					return api.saveAvailability(availabilityParams)
						.catch(commonExceptionHanlder);
				};

				var doSearchSchedules = function (searchParams) {
					return api.searchSchedules(searchParams)
						.catch(commonExceptionHanlder);
				};

				var searchSchedules = function (searchString) {
					return doSearchSchedules({
							resourceId: $ctrl.resource.id,
							textSearch: searchString || ''
						}).then(function (result) {
							var resultData;
							var filterCriterion = ($ctrl.isAvailable)?'availability':'unavailability';
							var schedules = [];

							if (result.success) {
								resultData = result.data;
								
								if (angular.isArray(resultData) && resultData.length) {
									resultData = resultData.filter(function (dataItem) {
										return dataItem.objectType === filterCriterion;
									});

									schedules = model.ScheduleModel.fromServerList(resultData);
								}
							} 

							return schedules;
						});
				};


				var showAvailabilityConflictsModal = function (data) {
					var mode = ($ctrl.isAvailable)?'Availability':'Unavailability';

					util.showModal({
						template: '<availability-conflicts-modal class="sked-modal-container" mode="mode" data="data" patient="patient" config-data="configData" on-close="onClose(this, message)"></availability-conflicts-modal>',
					}, {
						mode: mode,
						data: data,
						configData: $ctrl.configData,
						onClose: function (modalScope, message) {
							modalScope.closeModal();

							if (message === 'done') {
								util.toastSuccess(mode + ' has been ' + (($ctrl.pageMode === PAGE_MODE.CREATE)?'created':'updated') + ' successfully.');
								closeModal('done');
							}
						}
					});
				};

				var saveAvailability = function () {
					var availabilityParams;
					var mode = ($ctrl.isAvailable)?'Availability':'Unavailability';

					var savingCallback = function (result) {
						if (result.success) {
							//hasConflict = result.data && result.data.length && _.filter(result.data, {hasConflict: true}).length;
							hasConflict = result.data && result.data.hasConflict;

							if (hasConflict) {
								showAvailabilityConflictsModal(result.data);
							} else {
								util.toastSuccess(mode + ' has been ' + (($ctrl.pageMode === PAGE_MODE.CREATE)?'created':'updated') + ' successfully.');

								$ctrl.availability.id = result.data;
								closeModal('done');
							}
						} else{
							return $q.reject(result);
						}
					};

					if (validateAvailability()) {
						availabilityParams = buildAvailabilitySavingParams();

						showLoading();
						doSaveAvailability(availabilityParams, false)
							.then(savingCallback)
							.catch(function (exception) {
								console.error(exception);
								if (exception && exception.errorMessage) {
									util.toastError(exception.errorMessage);
								}
							})
							.finally(function () {
								hideLoading();
							});
					}
				};

				var validateAvailability = function () {
					var form = $ctrl.availabilityDetailsForm;
					var checkingTemplate, checkingEntry;
 
					form.$setSubmitted(true);

					if ((!form.$valid && form.$error.required) /*|| 
						(($ctrl.pageMode === PAGE_MODE.CREATE &&  ($ctrl.schedule.mode === SCHEDULE_MODE.REPEAT || $ctrl.schedule.mode === SCHEDULE_MODE.SCHEDULE)) && 
							($ctrl.schedule && !$ctrl.schedule.reference && !$ctrl.schedule.description))*/) {
						util.toastError('Please check all required fields.');
						return false;
					} else if (!form.$valid && (form.$error.pattern || form.$error.number || form.$error.skedTimeValidator)) {
						util.toastError('Invalid data format, please check date/time and number fields.');
						return false;
					} else if (!form.$valid && form.$error.timeRange) {
						util.toastError('Availability start date/time should before end date/time.');
						return false;
					} else if (!$ctrl.schedule.reference) {
						// if (form.$error.oncallRecurring && form.$error.oncallRecurring.length > 0) {
						// 	util.toastError('An On-call availability recurrence is only allowed for 6 months.');
						// 	return false;
						// }

						if ($ctrl.schedule.mode === SCHEDULE_MODE.REPEAT) {
							/*if (!form.$valid && (form.$error.min)) {
								util.toastError('Number of repeating weeks should be greater than or equal to ' + $ctrl.schedule.pattern.value + '.');
								return false;
							}*/

							for (var i = 0; i < $ctrl.schedule.weekdays.length; i++) {
								if ($ctrl.schedule.weekdays[i].length === 0) {
									util.toastError('Please select recurring weekdays.');
									return false;
								}
							}
						} else if ($ctrl.schedule.mode === SCHEDULE_MODE.SCHEDULE) {
							if (!angular.isArray($ctrl.schedule.weekTemplates) || $ctrl.schedule.weekTemplates.length === 0) {
								util.toastError('Please setup atleast one week template.');
								return false;
							} else {
								for (var j = 0; j < $ctrl.schedule.weekTemplates.length; j++) {
									checkingTemplate = $ctrl.schedule.weekTemplates[j];
									if (checkingTemplate.entries.length === 0) {
										util.toastError('Week template requires atleast a date entry.');
										return false;
									} else {
										for (var k = 0; k < checkingTemplate.entries.length; k++) {
											checkingEntry = checkingTemplate.entries[k]
											if (!!checkingEntry.hasErrors) {
												util.toastError('Please check template errors before saving.');
												return false;
											}
										}
									}
								}
							}
						}
					} else if (!!$ctrl.schedule.reference && !form.$valid && form.$error.recurringExtendedRange) {
						util.toastError('The schedule is only be extended, start date should be before current start date and end date should be after current end date.');
						return false;
					}

					return true;
				};

				var buildAvailabilitySavingParams = function () {
					var availabilityParams = $ctrl.availability.toServer();
					var recurringOptions = null;
					// var onCallTeamMembers = null;
					var strStartDate = dateUtil.dateToString($ctrl.schedule.startDate),
						strEndDate = dateUtil.dateToString($ctrl.schedule.endDate);

					// availability date/time
					availabilityParams.startDate = strStartDate;
					availabilityParams.endDate = strEndDate;
					availabilityParams.startTime = $ctrl.schedule.startTime;
					availabilityParams.endTime = $ctrl.schedule.endTime;
					availabilityParams.isAllDay = !!$ctrl.availability.isAllDay; //$ctrl.schedule.isAllDay;
						
					// resource
					availabilityParams.resourceId = $ctrl.resource.id;

					// timezone
					availabilityParams.timezoneSidId = $ctrl.timezone.id;

					// recurring options
					if ($ctrl.pageMode === PAGE_MODE.CREATE) {
						if ($ctrl.schedule.mode === SCHEDULE_MODE.SINGLE) {
							recurringOptions = null;
						} else if ($ctrl.schedule.mode === SCHEDULE_MODE.REPEAT) {
							recurringOptions = {
								//description: $ctrl.schedule.description,
								skipHolidays: $ctrl.schedule.skipHolidays,
								availabilityTemplate: {
									startDate: strStartDate,
									endDate: strEndDate,
									availabilityTemplateEntries: []
								}
							};

							// produce template entries
							angular.forEach($ctrl.schedule.weekdays, function (weekdays, weekInd) {
								angular.forEach(weekdays, function (wd) {
									recurringOptions.availabilityTemplate.availabilityTemplateEntries.push({
										weekNo: weekInd + 1,
										weekday: wd.value,
										startTime: $ctrl.schedule.startTime,
										//endTime: ($ctrl.schedule.isAllDay)?2400:$ctrl.schedule.endTime,
										//isAllDay: $ctrl.schedule.isAllDay
										endTime: $ctrl.schedule.endTime
									});
								});
							});

							// selected schedule or description
							if ($ctrl.schedule.reference) {
								recurringOptions.scheduleId = $ctrl.schedule.reference.id;
							} else {
								recurringOptions.description = $ctrl.schedule.description;
							}
						} else if ($ctrl.schedule.mode === SCHEDULE_MODE.SCHEDULE) {
							recurringOptions = {
								//description: $ctrl.schedule.description,
								skipHolidays: $ctrl.schedule.skipHolidays,
								availabilityTemplate: {
									startDate: strStartDate,
									endDate: strEndDate,
									availabilityTemplateEntries: []
								}
							};

							// produce template entries
							angular.forEach($ctrl.schedule.weekTemplates, function (weekTemplate, weekInd) {
								angular.forEach(weekTemplate.entries, function (templateEntry) {
									recurringOptions.availabilityTemplate.availabilityTemplateEntries.push({
										weekNo: weekInd + 1,
										weekday: templateEntry.weekday.value,
										startTime: templateEntry.startTime,
										endTime: templateEntry.endTime,
										//isAllDay: templateEntry.isAllDay
									});
								});
							});

							// selected schedule or description
							if ($ctrl.schedule.reference) {
								recurringOptions.scheduleId = $ctrl.schedule.reference.id;
							} else {
								recurringOptions.description = $ctrl.schedule.description;
							}
						}
					} else if ($ctrl.pageMode === PAGE_MODE.EDIT) {
						recurringOptions = ($ctrl.editRecurringAction && $ctrl.editRecurringAction !== EDIT_RECURRING_ACTION.ONLY_ME)?{
							editAction: $ctrl.editRecurringAction.value
						}:null;
					}

					// build on-call team members
					// if ($ctrl.availability.eventType.id === constants.AVAILABILITY_TYPE.ON_CALL && 
					// 	angular.isArray($ctrl.availability.members)) {
					// 	onCallTeamMembers = $ctrl.availability.members.map(function (member) {
					// 		return {
					// 			id: member.id,
					// 			name: member.name,
					// 			priority: member.priority || 1,
					// 			action: identifyOncallTeamMemberAction(member)
					// 		}
					// 	});

					// 	if (angular.isArray($ctrl.availability.originMembers)) {
					// 		angular.forEach($ctrl.availability.originMembers, function (originMember) {
					// 			var originMemberFound = onCallTeamMembers.find(function (member) {
					// 				return member.id === originMember.id;
					// 			})

					// 			if (!originMemberFound) {
					// 				onCallTeamMembers.push({
					// 					id: originMember.id,
					// 					name: originMember.name,
					// 					action: 'delete'
					// 				});
					// 			}
					// 		});
					// 	}
					// }

					return {
						event: availabilityParams,
						recurringOptions: recurringOptions,
						// onCallTeamMembers: onCallTeamMembers
					};
				};

				// var identifyOncallTeamMemberAction = function (member) {
				// 	var action = null, memberFound;
				// 	if (angular.isArray($ctrl.availability.originMembers)) {
				// 		memberFound = $ctrl.availability.originMembers.find(function (originMember) {
				// 			return originMember.id === member.id;
				// 		});

				// 		if (!memberFound) {
				// 			action = 'create';
				// 		}
				// 	}

				// 	return action;
				// };

				var toggleFullday = function (isAllDay) {
					if (isAllDay) {
						$ctrl.schedule.startTime = 0;
						$ctrl.schedule.endTime = 0;

						if ($ctrl.schedule.endDate.getTime() <= $ctrl.schedule.startDate.getTime()) {
							$ctrl.schedule.endDate = angular.copy($ctrl.schedule.startDate);
							$ctrl.schedule.endDate.setDate($ctrl.schedule.startDate.getDate() + 1);
						}
					} 
				};

				var toggleScheduleMode = function () {
				};

				var selectWeekDay = function (weekday, index) {
					var ind;
					if ($ctrl.schedule && $ctrl.schedule.weekdays.length &&
						angular.isArray($ctrl.schedule.weekdays[index])) {
						ind = $ctrl.schedule.weekdays[index].indexOf(weekday);

						if (ind > -1) {
							$ctrl.schedule.weekdays[index].splice(ind, 1);
						} else {
							$ctrl.schedule.weekdays[index].push(weekday);
						}
					}
				};

				var handlePatternChanged = function () {
					if ($ctrl.schedule && $ctrl.schedule.pattern && $ctrl.schedule.pattern.value) {
						if (!angular.isArray($ctrl.schedule.weekdays)) {
							$ctrl.schedule.weekdays = new Array();
						}

						if ($ctrl.schedule.weekdays.length > $ctrl.schedule.pattern.value) {
							$ctrl.schedule.weekdays.splice($ctrl.schedule.pattern.value);
						} else {
							for (var i = $ctrl.schedule.weekdays.length; i < $ctrl.schedule.pattern.value; i++) {
								$ctrl.schedule.weekdays.push([]);
							}
						}

						if ($ctrl.schedule.pattern.value > $ctrl.schedule.recurFor || !$ctrl.schedule.recurFor) {
							$ctrl.schedule.recurFor = $ctrl.schedule.pattern.value;
						}
					}
				}

				var identifyWeekday = function (weekdayVal) {
					var weekday = null;

					if (weekdayVal) {
						weekday = WEEK_DAYS[weekdayVal.toUpperCase()];
					}

					return weekday;
				};

				var applyScheduleDetails = function () {
					var dateDiff;

					$ctrl.schedule.startDate = angular.copy($ctrl.availability.startDate);
					$ctrl.schedule.endDate = angular.copy($ctrl.availability.endDate);
					$ctrl.schedule.startTime = $ctrl.availability.startTime;
					$ctrl.schedule.endTime = $ctrl.availability.endTime;
					$ctrl.schedule.isAllDay = !!$ctrl.availability.isAllDay;

					if ($ctrl.schedule.endTime >= 2400) {
						dateDiff = Math.floor($ctrl.schedule.endTime / 2400);
						$ctrl.schedule.endTime = $ctrl.schedule.endTime % 2400;
						$ctrl.schedule.endDate.setDate($ctrl.schedule.endDate.getDate() + dateDiff);
					}
				};

				var addWeekTemplate = function () {
					var weekTemplates = $ctrl.schedule.weekTemplates;

					if (!angular.isArray(weekTemplates)) {
						weekTemplates = $ctrl.schedule.weekTemplates = [];
					}

					weekTemplates.push({
						isAllDay: false,
						entries: []
					});
				};

				var copyWeekTemplate = function (index) {
					var weekTemplates = $ctrl.schedule.weekTemplates,
						weekTemplate, clonedWeekTemplate;

					if (angular.isArray(weekTemplates) && weekTemplates.length > index) {
						weekTemplate = weekTemplates[index];

						clonedWeekTemplate = angular.copy(weekTemplate);
						clonedWeekTemplate.entries.map(function (entry) {
							if (entry.weekday) {
								entry.weekday = identifyWeekday(entry.weekday.value)
							}
						});

						weekTemplates.splice(index + 1, 0, clonedWeekTemplate);
					}
				};

				var removeWeekTemplate = function (index) {
					var weekTemplates = $ctrl.schedule.weekTemplates;

					if (angular.isArray(weekTemplates) && weekTemplates.length > index) {
						weekTemplates.splice(index, 1);
					}
				};

				var addWeekTemplateEntry = function (weekTemplate) {
					var entries;

					if (weekTemplate) {
						entries = weekTemplate.entries;

						if (!angular.isArray(entries)) {
							entries = weekTemplate.entries = [];
						}

						entries.push({
							weekday: null,
							startTime: $ctrl.availability.startTime,
							endTime: ($ctrl.availability.endTime === 2400 || $ctrl.availability.endTime === 0)?2330:$ctrl.availability.endTime,
							isAllDay: weekTemplate.isAllDay
						});

						verifyWeekTemplateErrors(weekTemplate);
					}
				};

				var removeWeekTemplateEntry = function (weekTemplate, index) {
					var entries;

					if (weekTemplate) {
						entries = weekTemplate.entries;

						if (angular.isArray(entries) && entries.length > index) {
							entries.splice(index, 1);

							verifyWeekTemplateErrors(weekTemplate);
						}
					}
				};

				var verifyWeekTemplateErrors = function (weekTemplate) {
					if (weekTemplate && angular.isArray(weekTemplate.entries) && weekTemplate.entries.length > 0) {
						angular.forEach(weekTemplate.entries, function (entry) {
							
							entry.errors = {
								weekday: !entry.weekday,
								timeRange: entry.startTime >= entry.endTime,
								startTime: (!angular.isNumber(entry.startTime) || entry.startTime < 0 || entry.startTime > 2400),
								endTime: (!angular.isNumber(entry.endTime) || entry.endTime < 0 || entry.endTime > 2400),
								conflict: checkEntryConflict(entry, weekTemplate.entries)
							}

							entry.hasErrors = entry.errors.weekday || entry.errors.timeRange || entry.errors.startTime || entry.errors.endTime || entry.errors.conflict;
						});
					}
				};

				var checkEntryConflict = function (entry, entries) {
					var otherEntry, isConflict = false;

					if (angular.isArray(entries) && entries.length > 0 ) {
						for (var i = 0; i < entries.length; i++) {
							otherEntry = entries[i];

							if (otherEntry !== entry &&
								otherEntry.weekday && entry.weekday && otherEntry.weekday === entry.weekday && // same date
								entry.startTime <= otherEntry.endTime && entry.endTime >= otherEntry.startTime) {
								isConflict = true;
								break;
							}
						}
					}

					return isConflict;
				};

				var handleTemplateEntryWeekdayChanged = function (weekTemplate, entry) {
					verifyWeekTemplateErrors(weekTemplate);
				};

				var toggleTemplateEntryAllDay = function (weekTemplate, entry) {
					var isAllDay = true;

					if (entry.isAllDay) {
						entry.startTime = 0;
						entry.endTime = 2400;
					} else {
						entry.startTime = $ctrl.availability.startTime;
						entry.endTime = $ctrl.availability.endTime;
					}

					for (var i = 0; i < weekTemplate.entries.length; i++) {
						if (!weekTemplate.entries[i].isAllDay) {
							isAllDay = false;
							break;
						}
					}

					weekTemplate.isAllDay = isAllDay;

					verifyWeekTemplateErrors(weekTemplate);
				};

				var toggleWeekTemplateAllDay = function (weekTemplate) {
					angular.forEach(weekTemplate.entries, function (entry) {
						if (entry.isAllDay !== weekTemplate.isAllDay) {
							if (weekTemplate.isAllDay) {
								entry.startTime = 0;
								entry.endTime = 0;
							} else {
								entry.startTime = $ctrl.availability.startTime;
								entry.endTime = $ctrl.availability.endTime;
							}
						}

						entry.isAllDay = weekTemplate.isAllDay;
					});

					verifyWeekTemplateErrors(weekTemplate);
				};
				
				// var addMoreOncallMembers = function () {
				// 	util.showModal({
				// 		template: '<resource-allocation-modal class="sked-modal-container" resource="resource" availability="availability" config-data="configData" on-close="onClose(this, message)"></resource-allocation-modal>',
				// 	}, {
				// 		resource: $ctrl.resource,
				// 		availability: $ctrl.availability,
				// 		configData: $ctrl.configData,
				// 		onClose: function (modalScope, message) {
				// 			modalScope.closeModal();

				// 			if (message === 'done') {
				// 			}
				// 		}
				// 	});
				// };

				var buidlMemberRefData = function (memberResource, action) {
					return {
						resourceId: memberResource.id,
						action: action
					};
				};

				// var setupOncallAvailabilityMembers = function () {
				// 	var memberIds;

				// 	if (!angular.isArray($ctrl.availability.members)) {
				// 		$ctrl.availability.members = [];
				// 	}

				// 	memberIds = $ctrl.availability.members.map(function (member) {
				// 		return member.id;
				// 	});

				// 	$ctrl.availability.originMembers = angular.extend([], $ctrl.availability.members);

				// 	if (!$ctrl.availability.id || memberIds.indexOf($ctrl.resource.id) === -1) {
				// 		$ctrl.availability.members.push($ctrl.resource);
				// 	}
				// };

				var filterAvailabilityTypes = function (availabilityType, index) {
					if ($ctrl.pageMode === PAGE_MODE.EDIT && 
						$ctrl.availability && 
						$ctrl.availability.eventType) {
						return $ctrl.availability.eventType.id === availabilityType.id || UNCREATABLE_AVAILABILITY.indexOf(availabilityType.id) === -1;
					} else {
						return UNCREATABLE_AVAILABILITY.indexOf(availabilityType.id) === -1;
					}
				};
				
				/**
				 * controller init
				 * used for setting initial value
				 */
				$ctrl.$onInit = function () {

					$ctrl.entryTimepickerOptions =  {
						step: $ctrl.configData.consoleSettings.timePickerStep || 30,
						events: {
							hideTimepicker: function (event) {
								var timePickerInput, inputScope;

								if (event && event.target) {
									timePickerInput = angular.element(event.target);

									if (timePickerInput) {
										inputScope = timePickerInput.scope();

										if (inputScope && inputScope.weekTemplate) {
											inputScope.$apply(function () {
												verifyWeekTemplateErrors(inputScope.weekTemplate);
											});
										}
									}
								}
							}
						}
					};
					$ctrl.timePickerOptions = {
						step: $ctrl.configData.consoleSettings.timePickerStep || 30
					};
					$ctrl.isModalOpen = true;
					var WEEK_DAYS_ORDER = [
							WEEK_DAYS.MON,
							WEEK_DAYS.TUE,
							WEEK_DAYS.WED,
							WEEK_DAYS.THU,
							WEEK_DAYS.FRI,
							WEEK_DAYS.SAT
					];
			
					if ($ctrl.configData.consoleSettings.firstDay) {
							WEEK_DAYS_ORDER.push(WEEK_DAYS.SUN);
					} else {
							WEEK_DAYS_ORDER.unshift(WEEK_DAYS.SUN);
					}
					$ctrl.WEEK_DAYS_ORDER = WEEK_DAYS_ORDER;

					if ($ctrl.availability.id) {
						$ctrl.pageMode = PAGE_MODE.EDIT;
						$ctrl.editRecurringAction = EDIT_RECURRING_ACTION.ONLY_ME;

						originWeekday = dateFilter($ctrl.availability.startDate, 'EEEE');
					}

					applyScheduleDetails();
					handlePatternChanged();

					// setup member ref
					// setupOncallAvailabilityMembers();
				};

				/**
				 * init block
				 * used for setting up controller
				 */
				(function () {
					$scope.SCHEDULE_MODE = SCHEDULE_MODE;
					$scope.RECURRING_PATTERN = RECURRING_PATTERN;
					$scope.INTEGER_PATTERN = INTEGER_PATTERN;
					$scope.WEEK_DAYS = WEEK_DAYS;
					$scope.PAGE_MODE = PAGE_MODE;
					$scope.EDIT_RECURRING_ACTION = EDIT_RECURRING_ACTION;

					$scope.AVAILABILITY_TYPE = constants.AVAILABILITY_TYPE;

					$ctrl.isModalOpen = false;
					$ctrl.contentLoading = false;

					$ctrl.closeModal = closeModal;
					$ctrl.pageMode = PAGE_MODE.CREATE;

					$ctrl.toggleFullday = toggleFullday;
					$ctrl.toggleScheduleMode = toggleScheduleMode;
					$ctrl.selectWeekDay = selectWeekDay;

					$ctrl.saveAvailability = saveAvailability;
					$ctrl.getArray = getArray;
					$ctrl.handlePatternChanged = handlePatternChanged;

					$ctrl.schedule = {
						mode: SCHEDULE_MODE.SINGLE,
						startDate: null,
						startTime: 0,
						endDate: null,
						endTime: 0,
						pattern: RECURRING_PATTERN.WEEKLY,
						weekdays: null,
						recurFor: 1,
						isAllDay: false,
						skipHolidays: false,
						weekTemplates: null,
						editAction: null,
						reference: null
					};
					$ctrl.editRecurringAction = null;

					$ctrl.addWeekTemplate = addWeekTemplate;
					$ctrl.removeWeekTemplate = removeWeekTemplate;
					$ctrl.addWeekTemplateEntry = addWeekTemplateEntry;
					$ctrl.copyWeekTemplate = copyWeekTemplate;
					$ctrl.removeWeekTemplateEntry = removeWeekTemplateEntry;
					$ctrl.handleTemplateEntryWeekdayChanged = handleTemplateEntryWeekdayChanged;

					$ctrl.toggleTemplateEntryAllDay = toggleTemplateEntryAllDay;
					$ctrl.toggleWeekTemplateAllDay = toggleWeekTemplateAllDay;

					$ctrl.searchSchedules = searchSchedules;

					// $ctrl.addMoreOncallMembers = addMoreOncallMembers;
					$ctrl.filterAvailabilityTypes = filterAvailabilityTypes;

					$scope.$watch('$ctrl.schedule.reference', function (newVal) {
						if (!!newVal) {
							$ctrl.schedule.mode = SCHEDULE_MODE.REPEAT;

							if ($ctrl.schedule.reference.template) {
								$ctrl.schedule.startDate = angular.copy($ctrl.schedule.reference.template.startDate);
								$ctrl.schedule.endDate = angular.copy($ctrl.schedule.reference.template.endDate);
							}
						}
					});

					$scope.$watchGroup([
						'$ctrl.schedule.mode',
						'$ctrl.schedule.startDate', 
						'$ctrl.schedule.startTime',
						'$ctrl.schedule.endDate', 
						'$ctrl.schedule.endTime',
						'$ctrl.schedule.isAllDay',
						'$ctrl.availability.eventType'
						], function () {
						var startDate = $ctrl.schedule.startDate, 
							endDate = $ctrl.schedule.endDate, 
							startTime = $ctrl.schedule.startTime, 
							endTime = $ctrl.schedule.endTime;
						var startDateTime, startDateTime;
						var timeRangeValidity = false,
							dateRangeValidity = false,
							recurringtExtendedValidity = false;
							// oncallRecurringValidity = false;
						var form = $ctrl.availabilityDetailsForm;
						var template;
						var nextSixMonths;

						if (form) {
							if (angular.isDate(startDate) && angular.isDate(endDate) &&
								angular.isNumber(startTime) && startTime >= 0 && startTime <= 2400 &&
								angular.isNumber(endTime) && endTime >= 0 && endTime <= 2400) {
								
								if ($ctrl.schedule.mode === SCHEDULE_MODE.SINGLE) {
									startDateTime = dateUtil.parseDateTime(startDate, startTime);
									endDateTime = dateUtil.parseDateTime(endDate, endTime);

									timeRangeValidity = dateRangeValidity = endDateTime > startDateTime;
									recurringtExtendedValidity = true;
									// oncallRecurringValidity = true;
								} else {
									timeRangeValidity = ($ctrl.schedule.mode === SCHEDULE_MODE.SCHEDULE) || endTime > startTime || $ctrl.schedule.isAllDay;
									dateRangeValidity = endDate.getTime() > startDate.getTime();

									if ($ctrl.schedule.reference && $ctrl.schedule.reference.template) {
										template = $ctrl.schedule.reference.template;
										recurringtExtendedValidity = (startDate.getTime() <= template.startDate.getTime() && endDate.getTime() >= template.endDate.getTime());
									} else {
										recurringtExtendedValidity = true;
									}

									// if ($ctrl.availability.eventType && $ctrl.availability.eventType.id === constants.AVAILABILITY_TYPE.ON_CALL) {
									// 	nextSixMonths = angular.copy(startDate);
									// 	nextSixMonths.setMonth(nextSixMonths.getMonth() + 6);
									// 	oncallRecurringValidity = endDate.getTime() <= nextSixMonths.getTime();
									// } else {
									// 	oncallRecurringValidity = true;
									// }
								}                                
							}

							if (form.startDate) {
								form.startDate.$setValidity('timeRange', dateRangeValidity);
								form.startDate.$setValidity('recurringExtendedRange', recurringtExtendedValidity);
								// form.startDate.$setValidity('oncallRecurring', oncallRecurringValidity);
							}
							if (form.startTime) {
								form.startTime.$setValidity('timeRange', timeRangeValidity);
							}
							if (form.endDate) {
								form.endDate.$setValidity('timeRange', dateRangeValidity);
								form.endDate.$setValidity('recurringExtendedRange', recurringtExtendedValidity);
								// form.endDate.$setValidity('oncallRecurring', oncallRecurringValidity);
							}
							if (form.endTime) {
								form.endTime.$setValidity('timeRange', timeRangeValidity);
							}
						}

					});
				})();
			}
		]
	});
})(angular, top);