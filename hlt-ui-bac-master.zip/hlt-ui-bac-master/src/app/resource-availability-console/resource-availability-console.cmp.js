(function (angular, $) {
  angular.module('hltApp')
    .component('resourceAvailabilityConsole', {
      templateUrl: 'src/app/resource-availability-console/resource-availability-console.tpl.html',
      bindings: {},
      controller: [
        '$timeout',
        '$window',
        '$location',
        '$q',
        '$scope',
        '$filter',
        'util',
        'dateUtil',
        'api',
        'model',
        'ggLocationApi',
        'constants',
        function ($timeout, $window, $location, $q, $scope, $filter, util, dateUtil, api, model, ggLocationApi, constants) {
          var $ctrl = this;
          var contentPanelEl;
          var filterFn = $filter('filter');
          var searchParams = $location.search();
          var currentParams = {};

          var RAC_REQUIRED_CONFIG_DATA = [
            'activityTypes',
            'availabilityTypes',
            'holidays',
            'jobTypes',
            'regions',
            'serviceLocations',
            'timezones',
            'resourceEmploymentTypes',
            'resourceCategories',
            'availabilityStatuses',
            'availabilityDeclineReasons'
          ];
          var DEFAULT_PHOTO_URL = $filter('skedSfUrl')('slds/images/avatar3.jpg');
          var CONSOLE_VIEW_MODE = {
            ALL_RESOURCES: {
              templateUrl: 'src/app/resource-availability-console/rac-all-resources.tpl.html',
            },
            INDIVIDUAL_RESOURCE: {
              templateUrl: 'src/app/resource-availability-console/rac-individual-resource.tpl.html'
            }
          };
          var RAC_TYPE = {
            RESOURCES: 'RESOURCES',
            AVAILABILITY_REQUEST: 'AVAILABILITY_REQUEST'
          };
          var EVENTS_LIMIT = 3;
          var DEFAULT_EVENT_STATUS = 'DEFAULT_EVENT_STATUS';
          var GRID_SETTINGS = {
            ALL_RESOURCES: {
              headerHeight: 3,
              leftColWidth: 18,
              slotSize: {
                w: 8.5,
                h: 2.5
              },
              allDayBlock: {
                h: 1.125,
                m: 0.125
              },
              shiftBlock: {
                h: 1.3125,
                m: 0.25
              }
            },
            INDIVIDUAL_RESOURCE: {
              leftColWidth: 6.5,
              headerHeight: 3,
              slotSize: {
                w: 11.5,
                h: 2.5
              },
              allDayBlock: {
                h: 1.125,
                m: 0.125
              }
            }
          };
          var OBJECT_TYPE = {
            AVAILABILITY: 'availability',
            ACTIVITY: 'activity',
            JOB: 'job',
            TEMPLATE_ENTRY: 'templateEntry'
          };
          var SHIFT_TYPE = {
            RESOURCE_SHIFT: 'RESOURCE_SHIFT',
            LOCATION_SHIFT: 'LOCATION_SHIFT',
          };
          var EDIT_RECURRING_ACTION = {
            ONLY_ME: {
              value: 'only_me',
              getLabel: function (event) {
                var eventLabel;

                if (event.objectType === OBJECT_TYPE.AVAILABILITY) {
                  eventLabel = (event.eventType && event.eventTypeSettings && event.eventTypeSettings.isAvailable) ? 'Availability' : 'Unavailability';
                } else {
                  eventLabel = event.objectType.charAt(0).toUpperCase() + event.objectType.substring(1);
                }

                return 'Only this ' + eventLabel;
              }
            },
            SAME_WEEKDAY: {
              value: 'same_weekday',
              getLabel: function (event) {
                return 'Same Weekday (' + dateFilter(event.startDate, 'EEEE') + ')';
              }
            },
            FOLLOWING_EVENTS: {
              value: 'following_events',
              label: 'Following Events'
            },
            ALL_EVENTS: {
              value: 'all_events',
              label: 'All Events'
            }
          };

          var WEEK_DAYS = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];

          var dateFilter = $filter('date');

          var focusInput = function (inputSelector) {
            var input = angular.element(inputSelector);

            if (input && input.length > 0) {
              $timeout(function () {
                input[0].focus();
              }, 10);
            }
          };

          var weekPickerOptions = {
            timeoutPromise: null,
            firstDay: 0,
            showOtherMonths: true,
            beforeShow: function (el, inst) {
              if (weekPickerOptions.timeoutPromise) {
                $timeout.cancel(weekPickerOptions.timeoutPromise);
              }

              inst.dpDiv.addClass('week-picker');

              $timeout(function () {
                inst.dpDiv.find('tr:has(td.ui-datepicker-current-day) .ui-state-default').addClass('ui-state-co-active');
              }, 0);
            },
            onChangeMonthYear: function (year, month, inst) {
              //inst.dpDiv.addClass('week-picker');

              $timeout(function () {
                inst.dpDiv.find('tr:has(td.ui-datepicker-current-day) .ui-state-default').addClass('ui-state-co-active');
              }, 0);
            },
            onClose: function (dateText, inst) {
              weekPickerOptions.timeoutPromise = $timeout(function () {
                inst.dpDiv.removeClass('week-picker');
              }, 200);
            }
          };

          var formatWeekPickerDates = function (startDate, endDate) {
            var formatedValue = '';
            var patternReg = /([se])\[([^\]]*)\]/g;
            var patternString;

            var formatDate = function (replacingString, dateIdent, formatPattern) {
              var dateValue;

              switch (dateIdent) {
              case 's':
                dateValue = startDate;
                break;
              case 'e':
                dateValue = endDate;
                break;
              }

              if ($ && $.datepicker && $.datepicker.formatDate && dateValue) {
                return $.datepicker.formatDate(formatPattern, dateValue);
              }

              return '';
            };

            if ($ctrl.configData && $ctrl.configData.consoleSettings &&
              $ctrl.configData.consoleSettings.weekPickerFormat) {
              patternString = $ctrl.configData.consoleSettings.weekPickerFormat;
            } else {
              patternString = 's[M d] - e[M d, yy]';
            }

            formatedValue = patternString
              .replace(patternReg, formatDate);


            return formatedValue;
          };

          var commonExceptionHanlder = function (exception) {
            console.error(exception);
            util.toastError('Can not perform action due to server error.');

            return $q.reject();
          };

          var showLoading = function () {
            util.showLoading();
          };

          var hideLoading = function () {
            util.hideLoading();
          };

          /**
           * move calendar to previous month
           */
          var moveBack = function () {
            if (angular.isDate($ctrl.date) &&
              $ctrl.configData && $ctrl.configData.consoleSettings &&
              angular.isNumber($ctrl.configData.consoleSettings.viewPeriod) && $ctrl.configData.consoleSettings.viewPeriod > 0) {
              $ctrl.date = dateUtil.addDay($ctrl.date, -((7 * $ctrl.configData.consoleSettings.viewPeriod)));
            }

          };

          /**
           * move calendar to next month
           */
          var moveNext = function () {
            if (angular.isDate($ctrl.date) &&
              $ctrl.configData && $ctrl.configData.consoleSettings &&
              angular.isNumber($ctrl.configData.consoleSettings.viewPeriod) && $ctrl.configData.consoleSettings.viewPeriod > 0) {
              $ctrl.date = dateUtil.addDay($ctrl.date, ((7 * $ctrl.configData.consoleSettings.viewPeriod)));
            }
          };

          /**
           * check whether calendar params are really changed
           */
          var isParamsReallyChanged = function (params) {
            return !util.compareValues(params, currentParams);
          };

          var doInitialize = function (requestParams) {
            return api.initialize(requestParams)
              .catch(commonExceptionHanlder);
          };

          var doGetResourceData = function (query) {
            return api.getResourceData(query)
              .catch(commonExceptionHanlder);
          };

          var doGetEventDetails = function (query) {
            return api.getEventDetails(query)
              .catch(commonExceptionHanlder);
          };

          var doGetPatternDetails = function (query) {
            return api.getPatternDetails(query)
              .catch(api.commonExceptionHanlder);
          };

          var doGetIndividualResourceData = function (query) {
            return api.getIndividualResourceData(query)
              .catch(commonExceptionHanlder);
          };

          var doGetShifts = function (query) {
            return api.getShifts(query)
              .catch(commonExceptionHanlder);
          };

          var doDeleteAvailability = function (params) {
            return api.deleteAvailability(params)
              .catch(commonExceptionHanlder);
          };

          var doDeclineAvailability = function (params) {
            return api.declineAvailability(params)
              .catch(commonExceptionHanlder);
          };

          var doApproveAvailability = function (params) {
            return api.approveAvailability(params)
              .catch(commonExceptionHanlder);
          };

          var doDeleteActivity = function (params) {
            return api.deleteActivity(params)
              .catch(commonExceptionHanlder);
          };

          var doSearchTags = function (searchString) {
            return api.search({
              objectType: constants.OBJECT_TYPE.TAG,
              queryText: searchString || ''
            })
              .catch(commonExceptionHanlder);
          };

          var doSearchAvailabilityTemplates = function (searchString) {
            return api.search({
              objectType: constants.OBJECT_TYPE.AVAILABILITY_TEMPLATE,
              queryText: searchString || ''
            })
              .catch(api.commonExceptionHanlder);
          };

          var doSearchAvailabilityPatterns = function (searchString) {
            return api.search({
              objectType: constants.OBJECT_TYPE.AVAILABILITY_PATTERN,
              queryText: searchString || ''
            })
              .catch(api.commonExceptionHanlder);
          };

          var doSaveAvailabilityPattern = function (params) {
            return api.savePattern(params)
              .catch(api.commonExceptionHanlder);
          };

          var getMinuteValue = function (timeValue) {
            return (Math.floor(timeValue / 100) * 60) + Math.round(timeValue % 100);
          };

          var getRemValue = function (timeValue) {
            return ((Math.round((timeValue / $ctrl.configData.consoleSettings.calendarStep) * 1000) / 1000) * GRID_SETTINGS.INDIVIDUAL_RESOURCE.slotSize.h);
          };

          var processResourcesData = function (resources) {
            var processEvent = function (event) {
              var eventTypes;
              var objectType = event.objectType;

              if ($ctrl.configData) {
                switch (objectType) {
                case OBJECT_TYPE.AVAILABILITY:
                  eventTypes = ($ctrl.configData.availabilityTypes.concat($ctrl.configData.otherEventTypes)) || [];
                  break;
                case OBJECT_TYPE.ACTIVITY:
                  eventTypes = ($ctrl.configData.activityTypes.concat($ctrl.configData.otherEventTypes)) || [];
                  break;
                case OBJECT_TYPE.JOB:
                  eventTypes = ($ctrl.configData.jobTypes.concat($ctrl.configData.otherEventTypes)) || [];
                  break;
                default:
                  eventTypes = [];
                  break;
                }

                // identify event type
                if (event.eventType) {
                  for (var i = 0; i < eventTypes.length; i++) {
                    if (eventTypes[i].id === event.eventType.id) {
                      event.eventType = eventTypes[i];
                      event.eventTypeSettings = event.eventType.eventTypeSettings[event.jobStatus || event.status];

                      if (!event.eventTypeSettings) {
                        event.eventTypeSettings = event.eventType.eventTypeSettings[DEFAULT_EVENT_STATUS];
                      }

                      break;
                    }
                  }
                }

                event.approvalRequired = (event.status === constants.AVAILABILITY_STATUS.PENDING &&
                  event.objectType === OBJECT_TYPE.AVAILABILITY);

                // if (objectType === OBJECT_TYPE.AVAILABILITY && 
                //   event.eventType && event.eventType.id === constants.AVAILABILITY_TYPE.ON_CALL && 
                //   event.onCallTeamId) {
                //   event.oncallTeam = $ctrl.onCallTeams.find(function (oncallTeam) {
                //     return oncallTeam.id === event.onCallTeamId;
                //   });

                //   if (event.oncallTeam) {
                //     event.members = event.oncallTeam.members;
                //   }
                // } 
              }
            };

            var produceAvailabilityPatternItem = function (patternResource, date, startTime, endTime, dayInfo) {
              return {
                objectType: OBJECT_TYPE.TEMPLATE_ENTRY,
                patternResource: patternResource,
                date: date,
                startTime: startTime,
                endTime: endTime,
                dayInfo: dayInfo,
                patternId: patternResource.availabilityPattern.id,
                isAllDay: startTime === 0 && endTime === 0
              };
            };

            var produceWeeklyPatternItems = function (patternResource) {
              var patternItems = [];
              var availabilityPattern = patternResource.availabilityPattern,
                pattern = availabilityPattern.pattern,
                startDate = patternResource.startDate,
                endDate = patternResource.endDate,
                startWeekDate;

              var isDateInPatternRange = function (date) {
                return date >= startDate && (!endDate || date <= endDate);
              };

              var isWeekMatch = function (date) {
                var calWeekDiff = Math.floor(dateUtil.getDiff(startWeekDate, date) / 7);

                return (calWeekDiff % pattern.repeatWeeks) === 0;
              };

              var isWeekDayMatch = function (date, weekday) {
                return WEEK_DAYS[date.getDay()] === weekday;
              };

              var identifyStartWeekDate = function () {
                var firstDay = getFirstDay();
                var startWeekDate = angular.copy(startDate);

                firstDay = firstDay || 0;
                startWeekDate.setDate(startWeekDate.getDate() - startWeekDate.getDay() + firstDay);

                return startWeekDate;
              };

              if (angular.isArray($ctrl.days) && $ctrl.days.length > 0) {
                startWeekDate = identifyStartWeekDate();

                angular.forEach($ctrl.days, function (calDayInfo) {
                  var calDate = calDayInfo.date;
                  var patternDayInfo, firstInterval,
                    startTime = 0,
                    endTime = 0;


                  if (isDateInPatternRange(calDate) &&
                    isWeekMatch(calDate)) {
                    patternDayInfo = pattern.days.find(function (patternDay) {
                      return isWeekDayMatch(calDate, patternDay.weekday);
                    });

                    if (patternDayInfo) {
                      if (angular.isArray(patternDayInfo.intervals) && patternDayInfo.intervals.length > 0) {
                        firstInterval = patternDayInfo.intervals[0];
                        startTime = firstInterval.startTime;
                        endTime = firstInterval.endTime;
                      }
                      patternItems.push(produceAvailabilityPatternItem(patternResource, calDate, startTime, endTime, calDayInfo));
                    }
                  }
                });
              }

              return patternItems;
            };

            var produceCustomPatternItems = function (patternResource) {
              var patternItems = [];
              var availabilityPattern = patternResource.availabilityPattern,
                pattern = availabilityPattern.pattern,
                startDate = patternResource.startDate,
                endDate = patternResource.endDate;

              var isDateInPatternRange = function (date) {
                return date >= startDate && (!endDate || date <= endDate);
              };

              var identifyDayNumber = function (date) {
                return ((dateUtil.getDiff(startDate, date)) % pattern.lengthDays) + 1;
              };

              if (angular.isArray($ctrl.days) && $ctrl.days.length > 0) {
                angular.forEach($ctrl.days, function (calDayInfo) {
                  var calDate = calDayInfo.date;
                  var patternDayInfo, firstInterval;
                  var calDayNumber;
                  var startTime = 0,
                    endTime = 0;

                  if (isDateInPatternRange(calDate)) {
                    calDayNumber = identifyDayNumber(calDate);
                    patternDayInfo = pattern.days.find(function (patternDay) {
                      return patternDay.day === calDayNumber;
                    });

                    if (patternDayInfo) {
                      if (angular.isArray(patternDayInfo.intervals) && patternDayInfo.intervals.length > 0) {
                        firstInterval = patternDayInfo.intervals[0];
                        startTime = firstInterval.startTime;
                        endTime = firstInterval.endTime;
                      }
                      patternItems.push(produceAvailabilityPatternItem(patternResource, calDate, startTime, endTime, calDayInfo));
                    }
                  }
                });
              }

              return patternItems;
            };

            var processAvailabilityPattern = function (patternResource) {
              var availabilityPattern;

              if (patternResource &&
                patternResource.availabilityPattern &&
                patternResource.availabilityPattern.id) {

                availabilityPattern = patternResource.availabilityPattern = $ctrl.availabilityPatterns.find(function (availPattern) {
                  return availPattern.id === patternResource.availabilityPattern.id;
                });

                if (availabilityPattern && availabilityPattern.pattern) {
                  if (availabilityPattern.pattern.type === constants.AVAILABILITY_PATTERN_TYPE.WEEKLY) {
                    patternResource.availabilityPatternItems = produceWeeklyPatternItems(patternResource);
                  } else if (availabilityPattern.pattern.type === constants.AVAILABILITY_PATTERN_TYPE.CUSTOM) {
                    patternResource.availabilityPatternItems = produceCustomPatternItems(patternResource);
                  }
                }
              }
            };

            var processResource = function (resource) {
              var regions = [];
              var resourceRegionId = (resource.region) ? resource.region.id : null;

              // identify resource region
              resource.region = null;
              if (resourceRegionId && $ctrl.configData) {
                regions = $ctrl.configData.regions;
                for (var i = 0; i < regions.length; i++) {
                  if (regions[i].id === resourceRegionId) {
                    resource.region = regions[i];
                    break;
                  }
                }
              }

              angular.forEach(resource.events, processEvent);
              angular.forEach(resource.availability, processEvent);

              angular.forEach(resource.availabilityPatternResources, processAvailabilityPattern);
            };

            angular.forEach(resources, processResource);

            return resources;
          };

          var processAllDayEvent = function (event) {
            var backgroundSettings = '',
              defaultBackgroundColor = '',
              backgroundColorParts = [];

            var allDayData = {
              days: [],
              startOutside: false,
              endOutside: false,
              backgroundColor: ''
            };

            var allDayStart, allDayEnd,
              eventEndTime = event.endTime,
              eventStart = event.startDate,
              eventEnd = angular.copy(event.endDate),
              calStart = $ctrl.days[0].date,
              calEnd = $ctrl.days[$ctrl.days.length - 1].date;

            var buildLinearGradient = function (deg, color) {
              return 'linear-gradient(' + deg + 'deg, ' + color + ' calc(100% - .375rem), transparent .375rem)';
            };

            if (eventEndTime === 0) {
              eventEnd.setDate(eventEnd.getDate() - 1);
            }

            // boundary
            if (eventStart < calStart) {
              allDayStart = calStart;
              allDayData.startOutside = true;
            } else {
              allDayStart = eventStart;
              allDayData.startOutside = false;
            }

            if (eventEnd > calEnd) {
              allDayEnd = calEnd;
              allDayData.endOutside = true;
            } else {
              allDayEnd = eventEnd;
              allDayData.endOutside = false;
            }

            // days
            for (var dallDayTemp = angular.copy(allDayStart); dallDayTemp <= allDayEnd; dallDayTemp.setDate(dallDayTemp.getDate() + 1)) {
              allDayData.days.push(dateUtil.dateToString(dallDayTemp));
            }

            backgroundSettings = ((event.eventType && event.eventTypeSettings) ? event.eventTypeSettings.backgroundColor : 'fff');
            defaultBackgroundColor = 'linear-gradient(' + backgroundSettings + ', ' + backgroundSettings + ')';
            if (allDayData.startOutside || allDayData.endOutside) {
              if (allDayData.startOutside) {
                backgroundColorParts.push(buildLinearGradient(315, backgroundSettings), buildLinearGradient(225, backgroundSettings));
              } else {
                backgroundColorParts.push(defaultBackgroundColor, defaultBackgroundColor);
              }

              if (allDayData.endOutside) {
                backgroundColorParts.push(buildLinearGradient(45, backgroundSettings), buildLinearGradient(135, backgroundSettings));
              } else {
                backgroundColorParts.push(defaultBackgroundColor, defaultBackgroundColor);
              }

              allDayData.backgroundColor = backgroundColorParts.join(', ');
            } else {
              allDayData.backgroundColor = defaultBackgroundColor;
            }

            event.allDayData = allDayData;
          };

          var processScheduleData = function (resources) {
            var scheduleData = [];

            if (angular.isArray(resources) && resources.length > 0) {
              // process schedule data
              angular.forEach(resources, function (resource) {
                var allDayEvents = [];

                var dataItem = {
                  resource: resource,
                  eventsByDate: {},
                  shiftsByDate: {},
                  availabilityByDate: {},
                  allDayEventsByDate: {},
                  allDayEventsCount: 0,
                  allEventsByDate: {},
                  availabilityTemplateEntriesByDate: {},
                  availabilityTemplatePatternItemsByDate: {}
                };

                // process shifts
                if ($ctrl.isShiftEnabled) {
                  processScheduleShifts(resource, dataItem);
                }

                // process events
                if (angular.isArray(resource.events) && resource.events.length > 0) {
                  processScheuldeEvents(resource, dataItem, allDayEvents);
                }

                // process availability
                if (angular.isArray(resource.availability) && resource.availability.length > 0) {
                  processScheduleAvailabilities(resource, dataItem, allDayEvents);
                }

                // process all day events
                if (allDayEvents.length > 0) {
                  processScheduleAllDayEvents(resource, dataItem, allDayEvents);
                }

                // concat all events to a single array
                angular.forEach($ctrl.days, function (day) {
                  var eventsAndAvailability;
                  var allEvents, event;

                  dataItem.availabilityTemplateEntriesByDate[day.dateIso] = collectAvailabilityTemplateByDate(resource.availabilityTemplates, day);
                  dataItem.availabilityTemplatePatternItemsByDate[day.dateIso] = collectAvailabilityPatternItemsByDate(resource.availabilityPatternResources, day);

                  eventsAndAvailability = [].concat(
                    dataItem.availabilityTemplateEntriesByDate[day.dateIso] || [],
                    dataItem.availabilityTemplatePatternItemsByDate[day.dateIso] || [],
                    dataItem.availabilityByDate[day.dateIso] || [],
                    dataItem.eventsByDate[day.dateIso] || []
                  );
                  allEvents = angular.extend([], dataItem.allDayEventsByDate[day.dateIso]);

                  if (eventsAndAvailability.length > 0) {
                    for (var i = 0; i < allEvents.length; i++) {
                      event = allEvents[i];
                      if (event.redundant) {
                        allEvents[i] = eventsAndAvailability[0];
                        eventsAndAvailability.splice(0, 1);

                        if (eventsAndAvailability.length === 0) {
                          break;
                        }
                      }
                    }

                    if (eventsAndAvailability.length > 0) {
                      allEvents = allEvents.concat(eventsAndAvailability);
                    }
                  }

                  dataItem.allEventsByDate[day.dateIso] = allEvents;
                });

                scheduleData.push(dataItem);
              });
            }

            return scheduleData;
          };

          var processScheduleShifts = function (resource, dataItem) {
            var shifts = resource.resourceShifts.map(function (resourceShift) {
              return resourceShift.shift;
            });

            if (shifts.length > 0) {
              dataItem.shiftsByDate = groupShiftsByDate(shifts);
            }

            if ($ctrl.selectedResource || $ctrl.viewMode === CONSOLE_VIEW_MODE.INDIVIDUAL_RESOURCE) {
              angular.forEach(dataItem.shiftsByDate, function (shift, dateKey) {
                processTimeslots(shift, dateUtil.parseDateString(dateKey), true);
              });
            }
          };

          var processScheuldeEvents = function (resource, dataItem, allDayEvents) {
            angular.forEach(resource.events, function (event) {
              var dateKey;
              // var alldayEventLevel;

              if (isAllDayEvent(event)) {
                allDayEvents.push(event);

              } else {
                dateKey = dateUtil.dateToString(event.startDate);

                // push event to data map
                if (!angular.isArray(dataItem.eventsByDate[dateKey])) {
                  dataItem.eventsByDate[dateKey] = [];
                }

                dataItem.eventsByDate[dateKey].push(event);
              }

            });

            if ($ctrl.selectedResource || $ctrl.viewMode === CONSOLE_VIEW_MODE.INDIVIDUAL_RESOURCE) {
              angular.forEach(dataItem.eventsByDate, function (events, dateKey) {
                processTimeslots(events, dateUtil.parseDateString(dateKey), true);
                dataItem.eventsByDate[dateKey] = events = events.filter(function (event) {
                  return !!event.timeslotData;
                });

                // sort by y position
                events.sort(function (event1, event2) {
                  return event1.timeslotData.y - event2.timeslotData.y;
                });

                // check overlapping
                angular.forEach(events, function (event
                  // , index
                ) {
                  checkOverlappingEvent(events, event, 1);
                });

                // calculate postion and width
                angular.forEach(events, function (event) {
                  if (event.overlapInfo) {
                    angular.forEach(event.overlapInfo.overlappedEvents, function (overlappedEvent) {
                      if (event.overlapInfo.maxLevel < overlappedEvent.overlapInfo.maxLevel) {
                        event.overlapInfo.maxLevel = overlappedEvent.overlapInfo.maxLevel;
                      } else {
                        overlappedEvent.overlapInfo.maxLevel = event.overlapInfo.maxLevel;
                      }
                    });

                    event.timeslotData.w = ((Math.round(10000 / event.overlapInfo.maxLevel)) / 100);
                    event.timeslotData.x = event.timeslotData.w * (event.overlapInfo.level - 1);
                  }
                });
              });
            }
          };

          var processScheduleAvailabilities = function (resource, dataItem, allDayEvents) {
            angular.forEach(resource.availability, function (availability) {
              var dateKey;
              // var alldayAvailabilityLevel;

              if (availability.eventType && availability.eventType.id !== 'non-working' && isAllDayEvent(availability)) {
                allDayEvents.push(availability);
              } else {
                for (var tmpDate = angular.copy(availability.startDate);
                  ((availability.endTime > 0 && tmpDate <= availability.endDate) || (availability.endTime === 0 && tmpDate < availability.endDate)); tmpDate.setDate(tmpDate.getDate() + 1)) {
                  dateKey = dateUtil.dateToString(tmpDate);
                  // push availability to data map
                  if (!angular.isArray(dataItem.availabilityByDate[dateKey])) {
                    dataItem.availabilityByDate[dateKey] = [];
                  }

                  dataItem.availabilityByDate[dateKey].push(angular.extend(new model.AvailabilityModel(), availability));
                }
              }
            });

            if ($ctrl.selectedResource || $ctrl.viewMode === CONSOLE_VIEW_MODE.INDIVIDUAL_RESOURCE) {
              angular.forEach(dataItem.availabilityByDate, function (availability, dateKey) {
                processTimeslots(availability, dateUtil.parseDateString(dateKey), true);
              });
            }
          };

          var processScheduleAllDayEvents = function (resource, dataItem, allDayEvents) {
            // sort by dates
            allDayEvents.sort(function (event1, event2) {
              var startDiff = (event1.startDate.getTime() + event1.startTime) - (event2.startDate.getTime() + event2.startTime),
                endDiff = (event1.endDate.getTime() + event1.endTime) - (event2.endDate.getTime() + event2.endTime);
              return startDiff === 0 ? endDiff : startDiff;
            });

            angular.forEach(allDayEvents, function (event) {
              var alldayAvailabilityLevel;
              event.isAllDayEvent = true;
              processAllDayEvent(event);

              angular.forEach(event.allDayData.days, function (dayIso, indx) {
                var redundantIndx = -1;
                if (!angular.isArray(dataItem.allDayEventsByDate[dayIso])) {
                  dataItem.allDayEventsByDate[dayIso] = [];
                }

                if (indx === 0) {
                  if (dataItem.allDayEventsByDate[dayIso].length > 0) {
                    for (var i = 0; i < dataItem.allDayEventsByDate[dayIso].length; i++) {
                      if (dataItem.allDayEventsByDate[dayIso][i].redundant) {
                        redundantIndx = i;
                        break;
                      }
                    }
                  }

                  if (redundantIndx > -1) {
                    dataItem.allDayEventsByDate[dayIso][redundantIndx] = event;
                  } else {
                    dataItem.allDayEventsByDate[dayIso].push(event);
                  }

                  alldayAvailabilityLevel = dataItem.allDayEventsByDate[dayIso].indexOf(event);
                } else {
                  if (dataItem.allDayEventsByDate[dayIso].length > alldayAvailabilityLevel) {
                    dataItem.allDayEventsByDate[dayIso][alldayAvailabilityLevel].redundant = false;
                  } else {
                    while (dataItem.allDayEventsByDate[dayIso].length <= alldayAvailabilityLevel) {
                      dataItem.allDayEventsByDate[dayIso].push({
                        isAllDayEvent: true,
                        allDayEvent: event,
                        redundant: alldayAvailabilityLevel > dataItem.allDayEventsByDate[dayIso].length
                      });
                    }
                  }
                }
              });
            });

            if ($ctrl.selectedResource || $ctrl.viewMode === CONSOLE_VIEW_MODE.INDIVIDUAL_RESOURCE) {
              // count all day events
              angular.forEach(dataItem.allDayEventsByDate, function (allDayEvents) {
                if (allDayEvents.length > dataItem.allDayEventsCount) {
                  dataItem.allDayEventsCount = allDayEvents.length;
                }
              });
            }
          };

          var processShiftsData = function (shifts) {
            var shiftsData = {
              shiftsCount: shifts.length,
              maxShiftsCount: 0,
              shiftsByDate: groupShiftsByDate(shifts)
            };

            angular.forEach(shiftsData.shiftsByDate, function (shiftsByDate) {
              if (shiftsByDate.length > shiftsData.maxShiftsCount) {
                shiftsData.maxShiftsCount = shiftsByDate.length;
              }
            });

            return shiftsData;
          };

          var groupShiftsByDate = function (shifts) {
            var shiftsByDate = {};
            if (angular.isArray(shifts) && shifts.length > 0) {
              angular.forEach(shifts, function (shift) {

                var dateKey;
                if (shift) {
                  dateKey = dateUtil.dateToString(shift.startDate);

                  // push shift to data map
                  if (!angular.isArray(shiftsByDate[dateKey])) {
                    shiftsByDate[dateKey] = [];
                  }

                  shiftsByDate[dateKey].push(shift);
                }
              });
            }

            return shiftsByDate;
          };

          // find template entries match date
          var collectAvailabilityTemplateByDate = function (resourceAvailabilityTemplates, dayInfo) {
            var availabilityTemplateEntries = [];

            if (angular.isArray(resourceAvailabilityTemplates)) {
              angular.forEach(resourceAvailabilityTemplates, function (template) {
                if (template.entriesByDates && angular.isArray(template.entriesByDates[dayInfo.dateIso])) {
                  availabilityTemplateEntries = availabilityTemplateEntries.concat(template.entriesByDates[dayInfo.dateIso]);
                }
              });
            }

            return availabilityTemplateEntries;
          };

          // find pattern items match date
          var collectAvailabilityPatternItemsByDate = function (availabilityPatternResources, dayInfo) {
            var availabilityPatternItems = [];

            if (angular.isArray(availabilityPatternResources)) {
              angular.forEach(availabilityPatternResources, function (patternResource) {
                if (angular.isArray(patternResource.availabilityPatternItems)) {
                  availabilityPatternItems = availabilityPatternItems.concat(patternResource.availabilityPatternItems.filter(function (patternItem) {
                    return patternItem.dayInfo === dayInfo;
                  }));
                }
              });
            }

            return availabilityPatternItems;
          };

          /**
           * check if 2 events are overlapped
           */
          var isEventsOverlapped = function (event1, event2) {
            if (!event1.timeslotData || !event2.timeslotData) return false;

            var start1 = event1.timeslotData.y,
              start2 = event2.timeslotData.y,
              end1 = event1.timeslotData.y + event1.timeslotData.h,
              end2 = event2.timeslotData.y + event2.timeslotData.h;

            return (start1 < end2 && end1 > start2);
          };

          /**
           * go through list to put overlapping information for each event
           */
          var checkOverlappingEvent = function (checkingList, event, startLevel) {
            var tmpEvent, maxLevel;

            if (angular.isArray(checkingList) && checkingList.length > 1) {

              if (!event.overlapInfo) {
                event.overlapInfo = {
                  level: startLevel,
                  maxLevel: startLevel,
                  overlappedEvents: []
                };

                for (var i = 0; i < checkingList.length; i++) {
                  tmpEvent = checkingList[i];

                  if (event !== tmpEvent && isEventsOverlapped(event, tmpEvent)) {
                    event.overlapInfo.overlappedEvents.push(tmpEvent);
                    maxLevel = checkOverlappingEvent(checkingList, tmpEvent, startLevel + 1);

                  }
                }

              }

              if (maxLevel > event.overlapInfo.maxLevel) {
                event.overlapInfo.maxLevel = maxLevel;
              }

              return event.overlapInfo.maxLevel;
            }

            return startLevel;
          };

          var processTimeslots = function (events, processingDate, acceptOutOfRange) {
            var startCalSlot = $ctrl.timeslots[0],
              endCalSlot = $ctrl.timeslots[$ctrl.timeslots.length - 1],
              startCalMinuteVal = ((startCalSlot && startCalSlot.start >= 0) ? getMinuteValue(startCalSlot.start) : -1),
              endCalMinuteVal = ((endCalSlot && endCalSlot.start) ? getMinuteValue(endCalSlot.start) : -1);

            if (startCalMinuteVal >= 0 && endCalMinuteVal >= 0 && angular.isArray(events)) {
              angular.forEach(events, function (event) {
                // var processedData = null;
                var yPosition, xPosition, slotHeight, slotWidth, boxHeight;
                var eventStartTime = (event.startDate.getTime() < processingDate.getTime()) ? 0 : event.startTime,
                  eventEndTime = (event.endDate.getTime() > processingDate.getTime()) ? 2400 : event.endTime;
                var startEventMinuteVal = getMinuteValue(eventStartTime),
                  endEventMinuteVal = getMinuteValue(eventEndTime),
                  travelMinuteVal = (event.travelTime || 0),
                  startSlotMinuteVal = startEventMinuteVal - travelMinuteVal;
                var isOutTravel = false,
                  isOutStart = false,
                  isOutEnd = false,
                  isOutCal = false;

                xPosition = 0;
                slotWidth = 100;

                if (acceptOutOfRange === true) {
                  if (startSlotMinuteVal < startCalMinuteVal) {
                    startSlotMinuteVal = startCalMinuteVal;
                    isOutTravel = true;

                    isOutStart = (startEventMinuteVal < startCalMinuteVal);
                  }

                  if (endEventMinuteVal > endCalMinuteVal) {
                    endEventMinuteVal = endCalMinuteVal;
                    isOutEnd = true;
                  }
                }

                // identify y position
                yPosition = getRemValue(startSlotMinuteVal - startCalMinuteVal);
                // identify event height
                slotHeight = getRemValue(endEventMinuteVal - startSlotMinuteVal);
                // identify box height
                boxHeight = getRemValue(endEventMinuteVal - startEventMinuteVal);

                if (boxHeight > slotHeight) {
                  boxHeight = slotHeight;
                }

                isOutCal = (endEventMinuteVal <= startCalMinuteVal || startEventMinuteVal >= endCalMinuteVal);

                if (yPosition >= 0 && !isOutCal) {
                  event.timeslotData = {
                    y: yPosition,
                    x: xPosition,
                    w: slotWidth,
                    h: slotHeight,
                    b: boxHeight,
                    travelBeforeGrid: isOutTravel,
                    startBeforeGrid: isOutStart,
                    endAfterGrid: isOutEnd
                  };
                }
              });
            }
          };

          var getResourceData = function (query) {
            return doGetResourceData(query)
              .then(function (result) {
                // var selectedResourceData;

                if (result.success) {
                  $ctrl.today = dateUtil.parseDateString(result.data.today);
                  $ctrl.resourcesPaginModel.numberOfPages = result.data.totalPages || 0;
                  // $ctrl.onCallTeams = model.OncallTeamModel.fromServerList(result.data.onCallTeams, true);

                  $ctrl.rawResourcesData = model.ResourceModel.fromServerList(result.data.resources || [], true, $ctrl.timezone.label);
                  $ctrl.availabilityTemplates = model.TemplateModel.fromServerList(result.data.templates || [], true, $ctrl.timezone.label);
                  $ctrl.availabilityPatterns = model.AvailabilityPatternModel.fromServerList(result.data.patterns || [], true, $ctrl.timezone.label);

                  if (!angular.isDate($ctrl.today)) {
                    $ctrl.today = new Date();
                    $ctrl.today.setHours(0, 0, 0, 0);
                  }
                } else {
                  return $q.reject(result);
                }
              });
          };

          var getEventDetails = function (availability) {
            return doGetEventDetails({
              event: availability.toServer()
            });
          };

          var getPatternDetails = function (patternId) {
            return doGetPatternDetails({
              recordId: patternId
            });
          };

          var getIndividualResourceData = function (query) {
            return doGetIndividualResourceData(query)
              .then(function (result) {
                // var selectedResourceData;

                if (result.success) {
                  $ctrl.today = dateUtil.parseDateString(result.data.today);
                  // $ctrl.onCallTeams = model.OncallTeamModel.fromServerList(result.data.onCallTeams, true);
                  $ctrl.rawResourcesData = model.ResourceModel.fromServerList(result.data.resources || [], false);
                  $ctrl.availabilityTemplates = model.TemplateModel.fromServerList(result.data.templates || [], false);

                  if (!angular.isDate($ctrl.today)) {
                    $ctrl.today = new Date();
                    $ctrl.today.setHours(0, 0, 0, 0);
                  }
                } else {
                  return $q.reject(result);
                }
              });
          };

          var getShifts = function (query) {
            return doGetShifts(query)
              .then(function (result) {
                if (result.success) {
                  // var selectedResourceData;

                  $ctrl.shifts = model.ShiftModel.fromServerList(result.data);
                  $ctrl.shiftsData = processShiftsData($ctrl.shifts);

                } else {
                  return $q.reject(result);
                }
              });
          };

          var mapShiftLocations = function (shifts, serviceLocations) {
            var locationIds = serviceLocations.map(function (serviceLocation) {
              return serviceLocation.id;
            });

            angular.forEach(shifts, function (shift) {
              var locationIndx;

              if (shift.location) {
                locationIndx = locationIds.indexOf(shift.location.id);

                if (locationIndx > -1) {
                  shift.location = serviceLocations[locationIndx];
                } else {
                  shift.location = null;
                }
              }
            });
          };

          var processAvailabilityTemplates = function () {
            var calStart, calEnd;

            var isWeekDayMatch = function (entry, date) {
              return angular.isString(entry.weekday) && WEEK_DAYS[date.getDay()] === entry.weekday.toUpperCase();
            };

            var isWeekNoMatch = function (template, entry, date) {
              var isMatched = false;
              var templateWeekNos, maxWeekNo;
              var templateWeekBegin, dateWeekBegin, weekDiff;
              var dateWeekNo;

              if (template && angular.isDate(template.startDate) &&
                template.startDate.getTime() <= date.getTime() &&
                entry && entry.weekNo && entry.weekNo >= 1) {
                templateWeekNos = template.entries.map(function (entryItem) {
                  return entryItem.weekNo || 0;
                });

                maxWeekNo = Math.max.apply(null, templateWeekNos);

                if (maxWeekNo > -1) {
                  templateWeekBegin = angular.copy(template.startDate);
                  templateWeekBegin.setDate(templateWeekBegin.getDate - templateWeekBegin.getDay());

                  dateWeekBegin = angular.copy(date);
                  dateWeekBegin.setDate(dateWeekBegin.getDate - dateWeekBegin.getDay());

                  weekDiff = (dateUtil.getDiff(templateWeekBegin, dateWeekBegin) / 7) + 1;

                  dateWeekNo = (weekDiff % maxWeekNo) || maxWeekNo;

                  isMatched = (dateWeekNo === entry.weekNo);
                }
              }

              return isMatched;
            };

            if (angular.isArray($ctrl.availabilityTemplates) &&
              angular.isArray($ctrl.days) && $ctrl.days.length > 0) {
              calStart = $ctrl.days[0].date;
              calEnd = $ctrl.days[$ctrl.days.length - 1].date;

              // group template entries by dates
              angular.forEach($ctrl.availabilityTemplates, function (template) {
                template.entriesByDates = {};

                if (!(angular.isDate(template.startDate) && template.startDate.getTime() > calEnd.getTime()) &&
                  !(angular.isDate(template.endDate) && template.endDate.getTime() < calStart.getTime()) &&
                  angular.isArray(template.entries) && template.entries.length > 0) {
                  angular.forEach($ctrl.days, function (dayInfo) {
                    var date = dayInfo.date;
                    var entriesForDay = template.entries.filter(function (entry) {
                      entry.objectType = OBJECT_TYPE.TEMPLATE_ENTRY;
                      return isWeekDayMatch(entry, date) &&
                        (!entry.weekNo || entry.weekNo <= 1 || isWeekNoMatch(template, entry, date));
                    });

                    if (entriesForDay.length > 0) {
                      template.entriesByDates[dayInfo.dateIso] = entriesForDay;
                    }
                  });
                }
              });
            }
          };

          var mapResourcesShifts = function (resources, shifts) {
            var shiftIds;
            if (angular.isArray(resources) && angular.isArray(shifts)) {
              shiftIds = shifts.map(function (shift) {
                return shift.id;
              });

              angular.forEach(resources, function (resource) {
                var resourceShifts;

                if (resource &&
                  angular.isArray(resource.resourceShifts) &&
                  resource.resourceShifts.length > 0) {
                  resourceShifts = resource.resourceShifts;

                  angular.forEach(resourceShifts, function (resourceShift) {
                    var shiftInd;

                    if (resourceShift.shift) {
                      shiftInd = shiftIds.indexOf(resourceShift.shift.id);

                      if (shiftInd > -1) {
                        resourceShift.shift = shifts[shiftInd];
                      } else {
                        resourceShift.shift = null;
                      }
                    }
                  });
                }
              });
            }
          };

          var rebuildScheduleConsole = function (forceBuild) {
            var query;
            var fetchDataPromises = [];

            if ($ctrl.configData && $ctrl.configData.consoleSettings && $ctrl.timezone &&
              angular.isArray($ctrl.regions) && $ctrl.regions.length > 0 &&
              angular.isArray($ctrl.days) && $ctrl.days.length > 0) {

              query = {
                resourceId: ($ctrl.selectedResource && $ctrl.selectedResource.resource) ? $ctrl.selectedResource.resource.id : '',
                regionIds: $ctrl.regions.length === $ctrl.configData.regions.length ? null : $ctrl.regions.map(function (region) {
                  return region.id;
                }),
                locationIds: ($ctrl.location) ? [$ctrl.location.id] : [],
                startDate: $ctrl.days[0].dateIso,
                endDate: $ctrl.days[$ctrl.days.length - 1].dateIso,
                timezoneSidId: $ctrl.timezone.label,
                pageNo: $ctrl.resourcesPaginModel.pageNumber,
                pageSize: $ctrl.resourcesPaginModel.recordsPerPage,
                queryText: $ctrl.resourcesFilterString || '',
                resourceEmploymentTypes: $ctrl.appliedResourcesFilters.resourceEmploymentTypes || [],
                resourceCategories: $ctrl.appliedResourcesFilters.resourceCategories || [],
                tagIds: $ctrl.appliedResourcesFilters.tagIds || [],

                patternId: $ctrl.appliedResourcesFilters.availabilityPatternId,

              };

              if (forceBuild || isParamsReallyChanged(query)) {
                currentParams = query;

                if (query.resourceId) {
                  fetchDataPromises.push(getIndividualResourceData(query));
                } else {
                  fetchDataPromises.push(getResourceData(query));
                }

                if ($ctrl.isShiftEnabled) {
                  fetchDataPromises.push(getShifts(query));
                }

                showLoading();
                return $q.all(fetchDataPromises)
                  .then(function () {
                    if ($ctrl.isShiftEnabled && angular.isArray($ctrl.shifts) && $ctrl.shifts.length > 0) {
                      mapShiftLocations($ctrl.shifts, $ctrl.configData.serviceLocations);
                      mapResourcesShifts($ctrl.rawResourcesData, $ctrl.shifts);
                    }

                    // process availability template
                    processAvailabilityTemplates();

                    if ($ctrl.viewMode === CONSOLE_VIEW_MODE.INDIVIDUAL_RESOURCE) {
                      $ctrl.resources = processResourcesData($ctrl.rawResourcesData);
                      var selectedResourceData = processScheduleData($ctrl.resources);

                      if (angular.isArray(selectedResourceData) && selectedResourceData.length > 0) {
                        $ctrl.selectedResource = selectedResourceData[0];
                      }
                    } else {
                      transformResourcesData($ctrl.rawResourcesData);
                    }
                  })
                  .catch(function (exception) {
                    console.error(exception);
                    if (exception && exception.errorMessage) {
                      util.toastError(exception.errorMessage);
                    }
                  })
                  .finally(function () {
                    hideLoading();
                  });
              }
            }
          };

          var transformResourcesData = function (rawResourcesData) {
            //var newMaxPageNumber, searchString;
            $ctrl.filteredResourcesData = rawResourcesData;

            /*// apply source filter
            if ($ctrl.resourcesFilterString && $ctrl.resourcesFilterString.length > 0) {
              searchString = $ctrl.resourcesFilterString.toLowerCase();
              $ctrl.filteredResourcesData = filterFn(rawResourcesData, function (rsData) {
                return (angular.isString(rsData.name) && rsData.name.toLowerCase().indexOf(searchString) > -1) ||
                  (angular.isString(rsData.category) && rsData.category.toLowerCase().indexOf(searchString) > -1);
              });
            }

            newMaxPageNumber = Math.ceil($ctrl.filteredResourcesData.length / $ctrl.resourcesPaginModel.recordsPerPage)

            // page number keep, force apply pagination
            // else, let watch expression do its works
            if (newMaxPageNumber > 0 && $ctrl.resourcesPaginModel.pageNumber <= newMaxPageNumber ) { 
              applyResourcesPagin($ctrl.filteredResourcesData);
            } else if (newMaxPageNumber <= 0) {
              paginResources = null;
              $ctrl.resources = null;
              $ctrl.scheduleData = null;
            }*/

            $ctrl.resources = processResourcesData($ctrl.filteredResourcesData);
            $ctrl.scheduleData = processScheduleData($ctrl.resources);
          };

          /*var applyResourcesPagin = function (filteredResourcesData) {
          var paginResources = filteredResourcesData;

          if (angular.isArray(paginResources) && $ctrl.resourcesPaginModel.pageNumber > 0) {
            paginResources = paginResources.slice(($ctrl.resourcesPaginModel.pageNumber - 1) * $ctrl.resourcesPaginModel.recordsPerPage, $ctrl.resourcesPaginModel.pageNumber * $ctrl.resourcesPaginModel.recordsPerPage);

            $ctrl.resources = processResourcesData(paginResources);
            $ctrl.scheduleData = processScheduleData($ctrl.resources);
          }
        };
*/
          var calculateCalendarDays = function (calStartDate) {
            var ONE_DAY_TIME = 86400000;
            var tmpDate, startDate, endDate,
              // dI, 
              dw;
            var tmpHoliday, tmpHolidayDateTime, holidayStartDate, holidayEndDate;
            var regionIds, tmpCalStartDate, tmpCalEndDate;
            var yesterday = angular.copy($ctrl.today);
            var daysMap = {};
            var regionIdx;

            yesterday.setDate($ctrl.today.getDate() - 1);
            if ($ctrl.configData && $ctrl.configData.consoleSettings && angular.isDate(calStartDate)) {
              //startDate = new Date(calStartDate.getFullYear(), calStartDate.getMonth(), calStartDate.getDate() - calStartDate.getDay());
              startDate = new Date(calStartDate.getFullYear(), calStartDate.getMonth(), calStartDate.getDate());
              endDate = angular.copy(startDate);
              endDate.setDate(endDate.getDate() + (7 * $ctrl.configData.consoleSettings.viewPeriod));

              for (tmpDate = angular.copy(startDate); tmpDate < endDate; tmpDate.setDate(tmpDate.getDate() + 1)) {
                // dI = [tmpDate.getMonth() + 1, tmpDate.getDate()];
                dw = tmpDate.getDay();

                daysMap[tmpDate.getTime()] = {
                  dateIso: dateUtil.dateToString(tmpDate),
                  date: angular.copy(tmpDate),
                  isWeekend: (dw === 0 || dw === 6),
                  isInPast: isInPast(tmpDate),
                  isToday: (tmpDate.getTime() === $ctrl.today.getTime()),
                  isYesterday: (tmpDate.getTime() === yesterday.getTime())
                };
              }

              // identify holiday information
              tmpCalStartDate = startDate.getTime();
              tmpCalEndDate = endDate.getTime();

              // region ids
              if ($ctrl.location) {
                regionIds = [];

                if ($ctrl.location.region) {
                  regionIds.push($ctrl.location.region.id);
                }
              } else {
                regionIds = $ctrl.regions.map(function (region) {
                  return region.id;
                });
              }


              if ($ctrl.configData.holidays && $ctrl.configData.holidays.length > 0) {
                for (var i = 0; i < $ctrl.configData.holidays.length; i++) {
                  tmpHoliday = $ctrl.configData.holidays[i];
                  regionIdx = (tmpHoliday.regionId ? regionIds.indexOf(tmpHoliday.regionId) : -1);
                  if (tmpHoliday &&
                    angular.isDate(tmpHoliday.startDate) && angular.isDate(tmpHoliday.endDate) &&
                    (tmpHoliday.isGlobal || regionIdx > -1)) {
                    holidayStartDate = tmpHoliday.startDate.getTime();
                    holidayEndDate = tmpHoliday.endDate.getTime();

                    if (holidayStartDate <= tmpCalEndDate && holidayEndDate >= tmpCalStartDate) {
                      if (holidayStartDate < tmpCalStartDate) {
                        tmpHolidayDateTime = tmpCalStartDate;
                      } else {
                        tmpHolidayDateTime = holidayStartDate;
                      }

                      if (regionIdx > -1) {
                        tmpHoliday.region = $ctrl.regions[regionIdx];
                      }

                      for (; tmpHolidayDateTime <= holidayEndDate && tmpHolidayDateTime <= tmpCalEndDate; tmpHolidayDateTime += ONE_DAY_TIME) {
                        if (daysMap[tmpHolidayDateTime]) {
                          if (!angular.isArray(daysMap[tmpHolidayDateTime].holidays)) {
                            daysMap[tmpHolidayDateTime].holidays = [];
                          }

                          daysMap[tmpHolidayDateTime].holidays.push(tmpHoliday);
                        }
                      }
                    }
                  }
                }
              }
            }

            return Object.values(daysMap);
          };

          var getInitialData = function () {
            var requestParams = {
              configKeys: RAC_REQUIRED_CONFIG_DATA
            };
            return doInitialize(requestParams)
              .then(function (result) {
                if (result.success) {
                  $ctrl.configData = model.ConfigDataModel.fromServer(result.data);

                  return $ctrl.configData;
                } else {
                  return $q.reject(result);
                }
              });
          };

          var isInPast = function (date) {
            return date < $ctrl.today;
          };

          var showShiftAllocationModal = function (item) {
            util.showModal({
              template: '<shift-allocation class="sked-modal-container" regions="regions" locations="locations" shift="shift" allow-posting-message="false" on-close="onClose(message, this)" config-data="configData" timezone="timezone"></shift-allocation>'
            }, {
              configData: $ctrl.configData,
              regions: $ctrl.regions,
              locations: ($ctrl.location) ? [$ctrl.location] : [],
              shift: item,
              timezone: $ctrl.timezone,
              onClose: function (message, modalScope) {
                modalScope.closeModal(message);

                if (message === 'done') {
                  rebuildScheduleConsole(true);
                }
              }
            });
          };

          /*var showAvailabilityDetailsModal = function (availability, resource, day, startTime, endTime, isAvailable) {
            var edittingAvailability = new model.AvailabilityModel();

            if (!availability) {
              edittingAvailability.startDate = angular.copy(day.date);
              edittingAvailability.endDate = angular.copy(day.date);
              edittingAvailability.startTime = startTime || $ctrl.configData.consoleSettings.calendarStart;
              edittingAvailability.endTime = endTime || $ctrl.configData.consoleSettings.calendarEnd;
            }else {
              edittingAvailability = angular.extend(edittingAvailability, availability);

              if (isAvailable === undefined || isAvailable === null) {
                isAvailable = (availability.eventTypeSettings)?!!availability.eventTypeSettings.isAvailable:false;
              }
            }

            util.showModal({
              template: '<availability-details class="sked-modal-container" timezone="timezone" availability="availability" resource="resource" config-data="configData" is-available="isAvailable" on-close="onClose(this, message)" ></availability-details>',
            }, {
              availability: edittingAvailability,
              resource: resource,
              configData: $ctrl.configData,
              timezone: $ctrl.timezone,
              isAvailable: isAvailable,
              onClose: function (modalScope, message) {
                modalScope.closeModal();

                if (message === 'done') {
                  rebuildScheduleConsole(true);
                } 
              }
            });
          };*/

          var showAvailabilityDetailsModal = function (availability, resource, day, startTime, endTime, isAvailable) {
            var edittingAvailability = new model.AvailabilityModel();
            var showModal = function () {
              util.showModal({
                template: '<availability-details class="sked-modal-container" timezone="timezone" availability="availability" resource="resource" config-data="configData" is-available="isAvailable" on-close="onClose(this, message)" ></availability-details>',
              }, {
                availability: edittingAvailability,
                resource: resource,
                configData: $ctrl.configData,
                timezone: $ctrl.timezone,
                isAvailable: isAvailable,
                onClose: function (modalScope, message) {
                  modalScope.closeModal();

                  if (message === 'done') {
                    // rebuildScheduleConsole(true);
                    refreshConsole();
                  }
                }
              });
            };
            // var collectOncallTeamMembers = function (availabilityData) {
            //   var oncallTeamMembers = angular.extend([], availabilityData.onCallTeamMembers);

            //   return oncallTeamMembers;
            // };

            if (!availability) {
              edittingAvailability.startDate = angular.copy(day.date);
              edittingAvailability.endDate = angular.copy(day.date);
              edittingAvailability.startTime = startTime || $ctrl.configData.consoleSettings.calendarStart;
              edittingAvailability.endTime = endTime || $ctrl.configData.consoleSettings.calendarEnd;

              showModal();
            } else {
              edittingAvailability = angular.extend(edittingAvailability, availability);

              if (isAvailable === undefined || isAvailable === null) {
                isAvailable = (availability.eventTypeSettings) ? !!availability.eventTypeSettings.isAvailable : false;
              }

              showLoading();
              getEventDetails(edittingAvailability)
                .then(function (results) {
                  if (results.success) {
                    // edittingAvailability.members = collectOncallTeamMembers(results.data);
                    showModal();
                  } else {
                    return $q.reject(results);
                  }
                })
                .catch(function (exception) {
                  console.error(exception);
                  if (exception && exception.errorMessage) {
                    util.toastError(exception.errorMessage);
                  }
                })
                .finally(hideLoading);
            }


          };

          // var showOncallAppointmentDetailsModal = function (appointment, resource, day, startTime, endTime, isAvailable) {
          //   var edittingAppointment = new model.OncallAppointmentModel();

          //   if (!appointment) {
          //     edittingAppointment.startDate = angular.copy(day.date);
          //     edittingAppointment.endDate = angular.copy(day.date);
          //     edittingAppointment.startTime = startTime || $ctrl.configData.consoleSettings.calendarStart;
          //     edittingAppointment.endTime = endTime || $ctrl.configData.consoleSettings.calendarEnd;
          //   } else {
          //     edittingAppointment = angular.extend(edittingAppointment, appointment);
          //   }

          //   util.showModal({
          //     template: '<oncall-appointment-details class="sked-modal-container" timezone="timezone" appointment="appointment" resource="resource" config-data="configData" on-close="onClose(this, message)" ></oncall-appointment-details>',
          //   }, {
          //     appointment: edittingAppointment,
          //     resource: resource,
          //     configData: $ctrl.configData,
          //     timezone: $ctrl.timezone,
          //     onClose: function (modalScope, message) {
          //       modalScope.closeModal();

          //       if (message === 'done') {
          //         rebuildScheduleConsole(true);
          //       } 
          //     }
          //   });
          // };

          var showShiftDetailsModal = function (shift, resource, day, startTime, endTime) {
            var shiftType,
              edittingShift = new model.ShiftModel();

            if (!shift) {
              edittingShift.startDate = angular.copy((day) ? day.date : $ctrl.calStartDate);
              edittingShift.endDate = angular.copy((day) ? day.date : $ctrl.calStartDate);
              edittingShift.startTime = startTime || $ctrl.configData.consoleSettings.calendarStart;
              edittingShift.endTime = endTime || $ctrl.configData.consoleSettings.calendarEnd;

              if ($ctrl.location) {
                edittingShift.location = $ctrl.location;

                if ($ctrl.location.address) {
                  edittingShift.address = $ctrl.location.address;
                }
              }
            } else {
              edittingShift = angular.extend(edittingShift, shift);
            }

            if (resource) {
              shiftType = SHIFT_TYPE.RESOURCE_SHIFT;
            } else {
              shiftType = SHIFT_TYPE.LOCATION_SHIFT;
            }

            util.showModal({
              template: '<shift-details class="sked-modal-container" region="region" timezone="timezone" shift="shift" config-data="configData" on-close="onClose(this, message)" shift-type="shiftType" resource="resource"></shift-details>',
            }, {
              SHIFT_TYPE: SHIFT_TYPE,
              shift: edittingShift,
              resource: resource,
              shiftType: shiftType,
              configData: $ctrl.configData,
              region: $ctrl.region,
              timezone: $ctrl.timezone,
              onClose: function (modalScope, message) {
                modalScope.closeModal();

                if (message === 'done') {
                  rebuildScheduleConsole(true);
                } else if (message === 'allocating') {
                  showShiftAllocationModal(shift);
                }
              }
            });
          };

          var showActivityDetailsModal = function (activity, resource, day, startTime, endTime) {
            var edittingActivity = new model.EventModel();

            if (!activity) {
              edittingActivity.startDate = angular.copy(day.date);
              edittingActivity.endDate = angular.copy(day.date);
              edittingActivity.startTime = startTime || $ctrl.configData.consoleSettings.calendarStart;
              edittingActivity.endTime = endTime || $ctrl.configData.consoleSettings.calendarEnd;
            } else {
              edittingActivity = angular.extend(edittingActivity, activity);
            }


            util.showModal({
              template: '<activity-details class="sked-modal-container" timezone="timezone" activity="activity" resource="resource" config-data="configData" on-close="onClose(this, message)" ></activity-details>',
            }, {
              activity: edittingActivity,
              resource: resource,
              configData: $ctrl.configData,
              timezone: $ctrl.timezone,
              onClose: function (modalScope, message) {
                modalScope.closeModal();

                if (message === 'done') {
                  rebuildScheduleConsole(true);
                }
              }
            });
          };

          var showAvailabilityPatternDetailsModal = function (availabilityPatternItem) {
            var availabilityPattern;
            var showModal = function (availPattern) {
              util.showModal({
                template: [
                  '<availability-pattern-details',
                  'class="sked-modal-container"',
                  'on-close="onClose(this, message)"',
                  'on-save="onSave(this, params)"',
                  'config-data="configData"',
                  'regions="regions"',
                  'availability-pattern="availabilityPattern">',
                  '</availability-pattern-details>'
                ].join(' ')
              }, {
                configData: $ctrl.configData,
                regions: $ctrl.regions,
                availabilityPattern: availPattern,

                onClose: function (modalScope, message) {
                  modalScope.closeModal();

                  if (message === 'done') {
                    refreshConsole();
                  }
                },
                onSave: function (modalScope, params) {
                  return saveAvailabilityPattern(params);
                }
              });
            };

            if (availabilityPatternItem && availabilityPatternItem.patternResource &&
              availabilityPatternItem.patternResource.availabilityPattern &&
              availabilityPatternItem.patternResource.availabilityPattern.id) {
              availabilityPattern = availabilityPatternItem.patternResource.availabilityPattern;
              showLoading();
              getPatternDetails(availabilityPattern.id)
                .then(function (results) {
                  if (results.success) {
                    showModal(model.AvailabilityPatternModel.fromServer(results.data));
                  } else {
                    return $q.reject(results);
                  }
                })
                .catch(function (exception) {
                  console.error(exception);
                  if (exception && exception.errorMessage) {
                    util.toastError(exception.errorMessage);
                  }
                })
                .finally(hideLoading);
            } else {
              showModal(new model.AvailabilityPatternModel());
            }
          };

          var saveAvailabilityPattern = function (params) {
            return doSaveAvailabilityPattern(params)
              .then(function (result) {
                if (result.success) {
                  return true;
                } else {
                  return $q.reject(result);
                }
              })
              .catch(function (exception) {
                if (exception !== 'cancel') {
                  console.error(exception);
                  if (exception && exception.errorMessage) {
                    util.toastError(exception.errorMessage);
                  }
                }
              });
          };

          var showEventDetailsModal = function (event, resource, day) {
            if (event) {
              switch (event.objectType) {
              case OBJECT_TYPE.AVAILABILITY:
                showAvailabilityDetailsModal(event, resource, day);
                break;
              case OBJECT_TYPE.ACTIVITY:
                showActivityDetailsModal(event, resource, day);
                break;
              case OBJECT_TYPE.TEMPLATE_ENTRY:
                showAvailabilityPatternDetailsModal(event, resource, day);
                break;
              }
            }
          };

          var showScheduleDetailsModal = function (event) {
            util.showModal({
              template: '<schedule-details class="sked-modal-container" event="event" timezone="timezone" schedule-id="scheduleId" resource="resource" config-data="configData" on-close="onClose(this, message)" ></schedule-details>',
            }, {
              event: event,
              scheduleId: event.scheduleId,
              configData: $ctrl.configData,
              timezone: $ctrl.timezone,
              onClose: function (modalScope, message) {
                modalScope.closeModal();

                if (message === 'done') {
                  rebuildScheduleConsole(true);
                }
              }
            });
          };

          var showDeleteEventConfirmationBox = function (event) {
            var objectTypeLabel, doDeleteEvent, eventParams;
            if (event && event.id) {
              switch (event.objectType) {
              case OBJECT_TYPE.AVAILABILITY:
                objectTypeLabel = (event.eventType && event.eventTypeSettings && event.eventTypeSettings.isAvailable) ? 'Availability' : 'Unavailability';
                eventParams = event.toServer();
                doDeleteEvent = doDeleteAvailability;
                break;
              case OBJECT_TYPE.ACTIVITY:
                objectTypeLabel = 'Activity';
                eventParams = event.toActivityServer();
                doDeleteEvent = doDeleteActivity;
                break;
              default:
                objectTypeLabel = 'Event';
                break;
              }

              util.showModal({
                templateUrl: 'src/app/resource-availability-console/rac-delete-event-confirm-modal.tpl.html',
              }, {
                EDIT_RECURRING_ACTION: EDIT_RECURRING_ACTION,
                AVAILABILITY_TYPE: constants.AVAILABILITY_TYPE,
                title: 'Delete ' + objectTypeLabel + '?',
                message: 'Are you sure you want to delete this ' + objectTypeLabel.toLowerCase() + '?',
                event: event,
                editRecurringAction: EDIT_RECURRING_ACTION.ONLY_ME
              })
                .then(function (result) {
                  var recurringOptions = null;
                  if (result !== 'cancel') {
                    if (angular.isFunction(doDeleteEvent)) {
                      if (result.editRecurringAction && result.editRecurringAction.value !== EDIT_RECURRING_ACTION.ONLY_ME.value) {
                        recurringOptions = {
                          editAction: result.editRecurringAction.value
                        };
                      }
                      eventParams.timezoneSidId = $ctrl.timezone.label;

                      showLoading();
                      return doDeleteEvent({
                        event: eventParams,
                        recurringOptions: recurringOptions,
                        // deleteAction: ((event.eventType.id === constants.AVAILABILITY_TYPE.ON_CALL)?(result.applyChangesToAllMembers?'allMember':'outTeam'):null)
                      });
                    }
                  }

                  return $q.reject(result);
                })
                .then(function (result) {
                  if (result.success) {
                    util.toastSuccess(objectTypeLabel + ' has been deleted successfully.');
                    // return rebuildScheduleConsole(true);
                    refreshConsole();
                  } else {
                    return $q.reject(result);
                  }
                })
                .catch(function (exception) {
                  if (exception !== 'cancel') {
                    console.error(exception);
                    if (exception && exception.errorMessage) {
                      util.toastError(exception.errorMessage);
                    }
                  }
                })
                .finally(function () {
                  hideLoading();
                });
            }
          };

          var showDeclineEventConfirmationBox = function (event) {
            var objectTypeLabel, doneActionText, actionLabel, performAction, eventParams;
            var action = 'decline';

            performAction = doDeclineAvailability;
            actionLabel = 'Decline';
            doneActionText = 'declined';

            if (event && event.id) {
              switch (event.objectType) {
              case OBJECT_TYPE.AVAILABILITY:
                objectTypeLabel = (event.eventType && event.eventTypeSettings && event.eventTypeSettings.isAvailable) ? 'Availability' : 'Unavailability';
                eventParams = event.toServer();
                break;
              default:
                objectTypeLabel = 'Event';
                break;
              }

              util.showModal({
                templateUrl: 'src/app/resource-availability-console/rac-decline-event-confirm-modal.tpl.html',
              }, {
                EDIT_RECURRING_ACTION: EDIT_RECURRING_ACTION,
                title: actionLabel + ' ' + objectTypeLabel + '?',
                message: 'Are you sure you want to ' + action + ' this ' + objectTypeLabel.toLowerCase() + '?',
                event: event,
                editRecurringAction: EDIT_RECURRING_ACTION.ONLY_ME,
                configData: $ctrl.configData,
                confirm: function (modalScope) {
                  modalScope.declineRequestForm.$setSubmitted(true);
                  if (modalScope.declineRequestForm.$invalid) {
                    util.toastError('Please provide reason for declining this request.');
                  } else {
                    modalScope.closeModal({
                      confirmed: true,
                      editRecurringAction: modalScope.editRecurringAction,
                      declineReason: modalScope.declineReason,
                      otherDeclineReason: modalScope.otherDeclineReason
                    });
                  }
                }
              })
                .then(function (result) {
                  var recurringOptions = null;

                  if (result && result.confirmed) {
                    if (angular.isFunction(performAction)) {
                      if (result.editRecurringAction && result.editRecurringAction.value !== EDIT_RECURRING_ACTION.ONLY_ME.value) {
                        recurringOptions = {
                          editAction: result.editRecurringAction.value
                        };
                      }

                      eventParams.timezoneSidId = $ctrl.timezone.label;
                      eventParams.declineReason = result.declineReason || '';
                      eventParams.otherDeclineReason = result.otherDeclineReason || '';

                      showLoading();
                      return performAction({
                        event: eventParams,
                        recurringOptions: recurringOptions
                      });
                    }
                  }

                  return $q.reject(result);
                })
                .then(function (result) {
                  if (result.success) {
                    util.toastSuccess(objectTypeLabel + ' has been ' + doneActionText + ' successfully.');
                    refreshConsole();
                  } else {
                    return $q.reject(result);
                  }
                })
                .catch(function (exception) {
                  if (exception !== 'cancel') {
                    if (exception && exception.errorMessage) {
                      util.toastError(exception.errorMessage);
                    }
                  }
                })
                .finally(function () {
                  hideLoading();
                });
            }
          };

          var generateJobURL = function (jobId) {
            if ($ctrl.configData.jobURL.includes('{jobId}')) {
              return $ctrl.configData.jobURL.replace('{jobId}', jobId);
            }

            return $ctrl.configData.jobURL + jobId;
          };

          var showApproveEventConfirmationBox = function (event) {
            var objectTypeLabel, performAction, eventParams, actionLabel, doneActionText;
            if (event && event.id) {
              switch (event.objectType) {
              case OBJECT_TYPE.AVAILABILITY:
                objectTypeLabel = (event.eventType && event.eventTypeSettings && event.eventTypeSettings.isAvailable) ? 'Availability' : 'Unavailability';
                eventParams = event.toServer();
                performAction = doApproveAvailability;
                doneActionText = 'approved';
                actionLabel = 'Approve';
                break;
              default:
                objectTypeLabel = 'Event';
                break;
              }

              if (!performAction) return;

              util.showModal({
                templateUrl: 'src/app/resource-availability-console/rac-approve-event-confirm-modal.tpl.html',
              }, {
                EDIT_RECURRING_ACTION: EDIT_RECURRING_ACTION,
                title: actionLabel + ' ' + objectTypeLabel + '?',
                message: 'Are you sure you want to ' + actionLabel.toLowerCase() + ' this ' + objectTypeLabel.toLowerCase() + '?',
                event: event,
                editRecurringAction: EDIT_RECURRING_ACTION.ONLY_ME,
                configData: $ctrl.configData,
                confirm: function (modalScope) {
                  modalScope.closeModal({
                    confirmed: true,
                    editRecurringAction: modalScope.editRecurringAction
                  });
                }
              })
                .then(function (result) {
                  var recurringOptions = null;

                  if (result && result.confirmed) {
                    if (angular.isFunction(performAction)) {
                      if (result.editRecurringAction && result.editRecurringAction.value !== EDIT_RECURRING_ACTION.ONLY_ME.value) {
                        recurringOptions = {
                          editAction: result.editRecurringAction.value
                        };
                      }

                      eventParams.timezoneSidId = $ctrl.timezone.label;

                      showLoading();
                      return performAction({
                        event: eventParams,
                        recurringOptions: recurringOptions
                      });
                    }
                  }

                  return $q.reject(result);
                })
                .then(function (result) {
                  if (result.success) {
                    util.toastSuccess(objectTypeLabel + ' has been ' + doneActionText + ' successfully.');
                    refreshConsole();
                  } else {
                    return $q.reject(result);
                  }
                })
                .catch(function (exception) {
                  if (exception !== 'cancel') {
                    if (exception && exception.errorMessage) {
                      util.toastError(exception.errorMessage);
                    }
                  }
                })
                .finally(function () {
                  hideLoading();
                });
            }
          };

          var showResourcePeriod = function (resource) {
            $ctrl.selectedResource = {
              resource: resource
            };
            $ctrl.viewMode = CONSOLE_VIEW_MODE.INDIVIDUAL_RESOURCE;

            rebuildScheduleConsole(true);
          };

          var showAllResources = function () {
            if ($ctrl.racType !== RAC_TYPE.RESOURCES || $ctrl.viewMode !== CONSOLE_VIEW_MODE.ALL_RESOURCES) {
              $ctrl.selectedResource = null;

              $ctrl.racType = RAC_TYPE.RESOURCES;
              $ctrl.viewMode = CONSOLE_VIEW_MODE.ALL_RESOURCES;

              rebuildScheduleConsole(true);
            }
          };

          var searchLocations = function (searchString) {
            var results = [];
            if ($ctrl.configData && $ctrl.configData.serviceLocations) {
              results = $ctrl.configData.serviceLocations;

              if (searchString) {
                results = filterFn(results, {
                  name: searchString
                });
              }
            }

            return results;
          };

          var searchTags = function (searchString) {
            if (util.isNullOrEmpty(searchString)) {
              searchString = '';
            }

            return doSearchTags(searchString)
              .then(function (result) {
                if (result.success) {
                  return model.TagModel.fromServerList(result.data);
                } else {
                  return $q.reject(result);
                }
              });
          };

          var searchAvailabilityTemplates = function (searchString) {
            if (util.isNullOrEmpty(searchString)) {
              searchString = '';
            }

            return doSearchAvailabilityTemplates(searchString)
              .then(function (result) {
                if (result.success) {
                  return model.TemplateModel.fromServerList(result.data);
                } else {
                  return $q.reject(result);
                }
              });
          };

          var searchAvailabilityPatterns = function (searchString) {
            if (util.isNullOrEmpty(searchString)) {
              searchString = '';
            }

            return doSearchAvailabilityPatterns(searchString)
              .then(function (result) {
                if (result.success) {
                  return model.AvailabilityPatternModel.fromServerList(result.data);
                } else {
                  return $q.reject(result);
                }
              });
          };

          var searchAddresses = function (searchString) {
            searchString = searchString || '';

            if (searchString.length >= 1) {
              return ggLocationApi.geocode({
                address: searchString
              })
                .then(function (response) {
                  if (response.status === 'OK') {
                    return model.AddressModel.fromGGServerList(response.results);
                  } else {
                    return [];
                  }
                });
            }
          };

          /**
           * event is all day when:
           * startDate !== endDate
           * isAllDay = true
           * startTime <= 0 && endTime >= 2400
           */
          var isAllDayEvent = function (event) {
            var isAllDay = false;
            var checkingEndDate = angular.copy(event.endDate),
              checkingEndTime = event.endTime;

            if (checkingEndTime === 0) {
              checkingEndDate.setDate(checkingEndDate.getDate() - 1);
              checkingEndTime = 2400;
            }

            //isAllDay = event.isAllDay = event.isAllDay || (checkingEndDate.getTime() > event.startDate.getTime()) || (event.startTime === 0 && checkingEndTime === 2400); 
            //isAllDay =  event.isAllDay || (checkingEndDate.getTime() > event.startDate.getTime());
            isAllDay = event.isAllDay || (checkingEndDate.getTime() > event.startDate.getTime()) || (event.startTime === 0 && checkingEndTime === 2400);

            return isAllDay;
          };

          var showLessEvents = function (keepEventInfo) {
            if ($ctrl.resourceDateCell) {
              $ctrl.resourceDateCell.show = false;

              $timeout(function () {
                $ctrl.resourceDateCell = null;
              }, 200);
            }

            if (!keepEventInfo) {
              hideEventInfo();
              hideShiftInfo();
            }
          };

          var showMoreEvents = function (resourceData, day, $event) {
            var currentlyOpened = !!$ctrl.resourceDateCell,
              currentPosition = currentlyOpened ? $ctrl.resourceDateCell.position : null;
            var el = angular.element($event.currentTarget),
              cellEl = el.parents('.resource-date-cell'),
              cellElOffset, posX, posY;

            hideEventInfo();
            hideShiftInfo();

            if (cellEl) {
              cellElOffset = cellEl.offset();

              posX = cellElOffset.left - 32;
              posY = cellElOffset.top - 32;

              $ctrl.resourceDateCell = {
                data: resourceData,
                day: day,
                position: currentPosition,
                show: currentPosition
              };

              $timeout(function () {
                var dateCellEl = angular.element('.hco-rac-resource-date-cell');
                var containerHeight = contentPanelEl.height(),
                  containerWidth = contentPanelEl.width();
                var dateCellElHeight = dateCellEl.height(),
                  dateCellElWidth = dateCellEl.width();

                if (posY + dateCellElHeight > containerHeight) {
                  posY = containerHeight - dateCellElHeight - 16;
                }

                if (posX + dateCellElWidth > containerWidth) {
                  posX = containerWidth - dateCellElWidth - 16;
                }

                $ctrl.resourceDateCell.show = true;
                $ctrl.resourceDateCell.position = {
                  x: posX,
                  y: posY
                };
              });

              if (currentlyOpened) {
                $event.stopPropagation();
              }
            } else {
              $ctrl.resourceDateCell = null;
            }
          };

          var hideEventInfo = function ($event) {
            if ($ctrl.eventInfo) {
              $ctrl.eventInfo.show = false;

              $timeout(function () {
                $ctrl.eventInfo = null;
              }, 200);
            }

            if ($event && $ctrl.resourceDateCell) {
              $event.stopPropagation();
            }
          };

          var showEventInfo = function (event, resource, day, $event, showByMousePos, keepShowingMore) {
            var currentlyOpened = !!$ctrl.eventInfo,
              currentPosition = currentlyOpened ? $ctrl.eventInfo.position : null;
            var el = angular.element($event.currentTarget),
              elWidth,
              // elHeight, 
              elOffset, posX, posY, mouseOffsetX;

            hideShiftInfo();

            mouseOffsetX = $event.offsetX;

            elOffset = el.offset();
            elWidth = el.width();
            // elHeight = el.height();

            if (showByMousePos) {
              posX = elOffset.left + mouseOffsetX + 8;
            } else {
              posX = elOffset.left + elWidth + 8;
            }

            posY = elOffset.top;

            $ctrl.eventInfo = {
              event: event,
              resource: resource,
              day: day,
              position: currentPosition,
              show: currentlyOpened
            };

            if (!keepShowingMore && !!$ctrl.resourceDateCell) {
              currentlyOpened = true;
              showLessEvents(true);
            }

            $timeout(function () {
              var eventInfoEl = angular.element('.hco-rac-event-info');
              var containerHeight = contentPanelEl.height(),
                containerWidth = contentPanelEl.width();
              var eventInfoElHeight = eventInfoEl.height(),
                eventInfoElWidth = eventInfoEl.width();

              posY -= (eventInfoElHeight / 2);

              if (posY < 0) {
                posY = 8;
              } else if (posY + eventInfoElHeight > containerHeight) {
                posY = containerHeight - eventInfoElHeight - 16;
              }

              if (posX + eventInfoElWidth > containerWidth) {
                posX = containerWidth - eventInfoElWidth - 16;
              }

              $ctrl.eventInfo.show = true;
              $ctrl.eventInfo.position = {
                x: posX,
                y: posY
              };
            });

            if (currentlyOpened) {
              $event.stopPropagation();
            }
          };

          var hideShiftInfo = function ($event) {
            if ($ctrl.shiftInfo) {
              $ctrl.shiftInfo.show = false;

              $timeout(function () {
                $ctrl.shiftInfo = null;
              }, 200);
            }

            if ($event && $ctrl.resourceDateCell) {
              $event.stopPropagation();
            }
          };

          var showShiftInfo = function (shift, resource, day, $event, showByMousePos, keepShowingMore) {
            var currentlyOpened = !!$ctrl.shiftInfo,
              currentPosition = currentlyOpened ? $ctrl.shiftInfo.position : null;
            var el = angular.element($event.currentTarget),
              elWidth,
              // elHeight, 
              elOffset, posX, posY, mouseOffsetX;

            hideEventInfo();

            mouseOffsetX = $event.offsetX;

            elOffset = el.offset();
            elWidth = el.width();
            // elHeight = el.height();

            if (showByMousePos) {
              posX = elOffset.left + mouseOffsetX + 8;
            } else {
              posX = elOffset.left + elWidth + 8;
            }

            posY = elOffset.top;

            $ctrl.shiftInfo = {
              shift: shift,
              resource: resource,
              day: day,
              position: currentPosition,
              show: currentlyOpened
            };

            if (!keepShowingMore && !!$ctrl.resourceDateCell) {
              currentlyOpened = true;
              showLessEvents(true);
            }

            $timeout(function () {
              var eventInfoEl = angular.element('.hco-rac-shift-info');
              var containerHeight = contentPanelEl.height(),
                containerWidth = contentPanelEl.width();
              var eventInfoElHeight = eventInfoEl.height(),
                eventInfoElWidth = eventInfoEl.width();

              posY -= (eventInfoElHeight / 2);

              if (posY < 0) {
                posY = 8;
              } else if (posY + eventInfoElHeight > containerHeight) {
                posY = containerHeight - eventInfoElHeight - 16;
              }

              if (posX + eventInfoElWidth > containerWidth) {
                posX = containerWidth - eventInfoElWidth - 16;
              }

              $ctrl.shiftInfo.show = true;
              $ctrl.shiftInfo.position = {
                x: posX,
                y: posY
              };
            });

            if (currentlyOpened) {
              $event.stopPropagation();
            }
          };

          var hideAddEventMenu = function () {
            if ($ctrl.addEventParams) {
              $ctrl.addEventParams.show = false;

              $timeout(function () {
                $ctrl.addEventParams = null;
              }, 200);
            }
          };

          var showAddEventMenu = function (resource, day, startTimeslot, endTimeslot, $event) {
            var currentlyOpened = !!$ctrl.addEventParams,
              currentPosition = currentlyOpened ? $ctrl.addEventParams.position : null;
            var el = angular.element($event.currentTarget),
              elWidth,
              // elHeight, 
              elOffset, posX, posY;

            elOffset = el.offset();
            elWidth = el.width();
            // elHeight = el.height();

            posX = elOffset.left + elWidth + 8;
            posY = elOffset.top - 8;

            $ctrl.addEventParams = {
              resource: resource,
              day: day,
              startTimeslot: startTimeslot,
              endTimeslot: endTimeslot,
              position: currentPosition,
              show: currentlyOpened
            };

            $timeout(function () {
              var addEventEl = angular.element('.hco-rac-add-event');
              var containerHeight = contentPanelEl.height(),
                containerWidth = contentPanelEl.width();
              var addEventElHeight = addEventEl.height(),
                addEventElWidth = addEventEl.width();

              if (posY + addEventElHeight > containerHeight) {
                posY = containerHeight - addEventElHeight - 8;
              }

              if (posX + addEventElWidth > containerWidth) {
                posX = containerWidth - addEventElWidth - 8;
              }

              $ctrl.addEventParams.show = true;
              $ctrl.addEventParams.position = {
                x: posX,
                y: posY
              };
            });

            if (currentlyOpened) {
              $event.stopPropagation();
            }
          };

          var showResourceWorkingTemplate = function (resource) {
            util.showModal({
              template: '<resouce-working-template class="sked-modal-container" region="region" timezone="timezone" resource="resource" config-data="configData" on-close="onClose(this, message)" ></resouce-working-template>',
            }, {
              resource: resource,
              configData: $ctrl.configData,
              region: $ctrl.region,
              timezone: $ctrl.timezone,
              onClose: function (modalScope, message) {
                modalScope.closeModal();

                if (message === 'done') {
                  rebuildScheduleConsole(true);
                }
              }
            });
          };

          /**
           * controller init
           */
          $ctrl.$onInit = function () {
            showLoading();
            $q.all([
              getInitialData()
            ])
              .then(function (results) {
                var configData = results[0];

                // init default date
                initializeControls(configData);
                initializeServiceLocations(configData);
                initializeEventTypes(configData);
                initializeFilters(configData);

                return results;
              })
              .then(function (results) {
                var configData = results[0];

                // days
                if (angular.isDate($ctrl.calStartDate)) {
                  $ctrl.days = calculateCalendarDays($ctrl.calStartDate);
                }

                // timeslots
                if (configData.consoleSettings) {
                  $ctrl.timeslots = util.calculateCalendarTimeslots(configData.consoleSettings);
                  $ctrl.isShiftEnabled = !!configData.consoleSettings.enableShift;
                }
              })
              .catch(function (exception) {
                console.error(exception);
                if (exception && exception.errorMessage) {
                  util.toastError(exception.errorMessage);
                }
              })
              .finally(function () {
                hideLoading();
              });
          };

          var initializeControls = function (configData) {
            // init week picker
            weekPickerOptions.firstDay = getFirstDay();
            $ctrl.weekPickerOptions = weekPickerOptions;

            // init date options
            if (configData.consoleSettings) {
              configData.commonDateOptions = {
                firstDay: configData.consoleSettings.firstDay || 0,
                dateFormat: configData.consoleSettings.datePickerFormat || 'MM/dd/yyyy'
              };
            } else {
              configData.commonDateOptions = {};
            }
          };

          var initializeServiceLocations = function (configData) {
            var regionIds = configData.regions.map(function (region) {
              return region.id;
            });

            // map service location with regions
            angular.forEach(configData.serviceLocations, function (serviceLocation) {
              var regionIdx;

              if (serviceLocation.region) {
                regionIdx = regionIds.indexOf(serviceLocation.region.id);

                if (regionIdx > -1) {
                  serviceLocation.region = configData.regions[regionIdx];
                }
              }
            });
          };

          var initializeEventTypes = function (configData) {
            var eventTypeSettings = angular.copy(configData.eventTypeSettings) || [];

            // process availability types
            configData.availabilityStatusSettings = {}; // for legends showing only
            angular.forEach(configData.availabilityTypes, function (availabilityType) {
              var tmpEventStatus;

              availabilityType.eventTypeSettings = {};

              for (var j = 0; j < eventTypeSettings.length; j++) {
                if (eventTypeSettings[j].eventType === availabilityType.id) {
                  tmpEventStatus = eventTypeSettings[j].eventStatus;

                  if (tmpEventStatus) {
                    availabilityType.eventTypeSettings[tmpEventStatus] = eventTypeSettings[j];
                    availabilityType.eventTypeSettings[tmpEventStatus].showLegend = false; // AHI-203: force hiding all availability types with status included

                    if (!configData.availabilityStatusSettings[tmpEventStatus]) {
                      configData.availabilityStatusSettings[tmpEventStatus] = eventTypeSettings[j];
                    }
                  } else {
                    availabilityType.eventTypeSettings[DEFAULT_EVENT_STATUS] = eventTypeSettings[j];
                  }

                  availabilityType.isAvailable = eventTypeSettings[j].isAvailable;
                  availabilityType.isActive = !!eventTypeSettings[j];

                  eventTypeSettings.splice(j, 1);
                  j--;
                }
              }
            });

            // process activity types
            angular.forEach(configData.activityTypes, function (activityType) {
              activityType.eventTypeSettings = {};

              for (var j = 0; j < eventTypeSettings.length; j++) {
                if (eventTypeSettings[j].eventType === activityType.id) {
                  activityType.eventTypeSettings[eventTypeSettings[j].eventStatus || DEFAULT_EVENT_STATUS] = eventTypeSettings[j];
                  activityType.isActive = !!eventTypeSettings[j];
                  eventTypeSettings.splice(j, 1);
                  j--;
                }
              }
            });

            // process job types
            angular.forEach(configData.jobTypes, function (jobType) {
              jobType.eventTypeSettings = {};

              for (var j = 0; j < eventTypeSettings.length; j++) {
                if (eventTypeSettings[j].eventType === jobType.id) {
                  jobType.eventTypeSettings[eventTypeSettings[j].eventStatus || DEFAULT_EVENT_STATUS] = eventTypeSettings[j];
                  eventTypeSettings.splice(j, 1);
                  j--;
                }
              }
            });

            // process other event types
            configData.otherEventTypes = [];
            if (eventTypeSettings.length > 0) {
              angular.forEach(eventTypeSettings, function (settings) {
                configData.otherEventTypes.push({
                  id: settings.eventType,
                  name: settings.eventType,
                  eventTypeSettings: {
                    DEFAULT_EVENT_STATUS: settings
                  }
                });
              });
            }
          };

          var initializeFilters = function (configData) {
            var filterSavingData = null;

            if (configData &&
              configData.consoleSettings &&
              configData.consoleSettings.filters &&
              configData.consoleSettings.filters.jsonData) {
              try {
                filterSavingData = JSON.parse(configData.consoleSettings.filters.jsonData);
              } catch (exception) {
                console.error('Could not parse filter saving data', exception);
                filterSavingData = null;
              }
            }

            // init regions filter
            if (filterSavingData &&
              angular.isArray(filterSavingData.regionIds) &&
              filterSavingData.regionIds.length > 0) {
              $ctrl.regions = configData.regions.filter(function (region) {
                return filterSavingData.regionIds.indexOf(region.id) > -1;
              });
            } else {
              // select all regions by default
              $ctrl.regions = angular.extend([], configData.regions);
            }

            // init timezone filter
            if (filterSavingData && filterSavingData.timezoneSidId) {
              $ctrl.timezone = configData.timezones.find(function (timezone) {
                return timezone.id === filterSavingData.timezoneSidId;
              });
            } else {
              // select default timezone
              $ctrl.timezone = configData.timezones.find(function (timezone) {
                return !!timezone.selected;
              });
            }

            // init calendar date
            if (filterSavingData &&
              angular.isArray(filterSavingData.inputDates) &&
              filterSavingData.inputDates.length > 0) {
              $ctrl.date = dateUtil.parseDateString(filterSavingData.inputDates[0]);
            } else {
              // select today as default date
              $ctrl.date = new Date();
            }
            $ctrl.date.setHours(0, 0, 0, 0);

            // init gemstone teams filter
            // TODO: apply resource filter
            /*if (filterSavingData && 
              angular.isArray(filterSavingData.gemstoneTeamIds) &&
              filterSavingData.gemstoneTeamIds.length > 0) {

              $ctrl.resourcesFilters.gemstoneTeamTags = configData.gemstoneTeams.filter(function (gsTeam) {
                return filterSavingData.gemstoneTeamIds.indexOf(gsTeam.id) > -1;
              });

              applyResourceFilters();
            }*/
          };

          var attachScrollingEvent = function (el) {
            if (angular.isString(el)) {
              el = angular.element(el);
            }

            if (el && el.length > 0) {
              el.scroll(handleContainerScrolling);
            }
          };

          var handleContainerScrolling = function () {
            if (($ctrl.resourceDateCell && $ctrl.resourceDateCell.show) ||
              ($ctrl.eventInfo && $ctrl.eventInfo.show) ||
              ($ctrl.shiftInfo && $ctrl.shiftInfo.show) ||
              ($ctrl.addEventParams && $ctrl.addEventParams.show)) {
              $scope.$apply(function () {
                showLessEvents(false);
                hideAddEventMenu();
              });
            }
          };

          var refreshConsole = function () {
            if ($ctrl.racType === RAC_TYPE.RESOURCES) {
              return rebuildScheduleConsole(true);
            } else {
              $timeout(function () {
                $scope.$broadcast('rac:refreshConsole');
              });
            }
          };

          var getFirstDay = function () {
            var firstDay = 0;

            if ($ctrl.configData && $ctrl.configData.consoleSettings && $ctrl.configData.consoleSettings.firstDay > 0) {
              firstDay = $ctrl.configData.consoleSettings.firstDay;
            }

            return firstDay;
          };

          var applyResourceFilters = function () {
            $ctrl.appliedResourcesFilters = {
              availabilityPatternId: $ctrl.resourcesFilters.availabilityPattern ? $ctrl.resourcesFilters.availabilityPattern.id : null,
              tagIds: $ctrl.resourcesFilters.tags.map(function (tag) {
                return tag.id;
              }),
              resourceEmploymentTypes: $ctrl.resourcesFilters.resourceEmploymentTypes.map(function (employmentType) {
                return employmentType.id;
              }),
              resourceCategories: $ctrl.resourcesFilters.resourceCategories.map(function (resourceCategory) {
                return resourceCategory.id;
              })
            };

            $ctrl.resourcesFiltersApplied = $ctrl.appliedResourcesFilters.tagIds.length !== 0 ||
              $ctrl.appliedResourcesFilters.resourceEmploymentTypes.length !== 0 ||
              $ctrl.appliedResourcesFilters.resourceCategories.length !== 0;
          };

          var resetResourceFilters = function () {
            $ctrl.resourcesFilters = {
              availabilityPattern: null,
              tags: [],
              resourceEmploymentTypes: [],
              resourceCategories: []
            };

            applyResourceFilters();
          };

          var handleAvailabilityRequestListMenuClick = function (availability, action) {
            switch (action) {
            case 'approve':
              showApproveEventConfirmationBox(availability);
              break;
            case 'decline':
              showDeclineEventConfirmationBox(availability);
              break;
            case 'edit':
              showAvailabilityDetailsModal(availability, availability.resource);
              break;
            case 'delete':
              showDeleteEventConfirmationBox(availability);
              break;
            }
          };

          /**
           * scope init
           */
          (function init() {
            var elWindow = angular.element($window);

            contentPanelEl = angular.element('.hco-rac-page.main-rac-page');

            $scope.EVENTS_LIMIT = EVENTS_LIMIT;
            $scope.DEFAULT_PHOTO_URL = DEFAULT_PHOTO_URL;
            $scope.GRID_SETTINGS = GRID_SETTINGS;
            $scope.OBJECT_TYPE = OBJECT_TYPE;
            $scope.CONSOLE_VIEW_MODE = CONSOLE_VIEW_MODE;
            $scope.AVAILABILITY_STATUS = constants.AVAILABILITY_STATUS;
            $scope.AVAILABILITY_TYPE = constants.AVAILABILITY_TYPE;
            $scope.RAC_TYPE = RAC_TYPE;

            $ctrl.today = new Date();
            $ctrl.date = null;
            $ctrl.calStartDate = null;
            $ctrl.timezone = null;
            $ctrl.regions = [];
            $ctrl.configData = null;
            // $ctrl.onCallTeams = null;
            $ctrl.scheduleData = null; // processed by page
            $ctrl.rawResourcesData = null; // processed by page
            $ctrl.filteredResourcesData = null; // processed by page
            $ctrl.availabilityTemplates = [];
            $ctrl.days = [];
            $ctrl.timeslots = [];
            $ctrl.viewMode = CONSOLE_VIEW_MODE.ALL_RESOURCES;
            $ctrl.selectedResource = null;
            $ctrl.location = null;

            $ctrl.moveBack = moveBack;
            $ctrl.moveNext = moveNext;

            $ctrl.isInPast = isInPast;

            $ctrl.showAvailabilityDetailsModal = showAvailabilityDetailsModal;
            $ctrl.showActivityDetailsModal = showActivityDetailsModal;
            // $ctrl.showOncallAppointmentDetailsModal = showOncallAppointmentDetailsModal;
            $ctrl.showAvailabilityPatternDetailsModal = showAvailabilityPatternDetailsModal;
            $ctrl.showEventDetailsModal = showEventDetailsModal;
            $ctrl.showScheduleDetailsModal = showScheduleDetailsModal;
            $ctrl.showDeleteEventConfirmationBox = showDeleteEventConfirmationBox;
            $ctrl.showDeclineEventConfirmationBox = showDeclineEventConfirmationBox;
            $ctrl.showApproveEventConfirmationBox = showApproveEventConfirmationBox;
            $ctrl.showResourcePeriod = showResourcePeriod;
            $ctrl.showAllResources = showAllResources;
            //$ctrl.filterResources = filterResources;
            $ctrl.showMoreEvents = showMoreEvents;
            $ctrl.showLessEvents = showLessEvents;
            $ctrl.attachScrollingEvent = attachScrollingEvent;
            $ctrl.showEventInfo = showEventInfo;
            $ctrl.hideEventInfo = hideEventInfo;
            $ctrl.hideAddEventMenu = hideAddEventMenu;
            $ctrl.showAddEventMenu = showAddEventMenu;
            $ctrl.showShiftInfo = showShiftInfo;
            $ctrl.hideShiftInfo = hideShiftInfo;

            $ctrl.resourcesFilterString = '';
            $ctrl.resourcesPaginModel = {
              recordCountOptions: [5, 10, 15, 20, 25],
              recordsPerPage: 25,
              pageNumber: 1,
              numberOfPages: 0
            };

            $ctrl.resourcesFilters = {
              availabilityPattern: null,
              tags: [],
              resourceEmploymentTypes: [],
              resourceCategories: [],
              resourceTypes: [],
              categoriesSources: []
            };
            $ctrl.appliedResourcesFilters = {
              availabilityPatternId: null,
              tagIds: [],
              resourceEmploymentTypes: [],
              resourceCategories: []
            };

            $ctrl.resourceDateCell = null;
            $ctrl.eventInfo = null;
            $ctrl.shiftInfo = null;
            $ctrl.addEventParams = null;

            $ctrl.isShiftEnabled = false;
            $ctrl.showShiftDetailsModal = showShiftDetailsModal;

            $ctrl.refreshConsole = refreshConsole;
            $ctrl.searchLocations = searchLocations;

            $ctrl.showShiftAllocationModal = showShiftAllocationModal;

            $ctrl.showResourceWorkingTemplate = showResourceWorkingTemplate;

            $ctrl.focusInput = focusInput;
            $ctrl.formatWeekPickerDates = formatWeekPickerDates;

            $ctrl.generateJobURL = generateJobURL;
            //$ctrl.weekPickerOptions = weekPickerOptions;

            $ctrl.resourcesFilters = {
              tags: [],
              resourceEmploymentTypes: [],
              resourceCategories: []
            };
            $ctrl.appliedResourcesFilters = {
              tagIds: [],
              resourceEmploymentTypes: [],
              resourceCategories: []
            };
            $ctrl.resourcesFiltersApplied = false;
            $ctrl.searchTags = searchTags;
            $ctrl.searchAvailabilityTemplates = searchAvailabilityTemplates;
            $ctrl.searchAvailabilityPatterns = searchAvailabilityPatterns;
            $ctrl.searchAddresses = searchAddresses;
            $ctrl.applyResourceFilters = applyResourceFilters;
            $ctrl.resetResourceFilters = resetResourceFilters;

            $ctrl.racType = searchParams.tab || RAC_TYPE.RESOURCES;
            $ctrl.handleAvailabilityRequestListMenuClick = handleAvailabilityRequestListMenuClick;

            /**
             * watch start date changed
             */
            $scope.$watch('$ctrl.date', function (newVal
              // , oldVal
            ) {
              if (newVal && angular.isDate(newVal)) {
                $ctrl.calStartDate = angular.copy(newVal);
                $ctrl.calStartDate.setDate($ctrl.calStartDate.getDate() - (($ctrl.calStartDate.getDay() + 7 - getFirstDay()) % 7));
              } else {
                $ctrl.calStartDate = null;
              }
            }, true);

            /**
             * watch start date changed
             */
            $scope.$watchGroup([
              '$ctrl.calStartDate',
              '$ctrl.today',
            ], function (values) {
              if (values && values[0] && angular.isDate(values[0])) {
                $ctrl.days = calculateCalendarDays(values[0]);
              } else {
                $ctrl.days = [];
              }
            });

            $scope.$watch('$ctrl.location', function (newLocation) {
              if (newLocation) {
                $ctrl.regions.splice(0, $ctrl.regions.length);

                if (newLocation.region) {
                  $ctrl.regions.push(newLocation.region);
                }
              }
            });


            $scope.$watch('$ctrl.resourcesFilterString', function (
              // newVal
            ) {
              $ctrl.resourcesPaginModel.pageNumber = 1;
            });
            $scope.$watch('$ctrl.appliedResourcesFilters', function (
              // newVal
            ) {
              $ctrl.resourcesPaginModel.pageNumber = 1;
            });

            $scope.$watchGroup([
              '$ctrl.timezone',
              //'$ctrl.regions',
              '$ctrl.location',
              '$ctrl.days',
              '$ctrl.resourcesPaginModel.pageNumber',
              '$ctrl.resourcesPaginModel.recordsPerPage',
              '$ctrl.resourcesFilterString',
              '$ctrl.appliedResourcesFilters'
            ], function () {
              if ($ctrl.racType === RAC_TYPE.RESOURCES) {
                rebuildScheduleConsole();
              }
            });

            $scope.$watchCollection('$ctrl.regions', function (newRegions) {
              if (newRegions.length !== 1 || ($ctrl.location && $ctrl.location.region !== newRegions[0])) {
                $ctrl.location = null;
              }

              if ($ctrl.racType === RAC_TYPE.RESOURCES) {
                rebuildScheduleConsole();
              }
            });
            /*$scope.$watchGroup([
              '$ctrl.resourcesPaginModel.pageNumber',
              '$ctrl.resourcesPaginModel.recordsPerPage'], function () {
              if ($ctrl.viewMode === CONSOLE_VIEW_MODE.ALL_RESOURCES) {
                applyResourcesPagin($ctrl.filteredResourcesData);
              }
            });*/

            attachScrollingEvent(elWindow);
          })();
        }
      ]
    });
})(angular, jQuery);