(function (angular) {
  angular.module('hltApp')
    .component('patternResourceAllocationModal', {
      templateUrl: 'src/app/resource-availability-console/rac-pattern-resource-allocation-modal.tpl.html',
      bindings: {
        event: '=',
        selectedRegionIds: '<',
        patternResources: '<',
        sourceResources: '=?',
        onGetResources: '&?',
        configData: '<',
        onClose: '&',
        onSave: '&?'
      },
      controller: [
        '$scope',
        '$q',
        'util',
        'api',
        'model',
        function ($scope, $q, util, api, model) {
          var $ctrl = this;
          var cachedQuery = {};

          var ORDER_DIR_OPTIONS = {
            ASC: {dirVal: 1, label: 'ASC', reverse: false},
            DESC: {dirVal: -1, label: 'DESC', reverse: true}
          };
          var LIST_COLUMNS = {
            RESOURCE: {label: 'Resource', cssClass: 'col-resource', sortExp: 'name', isSortable: true},
          };

          var closeModal = function (message) {
            $ctrl.isModalOpen = false;
            // run onClose expression
            if (angular.isFunction ($ctrl.onClose)) {
              $ctrl.onClose({
                message: message
              });
            }
          };

          var doGetResources = function (query) {
            return api.getResources(query)
              .catch(api.commonExceptionHanlder);
          };

          var isParamsReallyChanged = function (params, currentParams) {
            return !util.compareValues(params, currentParams);
          };

          /**
				 * show content loading
				 */
          var showLoading = function () {
            $ctrl.contentLoading = true;
          };

          /**
				 * hide content loading
				 */
          var hideLoading = function () {
            $ctrl.contentLoading = false;
          };

          var transformResources = function (resources) {
            angular.forEach(resources, function (resource) {
            });

            return resources;
          };

          var buildGetResourcesQuery = function () {
            return {
              regionIds: $ctrl.filterModel.regions.length === $ctrl.configData.regions.length?null:$ctrl.filterModel.regions.map(function (region) {return region.id;}),
              pageNo: $ctrl.paginModel.pageNumber,
              pageSize: $ctrl.paginModel.recordsPerPage,
              orderBy: $ctrl.orderModel.by.sortExp,
              orderDirection: $ctrl.orderModel.dir.dirVal,
              queryText: $ctrl.filterModel.filterString || '',
            };
          };

          var processInititalData = function () {
            // selected regions
            if (angular.isArray($ctrl.configData.regions) && $ctrl.configData.regions.length > 0 &&
						angular.isArray($ctrl.selectedRegionIds) && $ctrl.selectedRegionIds.length > 0) {
              $ctrl.filterModel.regions =  $ctrl.configData.regions.filter(function (region) {
                return $ctrl.selectedRegionIds.indexOf(region.id) > -1;
              });
            } else {
              $ctrl.filterModel.regions = [];
            }
          };

          var getResources = function (forceFetching) {
            var query = buildGetResourcesQuery();

            if (forceFetching || isParamsReallyChanged(query, cachedQuery)) {
              cachedQuery = query;
              showLoading();
              $q.when(function () {
                if ($ctrl.sourceResources) {
                  return {
                    resources: $ctrl.sourceResources
                  };
                } else {
                  return doGetResources(query)
                    .then(function (result) {
                      var resources;
                      if (result.success) {
                        resources = (result.success && result.data)?model.ResourceModel.fromServerList(result.data.resources):[];
                        return {
                          totalPages: result.data.totalPages || 0,
                          totalRecords: result.data.totalRecords || 0,
                          resources: transformResources(resources)
                        };
                      } else {
                        return $q.reject(result);
                      }
                    });
                }
              }())
                .then(function (data) {
                  $ctrl.resources = data.resources;
                  $ctrl.paginModel.numberOfPages = data.totalPages || 0;
                  $ctrl.paginModel.numberOfRecords = data.totalRecords || 0;
                })
                .catch(function (exception) {
                  console.error(exception);
                  if (exception && exception.errorMessage) {
                    util.toastError(exception.errorMessage);
                  }
                })
                .finally(hideLoading);
            }
					
          };

          var sortList = function (col) {
            if (col.isSortable) {
              if ($ctrl.orderModel.by !== col) {
                $ctrl.orderModel.by = col;
                $ctrl.orderModel.dir = ORDER_DIR_OPTIONS.ASC;
              } else {
                $ctrl.orderModel.dir = ($ctrl.orderModel.dir === ORDER_DIR_OPTIONS.ASC)?ORDER_DIR_OPTIONS.DESC:ORDER_DIR_OPTIONS.ASC;
              }
            }
          };

          var toggleResourceSelection = function (resource, isSelected) {
            var patternResource, resourceId;

            if (resource && resource.id) {
              resourceId = resource.id;
              patternResource = $ctrl.patternResources[resourceId];

              if (patternResource && isSelected !== true) {
                delete $ctrl.patternResources[resourceId];
              } else if (!patternResource && isSelected !== false){
                $ctrl.patternResources[resourceId] = patternResource = new model.AvailabilityPatternResourceModel();
                patternResource.resource = resource;
                patternResource.startDate = new Date();
                patternResource.endDate = null;
              }
            }
          };

          var toggleAllResourcesSelection = function (isAllSelected) {
            if (angular.isArray($ctrl.resources)) {
              if (!angular.isDefined(isAllSelected)) {
                isAllSelected = isAllResourcesSelected();
              }

              angular.forEach($ctrl.resources, function (resource) {
                toggleResourceSelection(resource, !isAllSelected);
              });
            }
          };

          var isAllResourcesSelected = function () {
            var isAllResourcesSelected = false;
					
            if (angular.isArray($ctrl.resources) && $ctrl.resources.length > 0) {
              isAllResourcesSelected = !$ctrl.resources.find(function (resource) {
                return !$ctrl.patternResources[resource.id];
              });
            }

            return isAllResourcesSelected;
          };

          var isResourcesAllocationValid = function () {
            var isInvalid = false;
            var patternResourcesCount = countPatternResources();
            var form = $ctrl.patternResourcesForm;

            if (patternResourcesCount === 0) {
              util.toastError('Please assign at least a resource for the template.');
              isInvalid = true;
            } else if (form) {
              form.$setSubmitted();
              if (form.$invalid) {
                util.toastError('Invalid resource allocation details, please correct and save again.');
                isInvalid = true;
              }
            }

            return !isInvalid;
          };

          var saveResourcesAllocation = function () {
            if (isResourcesAllocationValid()) {
              showLoading();
              $q.when(function () {
                if (angular.isFunction($ctrl.onSave)) {
                  return $ctrl.onSave({patternResources: $ctrl.patternResources});
                } else {
                  return true;
                }
              }()).then(function (isClosing) {
                if (isClosing) {
                  closeModal('done');
                }
              }).finally(hideLoading);
            }
          };

          var countPatternResources = function () {
            var count = 0;
            var patternResources = $ctrl.patternResources;

            if (patternResources) {
              count = Object.keys(patternResources).length;
            }

            return count;
          };

          var dateRangeValidator = {
            dateRange: function (modelValue, modelController, modelScope) {
              var modelName = modelController.$name;
              var patternResource = modelScope.patternResource;
              var startDate = modelName.indexOf('startDate') > -1?modelValue:patternResource.startDate,
                endDate = modelName.indexOf('endDate') > -1?modelValue:patternResource.endDate;
              var isValid = !angular.isDate(startDate) || !angular.isDate(endDate) || startDate < endDate;

              modelController.$$parentForm['patternResource__startDate__' + modelScope.$index].$setValidity('dateRange', isValid);
              modelController.$$parentForm['patternResource__endDate__' + modelScope.$index].$setValidity('dateRange', isValid);

              return isValid;
            }
          };

          /**
				 * controller init
				 * used for setting initial value
				 */
          $ctrl.$onInit = function () {
            $ctrl.commonDateOptions = {
              dateFormat: _.get($ctrl, 'configData.consoleSettings.datePickerFormat', 'MM/dd/yy')
            };

            $ctrl.isModalOpen = true;
            processInititalData();
            getResources();
          };

          /**
				 * init block
				 * used for setting up controller
				 */
          (function () {
            $scope.ORDER_DIR_OPTIONS = ORDER_DIR_OPTIONS;
            $scope.LIST_COLUMNS = LIST_COLUMNS;

            $ctrl.paginModel = {
              recordCountOptions: [5, 10, 15, 20, 25],
              recordsPerPage: 25,
              pageNumber: 1,
              numberOfPages: 0,
              numberOfRecords: 0
            };
            $ctrl.orderModel = {
              by: LIST_COLUMNS.RESOURCE,
              dir: ORDER_DIR_OPTIONS.ASC
            };
            $ctrl.filterModel = {
              filterString: '',
              regions: [],
              showSelectedOnly: false
            };

            $ctrl.resources = [];
            $ctrl.filteredResources = [];

            $ctrl.sortList = sortList;
            $ctrl.toggleResourceSelection = toggleResourceSelection;
            $ctrl.toggleAllResourcesSelection = toggleAllResourcesSelection;
            $ctrl.saveResourcesAllocation = saveResourcesAllocation;
            $ctrl.isAllResourcesSelected = isAllResourcesSelected;

            $ctrl.countPatternResources = countPatternResources;
            $ctrl.dateRangeValidator = dateRangeValidator;
					
            $ctrl.closeModal = closeModal;

            $scope.$watchGroup ([
              '$ctrl.paginModel.recordsPerPage',
              '$ctrl.paginModel.pageNumber',
              '$ctrl.orderModel.by',
              '$ctrl.orderModel.dir',
              '$ctrl.filterModel.filterString',
            ], function () {
              getResources();
            });

            $scope.$watchCollection (
              '$ctrl.filterModel.regions', 
              function () {
                getResources();
              }
            );
          })();
        }
      ]
    });
})(angular);