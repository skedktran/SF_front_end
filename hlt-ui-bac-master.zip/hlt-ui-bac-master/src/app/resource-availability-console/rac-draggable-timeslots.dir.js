(function (angular) {
    angular.module('hltApp')
        .directive('hcoDraggableTimeslots', [
            '$timeout',
            '$window',
            '$compile',
            function($timeout, $window, $compile) {
                var isDraggingIgnored = function (target, currentTarget) {
                    var isDraggingIgnored = false;

                    for (var element = target; element && currentTarget && element !== currentTarget; element = element.parentNode) {
                        if (element.hasAttribute('dragging-ignored')) {
                            isDraggingIgnored = true;
                            break;
                        }
                    }

                    return isDraggingIgnored;
                };

                return {
                    scope: false,
                    link: function ($scope, $el, $attr) {
                        var curDown = false;
                        var windowEl = angular.element($window);
                        var timeslotSelectionEl;

                        var startPosition, endPosition;

                        var elOffset, elPosition, elHeight;

                        var timeslotHeight;
                        var timeslotsSource = $scope.$eval($attr.hcoDraggableTimeslots);
                        var dataItem = $scope.$eval($attr.hcoDraggableTimeslotsDataItem);

                        var handleMouseDown = function (event) {
                        //var targetEl, targetScope;

                            if (event.which === 1) {
                                if (!isDraggingIgnored(event.target, event.currentTarget)) {
                                    elOffset = $el.offset();
                                    elPosition = $el.position();
                                    elHeight = $el.height();

                                    curDown = true;
                                    startPosition = (Math.floor((event.pageY - elOffset.top + elPosition.top) / timeslotHeight)) * timeslotHeight;
                                    if (startPosition < 0) {
                                        startPosition = 0;
                                    }

                                    endPosition = startPosition;
                                
                                    windowEl.on('mousemove', handleMouseMove);
                                    windowEl.on('mouseup', handleMouseUp);

                                    timeslotSelectionEl = angular.element([
                                        '<div ',
                                        'class="hco-rac-timeslot-selection" ',
                                        'sked-dropdown-menu="src/app/resource-availability-console/add-event-menu.tpl.html" ',
                                        'sked-dropdown-menu-on-top="true" ',
                                        'sked-dropdown-menu-container=".main-rac-page" ',
                                        'sked-dropdown-menu-scroller=".hco-rac-data-content-wrapper" ',
                                        'on-dropdown-menu-hide="handleDropdownMenuHide()">',
                                        '</div>'].join(''));
                                    //timeslotSelectionEl = angular.element('<div class="hco-rac-timeslot-selection" ></div>');
                                    timeslotSelectionEl.appendTo($el);
                                    timeslotSelectionEl.css({
                                        'z-index': 9,
                                        left: 0,
                                        height: timeslotHeight,
                                        top: startPosition
                                    });
                                }
                            
                            }
                        };

                        var handleMouseUp = function () {
                            var dropdownMenuScope, clonedSelectionEl;
                            var handleDropdownMenuHide = function () {
                                if (dropdownMenuScope && angular.isFunction(dropdownMenuScope.$destroy)) {
                                    dropdownMenuScope.$destroy();
                                    dropdownMenuScope = null;
                                }

                                if (clonedSelectionEl) {
                                    clonedSelectionEl.remove();
                                    clonedSelectionEl = null;
                                }
                            };

                            if (curDown) {
                                curDown = false;

                                dropdownMenuScope = $scope.$new();
                                dropdownMenuScope.handleDropdownMenuHide = handleDropdownMenuHide;
                                dropdownMenuScope.dataItem = dataItem;
                                dropdownMenuScope.startTimeslot = identifyTimeSlot((startPosition <= endPosition)?startPosition:endPosition);
                                dropdownMenuScope.endTimeslot = identifyTimeSlot((startPosition > endPosition)?startPosition:endPosition);

                                $compile(timeslotSelectionEl)(dropdownMenuScope);
                                timeslotSelectionEl.trigger('click');

                                windowEl.off('mousemove', handleMouseMove);
                                windowEl.off('mouseup', handleMouseUp);

                                if (timeslotSelectionEl) {
                                    clonedSelectionEl = timeslotSelectionEl.clone();

                                    timeslotSelectionEl.remove();
                                    timeslotSelectionEl = null;

                                    clonedSelectionEl.appendTo($el);
                                }
                            }
                        };

                        var handleMouseMove = function (event) {
                            var selectionElHeight;
                        
                            endPosition = (Math.floor((event.pageY - elOffset.top + elPosition.top) / timeslotHeight)) * timeslotHeight;
                        
                            // limit the selection
                            if (endPosition < 0) {
                                endPosition = 0;
                            } else if (endPosition > (elHeight - timeslotHeight)) {
                                endPosition = (elHeight - timeslotHeight);
                            }

                            // calculate position values
                            if (startPosition !== endPosition) {
                                selectionElHeight = Math.abs(endPosition - startPosition);
                            
                                if (endPosition < startPosition) {
                                    timeslotSelectionEl.css('top', endPosition);
                                } 
                            
                                timeslotSelectionEl.css('height', selectionElHeight + timeslotHeight);
                            } else {
                                timeslotSelectionEl.css({
                                    height: timeslotHeight,
                                    top: startPosition
                                });
                            }
                        };

                        var identifyTimeSlot = function (postion) {
                            var timeslotIndx = Math.floor(postion / timeslotHeight);
                            var timeslot = timeslotsSource[timeslotIndx];

                            return timeslot;
                        };

                        $el.on('mousedown', handleMouseDown);
                        //$el.on('mouseup', handleMouseUp);

                        $timeout(function () {
                            timeslotHeight = angular.element('.timeslot__items li').height();
                        });
                    }
                };
            }
        ]);
})(angular);