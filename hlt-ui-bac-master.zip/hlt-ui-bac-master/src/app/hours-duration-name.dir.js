(function (angular) {
    angular.module('hltApp')
    .filter('hoursDurationName', [
        function() {
            return function (timeInMinute) {
                var hourPart, minutePart;

                if (angular.isNumber(timeInMinute)) {
                    hourPart = Math.floor(timeInMinute / 60);
                    minutePart = timeInMinute % 60;


                    if (hourPart > 0 || minutePart > 0) {
                        return ((hourPart > 0)?(hourPart + ((hourPart <= 1)?'hr':'hrs')):'') + ((minutePart > 0)?(' ' + minutePart + ((minutePart === 1)?'min':'mins')):'');
                    }
                }

                return '0hr';
            };
        }
    ])
})(angular);