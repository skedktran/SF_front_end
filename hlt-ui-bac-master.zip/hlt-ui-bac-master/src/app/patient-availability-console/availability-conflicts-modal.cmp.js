(function (angular, topWindow) {
    angular.module('hltApp')
    .component('availabilityConflictsModal', {
        templateUrl: 'src/app/patient-availability-console/availability-conflicts-modal.tpl.html',
        bindings: {
            mode: '<',
            configData: '<',
            //region: '<',
            //patient: '<',
            data: '<',
            onClose: '&',
        },
        controller: [
            '$scope',
            '$timeout',
            '$window',
            '$location',
            '$q',
            '$filter',
            'api',
            'util',
            'dateUtil',
            'model',
            'constants',
            'ggLocationApi',
            function ($scope, $timeout, $window, $location, $q, $filter, api, util, dateUtil, model, constants, ggLocationApi) {
                var $ctrl = this;
                
                var ACTIONS = {
                    EMPTY: '',
                    MERGE: 'Merge',
                    CANCEL: 'Cancel',
                    OVERWRITE: 'Overwrite'
                }

                var MODE = {
                    AVAILABILITY: 'Availability',
                    UNAVAILABILITY: 'Unavailability'
                }

                /**
                 * common remote action error handler
                 */
                var commonExceptionHanlder = function (exception) {
                    util.toastError('Can not perform action due to server error.');

                    return $q.reject(exception);
                };

                /**
                 * show content loading
                 */
                var showLoading = function () {
                    $ctrl.contentLoading = true;
                };

                /**
                 * hide content loading
                 */
                var hideLoading = function () {
                    $ctrl.contentLoading = false;
                };

                /**
                 * close main modal
                 */
                var closeModal = function (message) {
                    $ctrl.isModalOpen = false;
                    // run onClose expression
                    if (angular.isFunction ($ctrl.onClose)) {
                        $ctrl.onClose({
                            message: message
                        });
                    }
                };

                var doSaveAvailability = function (params) {
                    return api.handleSaveConflicts(params)
                        .catch(commonExceptionHanlder);
                };

                var buildSaveAvailabilityParams = function(data) {
                    var params = angular.copy(data.conflicts);
                    /*params.forEach(function(item){
                        item.record = item.record.toServer();
                        item.items.forEach(function(temp){
                            temp.conflictRecord = temp.conflictRecord.toServer();
                        })
                    })*/
                    return {
                        conflicts: params,
                        objectType: data.objectType,
                        recurringSchedule: data.recurringSchedule
                    }
                };

                var onActionChanged = function(parent, newAction) {
                    if(newAction === ACTIONS.CANCEL) {
                        parent.items.forEach(function(conflictItem){
                            conflictItem.action = newAction;
                        })
                    }
                }

                var saveAvailability = function () {
                    var requestParams;
                    var savingCallback = function (result) {
                        if (result.success) {
                            closeModal('done');
                        } else{
                            return $q.reject(result);
                        }
                    };

                    if (validateConflictsData($ctrl.conflictsData)) {

                        requestParams = {
                            conflictData: buildSaveAvailabilityParams($ctrl.data)
                        };
                        
                        showLoading();
                        doSaveAvailability(requestParams)
                            .then(savingCallback)
                            .catch(function (exception) {
                                if (exception && exception.errorMessage) {
                                    util.toastError(exception.errorMessage);
                                }
                            })
                            .finally(function () {
                                hideLoading();
                            });
                    }
                };

                var validateConflictsData = function(data) {
                    var form = $ctrl.form;
 
                    form.$setSubmitted(true);

                    if(!data) return false;

                    for (var i = data.length - 1; i >= 0; i--) {
                        var item = data[i];

                        if(item.hasConflict && item.items) {
                            for (var j = item.items.length - 1; j >= 0; j--) {
                                var conflictItem = item.items[j];
                                if(!conflictItem.action) {
                                    util.toastError('Please select action for all conflict appointments');
                                    return false;
                                }
                            }
                        }
                    }

                    return true;
                };

                var buildConflictsData = function(data) {
                    if(!data || !data.conflicts) return;
                    var conflictsData = [];
                    //var modelType = (data.objectType === 'clientAvailability')?model.PACAvailabilityModel:model.AvailabilityModel;

                    data.conflicts.forEach(function(item){
                        /*item.record = modelType.fromServer(item.record, $ctrl.configData);
                        item.items.forEach(function(temp){
                            temp.conflictRecord = modelType.fromServer(temp.conflictRecord, $ctrl.configData);
                        })*/

                        if(item.hasConflict) {
                            conflictsData.push(item);
                        }
                    })

                    return conflictsData;
                }

                var setAllActions = function(items, newAction) {
                    items.forEach(function(item){
                        if(item.items) {
                            item.items.forEach(function(conflictItem) {
                                var action = newAction;
                                if(action === ACTIONS.MERGE && !conflictItem.canMerge) {
                                    action = ACTIONS.EMPTY;
                                }

                                conflictItem.action = action;
                            })
                        }
                    })
                }

                /**
                 * controller init
                 * used for setting initial value
                 */
                $ctrl.$onInit = function () {
                    $ctrl.isModalOpen = true;
                    $ctrl.conflictsData = buildConflictsData($ctrl.data);

                    $ctrl.mode = $ctrl.mode === MODE.UNAVAILABILITY ? MODE.UNAVAILABILITY : MODE.AVAILABILITY;
                };

                /**
                 * init block
                 * used for setting up controller
                 */
                (function () {
                    $scope.ACTIONS = ACTIONS;
                    $scope.MODE = MODE;

                    $ctrl.form = null;
                    $ctrl.isModalOpen = false;
                    $ctrl.contentLoading = false;
                    $ctrl.conflictsData = [];
                    $ctrl.closeModal = closeModal;
                    $ctrl.util = util;
                    $ctrl.setAllActions = setAllActions;
                    $ctrl.onActionChanged = onActionChanged;
                    $ctrl.saveAvailability = saveAvailability;
                })();
            }
        ]
    });
})(angular, top);