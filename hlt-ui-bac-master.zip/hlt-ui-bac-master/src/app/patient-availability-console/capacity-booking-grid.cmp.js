(function (angular) {
  angular.module('hltApp')
    .component('capacityBookingGrid', {
      templateUrl: 'src/app/patient-availability-console/capacity-booking-grid.tpl.html',
      bindings: {
        mode: '<',
        patientId: '<',
        // caseId: '<',
        configData: '=',
        bookingGrid: '=',
        editingJob: '=',
        scheduledJobs: '=',
        refreshBookingGrid: '&',
        viewRegion: '<'
      },
      controller: [
        'JOB_STATUS',
        '$scope',
        '$timeout',
        '$window',
        '$location',
        '$q',
        '$filter',
        'api',
        'util',
        'ggLocationApi',
        'dateUtil',
        'constants',
        'model',
        function (JOB_STATUS, $scope, $timeout, $window, $location, $q, $filter, api, util, ggLocationApi, dateUtil, constants, model) {
          var $ctrl = this;
          var backupJob = null;

          var elWindow = angular.element($window);

          var MODE = constants.PAC_MODE;
          var DEFAULT_PHOTO_URL = $filter('skedSfUrl')('slds/images/avatar3.jpg');
                
                
          var CAL_SETTINGS = {
            timeslotWidth: 4,
            timeslotHeight: 3.125,
            slotSize: {
              w: 7,
              h: 2
            },
            intervals: [
              {value: 15, label: '15 Minutes'},
              {value: 30, label: '30 Minutes'},
              {value: 60, label: '1 Hour'},
            ]
          };

          var INTEGER_PATTERN = /^([0-9]*)$/;

          var nameFilter = $filter('filter');

          /**
                 * common remote action error handler
                 */
          var commonExceptionHanlder = function (exception) {
            console.error(exception);
            util.toastError('Can not perform action due to server error.');

            return $q.reject();
          };

          /**
                 * show content loading
                 */
          var showLoading = function () {
            $ctrl.contentLoading = true;
          };

          /**
                 * hide content loading
                 */
          var hideLoading = function () {
            $ctrl.contentLoading = false;
          };
                

          var doSearchAddresses = function (searchString) {
            return ggLocationApi.geocode({
              address: searchString
            });
            //.catch(commonExceptionHanlder);
          };

          var doSaveJob = function (jobParams) {
            return api.saveJob(jobParams)
              .catch(commonExceptionHanlder);
          };

          var doCancelJob = function (jobParams) {
            return api.cancelJob(jobParams)
              .catch(commonExceptionHanlder);
          };

          var findPrimaryContact = function () {
            // BAC specific logic, there is only one contact
            return $ctrl.configData.contacts[0];
            // var primaryContact = null;

            // for (var i = 0; i < $ctrl.configData.contacts.length; i++) {
            //     if ($ctrl.configData.contacts[i].isPrimary) {
            //         primaryContact = $ctrl.configData.contacts[i];
            //         break;
            //     }
            // }

            // return primaryContact;
          };

          var jobCanBeRescheduled = function (job) {
            var allowedJobStatuses = [
              JOB_STATUS.QUEUED,
              JOB_STATUS.PENDING_ALLOCATION,
              JOB_STATUS.PENDING_DISPATCH,
              JOB_STATUS.DISPATCHED,
              JOB_STATUS.READY,
              JOB_STATUS.EN_ROUTE,
              JOB_STATUS.ON_SITE,
              JOB_STATUS.IN_PROGRESS
            ];

            return allowedJobStatuses.indexOf(job.jobStatus) > -1;
          };

          var addNewJob = function () {
            if (!$ctrl.editingJob) {
              $ctrl.editingJob = new model.EventModel();

              if (angular.isArray($ctrl.configData.jobTypes) && $ctrl.configData.jobTypes.length > 0) {
                $ctrl.editingJob.eventType = $ctrl.configData.jobTypes[0]; // default first in list
              }
              $ctrl.editingJob.patientId = $ctrl.patientId;
              $ctrl.editingJob.contact = findPrimaryContact();
              $ctrl.editingJob.duration = $ctrl.configData.consoleSettings.calendarStep || 30;
              $ctrl.editingJob.quantity = null;
              $ctrl.editingJob.description = util.buildDescriptionForSingleJob($ctrl.editingJob.eventType, $ctrl.configData.patient);
              $ctrl.editingJob.inheritAccountTasks = true;
              $ctrl.editingJob.loneWorkerRisk = false;
              $ctrl.editingJob.region =  $ctrl.viewRegion ? _.find($ctrl.configData.regions, {
                id: $ctrl.viewRegion.id
              }) : null; 

              $ctrl.editingJob.supportPlan = _.find($ctrl.configData.supportPlans, {selected: true});

              $ctrl.editingJob.address = _.get(_.find($ctrl.configData.serviceLocations, { selected: true }), 'address');
                        
              $ctrl.isEditMode = false;
            }
          };

          var handleEditJobEvent = function (event, args) {
            if (args.job) {
              editJob(args.job);
            }
          };

          var editJob = function (job) {
            console.log(job);
            backupJob = {
              startDate: job.startDate,
              startTime: job.startTime,
              endTime: job.endTime,
              contact: job.contact,
              address: job.address
            };
            $ctrl.editingJob = job;
            $ctrl.isEditMode = true;
          };

          var closeJobEditingPanel = function () {
            var form = $ctrl.jobForm;

            if (form) {
              form.$setPristine();
            }

            //delete $ctrl.scheduledJobsMap[produceScheduledJobKey($ctrl.editingJob)];
            if (backupJob) {
              $ctrl.editingJob.startDate = backupJob.startDate;
              $ctrl.editingJob.startTime = backupJob.startTime;
              $ctrl.editingJob.endTime = backupJob.endTime;
                        
              //$ctrl.scheduledJobsMap[produceScheduledJobKey($ctrl.editingJob)] = $ctrl.editingJob;
            }

            backupJob = null;
            $ctrl.editingJob = null;

            $ctrl.refreshBookingGrid();
          };

          var cancelEditingJob = function () {
            util.confirm({
              title: 'Discard All Changes?',
              message: 'Are you sure you would like discard all changes?'
            }).then(function () {
              closeJobEditingPanel();
            }, angular.noop);
          };

          var cancelJob = function (job) {
            util.showModal ({
              templateUrl: 'src/app/patient-availability-console/capacity-bg-cancel-job-confirm-modal.tpl.html',
            }, {
              configData: $ctrl.configData,
              cancellationReason: $ctrl.configData.cancellationReasons[0]
            })
              .then(function (result) {
                var jobParam;

                if (result !== 'cancel') {
                  showLoading();
                  jobParam = job.toServer();
                  jobParam.cancellationReason = result.id;
                  return doCancelJob({
                    event: jobParam,
                    recurringOptions: null
                  });
                } 

                return $q.reject(result);
              })
              .then(function (result) {
                if (result.success) {
                  util.toastSuccess('Job has been canceled successfully.');
                                
                  $ctrl.refreshBookingGrid();

                  return true;
                } else {
                  return $q.reject(result);
                }
              })
              .catch(function (exception) {
                if (exception !== 'cancel') {
                  console.error(exception);
                  if (exception && exception.errorMessage) {
                    util.toastError(exception.errorMessage);
                  }
                }
              })
              .finally(function () {
                hideLoading();
              });
          };

          var searchTags = function (searchString) {
            var results = [];
            if ($ctrl.configData && $ctrl.configData.tags) {
              results = $ctrl.configData.tags;

              if (searchString) {
                results = nameFilter(results, {label: searchString});
              }
            }

            return results;
          };

          var searchAddresses = function (searchString) {

            searchString = searchString || '';

            if (searchString.length >= 1) {
              return doSearchAddresses(searchString)
                .then(function (response) {
                  if (response.status === 'OK') {
                    return model.AddressModel.fromGGServerList(response.results);
                  }
                });
            }
          };

          var searchContacts = function (searchString) {
            var results = [];
            if ($ctrl.configData && $ctrl.configData.contacts) {
              results = $ctrl.configData.contacts;

              if (searchString) {
                results = nameFilter(results, {fullName: searchString});
              }
            }

            return results;
          };

          var initializePage = function () {
            /*showLoading();
                    $q.all([
                        getScheduledJobs()
                        ])
                    .catch(function (exception) {
                        console.error(exception);
                        util.toastError(exception.errorMessage);
                    })
                    .finally(hideLoading);*/
          };

          var calculateSlotEndTime = function (slotStartTime, jobDuration) {
            var slotEndTime = null;
            if (angular.isNumber(slotStartTime)) {
              slotEndTime = getTimeValue(getMinuteValue(slotStartTime) + (jobDuration || 0));
            }
            return slotEndTime;
          };

          var getTimeValue = function (minuteValue) {
            tsH = Math.floor(minuteValue / 60);
            tsM = Math.round(minuteValue % 60);

            return ((tsH * 100) + tsM);
          };

          var getMinuteValue = function (timeValue) {
            return (Math.floor(timeValue/100) * 60) + Math.round(timeValue%100);
          };

          var validateJob = function () {
            var form = $ctrl.jobForm;
                    
            form.$setSubmitted();
            if (!form.$valid || !$ctrl.editingJob.contact || !$ctrl.editingJob.address ) {
              if (form.$error.required || !$ctrl.editingJob.contact || !$ctrl.editingJob.address) {
                util.toastError('Please check all required fields.');
              } else if (form.$error.number || form.$error.pattern) {
                util.toastError('Invalid data format, please check all number fields.');
              } else if (form.$error.min) {
                util.toastError('Duration and Number of resources should be greater than 0.');
              }

              return false;
            } 

            if (!$ctrl.editingJob.id &&  // check this in add new job only
                        ($ctrl.bookingGrid.selectedTimeslots.length === 0 || !$ctrl.bookingGrid.selectedTimeslots[0] || $ctrl.bookingGrid.selectedTimeslots[0].isDisabled)) {
              util.toastError('There is no time slot selected or the selected slot is no more available. Please select an avaliable time slot from booking grid.');
              return false;
            }

            return true;
          };

          var produceJobSavingParams = function (job) {
            var jobSavingParams,
              selectedTimeSlot;

            selectedTimeSlot = $ctrl.bookingGrid.selectedTimeslots[0];
            jobSavingParams = job.toServer();
            jobSavingParams.patientId = $ctrl.patientId;

            if (!job.id) {
              jobSavingParams.startDate = selectedTimeSlot.startDate;
              jobSavingParams.startTime = selectedTimeSlot.startTime;

              // [REMOVE_DURATION] calculate job end time 
              jobSavingParams.endDate = selectedTimeSlot.startDate;
              jobSavingParams.endTime = calculateSlotEndTime(selectedTimeSlot.startTime, job.duration);
            } else {
              jobSavingParams.endTime = calculateSlotEndTime(jobSavingParams.startTime, job.duration);
            }

            // if ($ctrl.region && $ctrl.region.id) {
            //     jobSavingParams.regionId = $ctrl.region.id;
            // }

            if (jobSavingParams.quantity <= 0) {
              jobSavingParams.quantity = null;
            }

            return jobSavingParams;
          };

          var saveJob = function (allocateAfterSaving) {
            var jobSavingParams;

            if (validateJob()) {
              jobSavingParams = produceJobSavingParams($ctrl.editingJob);

              showLoading();
              doSaveJob({
                event: jobSavingParams,
                recurringOptions: null
              })
                .then(function (result) {
                  var newJobId = result.data; // data returned

                  if (newJobId) {
                    util.toastSuccess(($ctrl.editingJob.id)?'Job ' + $ctrl.editingJob.name + ' has been saved successfully.':'Job has been created successfully.');

                    if (allocateAfterSaving) {
                      $ctrl.editingJob.id = newJobId;
                      $ctrl.editingJob.patientId = $ctrl.patientId;
                      showResourceAllocationModal($ctrl.editingJob);
                    }

                    closeJobEditingPanel();
                  } else {
                    return $q.reject({
                      errorMessage: 'Job has no id.'
                    });
                  }
                                
                })
                .catch(function (exception) {
                  console.error(exception);
                  if (exception && exception.errorMessage) {
                    util.toastError(exception.errorMessage);
                  }
                })
                .finally(hideLoading);
            }
          };

          var showResourceAllocationModal = function (job) {
            util.showModal({
              template: '<job-allocation class="sked-modal-container" job-pinning="true" is-single-job="true" job="job" on-close="onClose(message, this)" config-data="configData" ></job-allocation>'
            }, {
              configData: $ctrl.configData,
              job: job,
              onClose: function (message, modalScope) {
                modalScope.closeModal(message);
                if (message === 'done') {
                  $ctrl.refreshBookingGrid();
                }
              }
            });
          };

          var isPortalMode = function () {
            return $ctrl.mode === MODE.PORTAL;
          };

          var onEventTypeChanged = function() {
            var isDescriptionChanged = $ctrl.jobForm && $ctrl.jobForm.description && $ctrl.jobForm.description.$dirty;

            if(!$ctrl.isEditMode && !isDescriptionChanged) {
              $ctrl.editingJob.description = util.buildDescriptionForSingleJob($ctrl.editingJob.eventType, $ctrl.configData.patient);
            }
          };

          var toggleInherrit = function () {
            $ctrl.editingJob.jobTasks.clear();
          };

          /**
                 * controller init
                 * used for setting initial value
                 */
          $ctrl.$onInit = function () {
            initializePage();
          };

          /**
                 * init block
                 * used for setting up controller
                 */
          (function () {
            $scope.DEFAULT_PHOTO_URL = DEFAULT_PHOTO_URL;
            $scope.CAL_SETTINGS = CAL_SETTINGS;
            $scope.INTEGER_PATTERN = INTEGER_PATTERN;
            $scope.JOB_STATUS = JOB_STATUS;
            $scope.MODE = MODE;

            $ctrl.isEditMode = false;
            $ctrl.contentLoading = false;
            $ctrl.util = util;
                    
            $ctrl.addNewJob = addNewJob;
            $ctrl.editJob = editJob;
                    
            $ctrl.jobCanBeRescheduled = jobCanBeRescheduled;
            $ctrl.cancelEditingJob = cancelEditingJob;

            $ctrl.searchAddresses = searchAddresses;
            $ctrl.searchContacts = searchContacts;

            $ctrl.searchTags = searchTags;
            $ctrl.saveJob = saveJob;
            $ctrl.cancelJob = cancelJob;

            $ctrl.showResourceAllocationModal = showResourceAllocationModal;
            $ctrl.onEventTypeChanged = onEventTypeChanged;

            $ctrl.isPortalMode = isPortalMode;
            $ctrl.toggleInherrit = toggleInherrit;

            // $scope.$watch('$ctrl.editingJob.contact', function (newVal) {
            //     if (newVal) {
            //         if (newVal.address && (!backupJob || !backupJob.address)) {
            //             populateEditingJobAddress(newVal.address);
            //         }
            //     }

            //     if (backupJob) {
            //         backupJob.address = null;
            //     }
            // });

            $scope.$watch('$ctrl.editingJob', function () {
              $timeout(function () {
                elWindow.trigger('resize');
              });
            });

            $scope.$on('pac.appointment.addNewIndividualJob', addNewJob);
            $scope.$on('pac.appointment.editIndividualJob', handleEditJobEvent);
            

            $scope.$watch('$ctrl.editingJob.address', function (address) {
              if ($ctrl.editingJob && $ctrl.editingJob.serviceLocation && $ctrl.editingJob.serviceLocation.id !== 'Other' && !_.isEqual(address, $ctrl.editingJob.serviceLocation.address)) {
                $ctrl.editingJob.serviceLocation = _.find($ctrl.configData.eventServiceLocations, {
                  id: 'Other'
                });
              }
            });

          })();
        }
      ]
    });
})(angular);