(function(angular) {
  angular.module('hltApp').component('eventRecurrence', {
    templateUrl: 'src/app/patient-availability-console/event-recurrence-modal.tpl.html',
    bindings: {
      configData: '<',
      scheduleId: '<',
      patientId: '<',
      onClose: '&',
      timezone: '<'
    },
    controller: ['$scope', '$q', 'api', 'util', 'model', 
      function(
        $scope, $q, api, util, model) {
        var $ctrl = this;

        var COMMON_DATE_FORMAT = 'MM/dd/yyyy';
        var TABS = {
          EVENTS: 'events',
          ON_CALL_TEAM_MEMBERS: 'on-call team members'
        };
        var WEEK_DAYS = [
          {
            label: 'Sun',
            fullLabel: 'Sunday'
          },
          {
            label: 'Mon',
            fullLabel: 'Monday'
          },
          {
            label: 'Tue',
            fullLabel: 'Tuesday'
          },
          {
            label: 'Wed',
            fullLabel: 'Wednesday'
          },
          {
            label: 'Thu',
            fullLabel: 'Thursday'
          },
          {
            label: 'Fri',
            fullLabel: 'Friday'
          },
          {
            label: 'Sat',
            fullLabel: 'Saturday'
          }
        ];
        
        var entryTimepickerOptions = {
          step: 30,
          events: {
            hideTimepicker: function(event) {
              var timePickerInput, inputScope;

              if (event && event.target) {
                timePickerInput = angular.element(event.target);

                if (timePickerInput) {
                  inputScope = timePickerInput.scope();

                  if (inputScope && inputScope.event) {
                    inputScope.$apply(function() {
                      verifyEventEntryErrors(inputScope.event);
                    });
                  }
                }
              }
            }
          }
        };

        var currentFilters = {};
        var originEventData = {};

        /**
         * common remote action error handler
         */
        var commonExceptionHanlder = function(exception) {
          console.error(exception);
          util.toastError('Can not perform action due to server error.');

          return $q.reject();
        };

        /**
         * show content loading
         */
        var showLoading = function() {
          $ctrl.contentLoading = true;
        };

        /**
         * hide content loading
         */
        var hideLoading = function() {
          $ctrl.contentLoading = false;
        };

        /**
         * close main modal
         */
        var closeModal = function(message) {
          $ctrl.isModalOpen = false;
          // run onClose expression
          if (angular.isFunction($ctrl.onClose)) {
            $ctrl.onClose({
              message: message
            });
          }
        };
        var doGetRecurringEvents = function(requestParams) {
          return api.getJobs(requestParams)
            .catch(commonExceptionHanlder);
        };

        var doSaveRecurringEvents = function(requestParams) {
                    
          var jobsPerCall = 100;
          var processedJobs = 0;

          util.updateProgressBar(0);
          var promises = _.chunk(requestParams.jobs, jobsPerCall).map(function (events) {
              return function() {
                  return api.saveJobs(_.extend({}, requestParams, {
                      jobs: events
                  }))
                      .then(function(result) {
                          if(!result.success) {
                              return $q.reject(result);
                          }
                          processedJobs = processedJobs + jobsPerCall;
                          util.updateProgressBar(processedJobs);
                          return result;
                      });
              };

          });

          return util.serial(promises)
              .catch(commonExceptionHanlder);
        };

        var isEntryChanged = function (event) {
          var isChanged = false;
          var originEvent = originEventData[event.id];

          if (originEvent) {
            isChanged = event.startTime !== originEvent.startTime ||
              event.endTime !== originEvent.endTime;
          }

          return isChanged;
        };

        var identifyAction = function(event) {
          var action = '';

          if (!event.id) {
            action = 'create';
          } else if (event.isDeleted) {
            action = 'delete';
          } else if (event.id && isEntryChanged(event)) {
            action = 'update';
          }

          return action;
        };

        var transformEventData = function (serverList) {
          $ctrl.events = model.PACJobModel.fromServerList(serverList, $ctrl.configData);
        };

        var storeOriginEventData = function () {
          originEventData = {};
          angular.forEach($ctrl.events, function (event) {
            originEventData[event.id] = {
              startTime: event.startTime,
              endTime: event.endTime
            };
          });
        };

        var getRecurringEvents = function() {
          return doGetRecurringEvents({ 
            recordId: $ctrl.patientId,
            scheduleId: $ctrl.scheduleId 
          })
            .then(function(result) {
              if (result.success) {
                transformEventData(result.data.jobs);
                storeOriginEventData();
                
              } else {
                return $q.reject(result);
              }
            })
            .catch(function(exception) {
              console.error(exception);
              if (exception && exception.errorMessage) {
                util.toastError(exception.errorMessage);
              }
            });
        };
				
        var filterEvent = function (forceFilter) {
          var weekdaysFilter;
					
          if (forceFilter || !util.compareValues($ctrl.filters, currentFilters)) {
            currentFilters = angular.copy($ctrl.filters);
            if (angular.isArray($ctrl.events) && $ctrl.events.length > 0) {
              weekdaysFilter = $ctrl.filters.weekDays.map(function (weekday) {
                return WEEK_DAYS.indexOf(weekday);
              });
              
              $ctrl.filteredEvents = $ctrl.events.filter(function (event) {
                var eventWeekDay = event.startDate.getDay();
	
                return !event.isDeleted &&
                  weekdaysFilter.indexOf(eventWeekDay) > -1 && 
									(!angular.isDate($ctrl.filters.fromDate) || event.startDate.getTime() >= $ctrl.filters.fromDate.getTime()) &&
									(!angular.isDate($ctrl.filters.toDate) || event.startDate.getTime() <= $ctrl.filters.toDate.getTime());
              });

              filterSelectedEvents();
            } else {
              $ctrl.filteredEvents = [];
              $ctrl.selectedEvents = [];
            }
          }
        };

        var filterSelectedEvents = function () {
          var event;
          for (var i = 0; i < $ctrl.selectedEvents.length; i++) {
            event = $ctrl.selectedEvents[i];
						
            if ($ctrl.filteredEvents.indexOf(event) === -1) {
              $ctrl.selectedEvents.splice(i, 1);
              i--;
            }
          }
        };

        var toggleAllEventsSelection = function () {
          if ($ctrl.selectedEvents.length >= $ctrl.filteredEvents.length) {
            $ctrl.selectedEvents = [];
          } else {
            $ctrl.selectedEvents = angular.extend([], $ctrl.filteredEvents);
          }
        };

        var toggleEventSelection = function (event) {
          var eventIndex = $ctrl.selectedEvents.indexOf(event);

          if (eventIndex === -1) {
            $ctrl.selectedEvents.push(event);
          } else {
            $ctrl.selectedEvents.splice(eventIndex, 1);
          }
        };
        
        var updateSelectedEvents = function () {
          if (angular.isArray($ctrl.selectedEvents) && $ctrl.selectedEvents.length > 0) {
            angular.forEach($ctrl.selectedEvents, function (event) {
              event.startTime = $ctrl.recurring.startTime;
              event.endTime = $ctrl.recurring.endTime;

              verifyEventEntryErrors(event);
            });
          }
        };

        var removeSelectedEvents = function () {
          if (angular.isArray($ctrl.selectedEvents) && $ctrl.selectedEvents.length > 0) {
            angular.forEach($ctrl.selectedEvents, function (event) {
              event.isDeleted = true;
            });

            filterEvent(true);
          }
        };

        var clearFilter = function () {
          $ctrl.filters = {
            weekDays:  angular.extend([], WEEK_DAYS),
            fromDate: null,
            toDate: null
          };
        };

        var validateRecurrence = function () {
          var form = $ctrl.recurringForm;
          var hasErrors = false;

          if (form) {
            form.$setSubmitted();

            for (var i = 0; i < $ctrl.events.length; i++) {
              var event = $ctrl.events[i];

              if (event.hasErrors) {
                hasErrors = true;
                break;
              }
            }

            if (hasErrors) {
              util.toastError('Invalid data, please check your input, clear filter if needed.');
              return false;
            }
          }

          return true;
        };

        var showAvailabilityConflictsModal = function (data) {
          var mode = 'Recurrence';

          util.showModal({
            template: '<availability-conflicts-modal class="sked-modal-container" mode="mode" data="data" patient="patient" config-data="configData" on-close="onClose(this, message)"></availability-conflicts-modal>',
          }, {
            mode: mode,
            data: data,
            configData: $ctrl.configData,
            onClose: function (modalScope, message) {
              modalScope.closeModal();

              if (message === 'done') {
                util.toastSuccess('Recurrence has been updated successfully.');
                closeModal('done');
              }
            }
          });
        };

        var produceSavingParams = function () {
          var savingParams = [];
          angular.forEach($ctrl.events, function (event) {
            var eventParams = event.toServer();
            eventParams.action = identifyAction(event);

            if (eventParams.action !== '') {
              savingParams.push(eventParams);
              /* if (angular.isArray(event.relatedAvailability)) {
                angular.forEach(event.relatedAvailability, function (relAvailId) {
                  var relEventParam = angular.copy(eventParams);
                  relEventParam.id = relAvailId;

                  savingParams.push(relEventParam);
                });
              } */
            }
          });

          return savingParams;
        };

        var saveRecurrence = function () {
          var savingParams;
          var savingCallback = function (result) {
            if (result.success) {
              var hasConflict = result.data && result.data.hasConflict;

              if (hasConflict) {
                showAvailabilityConflictsModal(result.data);
              } else {
                util.toastSuccess('Recurrence has been updated successfully.');
                
                closeModal('done');
              }
            } else{
              return $q.reject(result);
            }
          };

          if (validateRecurrence()) {
            savingParams = produceSavingParams();
            
            if (savingParams.length > 0) {
              util.showProgressBar({
                message: 'Processing...',
                totalRecords: savingParams.length
              });
              doSaveRecurringEvents({
                jobs: savingParams
              })
                .then(savingCallback)
                .catch(function (exception) {
                  console.error(exception);
                  if (exception && exception.errorMessage) {
                    util.toastError(exception.errorMessage);
                  }
                })
                .finally(function () {
                  util.hideProgressBar();
                });
            } else {
              util.toastError('There are no changes. Please click Cancel button if you don\'t want to make any changes.');
            }
          } else {
            $ctrl.tab = TABS.EVENTS;
          }
        };

        var verifyEventEntryErrors = function (event) {
          var startTime = event.startTime,
            endTime = event.endTime,
            startTimeValid = angular.isNumber(startTime),
            endTimeValid = angular.isNumber(endTime);

          event.errors = {
            startTime: !startTimeValid,
            endTime: !endTimeValid,
            timePeriod: startTimeValid && endTimeValid && startTime >= endTime
          };

          event.hasErrors = event.errors.startTime || event.errors.endTime || event.errors.timePeriod;
        };

        /**
         * init block
         * used for setting up controller
         */
        (function() {
          $scope.WEEK_DAYS = WEEK_DAYS;
					
          $ctrl.entryTimepickerOptions = entryTimepickerOptions;

          $ctrl.isModalOpen = false;
          $ctrl.contentLoading = false;
          $ctrl.closeModal = closeModal;

          $ctrl.toggleAllEventsSelection = toggleAllEventsSelection;
          $ctrl.toggleEventSelection = toggleEventSelection;
          $ctrl.updateSelectedEvents = updateSelectedEvents;
          $ctrl.removeSelectedEvents = removeSelectedEvents;
          $ctrl.clearFilter = clearFilter;
          $ctrl.saveRecurrence = saveRecurrence;

          $ctrl.filters = {
            weekDays:  angular.extend([], WEEK_DAYS),
            fromDate: null,
            toDate: null
          };
          $ctrl.recurring = {
            startTime: null,
            endTime: null
          };
          $ctrl.events = [];
          $ctrl.selectedEvents = [];
          $ctrl.filteredEvents = [];
          
          $ctrl.recurringForm = null;

          $ctrl.$onInit = function () {
            $ctrl.commonDateOptions = {
              dateFormat: _.get($ctrl, 'configData.consoleSettings.datePickerFormat', 'MM/dd/yy')
            };

            $scope.COMMON_DATE_FORMAT = _.get($ctrl, 'configData.consoleSettings.dateFormat', 'MM/dd/yy');

            $ctrl.isModalOpen = true;
  
            showLoading();
            getRecurringEvents()
              .then(function (result) {
                $ctrl.selectedEvents = [];
                filterEvent(true);
  
                return result;
              })
              .finally(hideLoading);
          };

          $scope.$watchCollection('$ctrl.filters.weekDays', filterEvent);
          $scope.$watchGroup(['$ctrl.filters.fromDate', '$ctrl.filters.toDate'], filterEvent);
        })();
      }
    ]
  });
})(angular, top);
