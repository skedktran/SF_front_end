(function (angular, moment, $) {
    angular.module('hltApp')
        .component('patientAvailabilityConsole', {
            templateUrl: 'src/app/patient-availability-console/patient-availability-console.tpl.html',
            bindings: {
                configData: '<',
                mode: '<',
                regionId: '<',
                patientId: '<?',
                supportPlanId: '<?',
                viewCapacityGrid: '<?',
                onClose: '&'
            },
            controller: [
                '$timeout',
                '$location',
                '$q',
                '$scope',
                '$filter',
                'util',
                'dateUtil',
                'api',
                'constants',
                'model',
                function ($timeout, $location, $q, $scope, $filter, util, dateUtil, api, constants, model) {
                    var $ctrl = this;
                    var searchParams = $location.search();
                    var MODE = constants.PAC_MODE;
                    var LAYOUT_MODE = constants.LAYOUT_MODE;
                    var OBJECT_TYPE = constants.OBJECT_TYPE;

                    var DEFAULT_PHOTO_URL = $filter('skedSfUrl')(constants.DEFAULT_AVATAR_URL);
                    var TABS = constants.PATIENT_AVAILABILITY_TABS;

                    var PAC_REQUIRED_CONFIG_DATA = [
                        'jobCancellationReasons',
                        // 'patientCases',
                        'patientSupportPlans',
                        'patientContacts',
                        'jobTypes',
                        //'clientAvailabilityTypes',
                        'holidays',
                        'patientLocations',
                        'regions',
                        'timezones',
                        'tags',
                        'abortReasons',
                        'resourceCategories',
                        'holidays'
                    ];

                    var focusInput = function (inputSelector) {
                        var input = angular.element(inputSelector);

                        if (input && input.length > 0) {
                            $timeout(function() {
                                input[0].focus();
                            }, 10);
                        }
                    };

                    var weekPickerOptions = {
                        timeoutPromise: null,
                        firstDay: 0,
                        showOtherMonths: true,
                        beforeShow: function (el, inst) {
                            if (weekPickerOptions.timeoutPromise) {
                                $timeout.cancel(weekPickerOptions.timeoutPromise);
                            }

                            inst.dpDiv.addClass('week-picker');

                            $timeout(function () {
                                inst.dpDiv.find('tr:has(td.ui-datepicker-current-day) .ui-state-default').addClass('ui-state-co-active');
                            }, 0);
                        },
                        onChangeMonthYear: function (year, month, inst) {
                            //inst.dpDiv.addClass('week-picker');

                            $timeout(function () {
                                inst.dpDiv.find('tr:has(td.ui-datepicker-current-day) .ui-state-default').addClass('ui-state-co-active');
                            }, 0);
                        },
                        onClose: function (dateText, inst) {
                            weekPickerOptions.timeoutPromise = $timeout(function () {
                                inst.dpDiv.removeClass('week-picker');
                            }, 200);
                        }
                    };
                    var formatWeekPickerDates = function (startDate, endDate) {
                        var formatedValue = '';
                        var patternReg = /([se])\[([^\]]*)\]/g;
                        var patternString;

                        var formatDate = function (replacingString, dateIdent, formatPattern, index) {
                            var dateValue;
						
                            switch (dateIdent) {
                            case 's':
                                dateValue = startDate;
                                break;
                            case 'e':
                                dateValue = endDate;
                                break;
                            }

                            if ($ && $.datepicker && $.datepicker.formatDate && dateValue) {
                                return $.datepicker.formatDate(formatPattern, dateValue);
                            } 

                            return '';
                        };

                        if ($ctrl.configData && $ctrl.configData.consoleSettings &&
						$ctrl.configData.consoleSettings.weekPickerFormat) {
                            patternString = $ctrl.configData.consoleSettings.weekPickerFormat;
                        } else {
                            patternString = 's[M d] - e[M d, yy]';
                        }

                        formatedValue = patternString
                            .replace(patternReg, formatDate);
						
					
                        return formatedValue;
                    };

                    var commonExceptionHanlder = function (exception) {
                        util.toastError('Can not perform action due to server error.');

                        return $q.reject(exception);
                    };

                    var showErrorPrompt = function (errorMessage, noBackdrop) {
                        util.showModal({
                            templateUrl: 'src/app/error-prompt-template.html',
                            noBackdrop: !!noBackdrop
                        }, {
                            hideCloseButton: true,
                            message: errorMessage,
                            title: ''
                        });
                    };

                    var showLoading = function () {
                        util.showLoading();
                    };

                    var hideLoading = function () {
                        util.hideLoading();
                    };

                    var changeTab = function (newTab) {
                        $ctrl.tab = newTab;
                    };

                    /**
				 * move calendar to previous month
				 */
                    var moveBack = function () {
                        if (angular.isDate($ctrl.date) && 
						$ctrl.configData.consoleSettings && $ctrl.configData.consoleSettings.viewPeriod) {
                            $ctrl.date = moment($ctrl.date).subtract($ctrl.configData.consoleSettings.viewPeriod, 'weeks').toDate();
                        }
					
                    };

                    /**
				 * move calendar to next month
				 */
                    var moveNext = function () {
                        if (angular.isDate($ctrl.date) && 
						$ctrl.configData.consoleSettings && $ctrl.configData.consoleSettings.viewPeriod) {
                            $ctrl.date = moment($ctrl.date).add($ctrl.configData.consoleSettings.viewPeriod, 'weeks').toDate();
                        }
                    };

                    var moveMonthBack = function () {
                        var prevDate;

                        if (angular.isDate($ctrl.date)) {
                            prevDate = angular.copy($ctrl.date);
                            prevDate.setMonth($ctrl.date.getMonth() - 1);
                            prevDate.setDate(1);

                            $ctrl.date = prevDate;
                        }
                    };

                    /**
				 * move calendar to next month
				 */
                    var moveMonthNext = function () {
                        var nextDate;

                        if (angular.isDate($ctrl.date)) {
                            nextDate = angular.copy($ctrl.date);
                            nextDate.setMonth($ctrl.date.getMonth() + 1);
                            nextDate.setDate(1);

                            $ctrl.date = nextDate;
                        }
                    };

                    var doInitialize = function (requestParams) {
                        return api.initialize(requestParams)
                            .catch(commonExceptionHanlder);
                    };

                    var getInitialData = function (patientId) {
                        var requestParams = {
                            recordId: patientId,
                            configKeys: PAC_REQUIRED_CONFIG_DATA
                        };

                        return doInitialize(requestParams)
                            .then(function (result) {
                                if (result.success) {
                                    $ctrl.configData = model.ConfigDataModel.fromServer(result.data);
                                    console.log($ctrl.configData);

                                    return $ctrl.configData;
                                } else {
                                    return $q.reject(result);
                                }
                            });
                    };

                    var initCalDate = function () {
                        $ctrl.date = moment().toDate();
                        $ctrl.date.setHours(0, 0, 0, 0);
                    };

                    var togggleQueuedJobsSideMenu = function() {
                        $scope.$broadcast('toggleQueuedJobsMenu');
                    };

                    var closeCheckAvailability = function(message, data){
                        // run onClose expression
                        if (angular.isFunction ($ctrl.onClose)) {
                            $ctrl.onClose({
                                message: message,
                                data: data
                            });
                        }
                    };

                    var refreshCheckAvailability = function() {
                        $scope.$broadcast('refreshCheckAvailability');
                    };

                    var addAppointmentIndividualJob = function () {
                        $scope.$broadcast('pac.appointment.addNewIndividualJob');
                    };

                    var refreshConsole = function () {
                        $scope.$broadcast('pac.refreshConsole');
                    };

                    var doSearchAccounts = function(searchString) {
                        return api.search({
                            objectType: OBJECT_TYPE.ACCOUNT,
                            queryText: searchString
                        })
                            .catch(commonExceptionHanlder);
                    };

                    var searchAccounts = function(searchString) {
                        if(util.isNullOrEmpty(searchString)) {
                            searchString = '';
                        }
						
                        return doSearchAccounts(searchString)
                            .then(function (result) {
                                if (result.success) {
                                    return model.AccountModel.fromServerList(result.data);
                                } else {
                                    return $q.reject(result);
                                }
                            });
                    };

                    var onAccountChanged = function(newPatient) {
                        if(!newPatient) {
                            $ctrl.patientId = null;
                            return;
                        }

                        showLoading();
                        getInitialData(newPatient.id)
                            .then(function(){
                                processConfigData();
                                $ctrl.patientId = newPatient.id;
                            })
                            .catch(function (exception) {
                                if (exception && exception.errorMessage) {
                                    util.toastError(exception.errorMessage);
                                }
                            })
                            .finally(function () {
                                hideLoading();
                            });
                    };

                    var processConfigData = function() {
                        if(!$ctrl.configData) return;

                        var configData = $ctrl.configData;
                        var eventTypeSettings = angular.copy(configData.eventTypeSettings) || [];

                        // map service location with regions
                        angular.forEach(configData.serviceLocations, function (serviceLocation) {
                            var regionIdx;

                            if (serviceLocation.region) {
                                regionIdx = regionIds.indexOf(serviceLocation.region.id);

                                if (regionIdx > -1) {
                                    serviceLocation.region = configData.regions[regionIdx];
                                }
                            } 
                        });

                        // color map
                        configData.colorMap = {};
                        for (var k = 0; k < eventTypeSettings.length; k++) {
                            if (eventTypeSettings[k].eventType === 'Preferred') {
                                configData.colorMap.Preferred = eventTypeSettings[k];
                            } else if (eventTypeSettings[k].eventType === 'Normal') {
                                configData.colorMap.Normal = eventTypeSettings[k];
                            } else if (eventTypeSettings[k].eventType === 'Unavailable') {
                                configData.colorMap.Unavailable = eventTypeSettings[k];
                            }
                        }

                        // process job types
                        angular.forEach(configData.jobTypes, function (jobType) {
                            for (var i = 0; i < eventTypeSettings.length; i++) {
                                if (eventTypeSettings[i].eventType === jobType.id) {
                                    jobType.eventTypeSettings = eventTypeSettings[i];
                                    eventTypeSettings.splice(i, 1);
                                    break;
                                }
                            }
                        });

                        // client availability types
                        /*angular.forEach(configData.clientAvailabilityTypes, function (clientAvailabilityType) {
						for (var j = 0; j < eventTypeSettings.length; j++) {
							if (eventTypeSettings[j].eventType === clientAvailabilityType.id) {
								clientAvailabilityType.eventTypeSettings = eventTypeSettings[j];
								eventTypeSettings.splice(j, 1);
								break;
							}
						}
					});*/

                        configData.otherEventTypes = [];
                        if (eventTypeSettings.length > 0) {
                            angular.forEach(eventTypeSettings, function (settings) {
                                configData.otherEventTypes.push({
                                    id: settings.eventType,
                                    name: settings.eventType,
                                    eventTypeSettings: settings
                                });
                            });
                        }

                    };

                    var getFirstDay = function () {
                        var firstDay = 0;

                        if ($ctrl.configData && $ctrl.configData.consoleSettings && $ctrl.configData.consoleSettings.firstDay > 0) {
                            firstDay = $ctrl.configData.consoleSettings.firstDay;
                        }

                        return firstDay;
                    };

                    /**
				 * controller init
				 */
                    $ctrl.$onInit = function () {
                        // init default date
                        //initCalDate();
                        if(!$ctrl.mode) $ctrl.mode = MODE.LONG_TERM_SCHEDULING;

                        if(searchParams) {
                            $ctrl.patientId = $ctrl.patientId || searchParams.patientId;
                            $ctrl.supportPlanId = $ctrl.supportPlanId || searchParams.supportPlanId;
                            //$ctrl.regionId = $ctrl.regionId || searchParams.regionId;
                        }
					
                        if($ctrl.mode === MODE.PORTAL || $ctrl.mode === MODE.CHECK_AVAILABILITY) {
                            $ctrl.tab = TABS.AVAILABILITY;
                        }

                        $ctrl.needToSelectPatient = !$ctrl.patientId;

                        $ctrl.isInitCompleted = false;
                        showLoading();

                        var initFns = [];
                        if((!$ctrl.configData)) {
                            initFns.push(getInitialData($ctrl.patientId));
                        }
                        $q.all(initFns)
                            .then(function () {
                                processConfigData();
                                return true;
                            })
                            .then(function (results) {     
                                // init default date
                                initCalDate();

                                // init week picker
                                weekPickerOptions.firstDay = getFirstDay();
                                $ctrl.weekPickerOptions = weekPickerOptions;
                                $ctrl.viewRegion =  $ctrl.configData.patient.region ? _.find($ctrl.configData.regions, {
                                    id: $ctrl.configData.patient.region.id
                                }) : null; 
								
                                $ctrl.needToSelectRegion = !$ctrl.viewRegion;

                                $ctrl.isInitCompleted = true;

                                return results;
                            })
                            .then(function () {
                                if (!$ctrl.isJobEditing && $ctrl.viewCapacityGrid === true) {
                                    $timeout(function () {
                                        addAppointmentIndividualJob();
                                    }, 1000);
                                }
                            })
                            .catch(function (exception) {
                                if (exception && exception.errorMessage) {
                                    showErrorPrompt(exception.errorMessage, false);
                                    // util.toastError(exception.errorMessage);
                                }
                            })
                            .finally(function () {
                                hideLoading();
                            });
                    };

                    /**
				 * scope init
				 */
                    (function init() {
                        $scope.DEFAULT_PHOTO_URL = DEFAULT_PHOTO_URL;
                        $scope.MODE = MODE;
                        $scope.LAYOUT_MODE = LAYOUT_MODE;
                        $scope.TABS = TABS;

                        $ctrl.isInitCompleted = false;
                        $ctrl.mode = MODE.LONG_TERM_SCHEDULING;
                        $ctrl.filter = new model.PACFilterModel();
                        $ctrl.date = null;
                        $ctrl.days = [];
                        $ctrl.userFilter = null;
                        $ctrl.configData = null;
                        $ctrl.tab = TABS.CAPACITY_GRID;

                        $ctrl.changeTab = changeTab;
                        $ctrl.moveBack = moveBack;
                        $ctrl.moveNext = moveNext;
                        $ctrl.moveMonthBack = moveMonthBack;
                        $ctrl.moveMonthNext = moveMonthNext;
                        $ctrl.searchAccounts = searchAccounts;
                        $ctrl.onAccountChanged = onAccountChanged;
                        $ctrl.closeCheckAvailability = closeCheckAvailability;
                        $ctrl.refreshCheckAvailability = refreshCheckAvailability;
                        $ctrl.togggleQueuedJobsSideMenu = togggleQueuedJobsSideMenu;

                        $ctrl.addAppointmentIndividualJob = addAppointmentIndividualJob;

                        $ctrl.layoutMode = LAYOUT_MODE.TWO_WEEKS;
                        //$ctrl.weekPickerOptions = weekPickerOptions;
                        $ctrl.focusInput = focusInput;
                        $ctrl.formatWeekPickerDates = formatWeekPickerDates;

                        $ctrl.isJobEditing = false;
                        $ctrl.refreshConsole = refreshConsole;

                        $scope.$on('toggleCreateJob', function(message, data){
                            closeCheckAvailability('done', data);
                        });

                        $scope.$watch('$ctrl.date', function (newVal) {
                            $ctrl.calendarStartDate = null;
                            $ctrl.calendarEndDate = null;

                            if (angular.isDate(newVal)) {
                                $ctrl.calendarStartDate = angular.copy($ctrl.date);

                                $ctrl.calendarStartDate.setDate($ctrl.calendarStartDate.getDate() - (($ctrl.calendarStartDate.getDay() + 7 - getFirstDay()) % 7));
                                $ctrl.calendarEndDate = angular.copy($ctrl.calendarStartDate);
                                $ctrl.calendarEndDate.setDate($ctrl.calendarEndDate.getDate() + (($ctrl.configData.consoleSettings.viewPeriod * 7) - 1));
                            }
                        });

                        $scope.$on('pac.appointment.editIndividualJob', function (event, args) {
                            $ctrl.isJobEditing = !!args.editingJob;
                        });
                    })();
                }
            ]
        });
})(angular, moment, jQuery);