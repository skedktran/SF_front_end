(function (angular) {
    angular.module('hltApp')
    .directive('pacDraggableTimeslots', [
        '$timeout',
        '$window',
        '$compile',
        'constants',
        function($timeout, $window, $compile, constants) {
            var isDraggingIgnored = function (target, currentTarget) {
                var isDraggingIgnored = false;

                for (var element = target; element && currentTarget && element !== currentTarget; element = element.parentNode) {
                    if (element.hasAttribute && element.hasAttribute('dragging-ignored')) {
                        isDraggingIgnored = (/^(true|1)$/i).test(element.getAttribute('dragging-ignored'));
                        break;
                    }
                }

                return isDraggingIgnored;
            };

            var isMouseDownIgnored = function (target, currentTarget) {
                var isMouseDownIgnored = false;

                for (var element = target; element && currentTarget && element !== currentTarget; element = element.parentNode) {
                    if (element.hasAttribute && element.hasAttribute('mouse-down-ignored')) {
                        isMouseDownIgnored = (/^(true|1)$/i).test(element.getAttribute('mouse-down-ignored'));
                        break;
                    }
                }

                return isMouseDownIgnored;
            };

            return {
                scope: false,
                link: function ($scope, $el, $attr) {
                    var curDown = false;
                    var MODE = constants.PAC_MODE;
                    var windowEl = angular.element($window);
                    var mouseUpCallback = $attr.pacDraggableTimeslotsMouseUpCallback;
                    var api = $scope.$eval($attr.pacDraggableTimeslotsApi);
                    var mode = $scope.$eval($attr.pacDraggableTimeslotsMode);

                    var timeslotSelectionEl;

                    var startPosition, startTimeslot,
                        endPosition, endTimeslot;

                    var elOffset, elPosition, elHeight;

                    var timeslotHeight;
                    var timeslotsSource = $scope.$eval($attr.pacDraggableTimeslots);

                    var isDisabled = function() {
                        return !!$scope.$eval($attr.pacDraggableTimeslotsDisabled);
                    }

                    var handleMouseDown = function (event) {
                        var targetEl, targetScope, item;

                        if (event.which === 1) {
                            //clear all current selections
                            angular.element('.hco-rac-timeslot-selection').remove();

                            targetEl = angular.element(event.target);

                            if(isDisabled() || isDraggingIgnored(event.target, $el) || isMouseDownIgnored(event.target, $el)) {
                                return;
                            }

                            elOffset = $el.offset();
                            elPosition = $el.position();
                            elHeight = $el.height();

                            curDown = true;
                            startPosition = (Math.floor((event.pageY - elOffset.top + elPosition.top) / timeslotHeight)) * timeslotHeight;
                            if (startPosition < 0) {
                                startPosition = 0;
                            }

                            endPosition = startPosition;
                            
                            windowEl.on('mousemove', handleMouseMove);
                            windowEl.on('mouseup', handleMouseUp);

                            timeslotSelectionEl = angular.element('<div class="hco-rac-timeslot-selection" ></div>');
                            timeslotSelectionEl.appendTo($el);
                            timeslotSelectionEl.css({
                                'z-index': 1,
                                left: 0,
                                height: timeslotHeight,
                                top: startPosition
                            });
                        }
                    };


                    var handleMouseUp = function (event) {
                        var clonedSelectionEl;
                        var handleHideTimeslotSelection = function () {
                            if (clonedSelectionEl) {
                                clonedSelectionEl.remove();
                                clonedSelectionEl = null;
                            }
                        };

                        if (curDown) {
                            curDown = false;

                            timeslotSelectionEl.trigger('click');

                            var startTimeSlot = identifyTimeSlot((startPosition <= endPosition)?startPosition:endPosition);
                            var endTimeSlot = identifyTimeSlot((startPosition > endPosition)?startPosition:endPosition);
                            var selectedDate = $scope.day.date;

                            windowEl.off('mousemove', handleMouseMove);
                            windowEl.off('mouseup', handleMouseUp);

                            if(mode === MODE.CHECK_AVAILABILITY) {             
                                if (timeslotSelectionEl) {
                                    clonedSelectionEl = timeslotSelectionEl.clone();

                                    timeslotSelectionEl.remove();
                                    timeslotSelectionEl = null;

                                    clonedSelectionEl.appendTo($el);
                                }
                   
                                if(mouseUpCallback) {
                                    $scope.$eval(mouseUpCallback, {
                                        event: {
                                            currentTarget: clonedSelectionEl
                                        },
                                        data: {
                                            selectedDate: selectedDate,
                                            startTimeSlot: startTimeSlot,
                                            endTimeSlot: endTimeSlot,
                                            handleHideTimeslotSelection: handleHideTimeslotSelection
                                        }
                                    })
                                }
                            } else {
                                if (timeslotSelectionEl) {
                                    timeslotSelectionEl.remove();
                                    timeslotSelectionEl = null;
                                }

                                if(mouseUpCallback) {
                                    $scope.$eval(mouseUpCallback, {
                                        event: event,
                                        data: {
                                            selectedDate: selectedDate,
                                            startTimeSlot: startTimeSlot,
                                            endTimeSlot: endTimeSlot
                                        }
                                    })
                                }
                            }
                        }
                    };

                    var handleMouseMove = function (event) {
                        var selectionElHeight, tempPosition;
                        
                        var targetEl, item, pageY;
                        
                        targetEl = angular.element(event.target);
                        if(isDraggingIgnored(event.target, $el)) {
                            return;
                        }

                        endPosition = (Math.floor((event.pageY - elOffset.top + elPosition.top) / timeslotHeight)) * timeslotHeight;
                        if (endPosition > startPosition) {
                            endPosition = (Math.floor((event.pageY - 1 - elOffset.top + elPosition.top) / timeslotHeight)) * timeslotHeight;
                        }

                        // limit the selection
                        if (endPosition < 0) {
                            endPosition = 0;
                        } else if (endPosition > (elHeight - timeslotHeight)) {
                            endPosition = elHeight;
                        }

                        if (startPosition !== endPosition) {
                            selectionElHeight = Math.abs(endPosition - startPosition);
                            
                            if (endPosition < startPosition) {
                                timeslotSelectionEl.css('top', endPosition);
                            } 
                            
                            timeslotSelectionEl.css('height', selectionElHeight + timeslotHeight);
                        } else {
                            timeslotSelectionEl.css({
                                height: timeslotHeight,
                                top: startPosition
                            });
                        }
                    };

                     var identifyTimeSlotByRemHeight = function (postion, slotHeightInRem) {
                        var timeslotIndx = Math.floor(postion / slotHeightInRem);
                        var timeslot = timeslotsSource[timeslotIndx];

                        return timeslot;
                    };
                    
                    var identifyTimeSlot = function (postion) {
                        var timeslotIndx = Math.floor(postion / timeslotHeight);
                        var timeslot = timeslotsSource[timeslotIndx];

                        return timeslot;
                    };

                    $el.on('mousedown', handleMouseDown);
                    //$el.on('mouseup', handleMouseUp);

                    $timeout(function () {
                        timeslotHeight = angular.element('.timeslot__items li').height();
                    });

                    if(api) {
                        if(!api.selectTimeslotsByDate) api.selectTimeslotsByDate = {};
                        api.selectTimeslotsByDate[$scope.day.dateIso] = function(startPositionInRem, endPositionInRem, slotHeightInRem) {
                            var clonedSelectionEl;
                            var handleHideTimeslotSelection = function () {
                                if (clonedSelectionEl) {
                                    clonedSelectionEl.remove();
                                    clonedSelectionEl = null;
                                }
                            };

                            //clear all current selections
                            angular.element('.hco-rac-timeslot-selection').remove();

                            if (timeslotSelectionEl) {
                                timeslotSelectionEl.remove();
                                timeslotSelectionEl = null;
                            }

                            timeslotSelectionEl = angular.element('<div class="hco-rac-timeslot-selection"></div>');
                            timeslotSelectionEl.appendTo($el);
                            timeslotSelectionEl.css({
                                'z-index': 9,
                                left: 0,
                                height: Math.abs(endPositionInRem - startPositionInRem) + 'rem',
                                top: startPositionInRem + 'rem'
                            });    

                            clonedSelectionEl = timeslotSelectionEl.clone();
                            timeslotSelectionEl.remove();
                            timeslotSelectionEl = null;
                            clonedSelectionEl.appendTo($el);

                            var startTimeSlot = identifyTimeSlotByRemHeight((startPositionInRem <= endPositionInRem)?startPositionInRem:endPositionInRem, slotHeightInRem);
                            var endTimeSlot = identifyTimeSlotByRemHeight(((startPositionInRem > endPositionInRem)?startPositionInRem:endPositionInRem) - slotHeightInRem, slotHeightInRem);
                            var selectedDate = $scope.day.date;

                            if(mouseUpCallback) {
                                $scope.$eval(mouseUpCallback, {
                                    event: {
                                        currentTarget: clonedSelectionEl
                                    },
                                    data: {
                                        selectedDate: selectedDate,
                                        startTimeSlot: startTimeSlot,
                                        endTimeSlot: endTimeSlot,
                                        handleHideTimeslotSelection: handleHideTimeslotSelection
                                    }
                                })
                            }
                        }
                    }
                }
            };
        }
    ])
})(angular);