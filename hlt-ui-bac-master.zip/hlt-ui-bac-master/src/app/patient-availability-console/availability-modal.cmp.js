(function (angular, topWindow) {
    angular.module('hltApp')
        .component('availabilityModal', {
            templateUrl: 'src/app/patient-availability-console/availability-modal.tpl.html',
            bindings: {
                configData: '<',
                //patient: '<',
                //region: '<',
                availability: '<',
                onClose: '&',
            },
            controller: [
                '$scope',
                '$q',
                'api',
                'util',
                'model',
                'constants',
                function ($scope, $q,  api, util, model, constants) {
                    var $ctrl = this;
                
                    var PAGE_MODE = constants.PAGE_MODE;
                    var INTEGER_PATTERN = constants.INTEGER_PATTERN;
                
                    var getArray = function (len) {
                        len = len || 0;
                        return new Array(len);
                    };

                    /**
                 * common remote action error handler
                 */
                    var commonExceptionHanlder = function (exception) {
                        util.toastError('Can not perform action due to server error.');

                        return $q.reject(exception);
                    };

                    /**
                 * show content loading
                 */
                    var showLoading = function () {
                        $ctrl.contentLoading = true;
                    };

                    /**
                 * hide content loading
                 */
                    var hideLoading = function () {
                        $ctrl.contentLoading = false;
                    };

                    /**
                 * close main modal
                 */
                    var closeModal = function (message) {
                        $ctrl.isModalOpen = false;
                        // run onClose expression
                        if (angular.isFunction ($ctrl.onClose)) {
                            $ctrl.onClose({
                                message: message
                            });
                        }
                    };

                    var doSaveAvailability = function (params) {
                        return api.saveClientAvailability(params)
                            .catch(commonExceptionHanlder);
                    };

                    var saveAvailability = function () {
                        var params;
                        var savingCallback = function (result) {
                            if (result.success) {
                            //hasConflict = result.data && result.data.length && _.filter(result.data, {hasConflict: true}).length;
                                var hasConflict = result.data && result.data.hasConflict;

                                if(hasConflict) {
                                    showAvailabilityConflictsModal(result.data);
                                } else {
                                    util.toastSuccess('Availability has been ' + (($ctrl.pageMode === PAGE_MODE.CREATE) ? 'created' : 'updated') + ' successfully.');
                                    closeModal('done');
                                }
                            } else{
                                return $q.reject(result);
                            }
                        };

                        if (validateAvailability()) {
                            params = buildAvailabilitySavingParams();

                            showLoading();
                            doSaveAvailability(params)
                                .then(savingCallback)
                                .catch(function (exception) {
                                    if (exception && exception.errorMessage) {
                                        util.toastError(exception.errorMessage);
                                    }
                                })
                                .finally(function () {
                                    hideLoading();
                                });
                        }
                    };

                    var showAvailabilityConflictsModal = function (data) {
                        util.showModal({
                            template: '<availability-conflicts-modal class="sked-modal-container" data="data" config-data="configData" on-close="onClose(this, message)"></availability-conflicts-modal>',
                        }, {
                        //region: $ctrl.region,
                            data: data,
                            //patient: $ctrl.configData.patient,
                            configData: $ctrl.configData,
                            onClose: function (modalScope, message) {
                                modalScope.closeModal();

                                if (message === 'done') {
                                    util.toastSuccess('Availability has been ' + (($ctrl.pageMode === PAGE_MODE.CREATE) ? 'created' : 'updated') + ' successfully.');
                                    closeModal('done');
                                }
                            }
                        });
                    };

                    var validateAvailability = function () {
                        var form = $ctrl.form;
 
                        form.$setSubmitted(true);

                        if (form.$error.required) {
                            util.toastError('Please check all required fields.');
                            return false;
                        }

                        if (form.$error.pattern || form.$error.number || form.$error.skedTimeValidator) {
                            util.toastError('Invalid data format, please check date/time and number fields.');
                            return false;
                        }

                        if (form.$error.min) {
                            util.toastError('Number of repeating weeks should be greater than or equal to ' + $ctrl.recurring.pattern.value + '.');
                            return false;
                        }

                        var recurringErrorMessage = $ctrl.recurringSectionApi && angular.isFunction($ctrl.recurringSectionApi.validate) ? $ctrl.recurringSectionApi.validate() : null;
                        if(recurringErrorMessage) {
                            util.toastError(recurringErrorMessage);
                            return false;
                        }

                        return true;
                    };

                    var buildAvailabilitySavingParams = function () {
                        var tempAvailability = angular.copy($ctrl.availability);
                        var recurringModel = $ctrl.recurringSectionApi && angular.isFunction($ctrl.recurringSectionApi.getRecurringModel) ? $ctrl.recurringSectionApi.getRecurringModel() : null;

                        if(recurringModel && recurringModel.scheduleData) {
                        // availability date/time
                            tempAvailability.startDate = recurringModel.scheduleData.startDate;
                            tempAvailability.endDate = recurringModel.scheduleData.startDate;
                            tempAvailability.startTime = recurringModel.scheduleData.startTime;
                            tempAvailability.endTime = recurringModel.scheduleData.endTime;
                            tempAvailability.preferredStartTime = recurringModel.scheduleData.preferredStartTime;
                            tempAvailability.preferredEndTime = recurringModel.scheduleData.preferredEndTime;
                            tempAvailability.hasPreferredTimes = recurringModel.scheduleData.hasPreferredTimes;
                            tempAvailability.isAllTimePreferred = recurringModel.scheduleData.isAllTimePreferred;
                        }
                
                        var availabilityParams = tempAvailability.toServer();

                        // patient
                        //availabilityParams.patientId = $ctrl.patient.id;

                        return {
                            event: availabilityParams,
                            recurringOptions: recurringModel ? recurringModel.recurringOptions : null
                        };
                    };

                    var doSearchSchedules = function (searchParams) {
                        return api.searchSchedules(searchParams)
                            .catch(commonExceptionHanlder);
                    };

                    var searchSchedules = function (searchString) {
                        return doSearchSchedules({
                            //patientId: $ctrl.patient.id,
                            textSearch: searchString || ''
                        }).then(function (result) {
                            var resultData;
                            var filterCriterion = 'clientAvailability';
                            var schedules = [];

                            if (result.success) {
                                resultData = result.data;
                                
                                if (angular.isArray(resultData) && resultData.length) {
                                    resultData = resultData.filter(function (dataItem) {
                                        return dataItem.objectType === filterCriterion;
                                    });

                                    schedules = model.ScheduleModel.fromServerList(resultData);
                                }
                            } 

                            return schedules;
                        });
                    };

                    /**
                     * controller init
                     * used for setting initial value
                     */
                    $ctrl.$onInit = function () {
                        $ctrl.isModalOpen = true;

                        $ctrl.pageMode = $ctrl.availability && $ctrl.availability.id ? PAGE_MODE.EDIT : PAGE_MODE.CREATE;

                        if ($ctrl.pageMode === PAGE_MODE.CREATE) {
                            var tempAvailability = angular.copy($ctrl.availability);

                            $ctrl.availability = new model.PACAvailabilityModel();
                            $ctrl.availability.startDate = moment().toDate();
                            $ctrl.availability.endDate = moment().toDate();
                            $ctrl.availability.startTime = 0;
                            $ctrl.availability.endTime = 30;
                            $ctrl.availability.isAvailable = $ctrl.configData.patient.availabilityType === constants.SERVICE_USER_AVAIBILITY_TYPE.AVAILABILITY_ONLY;

                            if(tempAvailability) {
                                if(!util.isNullOrEmpty(tempAvailability.startDate)) {
                                    $ctrl.availability.startDate = tempAvailability.startDate;
                                }

                                if(!util.isNullOrEmpty(tempAvailability.endDate)) {
                                    $ctrl.availability.endDate = tempAvailability.endDate;
                                }

                                if(!util.isNullOrEmpty(tempAvailability.startTime)) {
                                    $ctrl.availability.startTime = tempAvailability.startTime;
                                }

                                if(!util.isNullOrEmpty(tempAvailability.endTime)) {
                                    $ctrl.availability.endTime = tempAvailability.endTime;
                                }
                            }

                            $ctrl.availability.serviceLocation = _.find($ctrl.configData.serviceLocations, { selected: true });
                        //$ctrl.availability.region = angular.copy($ctrl.region);
                        } else {
                            if($ctrl.availability.serviceLocation) {
                                $ctrl.availability.serviceLocation = _.find($ctrl.configData.serviceLocations, {id: $ctrl.availability.serviceLocation.id});
                            }
                        }
                    };

                    /**
                 * init block
                 * used for setting up controller
                 */
                    (function () {
                        $scope.INTEGER_PATTERN = INTEGER_PATTERN;
                        $scope.PAGE_MODE = PAGE_MODE;   

                        $ctrl.form = null;
                        $ctrl.recurringSectionApi = {};
                        $ctrl.isModalOpen = false;
                        $ctrl.contentLoading = false;

                        $ctrl.closeModal = closeModal;
                        $ctrl.pageMode = PAGE_MODE.CREATE;

                        $ctrl.getArray = getArray;
                        $ctrl.util = util;

                        $ctrl.saveAvailability = saveAvailability;
                        $ctrl.getArray = getArray;
                        $ctrl.searchSchedules = searchSchedules;
                    })();
                }
            ]
        });
})(angular, top);