(function (angular, moment, $) {
  angular.module('hltApp')
    .component('capacityGridConsole', {
      templateUrl: 'src/app/patient-availability-console/capacity-grid-console.tpl.html',
      bindings: {
        date: '=',
        configData: '<',
        filter: '<',
        layout: '=',
        patientId: '<',
        viewRegion: '<'
      },
      controller: [
        '$window',
        '$timeout',
        '$location',
        '$q',
        '$scope',
        '$filter',
        'util',
        'dateUtil',
        'api',
        'constants',
        'model',
        'availatorUtil',
        'uiGmapGoogleMapApi',
        function ($window, $timeout, $location, $q, $scope, $filter, util, dateUtil, api, constants, model, availatorUtil, uiGmapGoogleMapApi) {
          var $ctrl = this;
          var currentParams = {};
          var bookingGridCurrentParams = {};
          var mapsApi = null;

          var MODE = constants.PAC_MODE;
          var LAYOUT_MODE = constants.LAYOUT_MODE;
          var EVENT_TYPE = constants.EVENT_TYPE;
          var TABS = constants.PATIENT_AVAILABILITY_TABS;
          var DEFAULT_PHOTO_URL = $filter('skedSfUrl')(constants.DEFAULT_AVATAR_URL);
          var GRID_SETTINGS = constants.DEFAULT_GRID_SETTINGS;
          var OBJECT_TYPE = constants.OBJECT_TYPE;
          var DEFAULT_TIMESLOT_INTERVAL = 30;

          var ERROR_MESSAGE = {
            OUT_OF_SERVICE: 'OUT_OF_SERVICE',
            CONCURRENCY_ERROR: 'CONCURRENCY_ERROR',
            CONCURRENCY_PATIENT_ERROR: 'CONCURRENCY_PATIENT_ERROR'
          };
          var WEEK_DAYS = [
            'Sunday',
            'Monday',
            'Tuesday',
            'Wednesday',
            'Thursday',
            'Friday',
            'Saturday',
          ];

          var searchParams = $location.search();

          var commonExceptionHanlder = function (exception) {
            util.toastError('Can not perform action due to server error.');

            return $q.reject(exception);
          };

          var showGetExceptionLogLoading = function() {
						$ctrl.exceptionLogLoading = true;
					}

					var hideGetExceptionLogLoading = function() {
						$ctrl.exceptionLogLoading = false;
          }
          
          var showLoading = function () {
            util.showLoading();
          };

          var hideLoading = function () {
            util.hideLoading();
          };

          /**
                 * check whether calendar params are really changed
                 */
          var isParamsReallyChanged = function (params) {
            return !_.isEqual(angular.copy(params), angular.copy(currentParams));
          };

          var doGetGridData = function (params) {
            return api.getClientAvailability(params)
              .catch(commonExceptionHanlder);
          };

          var doGetJobExceptions = function (params) {
            return api.getExceptionLogs(params)
              .catch(commonExceptionHanlder);
          };


          var doGetBookingGridData = function (query) {
            return api.getBookingGrid(query)
              .catch(commonExceptionHanlder);
          };

          /**
                 * check whether calendar params are really changed
                 */
          var isBookingGridParamsReallyChanged = function (params) {
            return !util.compareValues(params, bookingGridCurrentParams);
          };

          /**
                 * erase calendar data
                 */
          var eraseBookingGrid = function () {
            bookingGridCurrentParams = {};

            if ($ctrl.bookingGrid) {
              $ctrl.bookingGrid.data = [];
            }
          };

          var processBookingGridData = function (bookingGridData) {
            var data = angular.copy($ctrl.bookingGrid.days);
            var timeslots = angular.copy(bookingGridData.slots);

            if (angular.isArray(timeslots) && timeslots.length > 0) {
              angular.forEach(data, function (day) {
                // process timeslot data
                for (var i = 0; i < timeslots.length; i++) {
                  if (day.dateIso === timeslots[i].startDate) {
                    if (!angular.isObject(day.timeslots)) {
                      day.timeslots = {};
                    }

                    day.timeslots[timeslots[i].startTime] = timeslots[i];

                    timeslots.splice(i, 1);
                    i--;
                  }
                }
              });
            }

            return data;
          };

          var getBookingGridData = function (queryStack, dataArray, queryIndex) {
            if (queryIndex > queryStack.length - 1) {
              return dataArray;
            } else {
              return doGetBookingGridData(queryStack[queryIndex])
                .then(function (result) {
                  if (result.success) {
                    dataArray.push(result.data);
                    return getBookingGridData(queryStack, dataArray, queryIndex+1);
                                
                  } else {
                    return $q.reject(result);
                  }
                });
            }
          }; 

          /**
           * load booking grid data
           */
          var rebuildBookingGrid = function (forceBuild) {
            var requestParams = null;
            var enableJobOffer = true;
            var currentJobs = [];
            var resources = [];
            var resourceAvailabilitySimply = [];

            var initializeBookingGrid = function(request) {
              var timezoneSidId = request.timezoneSidId;
              var startDate = dateUtil.parseDateString(request.startDate);
              var endDate = dateUtil.parseDateString(request.endDate);
              var startTime = moment(startDate).startOf('day').toDate();
              var step = request.step || 30;
              var duration = $ctrl.editingJob.duration;

              var g = {};
              g.timezoneSidId = timezoneSidId;
              g.inputDates = [];
              var jobs = [];
              var daysNumber = moment(endDate).diff(moment(startDate), 'days');
              var startTimeDt = _.cloneDeep(startTime);
              for (var i = 0; i <= daysNumber; i++) {
                  var startDateStr = dateUtil.dateToString(startTimeDt);
                  var startTimeMinute = 0;
                  while(startTimeMinute < 24 * 60) {
                      var job = {};
                      var startDate = startDateStr;
                      var startTime = dateUtil.parseTimeFromMinute(startTimeMinute);
                      var endTime = dateUtil.parseTimeFromMinute(startTimeMinute + duration);
                      var endDayOffset = Math.floor(endTime / 2400);
                      endTime = Math.floor(endTime % 2400);
                      var endDate = moment(dateUtil.parseDateString(startDate)).add(endDayOffset, 'days').toDate();

                      job.sked__Start__c = dateUtil.parseDateTimeInfo({
                        date: startDate,
                        timeNumber: startTime
                      }, timezoneSidId)
                      job.sked__Finish__c = dateUtil.parseDateTimeInfo({
                        date: endDate,
                        timeNumber: endTime
                      }, timezoneSidId)
                      
                      job.sked__Timezone__c = timezoneSidId;
                      job.sked__GeoLocation__Longitude__s = $ctrl.editingJob.address.geometry.lng;
                      job.sked__GeoLocation__Latitude__s = $ctrl.editingJob.address.geometry.lat;
                      jobs.push(job);
                      
                      //first job
                      if(jobs.length === 1) {
                        g.expiryTagDate = dateUtil.parseDateTimeInfo({
                          date: startDate,
                          timeNumber: endTime
                        }, timezoneSidId, true)
                      }

                      if(g.inputDates.indexOf(startDate) === -1) {
                        g.inputDates.push(startDate);
                      }
                      startTimeMinute += step;
                  }
                  startTimeDt = moment(startTimeDt).add(1, 'day').toDate();
              }
              g.slots = jobs || [];
              return g;
            }

            var populateDateTimeToSObject = function(sObject, timezoneSidId) {
              var startDateTime = dateUtil.getDateTimeInfo(sObject.sked__Start__c || sObject.sked_Start_Date__c, timezoneSidId);
              sObject.start = startDateTime.dateTime;
              sObject.startDate = startDateTime.date;
              sObject.startTime = startDateTime.timeNumber
  
              var endDateTime = dateUtil.getDateTimeInfo(sObject.sked__Finish__c || sObject.sked__End__c || sObject.sked_End_Date__c, timezoneSidId);
              sObject.finish = endDateTime.dateTime;
              sObject.endDate = endDateTime.date;
              sObject.endTime = endDateTime.timeNumber
  
              return sObject;
            }
  
            var doGetResourceData = function(requestParams, pageNo) {
              return api.getResourceData(_.extend({}, requestParams, {
                pageNo: pageNo || 1,
                pageSize: 200
              })).then(function (result) {
                if (result.success && result.data) {
                  var resultData = result.data;
                  var totalRecords = resultData.totalRecords;
                  resources = resources.concat(resultData.resources);
                  
                  if(pageNo === 1) {
                    util.showProgressBar({
                      message: 'Loading resource data...',
                      totalRecords: totalRecords, 
                      totalPercentage: 240,
                      processedRecords: resources.length
                    });
                  } else {
                    util.updateProgressBar(resources.length);
                  }
  
                  if (totalRecords > resources.length) {
                    return doGetResourceData(requestParams, pageNo + 1);
                  } else {
                    return {
                      resources: resources
                    };
                  }
                } else {
                  return $q.reject(result);
                }
              });
            }
  
            var doGetResourceAvailabilitySimply = function(requestParams) {
              var resourcesPerCall = 200;
  
              var promises = _.chunk(requestParams.resourceIds, resourcesPerCall).map(function (resourceIds) {
                return function() {
                  return api.getResourceAvailabilitySimply(_.extend({}, requestParams, {
                    resourceIds: resourceIds
                  }))
                    .then(function(result) {
                      if(!result.success) {
                        return $q.reject(result);
                      }
  
                      resourceAvailabilitySimply = resourceAvailabilitySimply.concat((result.data || {}).result || []);
                      util.updateProgressBar(resourceAvailabilitySimply.length);
                      return {
                        success: true,
                        data: resourceAvailabilitySimply || []
                      };
                    });
                };
              });
  
              return $q.when()
              .then(function() {
                if(!promises.length) {
                  return {
                    success: true,
                    data: []
                  };
                }
  
                return util.serial(promises);
              })
              .catch(commonExceptionHanlder);
            } 
  
            var doTransformAvailabilitySimply = function(data, timezoneSidId) {
              var result = [];
              data.forEach(function(resourceAvailability) {
                var resource = {};
                resource.id = resourceAvailability.resourceId;
                var events = [];
                (resourceAvailability.mergedAvailabilities || []).forEach(function(simplifiedAvailability) {
                  var startDateInfo = dateUtil.getDateTimeInfo(simplifiedAvailability.start, timezoneSidId);
                  var endDateInfo = dateUtil.getDateTimeInfo(simplifiedAvailability.end_x, timezoneSidId);
                  if (startDateInfo.date < endDateInfo.date) {
                    var firstEvent = {};
                    firstEvent.start = startDateInfo.dateTime;
                    firstEvent.finish = endDateInfo.dateTime;
                    events.push(firstEvent);
  
                    var indexDate = moment(startDateInfo.date).add(1, 'day').toDate();
                    while (indexDate < endDateInfo.date) {
                      var event = {};
                      event.start = moment(indexDate).startOf('day').toDate();
                      event.finish = endDateInfo.dateTime;
                      events.push(event);
                      indexDate = moment(indexDate).add(1, 'day').toDate();
                    }
                    var lastEvent = {};
                    lastEvent.start = moment(endDateInfo.date).startOf('day').toDate();
                    lastEvent.finish = endDateInfo.dateTime;
                    events.push(lastEvent);
                  } else {
                    var event = {};
                    event.start = startDateInfo.dateTime;
                    event.finish = endDateInfo.dateTime;
                    events.push(event);
                  }
                })
                resource.events = events;
  
                result.push(resource);
              })
  
              return result;
            }

            var doGetBookingGrid = function (requestParams) {
              var allocationData = null;
              var simplyAvailabilityData = null;
              var timezoneSidId = null;
              var gridData;
              var promise;
              
              util.showProgressBar({
                message: 'Loading resource data...',
                loadingMode: true
              });
              promise = $q.when()
              .then(function() {
                console.log('>>> Start get allocation data: ', new Date());

                return $q.when()
                .then(function() {
                  gridData = initializeBookingGrid(requestParams);
                })
                .then(function() {
                  timezoneSidId = gridData.timezoneSidId;

                  allocationData = {
                    jobs: gridData.slots || [],
                    resources: [],
                    jobOffers: []
                  };
  
                  util.showProgressBar({
                    message: 'Loading resource data...',
                    isLoadingMode: true
                  });

                  return doGetResourceData(_.extend({}, _.omit(requestParams, ['step', 'timezoneSidId']), {
                    inputDates: gridData.inputDates,
                    expiryTagDate: gridData.expiryTagDate
                  }), 1);
                })
                .then(function() {
                  util.updateProgressBar(resources.length, 'Processing data...', true);
                  return {
                    jobOffers: allocationData.jobOffers,
                    jobs: allocationData.jobs,
                    resources: resources || []
                  }
                })
              })
              .then(function(result) {
                var data = result || {};
                data.jobs = data.jobs.map(function(item) {
                  item.objectType = 'jobAllocation';
                  return populateDateTimeToSObject(item, timezoneSidId);
                })
                data.jobs = _.orderBy(data.jobs, ['start'], ['asc']);
                data.resources.map(function(resource) {
                  var activities = (resource.sked__Activities__r || []).map(function(activity) {
                    activity.objectType = 'activity';
                    return activity;
                  });
                  var jobs = _.compact((resource.sked__Job_Allocations__r || []).map(function(ja) {
                    var job = ja.sked__Job__r;
                    job.objectType = 'jobAllocation';
                    return job;
                  }));
                  resource.events = activities.concat(jobs).map(function(item) {
                    return populateDateTimeToSObject(item, timezoneSidId);
                  });
                  resource.events = _.orderBy(resource.events, ['start'], ['asc']);
  
                  return resource;
                })
                allocationData = data;
                console.log('>>> Finished get allocation data: ', new Date());
              })
              .then(function() {
                //get simple availability
                var minStart = _.first(allocationData.jobs);
                var maxFinish = _.last(allocationData.jobs);
  
                console.log('>>> Start get simply availability data: ', new Date());
                util.showProgressBar({
                  message: 'Loading availability data...',
                  totalRecords: allocationData.resources.length, 
                  totalPercentage: 240,
                  defaultPercentage: 100,
                  processedRecords: 0
                });
                return doGetResourceAvailabilitySimply({
                  startDate: dateUtil.dateToString(minStart.startDate),
                  startTime: minStart.startTime,
                  endDate: dateUtil.dateToString(maxFinish.endDate),
                  endTime: maxFinish.endTime,
                  resourceIds: _.map((allocationData.resources || []), 'Id')
                });
              })
              .then(function(result) {
                util.updateProgressBar(resources.length, 'Processing data...', true);
                return $timeout(500)
                .then(function() {
                  return result;
                })
              })
              .then(function(result) {
                if(!result || !result.success) return $q.reject(result);
  
                simplyAvailabilityData = result.data;
                console.log('>>> Finished get simply availability data: ', new Date());
                simplyAvailabilityData = doTransformAvailabilitySimply(simplyAvailabilityData || [], timezoneSidId);
  
                console.log('>>> Finished build simply availability data: ', new Date());
                
                var skedAvailator = availatorUtil.getInstance($ctrl.configData, requestParams, mapsApi);
                var scheduledAllocation = skedAvailator.buildScheduledAllocations(allocationData, simplyAvailabilityData);
                
                console.log('>>> Finished build data data: ', new Date());
  
                return scheduledAllocation;
              })
            
              return promise.then(function(scheduledAllocation) {  
                //old logic
                return {
                  timezoneSidId: timezoneSidId,
                  slots: (scheduledAllocation.jobs || []).map(function(item) {
                    var endTime = dateUtil.parseDateTime(item.startDate, item.startTime);
                    endTime = moment(endTime).add(requestParams.step, 'minutes').toDate();
                    return {
                      endTime: dateUtil.getMinuteValue(endTime) || 2400,
                      noOfAvailable: (item.possibleAllocations || []).length,
                      startDate: dateUtil.dateToString(item.startDate),
                      startTime: item.startTime
                    }
                  })
                };
              })
            };

            if ($ctrl.editingJob) {
              if (
                $ctrl.editingJob &&
                            $ctrl.editingJob.address && $ctrl.editingJob.address.geometry &&
                            angular.isNumber($ctrl.editingJob.duration) && $ctrl.editingJob.duration > 0 &&
                            angular.isArray($ctrl.bookingGrid.timeslots) && $ctrl.bookingGrid.timeslots.length > 0 &&
                            angular.isArray($ctrl.bookingGrid.days) && $ctrl.bookingGrid.days.length > 0) {

              requestParams = {
                  startDate: $ctrl.bookingGrid.days[0].dateIso,
                  endDate: $ctrl.bookingGrid.days[$ctrl.bookingGrid.days.length - 1].dateIso,
                  step: $ctrl.bookingGrid.settings.interval,
                  job: $ctrl.editingJob.toServer(),
                  regionId: $ctrl.editingJob.region ? $ctrl.editingJob.region.id : null,
                  resourceCategories: _.map($ctrl.configData.resourceCategories, 'id'),
                  tags: ($ctrl.editingJob.tags || []).map(function(item) {
                    return {
                      id: item.id
                    }
                  }),
                  timezoneSidId: $ctrl.editingJob.region ? ($ctrl.editingJob.region.timezone || {}).id : null
                };

                // additional job param
              requestParams.job.duration = $ctrl.editingJob.duration; // [REMOVE_DURATION]

              if (forceBuild || isBookingGridParamsReallyChanged(requestParams)) {
                bookingGridCurrentParams = _.cloneDeep(requestParams);

                  doGetBookingGrid(requestParams)
                    .then(function (bookingGrid) {
                      console.log('Finished get booking grid', bookingGrid, new Date());
                        var rawData = bookingGrid;
                                            
                        // preprocess raw data
                        angular.forEach(rawData.slots, function (slot) {
                          slot.availableResourcesMap = {};
                        });

                        $ctrl.bookingGrid.rawData = rawData;
                        $ctrl.bookingGrid.timezone = rawData.timezone;
                        $ctrl.bookingGrid.data = processBookingGridData(rawData);

                        // keep selected timeslot
                        maintainSelectedTimeSlot();
                    })
                    .catch(function (exception) {
                      console.error(exception);
                      if (exception && exception.errorMessage) {
                        if (exception.errorMessage === ERROR_MESSAGE.OUT_OF_SERVICE) {
                          util.toastError('We do not support this address area (' + $ctrl.editingJob.address.fullAddress + '), please select another address.');
                          $ctrl.editingJob.address = null;
                        } else {
                          util.toastError(exception.errorMessage);
                        }
                      }
                    })
                    .finally(function () {
                      hideLoading();
                      util.hideProgressBar();
                    });
                }
              } else {
                eraseBookingGrid();
              }
            } else {
              $ctrl.bookingGrid.rawData = [];
              $ctrl.bookingGrid.data = processBookingGridData($ctrl.bookingGrid.rawData);
              bookingGridCurrentParams = {};
            }
          };
          
          /**
                 * load booking grid data
                 */
          var maintainSelectedTimeSlot = function () {
            var selectedTimeSlot,
              calendarDayData,
              newSelectedTimeSlot;

            selectedTimeSlot = ($ctrl.editingJob && angular.isArray($ctrl.bookingGrid.selectedTimeslots))?$ctrl.bookingGrid.selectedTimeslots[0]:null;
            if($ctrl.bookingGrid && $ctrl.bookingGrid.data && selectedTimeSlot) {
              for (var i = 0; i < $ctrl.bookingGrid.data.length; i++) {
                calendarDayData = $ctrl.bookingGrid.data[i];

                if (calendarDayData.dateIso === selectedTimeSlot.startDate && 
                                calendarDayData.timeslots && calendarDayData.timeslots[selectedTimeSlot.startTime]) {
                  newSelectedTimeSlot = calendarDayData.timeslots[selectedTimeSlot.startTime];
                  break;
                }
              }

              if (newSelectedTimeSlot) {
                $ctrl.bookingGrid.selectedTimeslots = [newSelectedTimeSlot];

                if (!newSelectedTimeSlot.isAvailable && selectedTimeSlot.warningInUnavailable) {
                  util.toastWarning('Selected time slot is no more available. Please select other slot.');
                }
              } else {
                if (!selectedTimeSlot.keepSelecting) {
                  $ctrl.bookingGrid.selectedTimeslots = []; // unselect
                }
              }
            }
          };

          var processAllDayEvent = function (event) {
            var backgroundSettings = '',
              defaultBackgroundColor = '',
              colorSettings = '',
              defaultColor = '',
              backgroundColorParts = [];

            var allDayData = {
              days: [],
              startOutside: false,
              endOutside: false,
              backgroundColor: '',
              color: '',
            };

            var allDayStart, allDayEnd,
              eventEndTime = event.endTime,
              eventStart = event.startDate,
              eventEnd = angular.copy(event.endDate),
              calStart = $ctrl.calendarDays[0].date,
              calEnd = $ctrl.calendarDays[$ctrl.calendarDays.length - 1].date;

            var buildLinearGradient = function (deg, color) {
              return 'linear-gradient(' + deg + 'deg, ' + color + ' calc(100% - .375rem), transparent .375rem)'
            };

            if (eventEndTime === 0) {
              eventEnd.setDate(eventEnd.getDate() - 1);
            }

            // boundary
            if (eventStart < calStart) {
              allDayStart = calStart;
              allDayData.startOutside = true;
            } else {
              allDayStart = eventStart;
              allDayData.startOutside = false;
            }

            if (eventEnd > calEnd) {
              allDayEnd = calEnd;
              allDayData.endOutside = true;
            } else {
              allDayEnd = eventEnd;
              allDayData.endOutside = false;
            }

            // days
            for (var dallDayTemp = angular.copy(allDayStart); dallDayTemp <= allDayEnd; dallDayTemp.setDate(dallDayTemp.getDate() + 1)) {
              allDayData.days.push(dateUtil.dateToString(dallDayTemp));
            }

            backgroundSettings = (event.eventType && event.eventType.eventTypeSettings)?event.eventType.eventTypeSettings.backgroundColor:'fff';
            if(event.objectType === OBJECT_TYPE.CLIENT_AVAILABILITY) {
              backgroundSettings = $ctrl.configData.colorMap.Normal.backgroundColor;
            }
            defaultBackgroundColor = 'linear-gradient(' + backgroundSettings + ', ' + backgroundSettings +')';
            if (allDayData.startOutside || allDayData.endOutside) {
              if (allDayData.startOutside) {
                backgroundColorParts.push(buildLinearGradient(315, backgroundSettings), buildLinearGradient(225, backgroundSettings));
              } else {
                backgroundColorParts.push(defaultBackgroundColor, defaultBackgroundColor);
              }
  
              if (allDayData.endOutside) {
                backgroundColorParts.push(buildLinearGradient(45, backgroundSettings), buildLinearGradient(135, backgroundSettings));
              } else {
                backgroundColorParts.push(defaultBackgroundColor, defaultBackgroundColor);
              }
  
              allDayData.backgroundColor = backgroundColorParts.join(', ');
            } else {
              allDayData.backgroundColor = defaultBackgroundColor;
            }

            event.allDayData = allDayData;
          };

          var processScheduleAllDayEvents = function (resource, dataItem, allDayEvents) {
            // sort by dates
            allDayEvents.sort(function (event1, event2) {
              var startDiff = (event1.startDate.getTime() + event1.startTime) - (event2.startDate.getTime() + event2.startTime),
                endDiff = (event1.endDate.getTime() + event1.endTime) - (event2.endDate.getTime() + event2.endTime);
              return startDiff === 0 ? endDiff : startDiff;
            });

            angular.forEach(allDayEvents, function (event) {
              event.isAllDayEvent = true;
              processAllDayEvent(event);

              angular.forEach(event.allDayData.days, function (dayIso, indx) {
                var redundantIndx = -1;
                if (!angular.isArray(dataItem.allDayEventsByDate[dayIso])) {
                  dataItem.allDayEventsByDate[dayIso] = [];
                }

                if (indx === 0) {
                  if (dataItem.allDayEventsByDate[dayIso].length > 0) {
                    for (var i = 0; i < dataItem.allDayEventsByDate[dayIso].length; i++) {
                      if (dataItem.allDayEventsByDate[dayIso][i].redundant) {
                        redundantIndx = i;
                        break;
                      }
                    }
                  }

                  if (redundantIndx > -1) {
                    dataItem.allDayEventsByDate[dayIso][redundantIndx] = event;
                  } else {
                    dataItem.allDayEventsByDate[dayIso].push(event);
                  }

                  alldayAvailabilityLevel = dataItem.allDayEventsByDate[dayIso].indexOf(event);
                } else {
                  if (dataItem.allDayEventsByDate[dayIso].length > alldayAvailabilityLevel) {
                    dataItem.allDayEventsByDate[dayIso][alldayAvailabilityLevel].redundant = false;
                  } else {
                    while (dataItem.allDayEventsByDate[dayIso].length <= alldayAvailabilityLevel) {
                      dataItem.allDayEventsByDate[dayIso].push({
                        isAllDayEvent: true,
                        allDayEvent: event,
                        redundant: alldayAvailabilityLevel > dataItem.allDayEventsByDate[dayIso].length
                      });
                    }
                  }
                }
              });
            });

            // count all day events
            angular.forEach(dataItem.allDayEventsByDate, function (allDayEvents) {
              if (allDayEvents.length > dataItem.allDayEventsCount) {
                dataItem.allDayEventsCount = allDayEvents.length;
              }
            });
          };

          var processGridData = function (data) {
            var gridData = model.PACGridDataModel.fromServer(data, $ctrl.configData);
            var allDayEvents = [];
            var builtGridData = {
              today: gridData.today,
              timezone: gridData.timezone,
              availabilitiesByDate: {},
              eventsByDate: {},
              allDayEventsByDate: {},
              allDayEventsCount: 0,
              allEventsByDate: {}
            };

            var processData = function(items, mapObject) {
              if (angular.isArray(items) && items.length > 0) {
                angular.forEach(items, function (item) {
                  // event type
                  if (item.eventType) {
                    item.eventType = _.find($ctrl.configData.jobTypes, {id: (angular.isString(item.eventType)?item.eventType:item.eventType.id)});
                  }

                  // urgency
                  if (item.urgency) {
                    item.urgency = _.find($ctrl.configData.jobUrgencies, {id: (angular.isString(item.urgency)?item.urgency:item.urgency.id)});
                  }

                  // date/time
                  if (item.endTime >= 2400) {
                    item.endTime = 0;
                    item.endDate.setDate(item.endDate.getDate() + 1);
                  }

                  if (item.scheduleId) {
                    item.schedule = _.find(gridData.schedules, {id: item.scheduleId});
                  }

                  var isSameCase = true;
                  if(!util.isNullOrEmpty($ctrl.caseId)) {
                    isSameCase = item.case && $ctrl.caseId === item.case.id;
                  }

                  var isGroupEventJob = false;

                  if(item.eventType && item.eventType.id === EVENT_TYPE.GROUP_EVENT) {
                    isGroupEventJob = true;
                  }

                  item.readonly = isGroupEventJob || !isSameCase;

                  if (util.isAllDayEvent(item) && $ctrl.layout !== LAYOUT_MODE.MONTH) {
                    allDayEvents.push(item);
                  } else {
                    var dateKey = dateUtil.dateToString(item.startDate);

                    // push item to data map
                    if (!angular.isArray(mapObject[dateKey])) {
                      mapObject[dateKey] = [];
                    } 

                    mapObject[dateKey].push(item);
                  }
                });

                angular.forEach(mapObject, function (items) {
                  util.processTimeslots($ctrl.configData, $ctrl.timeslots, items, true, GRID_SETTINGS);
                  util.processTimeslotsPreferredTimes(items, $ctrl.timeslots);

                  // sort by y position
                  items.sort(function (item1, item2) {
                    return item1.timeslotData && item2.timeslotData && item1.timeslotData.y - item2.timeslotData.y;
                  });

                  // check overlapping
                  angular.forEach(items, function (item) {
                    util.checkOverlappingEvent(items, item, 1);
                  });

                  // calculate postion and width
                  angular.forEach(items, function (item) {
                    if (item.overlapInfo) {
                      angular.forEach(item.overlapInfo.overlappedEvents, function (overlappedEvent) {
                        if (item.overlapInfo.maxLevel < overlappedEvent.overlapInfo.maxLevel) {
                          item.overlapInfo.maxLevel = overlappedEvent.overlapInfo.maxLevel;
                        } else {
                          overlappedEvent.overlapInfo.maxLevel = item.overlapInfo.maxLevel;
                        }
                      });

                      if(item.timeslotData) {
                        item.timeslotData.w = ((Math.round(10000 / item.overlapInfo.maxLevel)) / 100);
                        item.timeslotData.x = item.timeslotData.w * (item.overlapInfo.level - 1);
                      }
                    }
                  });
                });
              }
            };

            $ctrl.scheduledJobs = gridData.events;
            //rebuildScheduledJobMap();

            processData(gridData.availabilities, builtGridData.availabilitiesByDate);
            processData(gridData.events, builtGridData.eventsByDate);

            // process all day events
            if (allDayEvents.length > 0) {
              processScheduleAllDayEvents(null, builtGridData, allDayEvents);
            }
            
            // concat all events to a single array
            angular.forEach($ctrl.calendarDays, function (day) {
              var eventsAndAvailability = [].concat(builtGridData.availabilitiesByDate[day.dateIso] || [], builtGridData.eventsByDate[day.dateIso] || []);
              var allEvents, event;

              allEvents = angular.extend([], builtGridData.allDayEventsByDate[day.dateIso]);

              if (eventsAndAvailability.length > 0) {
                for (var i = 0; i < allEvents.length; i++) {
                  event = allEvents[i];
                  if (event.redundant) {
                    allEvents[i] = eventsAndAvailability[0];
                    eventsAndAvailability.splice(0, 1);

                    if (eventsAndAvailability.length === 0) {
                      break;
                    }
                  }
                }

                if (eventsAndAvailability.length > 0) {
                  allEvents = allEvents.concat(eventsAndAvailability);
                }
              }

              builtGridData.allEventsByDate[day.dateIso] = allEvents;
            });

            return builtGridData;
          };

          var isFilterValid = function() {
            //if(!filter) return false;
            //if(!filter.region || !filter.region.id) return false;
            if(!$ctrl.calendarDays || !$ctrl.calendarDays.length || !$ctrl.patientId || !$ctrl.viewRegion) return false;
            return [];
          };

          var getInvalidFilters = function() {
            //if(!filter) return [];
            var filters = [];
            //if(!filter.region || !filter.region.id) filters.push('Region');
            if(!$ctrl.calendarDays || !$ctrl.calendarDays.length) filters.push($ctrl.layout === LAYOUT_MODE.MONTH ? 'Month' : 'Start Week');
            if(!$ctrl.patientId) filters.push('Serivce User');
            if(!$ctrl.viewRegion) filters.push('Region');
            return filters;
          };

          var rebuildWeekColumns = function() {
            var calendarDays = $ctrl.calendarDays;
            var startDayOfWeek = $ctrl.configData.consoleSettings ? $ctrl.configData.consoleSettings.firstDay : 0;
            var endDayOfWeek = (startDayOfWeek + 6) % 7;
            var tempColspan = 1;
            $ctrl.weekColumns = [];

            if(calendarDays && calendarDays.length) {
              calendarDays.forEach(function(item, index){
                var isLastItem = index === calendarDays.length - 1;
                if(moment(item.date).format('d') == endDayOfWeek || isLastItem) {
                  $ctrl.weekColumns.push({
                    colspan: tempColspan    
                  });
                  tempColspan = 1;
                } else {
                  tempColspan += 1;
                }
              });
            }
          };

          var rebuildScheduleConsole = function (forceBuild) {
            if (isFilterValid()) {
              var params = {
                //patientId: $ctrl.patientId,
                //caseId: $ctrl.caseId,
                startDate: $ctrl.calendarDays[0].dateIso,
                endDate: $ctrl.calendarDays[$ctrl.calendarDays.length - 1].dateIso,
                regionId: $ctrl.viewRegion.id,
                objectTypes: [OBJECT_TYPE.CLIENT_AVAILABILITY, OBJECT_TYPE.JOB]
              };

              if (forceBuild || isParamsReallyChanged(params)) {
                var resetScroll = isNeedToResetScroll(params);
                currentParams = angular.copy(params);
                showLoading();
                return doGetGridData(params)
                  .then(function (result) {
                    if (result.success) {
                      $ctrl.gridData = processGridData(result.data);
                      // dateUtils will parse gridData.today to start of day moment of given date
                      $ctrl.today = $ctrl.gridData.today;

                      if($ctrl.needToScrollJob) {
                        $timeout(function(){
                          scrollToJob($ctrl.needToScrollJob);
                          $ctrl.needToScrollJob = null;
                        });
                      }

                      var _hidePopoverFn = function(){
                        if(!$ctrl.ignoreHideOnScroll) {
                          hideInfoPopover();
                        }
                      };
                      $timeout(function(){
                        $('.hco-rac-data-content-wrapper').off('scroll', _hidePopoverFn);
                        $('.hco-rac-data-content-wrapper').on('scroll', _hidePopoverFn);

                        if(resetScroll) {
                          resetGridScroll();
                        } else {
                          $('.hco-rac-data-content-wrapper').trigger('scroll');
                        }
                      });
                    } else {
                      return $q.reject(result);
                    }
                  })
                  .catch(function (exception) {
                    console.error(exception);
                    if (exception && exception.errorMessage) {
                      util.toastError(exception.errorMessage);
                    }
                  })
                  .finally(function () {
                    hideLoading();
                  });
              }
            } else {
              $ctrl.gridData = null;
              currentParams = {};
            }
          };

          var rebuildCurrentExceptionLog = function () {
            $timeout(function() {
              if (isFilterValid()) {
                showGetExceptionLogLoading();
                return doGetJobExceptions({
                  regionId: $ctrl.viewRegion.id,
                  startDate: $ctrl.calendarDays[0].dateIso > dateUtil.dateToString($ctrl.today) ? $ctrl.calendarDays[0].dateIso : dateUtil.dateToString($ctrl.today),
                  endDate: $ctrl.calendarDays[$ctrl.calendarDays.length - 1].dateIso,
                  pageNo: 1,
                  pageSize: 2000
                }).then(function (result) {
                  if (result.success) {
                    $ctrl.queuedJobsSideMenuData.currentViewJobs = model.PACJobExceptionModel.fromServerList(result.data.exceptions, $ctrl.configData);
                                      
                    $ctrl.queuedJobsSideMenuData.jobMap = _.groupBy($ctrl.queuedJobsSideMenuData.currentViewJobs, function(exception) {
                      return exception.job.id;
                    });
                  } else {
                    return $q.reject(result);
                  }
                }).catch(function (exception) {
                  if (exception && exception.errorMessage) {
                    util.toastError(exception.errorMessage);
                  }
                }).finally(function () {
                  hideGetExceptionLogLoading();
                });
              }
            }, 300);
          };

          var onSelectTimes = function(event, data) {
            showEventModal({
              startDate: data.selectedDate,
              endDate: data.selectedDate,
              startTime: data.startTimeSlot.start,
              endTime: data.endTimeSlot.end
            });
          };

          var createNewEvent = function (selectedDate) {
            showEventModal({
              startDate: selectedDate,
              endDate: selectedDate,
              startTime: $ctrl.configData.consoleSettings.calendarStart || 0,
              endTime: $ctrl.configData.consoleSettings.calendarEnd || 2400
            });
          };

          var showEventModal = function (item) {
            util.showModal({
              template: '<event-modal class="sked-modal-container" event="event" config-data="configData" on-close="onClose(this, message)" view-region="viewRegion"></event-modal>',
            }, {
              event: item ? angular.copy(item) : null,
              //patient: $ctrl.configData.patient,
              //case: model.PicklistItemModel.fromId($ctrl.caseId),
              //region: $ctrl.filter.region,
              configData: $ctrl.configData,
              viewRegion: $ctrl.viewRegion,
              onClose: function (modalScope, message) {
                modalScope.closeModal();

                if (message === 'done') {
                  refreshBookingGrid();
                }
              }
            });
          };

          var showEditRecurrence = function (item) {
            util.showModal({
              template: '<event-recurrence patient-id="patientId" config-data="configData" on-close="onClose(this, message)" schedule-id="scheduleId"></event-recurrence>'
            }, {
              configData: $ctrl.configData,
              scheduleId: item.scheduleId,
              patientId: $ctrl.patientId,
              onClose: function (modalScope, message) {
                modalScope.closeModal();
                if (message === 'done') {
                  refreshBookingGrid();
                } 
              }
            });
          };

          var editIndividualEvent = function (job) {
            $scope.$broadcast('pac.appointment.editIndividualJob', {job: job});
          };

          var showEventAllocationModal = function (item) {
            util.showModal({
              template: '<job-allocation class="sked-modal-container" job-pinning="true" job="job" allow-posting-message="false" on-close="onClose(message, this)" config-data="configData" ></job-allocation>'
            }, {
              configData: $ctrl.configData,
              job: item,
              onClose: function (message, modalScope) {
                modalScope.closeModal(message);

                if (message === 'done') {
                  refreshBookingGrid();
                }
              }
            });
          };

          var showCancelEventModal = function (item) {
            if (item && item.id) {
              util.showModal({
                template: '<cancel-event-modal class="sked-modal-container" event="event" patient="patient" config-data="configData" on-close="onClose(this, message)" ></cancel-event-modal>',
              }, {
                event: item ? angular.copy(item) : null,
                patient: $ctrl.configData.patient,
                configData: $ctrl.configData,
                onClose: function (modalScope, message) {
                  modalScope.closeModal();

                  if (message === 'done') {
                    util.toastSuccess('Appointment has been cancelled successfully.');
                    refreshBookingGrid();
                  }
                }
              });
            }
          };

          var toggleQueuedJobsSideMenu = function(isOpened) {
            $ctrl.isQueuedJobsSideMenuOpened = !!isOpened;

            var wrapperEl = angular.element('.hco-rac-data-content-wrapper');
            if(isOpened) {
              if(wrapperEl) {
                wrapperEl.css({
                  overflow: 'hidden'
                });
              }
            } else {
              if(wrapperEl) {
                wrapperEl.css({
                  overflow: ''
                });
              }
            }
          };

          var isNeedToResetScroll = function(params) {
            //reset scroll when start date changed
            return !_.isEqual(angular.copy(_.pick(params, 'startDate')), angular.copy(_.pick(currentParams, 'startDate')));
          };

          var resetGridScroll = function() {
            var contentWrapperEl = $('.hco-rac-data-content-wrapper');
            // contentWrapperEl.scrollTop(0);
            contentWrapperEl.scrollLeft(0);
          };

          var scrollToJob = function(item) {
            if(!item || !item.id) return;

            var targetEl = $('#job-' + item.id);
            var contentWrapperEl = $ctrl.layout === LAYOUT_MODE.MONTH ? $('html') : $('.hco-rac-data-content-wrapper');

            if(targetEl && targetEl[0]) {
              var eL = targetEl.offset().left,
                eT = targetEl.offset().top,
                eW = targetEl.outerWidth(),
                pT = contentWrapperEl.offset().top,
                pL = contentWrapperEl.offset().left,
                pSL = contentWrapperEl.scrollLeft(),
                pST = contentWrapperEl.scrollTop(),
                tsH = $('.timeslot__items li').outerHeight() || 20;

              if($ctrl.layout === LAYOUT_MODE.MONTH) {
                pST = 0;
                pSL = 0;
              }
                        
              contentWrapperEl.scrollTop(pST + eT - pT - tsH);
              contentWrapperEl.scrollLeft(pSL + eL - pL - eW);
            }
          };

          var navigateToJob = function(exception){
            if(!exception) {
              return;
            }
                    
            toggleQueuedJobsSideMenu(false);

            $ctrl.highlightedException = exception;
            if ($ctrl.queuedJobsSideMenuData.jobMap[exception.job.id]) {
              scrollToJob(exception.job);
            } else {
              $ctrl.date = exception.job.startDate;
              $ctrl.needToScrollJob = exception.job;
            }
          };

          var hideInfoPopover = function ($event) {
            if ($ctrl.infoPopoverData) {
              $ctrl.infoPopoverData.show = false;

              $timeout(function () {
                $ctrl.infoPopoverData = null;
              });
            }

            if ($event) {
              $event.stopPropagation();
            }
          };

          var getTimeValue = function (minuteValue) {
            var tsH = Math.floor(minuteValue / 60);
            var tsM = Math.round(minuteValue % 60);

            return ((tsH * 100) + tsM);
          };

          var getMinuteValue = function (timeValue) {
            return (Math.floor(timeValue/100) * 60) + Math.round(timeValue%100);
          };

          var calculateSlotEndTime = function (slotStartTime, jobDuration) {
            var slotEndTime = null;
            if (angular.isNumber(slotStartTime)) {
              slotEndTime = getTimeValue(getMinuteValue(slotStartTime) + (jobDuration || 0));
            }
            return slotEndTime;
          };

          var showInfoPopover = function ($event, item, showByMousePos) {
            var currentlyOpened = !!$ctrl.infoPopoverData,
              currentPosition = currentlyOpened ? $ctrl.infoPopoverData.position : null;
            var contentPanelEl = angular.element('.hco-pac-page.main-pac-page');
            var el = angular.element($event.currentTarget),
              elWidth, elOffset, posX, posY, mouseOffsetX;

            mouseOffsetX = $event.offsetX;

            elOffset = el.offset();
            elWidth = el.width();

            if (showByMousePos) {
              posX = elOffset.left + mouseOffsetX + 8;
            } else {
              posX = elOffset.left + elWidth + 8;
            }
                    
            posY = elOffset.top;

            $ctrl.infoPopoverData = {
              item: item,
              position: currentPosition,
              show: currentlyOpened
            };

            $timeout(function () {
              var infoPopoverEl = angular.element('.hco-info-popover');
              var containerHeight = contentPanelEl.height(),
                containerWidth = contentPanelEl.width();
              var infoPopoverElHeight = infoPopoverEl.height(),
                infoPopoverElWidth = infoPopoverEl.width();

              // if(!util.isTouchDevice()) {
              posY -= (infoPopoverElHeight / 2);
              // }

              if (posY < 0) {
                posY = 8;
              } else if (posY + infoPopoverElHeight > containerHeight) {
                posY = containerHeight - infoPopoverElHeight - 16;
              }

              if (posX + infoPopoverElWidth > containerWidth) {
                posX = containerWidth - infoPopoverElWidth - 16;
              }

              $ctrl.infoPopoverData.show = true;
              $ctrl.infoPopoverData.position = {
                x: posX,
                y: posY
              };
            });
                    
            if (currentlyOpened) {
              $event.stopPropagation();
            }
          };

          var refreshBookingGrid = function () {
            rebuildScheduleConsole(true);

            $timeout(function() {
							rebuildCurrentExceptionLog();
							if ($ctrl.allJobException.page.pageNumber === 1) {
								rebuildAllJobExceptionLog();
							} else {
								$ctrl.allJobException.page.pageNumber = 1;
							}
            }, 300)
          };

          var toggleShowAllException = function (isShowall) {
            $ctrl.showAllException = isShowall;
          };

          var isDisallowJobAllocation = function(job) {
            return moment().diff(
              moment.tz(
                moment(job.startDate).format('YYYY-MM-DD') + ' ' +moment(dateUtil.parseTimeValue(job.startTime)).format('HH:mm'), 
                $ctrl.viewRegion.timezone.id
              )
            ) > 0;
          };

          var selectTimeslot = function (timeSlot) {
            // support single selection for temporary
            if (timeSlot.noOfAvailable > 0) {
              if (!$ctrl.editingJob.id) { // new job
                if (timeSlot.noOfAvailable > 0) {
                  if ($ctrl.bookingGrid.selectedTimeslots[0] === timeSlot) {
                    $ctrl.bookingGrid.selectedTimeslots = [];
                  } else {
                    $ctrl.bookingGrid.selectedTimeslots[0] = timeSlot;
                  }
                }
              } else {
                //delete $ctrl.scheduledJobsMap[produceScheduledJobKey($ctrl.editingJob)];
                $ctrl.editingJob.startDate = dateUtil.parseDateString(timeSlot.startDate);
                $ctrl.editingJob.startTime = timeSlot.startTime;
                $ctrl.editingJob.endTime = calculateSlotEndTime(timeSlot.startTime, $ctrl.editingJob.duration);

                //$ctrl.editingJob.selectedTimeslot = timeSlot;

                //$ctrl.scheduledJobsMap[produceScheduledJobKey($ctrl.editingJob)] = $ctrl.editingJob;
              }
            }
                        
          };
          var rebuildAllJobExceptionLog = function (forceRebuild) {                
            $timeout(function() {        
              if (isFilterValid()) {
                showGetExceptionLogLoading();
                return doGetJobExceptions({
                  regionId: $ctrl.viewRegion.id,
                  pageNo: $ctrl.allJobException.page.pageNumber,
                  pageSize: $ctrl.allJobException.page.recordsPerPage
                }).then(function (result) {
                  if (result.success) {
                    $ctrl.allJobException.exceptions = model.PACJobExceptionModel.fromServerList(result.data.exceptions, $ctrl.configData);
                    $ctrl.allJobException.page.numberOfPages = result.data.totalPages || 0;
                    $ctrl.allJobException.page.totalRecords = result.data.totalRecords || 0;
                  } else {
                    return $q.reject(result);
                  }
                }).catch(function (exception) {
                  if (exception && exception.errorMessage) {
                    util.toastError(exception.errorMessage);
                  }
                }).finally(function () {
                  hideGetExceptionLogLoading();
                });
              }
            }, forceRebuild ? 0 : 300)
          };

          var getWeekDays = function () {
            var weekDays = [];
            var firstDay = $ctrl.configData.consoleSettings.firstDay || 0;

            for (var i = 0 ; i < 7; i++) {
              weekDays.push(WEEK_DAYS[((i + firstDay)%7)]);
            }

            return weekDays;
          };

          /**
                 * controller init
                 */
          $ctrl.$onInit = function () {
            uiGmapGoogleMapApi.then(function (maps) {
							mapsApi = maps;

              $ctrl.patientId = $ctrl.patientId || $ctrl.searchParams.patientId;

              // timeslots
              if ($ctrl.configData && $ctrl.configData.consoleSettings) {
                $ctrl.bookingGrid.settings = {
                  show24Hours: false,
                  interval: $ctrl.configData.consoleSettings.calendarStep || DEFAULT_TIMESLOT_INTERVAL,
                  startTime: $ctrl.configData.consoleSettings.calendarStart || 0,
                  endTime: $ctrl.configData.consoleSettings.calendarEnd || 2400
                };
                $ctrl.bookingGrid.timeslots = $ctrl.timeslots = util.calculateCalendarTimeslots($ctrl.configData.consoleSettings);
              }
            });
          };

          /**
                 * scope init
                 */
          (function init() {
            var elWindow = angular.element($window);
            $scope.DEFAULT_PHOTO_URL = DEFAULT_PHOTO_URL;
            $scope.MODE = MODE;
            $scope.LAYOUT_MODE = LAYOUT_MODE;
            $scope.WEEK_DAYS = WEEK_DAYS;

            $scope.GRID_SETTINGS = GRID_SETTINGS;
            $scope.TABS = TABS;
            $scope.EVENT_TYPE = EVENT_TYPE;
            $scope.OBJECT_TYPE = OBJECT_TYPE;

            $ctrl.readonly = false;

            $ctrl.highlightedException = null;
            $ctrl.gridData = null;
            $ctrl.date = null;
            $ctrl.showAllException = false; 
            // inital today to be browser's local timezone start of day
            // this might be difference from patient's timezone
            // thus this value will be updated once the first get availability return
            // if that happen and the value is difference with current value 
            // then it will cause a chain effect to recalculated these:
            // 1. $ctrl.calendarDays
            //    1.1 call new get Availability with new timerange
            //    1,2 call new get job exeption with new timerange
            // this hapen when 
            // local timezone is difference with patient timezone
            // browser is in a window between this timezone difference 
            //       => most of the time this is out of working hour
            $ctrl.today = moment().startOf('day').toDate();
            $ctrl.weekColumns = [];
            $ctrl.timeslots = [];
            $ctrl.calendarDays = [];
            $ctrl.isQueuedJobsSideMenuOpened = false;
            $ctrl.infoPopoverData = null;
                        
            $ctrl.allJobException = {
              page: {
                recordCountOptions: [5, 10, 15, 20, 25],
                recordsPerPage: 25,
                pageNumber: 1,
                numberOfPages: 0,
                totalRecords: 0
              },
              exceptions: []
            };

            $ctrl.queuedJobsSideMenuData = {
              invalid: false,
              allJobs: [],
              currentViewJobs: [],
              jobMap: {} //to check job in grid has exception or not
            };

            $ctrl.searchParams = {
              patientId: searchParams.patientId
            };
            $ctrl.navigateToJob = navigateToJob;
            $ctrl.isFilterValid = isFilterValid;
            $ctrl.getInvalidFilters = getInvalidFilters;
            $ctrl.toggleQueuedJobsSideMenu = toggleQueuedJobsSideMenu;

            $ctrl.showCancelEventModal = showCancelEventModal;
            $ctrl.showEventModal = showEventModal;
            $ctrl.showEditRecurrence = showEditRecurrence;
            $ctrl.showEventAllocationModal = showEventAllocationModal;
            $ctrl.onSelectTimes = onSelectTimes;
            $ctrl.hideInfoPopover = hideInfoPopover;
            $ctrl.showInfoPopover = showInfoPopover;
            $ctrl.util = util;
            $ctrl.toggleShowAllException = toggleShowAllException;
            $ctrl.isDisallowJobAllocation = isDisallowJobAllocation;

            $ctrl.selectTimeslot = selectTimeslot;
            $ctrl.editIndividualEvent = editIndividualEvent;

            $scope.$on('toggleQueuedJobsMenu', function(){
              toggleQueuedJobsSideMenu(true);
            });
            $scope.$on('pac.refreshConsole', function(){
              if ($ctrl.editingJob) {
                rebuildBookingGrid(true);  
              } else {
                refreshBookingGrid();
              }
            });

            $ctrl.tab = TABS.CAPACITY_GRID;
            $ctrl.getWeekDays = getWeekDays;

            $ctrl.editingJob = null;
            $ctrl.scheduledJobs = [];
            //$ctrl.scheduledJobsMap = {};
            $ctrl.bookingGrid = {
              date: new Date(),
              timeslots: [],
              days: [],
              data: [],
              rawData: null,
              selectedTimeslots: [],
              appointmentProfile: null,
              customerAvailabilities: [],
              settings: null,
              timezone: '',
              ignoredSlots: []
            };
            $ctrl.bookingGridErrorMessage = null;
            $ctrl.refreshBookingGrid = refreshBookingGrid;

            $ctrl.createNewEvent = createNewEvent;

            /**
                         * watch start date changed
                         */
            $scope.$watch(function () {
              return {
                date: $ctrl.date,
                today: $ctrl.today.toISOString(), // this will help watch to compare base on string value instead of date object
                layout: $ctrl.layout
              };
            }, function (newVals, oldVal) {
              console.log(newVals, oldVal);
              var startDate, endDate, firstDay, restDayCount;

              if ($ctrl.date && angular.isDate($ctrl.date)) {
                firstDay = $ctrl.configData.consoleSettings.firstDay || 0;

                if ($ctrl.layout === LAYOUT_MODE.MONTH) {
                  startDate = angular.copy($ctrl.date);
                  endDate = angular.copy($ctrl.date);
                  startDate.setDate(1);
                  endDate.setDate(1);

                  // identify calendar start date
                  startDate.setDate(1 - startDate.getDay() + firstDay);

                  // identify calendar end date
                  endDate.setMonth(endDate.getMonth() + 1);
                                
                  restDayCount = (7 - endDate.getDay() + firstDay);
                  if (restDayCount < 7) {
                    endDate.setDate(endDate.getDate() + restDayCount);
                  }

                  $ctrl.calendarDays = util.calculateCalendarDays(startDate, $ctrl.configData, $ctrl.filter.region ? [$ctrl.filter.region] : [], $ctrl.today, endDate);
                  $ctrl.calendarWeeks = util.buildCalendarWeeks($ctrl.calendarDays, $ctrl.date.getMonth(), firstDay);
                } else {
                  startDate = angular.copy($ctrl.date);

                  startDate.setDate(startDate.getDate() - ((startDate.getDay() + 7 - firstDay) % 7));
                  endDate = angular.copy(startDate);
                  endDate.setDate(endDate.getDate() + ($ctrl.configData.consoleSettings.viewPeriod * 7));

                  $ctrl.calendarDays = util.calculateCalendarDays(startDate, $ctrl.configData, $ctrl.filter.region ? [$ctrl.filter.region] : [], $ctrl.today, endDate);
                }

                $ctrl.bookingGrid.days = $ctrl.calendarDays;
              } else {
                $ctrl.calendarDays = [];
                $ctrl.calendarWeeks = [];
              }
            }, true);

            $scope.$watch(function() {
              return {
                patientId: $ctrl.patientId,
                filter: $ctrl.filter,
                days: $ctrl.calendarDays,
                regionId: $ctrl.viewRegion && $ctrl.viewRegion.id
              };
            }, function () {
              rebuildWeekColumns();
              rebuildScheduleConsole();
            }, true);

            // rebuild current exception log when startDate and endDate change
            $scope.$watchGroup([
              '$ctrl.viewRegion && $ctrl.viewRegion.id',
              '$ctrl.calendarDays[0].dateIso',
              '$ctrl.calendarDays[$ctrl.calendarDays.length - 1].dateIso'
            ], function () {
              rebuildCurrentExceptionLog();
            });

            elWindow.scroll(function(){
              $timeout(function(){
                hideInfoPopover();
              });
            });

            $scope.$watchGroup([
              '$ctrl.bookingGrid.days',
              '$ctrl.bookingGrid.timeslots',
              '$ctrl.editingJob.address',
              '$ctrl.editingJob.duration',
              // '$ctrl.editingJob.quantity'
            ], function () {
              rebuildBookingGrid();
            });

            $scope.$watchCollection('$ctrl.editingJob.tags', function () {
              rebuildBookingGrid();
            }, true);

            $scope.$watchCollection('$ctrl.editingJob.region', function () {
              rebuildBookingGrid();
            }, true);

            $scope.$watch('$ctrl.layout', function () {
              $timeout(function () {
                elWindow.trigger('resize');
              }, 100);
            });

            $scope.$watchGroup([
              '$ctrl.viewRegion && $ctrl.viewRegion.id',
              '$ctrl.allJobException.page.pageNumber',
              '$ctrl.allJobException.page.recordsPerPage'
            ], function() {
							rebuildAllJobExceptionLog(true);
						});

            $scope.$watch('$ctrl.editingJob', function () {
              $scope.$emit('pac.appointment.editIndividualJob', {editingJob: $ctrl.editingJob});

              // cleanup selected slot
              if ($ctrl.bookingGrid) {
                $ctrl.bookingGrid.selectedTimeslots = [];
              }
            });
          })();
        }
      ]
    });
})(angular, moment, jQuery);