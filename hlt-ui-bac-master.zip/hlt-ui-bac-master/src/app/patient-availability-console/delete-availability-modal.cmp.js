(function (angular, topWindow) {
    angular.module('hltApp')
    .component('deleteAvailabilityModal', {
        templateUrl: 'src/app/patient-availability-console/delete-availability-modal.tpl.html',
        bindings: {
            configData: '<',
            availability: '<',
            region: '<',
            onClose: '&',
        },
        controller: [
            '$scope',
            '$timeout',
            '$window',
            '$location',
            '$q',
            '$filter',
            'api',
            'util',
            'dateUtil',
            'model',
            'constants',
            'ggLocationApi',
            function ($scope, $timeout, $window, $location, $q, $filter, api, util, dateUtil, model, constants, ggLocationApi) {
                var $ctrl = this;
                var EDIT_RECURRING_ACTION = angular.copy(constants.EDIT_RECURRING_ACTION);

                /**
                 * common remote action error handler
                 */
                var commonExceptionHanlder = function (exception) {
                    util.toastError('Can not perform action due to server error.');

                    return $q.reject(exception);
                };

                /**
                 * show content loading
                 */
                var showLoading = function () {
                    $ctrl.contentLoading = true;
                };

                /**
                 * hide content loading
                 */
                var hideLoading = function () {
                    $ctrl.contentLoading = false;
                };

                /**
                 * close main modal
                 */
                var closeModal = function (message) {
                    $ctrl.isModalOpen = false;
                    // run onClose expression
                    if (angular.isFunction ($ctrl.onClose)) {
                        $ctrl.onClose({
                            message: message
                        });
                    }
                };

                var doDeleteAvailability = function (params) {
                    return api.deleteClientAvailability(params)
                        .catch(commonExceptionHanlder);
                };

                var validateForm = function() {
                    var form = $ctrl.form;
                    form.$setSubmitted(true);
                    return true;
                };

                var buildSavingParams = function () {
                    var params = $ctrl.availability.toServer();
                    var recurringOptions = null;

                    // recurring options
                    if ($ctrl.availability.scheduleId && $ctrl.recurring.editRecurringAction.value !== EDIT_RECURRING_ACTION.ONLY_ME.value) {
                        recurringOptions = {
                            editAction: $ctrl.recurring.editRecurringAction.value
                        }
                    }

                    return {
                        event: params,
                        recurringOptions: recurringOptions
                    };
                };

                var cancelEvent = function () {
                    var params;
                    var savingCallback = function (result) {
                        if (result.success) {
                            closeModal('done');
                        } else{
                            return $q.reject(result);
                        }
                    };

                    if (validateForm()) {
                        params = buildSavingParams();

                        showLoading();
                        doDeleteAvailability(params)
                            .then(savingCallback)
                            .catch(function (exception) {
                                if (exception && exception.errorMessage) {
                                    util.toastError(exception.errorMessage);
                                }
                            })
                            .finally(function () {
                                hideLoading();
                            });
                    }
                };

                /**
                 * controller init
                 * used for setting initial value
                 */
                $ctrl.$onInit = function () {
                    $ctrl.isModalOpen = true;

                    $ctrl.availability.region = angular.copy($ctrl.region);
                };

                /**
                 * init block
                 * used for setting up controller
                 */
                (function () {
                    $scope.EDIT_RECURRING_ACTION = EDIT_RECURRING_ACTION;

                    $ctrl.form = null;
                    $ctrl.isModalOpen = false;
                    $ctrl.contentLoading = false;
                    $ctrl.recurring = {
                        editRecurringAction: EDIT_RECURRING_ACTION.ONLY_ME
                    }

                    $ctrl.closeModal = closeModal;
                    $ctrl.util = util;
                    $ctrl.cancelEvent = cancelEvent;
                })();
            }
        ]
    });
})(angular, top);