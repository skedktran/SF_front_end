(function (angular, topWindow) {
    angular.module('hltApp')
    .component('cancelEventModal', {
        templateUrl: 'src/app/patient-availability-console/cancel-event-modal.tpl.html',
        bindings: {
            configData: '<',
            patient: '<',
            event: '<',
            onClose: '&',
        },
        controller: [
            '$scope',
            '$timeout',
            '$window',
            '$location',
            '$q',
            '$filter',
            'api',
            'util',
            'dateUtil',
            'model',
            'constants',
            'ggLocationApi',
            function ($scope, $timeout, $window, $location, $q, $filter, api, util, dateUtil, model, constants, ggLocationApi) {
                var $ctrl = this;
                var EDIT_RECURRING_ACTION = angular.copy(constants.EDIT_RECURRING_ACTION);

                /**
                 * common remote action error handler
                 */
                var commonExceptionHanlder = function (exception) {
                    util.toastError('Can not perform action due to server error.');

                    return $q.reject(exception);
                };

                /**
                 * show content loading
                 */
                var showLoading = function () {
                    $ctrl.contentLoading = true;
                };

                /**
                 * hide content loading
                 */
                var hideLoading = function () {
                    $ctrl.contentLoading = false;
                };

                /**
                 * close main modal
                 */
                var closeModal = function (message) {
                    $ctrl.isModalOpen = false;
                    // run onClose expression
                    if (angular.isFunction ($ctrl.onClose)) {
                        $ctrl.onClose({
                            message: message
                        });
                    }
                };

                var doGetJobDetails = function (jobId) {
                    return api.getJobDetails({
                        recordId: jobId,
                        isIncludingRecurring: true
                    })
                        .catch(commonExceptionHanlder);
                };
                
                var doCancelEvent = function (params) {
                    var jobsPerCall = 100;
                    var processedJobs = 0;

                    util.updateProgressBar(0);
                    var promises = _.chunk(params.jobs, jobsPerCall).map(function (events) {
                        return function() {
                            return api.cancelJob(_.extend({}, params, {
                                jobs: events
                            }))
                                .then(function(result) {
                                    if(!result.success) {
                                        return $q.reject(result);
                                    }
                                    processedJobs = processedJobs + jobsPerCall;
                                    util.updateProgressBar(processedJobs);
                                    return result;
                                });
                        };

                    });

                    return util.serial(promises)
                        .catch(commonExceptionHanlder);
                };

                var buildSavingParams = function () {
                    var params = $ctrl.event.toServer();
                    params.abortReason = $ctrl.abortReason.id;
                    params.cancellationReasonNotes = $ctrl.notes;
                    params.quantity = null;

                    //edit mode
                    //build recurring jobs
                    var recurringJobs = [];
                    var editRecurringOption = null;
                    if ($ctrl.event.scheduleId && $ctrl.recurring.editRecurringAction.value !== EDIT_RECURRING_ACTION.ONLY_ME.value) {
                        editRecurringOption = $ctrl.recurring.editRecurringAction.value;
                        recurringJobs = util.getRecurringJobsByRecurringOptions(model.PACJobModel.fromServer(params, $ctrl.configData), $ctrl.recurringSchedule ? $ctrl.recurringSchedule.events : [], editRecurringOption, $ctrl.today, true);
                    }

                    //apply changes to recurring jobs and toServer
                    var fieldChanges = _.pick(params, ['abortReason', 'cancellationReasonNotes', 'quantity']);
                    recurringJobs = recurringJobs.map(function(job) {
                        var tempJob = job.toServer();
                        var updatedJob = _.extend(_.pick(tempJob, ['id']), fieldChanges);
                        return updatedJob;
                    });

                    //always update the current job
                    recurringJobs.unshift(params);

                    return {
                        jobs: recurringJobs
                    };
                };

                var validateCancellationReason = function() {
                     var form = $ctrl.form;
 
                    form.$setSubmitted(true);

                    if (!form.$valid && form.$error.required) {
                        util.toastError('Please check all required fields.');
                        return false;
                    }

                    return true;
                };

                var cancelEvent = function () {
                    var params;
                    var savingCallback = function (result) {
                        if (result.success) {
                            closeModal('done');
                        } else{
                            return $q.reject(result);
                        }
                    };

                    if (validateCancellationReason()) {
                        util.showProgressBar({
                            message: 'Preparing...',
                            loadingMode: true
                        });
                        getJobDetails($ctrl.event.id)
                            .then(function() {
                                params = buildSavingParams();

                                util.showProgressBar({
                                    message: 'Processing...',
                                    totalRecords: params.jobs.length
                                });
                                return doCancelEvent(params)
                                    .then(savingCallback)
                                    .catch(function (exception) {
                                        if (exception && exception.errorMessage) {
                                            util.toastError(exception.errorMessage);
                                        }
                                    })
                                    .finally(function () {
                                        util.hideProgressBar();
                                    });
                            });
                    }
                }; 

                var getJobDetails = function (jobId) {
                    return doGetJobDetails(jobId)
                        .then(function(result){
                            if (result.success) {
                                $ctrl.event = model.PACJobModel.fromServer(result.data.job, $ctrl.configData);
                                $ctrl.recurringSchedule = {
                                    events: (result.data.recurringSchedule && result.data.recurringSchedule.jobs.length) ?
                                        model.PACJobModel.fromServerList(result.data.recurringSchedule.jobs, $ctrl.configData) : 
                                        [$ctrl.event]
                                };
                                return $ctrl.event;
                            } else {
                                return $q.reject(result);
                            }
                        })
                        .catch(function (exception) {
                            if (exception && exception.errorMessage) {
                                util.toastError(exception.errorMessage);
                            }
                        });
                };

                /**
                 * controller init
                 * used for setting initial value
                 */
                $ctrl.$onInit = function () {
                    $ctrl.isModalOpen = true;
                    $ctrl.abortReason = null;

                    if($ctrl.configData && $ctrl.configData.abortReasons) {
                        $ctrl.abortReason = $ctrl.configData.abortReasons[0]; 
                    }
                };

                /**
                 * init block
                 * used for setting up controller
                 */
                (function () {
                    $scope.EDIT_RECURRING_ACTION = EDIT_RECURRING_ACTION;

                    $ctrl.form = null;
                    $ctrl.isModalOpen = false;
                    $ctrl.contentLoading = false;
                    $ctrl.abortReason = null;
                    $ctrl.notes = '';
                    $ctrl.recurring = {
                        editRecurringAction: EDIT_RECURRING_ACTION.ONLY_ME
                    }

                    $ctrl.closeModal = closeModal;
                    $ctrl.util = util;

                    $ctrl.cancelEvent = cancelEvent;
                })();
            }
        ]
    });
})(angular, top);