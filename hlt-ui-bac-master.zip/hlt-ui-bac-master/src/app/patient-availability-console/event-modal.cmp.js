(function (angular, topWindow) {
  angular.module('hltApp')
    .component('eventModal', {
      templateUrl: 'src/app/patient-availability-console/event-modal.tpl.html',
      bindings: {
        mode: '<',
        configData: '<',
        supportPlan: '<',
        groupEvent: '<',
        event: '<',
        onClose: '&',
        viewRegion: '<'
      },
      controller: [
        '$scope',
        '$q',
        '$filter',
        'api',
        'util',
        'dateUtil',
        'model',
        'constants',
        'ggLocationApi',
        'recurringUtil',
        function ($scope, $q, $filter, api, util, dateUtil, model, constants, ggLocationApi, recurringUtil) {
          var $ctrl = this;
                
          var MODE = {
            SINGLE: 'single',
            GROUP_EVENT: 'group-event'
          };
          var INTEGER_PATTERN = /^([0-9]*)$/;
          var EVENT_TYPE = constants.EVENT_TYPE;
          var DEFAULT_PHOTO_URL = $filter('skedSfUrl')(constants.DEFAULT_AVATAR_URL);
          var PAGE_MODE = constants.PAGE_MODE;
          var OBJECT_TYPE = constants.OBJECT_TYPE;

          var $propertiesFilter = $filter('filter');
          var getArray = function (len) {
            len = len || 0;
            return new Array(len);
          };

          /**
                     * common remote action error handler
                     */
          var commonExceptionHanlder = function (exception) {
            util.toastError('Can not perform action due to server error.');

            return $q.reject(exception);
          };

          /**
                     * show content loading
                     */
          var showLoading = function () {
            $ctrl.contentLoading = true;
          };

          /**
                     * hide content loading
                     */
          var hideLoading = function () {
            $ctrl.contentLoading = false;
          };

          /**
                     * close main modal
                     */
          var closeModal = function (message) {
            $ctrl.isModalOpen = false;
            // run onClose expression
            if (angular.isFunction ($ctrl.onClose)) {
              $ctrl.onClose({
                message: message
              });
            }
          };

          var doSearchAddresses = function (searchString) {
            return ggLocationApi.geocode({
              address: searchString
            });
            //.catch(commonExceptionHanlder);
          };

          var doValidateClients = function (params) {
            return api.validateClients(params)
              .catch(commonExceptionHanlder);
          };

          var doGetJobDetails = function (jobId, isIncludingRecurring) {
						return api.getJobDetails({
							recordId: jobId,
							isIncludingRecurring: isIncludingRecurring
						})
							.catch(commonExceptionHanlder);
					};

          var doSaveEvents = function (params) {
						var jobsPerCall = 100; //params.skedJobs.length; //$ctrl.pageMode === PAGE_MODE.CREATE ? 100 : 50;
						var processedJobs = 0;
						var recurringScheduleId = null;
						var jobId = null;

						util.updateProgressBar(0);
						var promises = _.chunk(params.skedJobs, jobsPerCall).map(function (events, index) {
							return function() {
                var skedJobTags = [];
                var skedJobTasks = [];
								events.forEach(function(event) {
									var uniqueKey = _.uniqueId('temporary_event_');
									var jobTags = event.sked__JobTags__r || [];
									var jobTasks = event.sked__JobTasks__r || [];

									if($ctrl.pageMode === PAGE_MODE.CREATE) {
										event.sked_Unique_Key__c = uniqueKey;
										jobTags = jobTags.map(function(jobTag) {
											jobTag.sked_Unique_Key__c = uniqueKey;
											return jobTag;
                    })
                    jobTasks = jobTasks.map(function(jobTask) {
											jobTask.sked_Unique_Key__c = uniqueKey;
											return jobTask;
										})
									}

                  skedJobTags = skedJobTags.concat(jobTags);
                  skedJobTasks = skedJobTasks.concat(jobTasks);
                  delete event.sked__JobTags__r;
                  delete event.sked__JobTasks__r;
								})

								var params = _.extend({}, params, {
									skedJobs: events,
                  skedJobTags: skedJobTags,
                  skedJobTasks: skedJobTasks
								});

								if($ctrl.pageMode === PAGE_MODE.CREATE) {
									params.skedRecurringSchedule = _.extend({}, params.skedRecurringSchedule, {
										Id: recurringScheduleId
									})
								}

								return $q.when()
									.then(function() {
										if($ctrl.pageMode === PAGE_MODE.CREATE) {
											return api.saveJobSObject(params);
										} else {
											return api.editJobSObject(params)
										}
									})
									.then(function(result) {
										if(!result.success) {
											return $q.reject(result);
										}

										if($ctrl.pageMode === PAGE_MODE.CREATE) {
											recurringScheduleId = (result.data && result.data.skedRecurringSchedule) ? result.data.skedRecurringSchedule.Id : null;
											jobId = index === 0 ? ((result.data && result.data.skedJob) ? result.data.skedJob.Id : null) : jobId;
											result.data.jobId = jobId;
										}

                    processedJobs = processedJobs + events.length;
                    util.updateProgressBar(processedJobs);

										return result;
									});
							};

						});

						return util.serial(promises)
							.catch(commonExceptionHanlder);
          };
          
					var getJobDetails = function (jobId, isIncludingRecurring) {
            return doGetJobDetails(jobId, isIncludingRecurring)
              .then(function(result){
                if (result.success) {
                  $ctrl.event = model.PACJobModel.fromServer(result.data.job, $ctrl.configData);
                  $ctrl.event.eventType = _.find($ctrl.configData.jobTypes, {id: (angular.isString($ctrl.event.eventType)?$ctrl.event.eventType:$ctrl.event.eventType.id)});
                  $ctrl.recurringSchedule = {
										events: (result.data.recurringSchedule && result.data.recurringSchedule.jobs.length) ?
											model.PACJobModel.fromServerList(result.data.recurringSchedule.jobs, $ctrl.configData) : 
											[$ctrl.event]
									};
                  return $ctrl.event;
                } else {
                  return $q.reject(result);
                }
              })
              .catch(function (exception) {
                if (exception && exception.errorMessage) {
                  util.toastError(exception.errorMessage);
                }
              });
          };

          var saveEvent = function () {
            var params;
            var savingCallback = function (result) {
              if (result.success) {
                util.toastSuccess('Appointment has been ' + (($ctrl.pageMode === PAGE_MODE.CREATE) ? 'scheduled' : 'updated') + ' successfully.');
                closeModal('done');
              } else{
                return $q.reject(result);
              }
            };

            if (validateEvent()) {
              params = buildEventSavingParams();

              util.showProgressBar({
                message: 'Processing...',
                totalRecords: params.skedJobs.length
              });
              doSaveEvents(params)
                .then(savingCallback)
                .catch(function (exception) {
                  if (exception && exception.errorMessage) {
                    util.toastError(exception.errorMessage);
                  }
                })
                .finally(function () {
                  hideLoading();
                  util.hideProgressBar();
                });
            }
          };

          var validateEvent = function () {
            var form = $ctrl.form;
 
            form.$setSubmitted(true);
            if (form.$error.required || 
                        ($ctrl.mode !== MODE.GROUP_EVENT && !$ctrl.event.contact) || 
                        ($ctrl.mode !== MODE.GROUP_EVENT && $ctrl.event.serviceLocation && $ctrl.event.serviceLocation.id === 'Other' && !$ctrl.event.address)) {
              util.toastError('Please check all required fields.');
              return false;
            } 

            if($ctrl.mode === MODE.GROUP_EVENT) {
              for(var i = 0; i < $ctrl.event.clients.length; i++) {
                var client = $ctrl.event.clients[i];
                if(!client.isDeleted && (!client.contact || !client.supportPlan)) {
                  util.toastError('Please check all required fields.');
                  return false;
                }
              }

              var tempContactIds = [];
              for(var i = 0; i < $ctrl.event.clients.length; i++) {
                var client = $ctrl.event.clients[i];
                if(!client.isDeleted) {
                  if (tempContactIds.indexOf(client.contact.id) !== -1) {
                    util.toastError('Serivce user is duplicated.');
                    client.contact.duplicated = true;
                    return false;
                  }

                  tempContactIds.push(client.contact.id);
                }
              }
            }

            if (form.$error.pattern || form.$error.number || form.$error.skedTimeValidator) {
              util.toastError('Invalid data format, please check date/time and number fields.');
              return false;
            } 

            if (form.$error.min) {
              util.toastError('Number of repeating weeks should be greater than or equal to ' + $ctrl.recurring.pattern.value + '.');
              return false;
            } 

            var recurringErrorMessage = $ctrl.recurringSectionApi && angular.isFunction($ctrl.recurringSectionApi.validate) ? $ctrl.recurringSectionApi.validate() : null;
            if(recurringErrorMessage) {
              util.toastError(recurringErrorMessage);
              return false;
            }

            return true;
          };

          var buildValidateClientsParams = function () {
            var tempEvent = angular.copy($ctrl.event);
            var recurringModel = $ctrl.recurringSectionApi && angular.isFunction($ctrl.recurringSectionApi.getRecurringModel) ? $ctrl.recurringSectionApi.getRecurringModel() : null;

            if(recurringModel && recurringModel.scheduleData) {
              // event date/time
              tempEvent.startDate = recurringModel.scheduleData.startDate;
              tempEvent.endDate = recurringModel.scheduleData.startDate;
              tempEvent.startTime = recurringModel.scheduleData.startTime;
              tempEvent.endTime = recurringModel.scheduleData.endTime;
            }

            if($ctrl.createServiceLocation === 'Other') {
              tempEvent.serviceLocation = _.find($ctrl.configData.eventServiceLocations, {id: 'Other'});
            }

            var params = tempEvent.toServer();

            // patient
            //params.patientId = $ctrl.patient ? $ctrl.patient.id : null;

            // quantity
            if (params.quantity <= 0) {
              params.quantity = null;
            }

            return {
              event: params,
              recurringOptions: recurringModel.recurringOptions
            };
          };  


          var buildEventSavingParams = function () {
            var tempEvent = angular.copy($ctrl.event);
            var recurringModel = $ctrl.recurringSectionApi && angular.isFunction($ctrl.recurringSectionApi.getRecurringModel) ? $ctrl.recurringSectionApi.getRecurringModel() : null;

            if(recurringModel && recurringModel.scheduleData) {
              // event date/time
              tempEvent.startDate = recurringModel.scheduleData.startDate;
              tempEvent.endDate = recurringModel.scheduleData.startDate;
              tempEvent.startTime = recurringModel.scheduleData.startTime;
              tempEvent.endTime = recurringModel.scheduleData.endTime;
            }

            if($ctrl.createServiceLocation === 'Other') {
              tempEvent.serviceLocation = _.find($ctrl.configData.eventServiceLocations, {id: 'Other'});
            }

            // quantity
						if (tempEvent.quantity <= 0) {
							tempEvent.quantity = null;
            }
            
            if($ctrl.pageMode === PAGE_MODE.CREATE) {
							var recurringOptions = recurringModel ? recurringModel.recurringOptions : null;
							var skedRecurringUtil = recurringUtil.getInstance($ctrl.configData);
							var recurringJobs = skedRecurringUtil.generateRecurringJobs(tempEvent, recurringOptions);
							var recurringSchedule = skedRecurringUtil.generateRecurringSchedule(recurringOptions);
							return {
								skedJobs: recurringJobs.map(function(item) {
									return item.toServerSObject();
								}),
								skedRecurringSchedule: recurringSchedule ? {
									sked_Skip_Holidays__c: recurringSchedule.skipHolidays
								} : null
							};
						}
						
						//edit mode
						//build recurring jobs
						var recurringJobs = [];
						var editRecurringOption = (recurringModel && recurringModel.recurringOptions) ? recurringModel.recurringOptions.editAction : null;
						
						if(editRecurringOption) {
							recurringJobs = util.getRecurringJobsByRecurringOptions(tempEvent, $ctrl.recurringSchedule ? $ctrl.recurringSchedule.events : [], editRecurringOption, $ctrl.today, false);
						}

            //apply changes to recurring jobs and toServer
            var fieldChanges = _.pick(tempEvent, ['address', 'description', 'startTime', 'endTime', 'eventType', 'tags', 'jobTasks', 'quantity', 'serviceLocation', 'region', 'notes', 'supportPlan', 'inheritAccountTasks', 'loneWorkerRisk']);
            if($ctrl.mode === MODE.GROUP_EVENT) {
              var fieldChanges = _.pick(tempEvent, ['description', 'startTime', 'endTime', 'eventType', 'tags', 'notes', 'jobTasks']);
            }
						recurringJobs = recurringJobs.map(function(job) {
							var updatedJob = _.extend(job, fieldChanges);
							return updatedJob.toServerSObject();
						});

						//always update the current job
						recurringJobs.unshift(tempEvent.toServerSObject());

						return {
							skedJobs: recurringJobs
						};
          };

          var searchAddresses = function (searchString) {

            searchString = searchString || '';

            if (searchString.length >= 1) {
              return doSearchAddresses(searchString)
                .then(function (response) {
                  if (response.status === 'OK') {
                    return model.AddressModel.fromGGServerList(response.results);
                  }
                });
            }
          };

          var searchTags = function(searchString) {
            if(!$ctrl.configData || !$ctrl.configData.tags) {
              return $q.when()
                .then(function(){
                  return [];
                });
            }

            if(util.isNullOrEmpty(searchString)) {
              searchString = '';
            }

            return $propertiesFilter($ctrl.configData.tags, {name: searchString});
          };

          var searchContacts = function(searchString) {
            if(!$ctrl.configData || !$ctrl.configData.contacts) {
              return $q.when()
                .then(function(){
                  return [];
                });
            }

            if(util.isNullOrEmpty(searchString)) {
              searchString = '';
            }
                        
            return $propertiesFilter($ctrl.configData.contacts, {fullName: searchString});
          };

          var fetchDataFromGroupEvent = function(event, groupEvent) {
            if(!event || !groupEvent) return;

            event.description = groupEvent.description;
            event.clients = _.sortBy(angular.copy(groupEvent.clients), function (client) {
              return client.contact && client.contact.name;
            });
            event.clients.forEach(function(client){
              client.id = null;
            });
                    
            if (_.isArray(groupEvent.tags)) {
              tagIds = _.map(groupEvent.tags, 'id');
              event.tags = _.filter($ctrl.configData.tags, function (tag) {
                return tagIds.indexOf(tag.id) > -1;
              });
            }
          };

          var searchPatientsForGroupEvent = function (searchString) {
            var params = buildValidateClientsParams();
            if(!isParamsValidToValidateClients(params)) {
              return $q.when().then(function(){return [];});
            }

            return api.searchAvailablePatients({
              textSearch: searchString || '',
              event: params.event
            })
              .then(function (result) {
                if (result && result.success) {
                  var allPatients = model.PatientModel.fromServerList(result.data);

                  return _.filter(allPatients, function(patient) {
                    return !_.find($ctrl.event.clients, function(client){
                      return !client.isDeleted && (
                        client.contact && client.contact.id === patient.id
                      );
                    });
                  });
                } else {
                  return $q.reject(result);
                }
              })
              .catch(commonExceptionHanlder);
          };

          var searchSupportPlans = function (searchString, accountId) {
            if(!accountId) return $q.when().then(function(){return [];});
            return api.search({
              objectType: OBJECT_TYPE.SUPPORT_PLAN,
              queryText: searchString || '',
              criteria: {
                accountId: accountId
              }
            })
              .then(function (result) {
                if (result.success) {
                  return model.CarePlanModel.fromServerList(result.data);
                } else {
                  return [];
                }
              })
              .catch(commonExceptionHanlder);
          };


          var onClientChanged = function(client) {
            if(!client) return;

            //contact removed
            client.supportPlan = null;
            client.supportPlans = [];
          };

          var addClient = function () {
            var newClient = new model.ClientModel();
            $ctrl.event.clients.push(newClient);
          };

          var deleteClient = function (client) {
            if(!client) return;

            if(client.isNew()) {
              var index = $ctrl.event.clients.indexOf(client);
              if(index !== -1) {
                $ctrl.event.clients.splice(index, 1);
              }
            } else {
              client.isDeleted = true;
            }
          };

          var isParamsValidToValidateClients = function(params){
            if(!params || !params.event) return false;

            var event = params.event;
            if(util.isNullOrEmpty(event.startDate) || util.isNullOrEmpty(event.endDate) || util.isNullOrEmpty(event.startTime) || util.isNullOrEmpty(event.endTime)) {
              return false;
            }

            var startDateTime = dateUtil.parseDateTime(event.startDate, event.startTime);
            var endDateTime = dateUtil.parseDateTime(event.endDate, event.endTime);

            if(startDateTime >= endDateTime) return false;

            return true;
          };

          var validateClients = function(event) {
            if(!event) return;
            var clients = _.filter(event.clients, {isDeleted: false});
            if(!clients.length) return;

            $ctrl.clientErrorMap = {};
            $ctrl.removedClientsDueToErrors = [];

            var params = buildValidateClientsParams();
            if(!isParamsValidToValidateClients(params)) {
              return;
            }
            showLoading();
            doValidateClients({
              event: params.event
            })
              .then(function(result){
                if (result.success) {
                  $ctrl.clientErrorMap = _.keyBy(result.data, 'id');

                  clients.forEach(function(client){
                    var hasError = client.contact && $ctrl.clientErrorMap[client.contact.id] && $ctrl.clientErrorMap[client.contact.id].errors && $ctrl.clientErrorMap[client.contact.id].errors.length;
                    if(hasError){
                      deleteClient(client);
                      $ctrl.removedClientsDueToErrors.push(angular.copy(client));
                    }
                  });
                } else {
                  return $q.reject(result);
                }
              })
              .finally(hideLoading);
          };

          var doSearchSchedules = function (searchParams) {
            return api.searchSchedules(searchParams)
              .catch(commonExceptionHanlder);
          };

          var searchSchedules = function (searchString) {
            return doSearchSchedules({
              //patientId: $ctrl.patient.id,
              textSearch: searchString || ''
            }).then(function (result) {
              var resultData;
              var filterCriterion = 'job';
              var schedules = [];

              if (result.success) {
                resultData = result.data;
                                
                if (angular.isArray(resultData) && resultData.length) {
                  resultData = resultData.filter(function (dataItem) {
                    return dataItem.objectType === filterCriterion;
                  });

                  schedules = model.ScheduleModel.fromServerList(resultData);
                }
              } 

              return schedules;
            });
          };

          var onEventTypeChanged = function() {
            var isDescriptionChanged = $ctrl.form && $ctrl.form.description && $ctrl.form.description.$dirty;

            if(!($ctrl.pageMode === PAGE_MODE.EDIT) && !isDescriptionChanged) {
              $ctrl.event.description = util.buildDescriptionForSingleJob($ctrl.event.eventType, $ctrl.configData.patient);
            }
          };

          var filteredAccountTasks = function () {
            if (!$ctrl.event) {
              return [];
            }
            var recurringModel = $ctrl.recurringSectionApi && angular.isFunction($ctrl.recurringSectionApi.getRecurringModel) ? $ctrl.recurringSectionApi.getRecurringModel() : null;

            if(!recurringModel) {
              return [];
            }

            var eventDate = moment(recurringModel.scheduleData.startDate).format('YYYY-MM-DD');

            return !$ctrl.event ? [] : $ctrl.configData.patient.accountTasks.filter(function (accountTask) {
              if (!accountTask.startDate) {
                return true;
              }

              if (eventDate < accountTask.startDate) {
                return false;
              }

              return !accountTask.endDate || (eventDate <= accountTask.endDate);
            });
          };

          var viewJobTasks = function () {
            return !$ctrl.event ? [] :
              $ctrl.event.inheritAccountTasks && $ctrl.pageMode === PAGE_MODE.CREATE ? filteredAccountTasks() : $ctrl.event.jobTasks.getList();
          };

          var cloneAccountTask = function () {
            if ($ctrl.event.inheritAccountTasks) {
              $ctrl.event.inheritAccountTasks = false;
              $ctrl.pageMode === PAGE_MODE.CREATE && $ctrl.event.jobTasks.getList().length === 0 && $ctrl.event.jobTasks.inheritAccountTasks(filteredAccountTasks());
            }
          };

          var moveTask = function (index, action) {
            cloneAccountTask();
            $ctrl.event.jobTasks.changeSequence(index, action);
          };

          var editTask = function (index) {
            cloneAccountTask();
            $ctrl.event.jobTasks.getList()[index].switchToEdit();
          };
                    

          var deleteTask = function (index) {
            cloneAccountTask();
            $ctrl.event.jobTasks.deleteTask(index);
          };

          var addTask = function () {
            cloneAccountTask();
            $ctrl.event.jobTasks.addTask($ctrl.newTask);
            $ctrl.newTask = {
              name : '',
              description: '',
            };
          };

          var removeAllTasks = function () {
            $ctrl.event.inheritAccountTasks = false;
            $ctrl.event.jobTasks.clear();
          };

          var toggleInherrit = function () {
            $ctrl.event.jobTasks.clear();
          };


          /**
                     * controller init
                     * used for setting initial value
                     */
          $ctrl.$onInit = function () {
            $ctrl.isModalOpen = true;
            $ctrl.INTEGER_PATTERN = INTEGER_PATTERN;
            $ctrl.pageMode = $ctrl.event && $ctrl.event.id ? PAGE_MODE.EDIT : PAGE_MODE.CREATE;
            $ctrl.mode = $ctrl.mode === MODE.GROUP_EVENT ? MODE.GROUP_EVENT : MODE.SINGLE;
            $ctrl.initialized = false;
            $ctrl.newTask = {
              name: '',
              description: ''
            };

            var initPromise = $q.when();
                    

            if($ctrl.pageMode === PAGE_MODE.EDIT) {
              initPromise = initPromise.then(function(){
                return getJobDetails($ctrl.event.id, true);
              });
            }

            showLoading();
            initPromise.
              then(function() {
                if ($ctrl.pageMode === PAGE_MODE.CREATE) {
                  var tempEvent = angular.copy($ctrl.event);

                  $ctrl.event = new model.PACJobModel();
                  $ctrl.event.startDate = moment().toDate();
                  $ctrl.event.endDate = moment().toDate();
                  $ctrl.event.startTime = $ctrl.configData.consoleSettings.startWorkingTime;
                  $ctrl.event.endTime = dateUtil.parseTimeFromMinute(Math.min(dateUtil.getMinuteValue($ctrl.event.startTime) + $ctrl.configData.consoleSettings.defaultDuration, 24 * 60 - $ctrl.configData.consoleSettings.calendarStep));
                  $ctrl.event.supportPlan = _.find($ctrl.configData.supportPlans, {selected: true});
                  $ctrl.event.region =  $ctrl.viewRegion ? _.find($ctrl.configData.regions, {
                    id: $ctrl.viewRegion.id
                  }) : null; 
                  $ctrl.event.inheritAccountTasks = true;
                  $ctrl.event.loneWorkerRisk = false;

                  $ctrl.displaySmartServiceLocationOptions = $ctrl.configData.patient.availabilityType === constants.SERVICE_USER_AVAIBILITY_TYPE.AVAILABILITY_ONLY;

                  if(tempEvent) {
                    if(!util.isNullOrEmpty(tempEvent.startDate)) {
                      $ctrl.event.startDate = tempEvent.startDate;
                    }

                    if(!util.isNullOrEmpty(tempEvent.endDate)) {
                      $ctrl.event.endDate = tempEvent.endDate;
                    }

                    if(!util.isNullOrEmpty(tempEvent.startTime)) {
                      $ctrl.event.startTime = tempEvent.startTime;
                    }

                    if(!util.isNullOrEmpty(tempEvent.endTime)) {
                      $ctrl.event.endTime = tempEvent.endTime;
                    }
                  }

                  if($ctrl.mode === MODE.GROUP_EVENT) {
                    fetchDataFromGroupEvent($ctrl.event, $ctrl.groupEvent);
                  } else if($ctrl.mode === MODE.SINGLE) {
                    $ctrl.event.description = util.buildDescriptionForSingleJob(EVENT_TYPE.TREATMENT, $ctrl.configData.patient);
                    // BAC specific logic, there is only one contact
                    $ctrl.event.contact = $ctrl.configData.contacts[0];
                    $ctrl.event.patientId = $ctrl.configData.patient.id;
                    // $ctrl.event.contact = _.find($ctrl.configData.contacts[0], { isPrimary: true });
                    if (!$ctrl.displaySmartServiceLocationOptions) {
                      $ctrl.event.serviceLocation = _.find($ctrl.configData.eventServiceLocations, { selected: true });
                    }
                    $ctrl.event.tags = _.filter($ctrl.configData.tags, { selected: true });
                  }

                  //$ctrl.event.region = angular.copy($ctrl.region);
                } else {
                  if($ctrl.event.serviceLocation) {
                    $ctrl.event.serviceLocation = _.find($ctrl.configData.eventServiceLocations, {id: $ctrl.event.serviceLocation.id});
                  }

                  if($ctrl.event.supportPlan) {
                    $ctrl.event.supportPlan = _.find($ctrl.configData.supportPlans, {id: $ctrl.event.supportPlan.id});
                  }

                  //console.log($ctrl.event.contact, $ctrl.configData.contacts);
                  if($ctrl.event.contact) {
                    $ctrl.event.contact = _.find($ctrl.configData.contacts, {id: $ctrl.event.contact.id});
                  }

                  if($ctrl.event.tags) {
                    $ctrl.event.tags = _.filter($ctrl.configData.tags, function(item){
                      return _.find($ctrl.event.tags, {id: item.id});
                    });
                  }
                }

                //if have support plan pass from outsite, need to set it to event and hide input in form
                if($ctrl.supportPlan && $ctrl.supportPlan.id) {
                  $ctrl.event.supportPlan = angular.copy($ctrl.supportPlan);
                  $ctrl.hideSupportPlanSelect = true;
                }

                if($ctrl.mode === MODE.GROUP_EVENT) {
                  $ctrl.event.groupEventId = $ctrl.groupEvent.id;
                }

                $ctrl.initialized = true;
              })
              .catch(function (exception) {
                if (exception && exception.errorMessage) {
                  util.toastError(exception.errorMessage);
                }
              })
              .finally(hideLoading);
          };

          /**
                 * init block
                 * used for setting up controller
                 */
          (function () {
            $scope.DEFAULT_PHOTO_URL = DEFAULT_PHOTO_URL;
            $scope.PAGE_MODE = PAGE_MODE;   
            $scope.MODE = MODE;

            $ctrl.form = null;
            $ctrl.recurringSectionApi = {};
            $ctrl.isModalOpen = false;
            $ctrl.contentLoading = false;
            $ctrl.contacts = [];
            $ctrl.hideSupportPlanSelect = false;

            $ctrl.closeModal = closeModal;
            $ctrl.pageMode = PAGE_MODE.CREATE;

            $ctrl.getArray = getArray;

            $ctrl.util = util;
            $ctrl.searchTags = searchTags;
            $ctrl.searchContacts = searchContacts;
            $ctrl.searchAddresses = searchAddresses;
            $ctrl.saveEvent = saveEvent;
            $ctrl.getArray = getArray;

            $ctrl.onClientChanged = onClientChanged;
            $ctrl.addClient = addClient;
            $ctrl.deleteClient = deleteClient;
            $ctrl.searchPatientsForGroupEvent = searchPatientsForGroupEvent;
            // $ctrl.searchCases = searchCases;
            $ctrl.searchSupportPlans = searchSupportPlans;
            $ctrl.searchSchedules = searchSchedules;

            $ctrl.onEventTypeChanged = onEventTypeChanged;

            $ctrl.viewJobTasks = viewJobTasks;
            $ctrl.moveTask = moveTask;
            $ctrl.editTask = editTask;
            $ctrl.deleteTask = deleteTask;
            $ctrl.addTask = addTask;
            $ctrl.removeAllTasks = removeAllTasks;
            $ctrl.toggleInherrit = toggleInherrit;

            $scope.$watch(function(){
              if(!$ctrl.recurringSectionApi || !$ctrl.recurringSectionApi.initialized || !$ctrl.initialized) return null; 
              return $ctrl.recurringSectionApi.getRecurringModel().scheduleData;
            }, function(){
              if($ctrl.recurringSectionApi && $ctrl.recurringSectionApi.initialized && !!$ctrl.initialized && $ctrl.mode === MODE.GROUP_EVENT) {
                validateClients($ctrl.event);
              }
            }, true);
          })();
        }
      ]
    });
})(angular, top);