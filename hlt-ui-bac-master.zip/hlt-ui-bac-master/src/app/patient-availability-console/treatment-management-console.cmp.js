(function (angular, moment, $) {
    angular.module('hltApp')
    .component('treatmentManagementConsole', {
        templateUrl: 'src/app/patient-availability-console/treatment-management-console.tpl.html',
        bindings: {
            mode: '<',
            date: '=',
            patientId: '<',
            caseId: '<',
            configData: '<',
            filter: '<'
        },
        controller: [
            '$window',
            '$timeout',
            '$location',
            '$q',
            '$scope',
            '$filter',
            'util',
            'dateUtil',
            'api',
            'constants',
            'model',
            function ($window, $timeout, $location, $q, $scope, $filter, util, dateUtil, api, constants, model) {
                var $ctrl = this;
                var filterFn = $filter('filter')
                var currentParams = {};
                var queuedJobsCurrentParams = {};

                var MODE = constants.PAC_MODE;
                var EVENT_TYPE = constants.EVENT_TYPE;
                var TABS = constants.PATIENT_AVAILABILITY_TABS;
                var DEFAULT_PHOTO_URL = $filter('skedSfUrl')(constants.DEFAULT_AVATAR_URL);
                var GRID_SETTINGS = constants.DEFAULT_GRID_SETTINGS;
                var OBJECT_TYPE = constants.OBJECT_TYPE;

                var commonExceptionHanlder = function (exception) {
                    util.toastError('Can not perform action due to server error.');

                    return $q.reject(exception);
                };

                var showLoading = function () {
                    util.showLoading();
                };

                var hideLoading = function () {
                    util.hideLoading();
                };

                /**
                 * check whether calendar params are really changed
                 */
                var isParamsReallyChanged = function (params) {
                    return !_.isEqual(angular.copy(params), angular.copy(currentParams))
                };

                /**
                 * check whether queued jobs params are really changed
                 */
                var isQueuedJobParamsReallyChanged = function (params) {
                    return !_.isEqual(angular.copy(params), angular.copy(queuedJobsCurrentParams))
                };

                var doGetGridData = function (params) {
                    return api.getClientAvailability(params)
                        .catch(commonExceptionHanlder);
                };

                var doGetJobExceptions = function (params) {
                    return api.getExceptionLogs(params)
                        .catch(commonExceptionHanlder);
                };

                var processGridData = function (data) {
                    var gridData = model.PACGridDataModel.fromServer(data, $ctrl.configData);
                    var allDayEvents = [];
                    var builtGridData = {
                        today: gridData.today,
                        timezone: gridData.timezone,
                        availabilitiesByDate: {},
                        eventsByDate: {},
                        allDayEventsByDate: {},
                        allDayEventsCount: 0
                    };

                    var processData = function(items, mapObject) {
                        if (angular.isArray(items) && items.length > 0) {
                            angular.forEach(items, function (item) {
                                // date/time
                                if (item.endTime >= 2400) {
                                    item.endTime = 0;
                                    item.endDate.setDate(item.endDate.getDate() + 1);
                                }

                                if (item.scheduleId) {
                                    item.schedule = _.find(gridData.schedules, {id: item.scheduleId});
                                }

                                if (util.isAllDayEvent(item)) {
                                    allDayEvents.push(item);
                                } else {
                                    var dateKey = dateUtil.dateToString(item.startDate);

                                    // push item to data map
                                    if (!angular.isArray(mapObject[dateKey])) {
                                        mapObject[dateKey] = [];
                                    } 

                                    mapObject[dateKey].push(item);
                                }
                            });

                            angular.forEach(mapObject, function (items) {
                                util.processTimeslots($ctrl.configData, $ctrl.timeslots, items, true, GRID_SETTINGS);
                                util.processTimeslotsPreferredTimes(items, $ctrl.timeslots);

                                // sort by y position
                                items.sort(function (item1, item2) {
                                    return item1.timeslotData && item2.timeslotData && item1.timeslotData.y - item2.timeslotData.y;
                                });

                                // check overlapping
                                angular.forEach(items, function (item, index) {
                                    util.checkOverlappingEvent(items, item, 1);
                                });

                                // calculate postion and width
                                angular.forEach(items, function (item) {
                                    if (item.overlapInfo) {
                                        angular.forEach(item.overlapInfo.overlappedEvents, function (overlappedEvent) {
                                            if (item.overlapInfo.maxLevel < overlappedEvent.overlapInfo.maxLevel) {
                                                item.overlapInfo.maxLevel = overlappedEvent.overlapInfo.maxLevel;
                                            } else {
                                                overlappedEvent.overlapInfo.maxLevel = item.overlapInfo.maxLevel;
                                            }
                                        });

                                        if(item.timeslotData) {
                                            item.timeslotData.w = ((Math.round(10000 / item.overlapInfo.maxLevel)) / 100);
                                            item.timeslotData.x = item.timeslotData.w * (item.overlapInfo.level - 1);
                                        }
                                    }

                                    var isSameCase = false;
                                    if(!util.isNullOrEmpty($ctrl.caseId)) {
                                        isSameCase = item.case && $ctrl.caseId === item.case.id;
                                    } else {
                                        isSameCase = true;
                                    }

                                    var isGroupEventJob = false;
                                    if(item.eventType && item.eventType === EVENT_TYPE.GROUP_EVENT) {
                                        isGroupEventJob = true;
                                    }

                                    item.readonly = isGroupEventJob || !isSameCase;
                                });
                            });
                        }
                    }

                    processData(gridData.availabilities, builtGridData.availabilitiesByDate);
                    processData(gridData.events, builtGridData.eventsByDate);
        
                    return builtGridData;
                };

                var isFilterValid = function(filter) {
                    if(!filter) return false;
                    if(!filter.region || !filter.region.id) return false;
                    if(!$ctrl.calendarDays || !$ctrl.calendarDays.length) return false;
                    return [];
                };

                var getInvalidFilters = function(filter) {
                    if(!filter) return [];
                    var filters = [];
                    if(!filter.region || !filter.region.id) filters.push('Region');
                    if(!$ctrl.calendarDays || !$ctrl.calendarDays.length) filters.push('Start Date');
                    return filters;
                };

                var buildJobExceptionsData = function(allExceptions) {
                    $ctrl.queuedJobsSideMenuData.currentViewJobs = [];
                    $ctrl.queuedJobsSideMenuData.otherJobs = [];
                    $ctrl.queuedJobsSideMenuData.jobMap = {};

                    var currentViewStartDate =  $ctrl.calendarDays && $ctrl.calendarDays.length ? $ctrl.calendarDays[0].date : null;
                    var currentViewEndDate = $ctrl.calendarDays && $ctrl.calendarDays.length ? $ctrl.calendarDays[$ctrl.calendarDays.length - 1].date : null;
                    allExceptions.forEach(function(exception) {
                        if(exception.job) {
                            if(currentViewStartDate && currentViewEndDate && currentViewStartDate <= exception.job.startDate && exception.job.startDate <= currentViewEndDate) {
                                //in current view
                                $ctrl.queuedJobsSideMenuData.currentViewJobs.push(exception);
                            } else {
                                //others
                                $ctrl.queuedJobsSideMenuData.otherJobs.push(exception)
                            }
                        }
                    })

                    $ctrl.queuedJobsSideMenuData.jobMap = _.groupBy(allExceptions, function(exception) {
                        return exception.job.id;
                    })
                };

                var rebuildWeekColumns = function() {
                    var calendarDays = $ctrl.calendarDays;
                    var startDayOfWeek = $ctrl.configData.consoleSettings ? $ctrl.configData.consoleSettings.firstDay : 0;
                    var endDayOfWeek = (startDayOfWeek + 6) % 7;
                    var tempColspan = 1;
                    $ctrl.weekColumns = [];

                    if(calendarDays && calendarDays.length) {
                        calendarDays.forEach(function(item, index){
                            var isLastItem = index === calendarDays.length - 1;
                            if(moment(item.date).format('d') == endDayOfWeek || isLastItem) {
                                $ctrl.weekColumns.push({
                                    colspan: tempColspan    
                                })
                                tempColspan = 1;
                            } else {
                                tempColspan += 1;
                            }
                        })
                    }
                };

                var rebuildScheduleConsole = function (forceBuild) {
                    if (isFilterValid($ctrl.filter, $ctrl.calendarDays)) {
                        var params = {
                            patientId: $ctrl.patientId,
                            caseId: $ctrl.caseId,
                            startDate: $ctrl.calendarDays[0].dateIso,
                            endDate: $ctrl.calendarDays[$ctrl.calendarDays.length - 1].dateIso,
                            regionId: $ctrl.filter.region.id,
                            objectTypes: [OBJECT_TYPE.CLIENT_AVAILABILITY, OBJECT_TYPE.JOB]
                        }

                        if (forceBuild || isParamsReallyChanged(params)) {
                            currentParams = params;
                            showLoading();
                            return doGetGridData(params)
                                .then(function (result) {
                                    if (result.success) {
                                        $ctrl.gridData = processGridData(result.data);
                                        $ctrl.today = $ctrl.gridData.today;

                                        if($ctrl.needToScrollJob) {
                                            $timeout(function(){
                                                scrollToJob($ctrl.needToScrollJob)
                                                $ctrl.needToScrollJob = null;

                                                $('.hco-rac-data-content-wrapper').trigger('scroll');
                                            })
                                        }
                                    } else {
                                        return $q.reject(result);
                                    }
                                })
                                .catch(function (exception) {
                                    if (exception && exception.errorMessage) {
                                        util.toastError(exception.errorMessage);
                                    }
                                })
                                .finally(function () {
                                    hideLoading();
                                });
                        }
                    } else {
                        $ctrl.gridData = null;
                        currentParams = {};
                    }
                };

                var rebuildQueuedJobs = function (forceBuild) {
                    $ctrl.queuedJobsSideMenuData.invalid = !($ctrl.filter);

                    if (!$ctrl.queuedJobsSideMenuData.invalid) {
                        var params = {
                            patientId: $ctrl.patientId,
                            caseId: $ctrl.caseId
                        }

                        if (forceBuild || isQueuedJobParamsReallyChanged(params)) {
                            queuedJobsCurrentParams = params;
                            showLoading();
                            return doGetJobExceptions(params)
                                .then(function (result) {
                                    if (result.success) {
                                        $ctrl.highlightedException = null;
                                        $ctrl.queuedJobsSideMenuData.allJobs = model.PACJobExceptionModel.fromServerList(result.data, $ctrl.configData);
                                        buildJobExceptionsData($ctrl.queuedJobsSideMenuData.allJobs);
                                    } else {
                                        return $q.reject(result);
                                    }
                                })
                                .catch(function (exception) {
                                    if (exception && exception.errorMessage) {
                                        util.toastError(exception.errorMessage);
                                    }
                                })
                                .finally(function () {
                                    hideLoading();
                                });
                        } else {
                            //params not changed, rebuild by calendar days
                            buildJobExceptionsData($ctrl.queuedJobsSideMenuData.allJobs);
                        }
                    } else {
                        $ctrl.highlightedException = null;
                        $ctrl.queuedJobsSideMenuData.allJobs = [];
                        $ctrl.queuedJobsSideMenuData.currentViewJobs = [];
                        $ctrl.queuedJobsSideMenuData.otherJobs = [];
                        $ctrl.queuedJobsSideMenuData.jobMap = [];
                    }
                };

                var onSelectTimes = function(event, data) {
                    showEventModal({
                        startDate: data.selectedDate,
                        endDate: data.selectedDate,
                        startTime: data.startTimeSlot.start,
                        endTime: data.endTimeSlot.end
                    })
                }

                var showEventModal = function (item) {
                    util.showModal({
                        template: '<event-modal class="sked-modal-container" region="region" event="event" patient="patient" case="case" config-data="configData" on-close="onClose(this, message)" ></event-modal>',
                    }, {
                        event: item ? angular.copy(item) : null,
                        patient: $ctrl.configData.patient,
                        case: model.PicklistItemModel.fromId($ctrl.caseId),
                        region: $ctrl.filter.region,
                        configData: $ctrl.configData,
                        onClose: function (modalScope, message) {
                            modalScope.closeModal();

                            if (message === 'done') {
                                rebuildScheduleConsole(true);
                                rebuildQueuedJobs(true);
                            }
                        }
                    });
                };

                var showEventAllocationModal = function (item) {
                    util.showModal({
                        template: '<job-allocation class="sked-modal-container" job-pinning="true" job="job" allow-posting-message="false" on-close="onClose(message, this)" config-data="configData" ></job-allocation>'
                    }, {
                        configData: $ctrl.configData,
                        job: item,
                        onClose: function (message, modalScope) {
                            modalScope.closeModal(message);

                            if (message === 'done') {
                                rebuildScheduleConsole(true);
                                rebuildQueuedJobs(true);
                            }
                        }
                    });
                };

                var showCancelEventModal = function (item) {
                    if (item && item.id) {
                        util.showModal({
                            template: '<cancel-event-modal class="sked-modal-container" event="event" patient="patient" config-data="configData" on-close="onClose(this, message)" ></cancel-event-modal>',
                        }, {
                            event: item ? angular.copy(item) : null,
                            patient: $ctrl.configData.patient,
                            configData: $ctrl.configData,
                            onClose: function (modalScope, message) {
                                modalScope.closeModal();

                                if (message === 'done') {
                                    util.toastSuccess('Appointment has been cancelled successfully.');
                                    rebuildScheduleConsole(true);
                                    rebuildQueuedJobs(true);
                                }
                            }
                        });
                    }
                };

                var toggleQueuedJobsSideMenu = function(isOpened) {
                    $ctrl.isQueuedJobsSideMenuOpened = !!isOpened;
                }

                var scrollToJob = function(job) {
                    if(!job || !job.id) return;

                    var el = $('#job-' + job.id);
                    var container = $('.hco-rac-data-content-wrapper');
                    var header = $('.hco-rac-data-header-wrapper');
                    var body = $('html');

                    if(el && el[0]) {
                        var offset = el.offset();
                        body.scrollTop(offset.top - header.outerHeight() - $('.timeslot__items li').outerHeight());
                        container.scrollLeft(offset.left - container.offset().left - $('.hco-rac-data-header-table td').outerWidth());
                    }
                };

                var navigateToJob = function(exception, outOfCurrentView){
                    if(!exception) {
                        return;
                    }
                    
                    toggleQueuedJobsSideMenu(false);

                    $ctrl.highlightedException = exception;
                    if(outOfCurrentView) {
                        $ctrl.date = exception.job.startDate;
                        $ctrl.needToScrollJob = exception.job;
                    } else {
                        //auto scroll to job
                        scrollToJob(exception.job);
                    }
                }

                var hideInfoPopover = function ($event) {
                    if ($ctrl.infoPopoverData) {
                        $ctrl.infoPopoverData.show = false;

                        $timeout(function () {
                            $ctrl.infoPopoverData = null;
                        }, 200);
                    }

                    if ($event) {
                        $event.stopPropagation();
                    }
                };

                var showInfoPopover = function ($event, item, showByMousePos) {
                    var currentlyOpened = !!$ctrl.infoPopoverData,
                        currentPosition = currentlyOpened ? $ctrl.infoPopoverData.position : null;
                    var contentPanelEl = angular.element('.hco-pac-page.main-pac-page');
                    var el = angular.element($event.currentTarget),
                        elWidth, elHeight, posX, posY, mouseOffsetX;

                    mouseOffsetX = $event.offsetX;

                    elOffset = el.offset();
                    elWidth = el.width();
                    elHeight = el.height();

                    if (showByMousePos) {
                        posX = elOffset.left + mouseOffsetX + 8;
                    } else {
                        posX = elOffset.left + elWidth + 8;
                    }
                    
                    posY = elOffset.top;

                    $ctrl.infoPopoverData = {
                        item: item,
                        position: currentPosition,
                        show: currentlyOpened
                    };

                    $timeout(function () {
                        var infoPopoverEl = angular.element('.hco-info-popover');
                        var containerHeight = contentPanelEl.height(),
                            containerWidth = contentPanelEl.width();
                        var infoPopoverElHeight = infoPopoverEl.height(),
                            infoPopoverElWidth = infoPopoverEl.width();

                        posY -= (infoPopoverElHeight / 2);

                         if (posY < 0) {
                            posY = 8;
                        } else if (posY + infoPopoverElHeight > containerHeight) {
                            posY = containerHeight - infoPopoverElHeight - 16;
                        }

                        if (posX + infoPopoverElWidth > containerWidth) {
                            posX = containerWidth - infoPopoverElWidth - 16;
                        }

                        $ctrl.infoPopoverData.show = true;
                        $ctrl.infoPopoverData.position = {
                            x: posX,
                            y: posY
                        };
                    });
                    
                    if (currentlyOpened) {
                        $event.stopPropagation();
                    }
                };

                /**
                 * controller init
                 */
                $ctrl.$onInit = function () {
                    // showLoading();
                    $q.all([
                    ])
                    .then(function (results) {
                        // timeslots
                        if ($ctrl.configData && $ctrl.configData.consoleSettings) {
                            $ctrl.timeslots = util.calculateCalendarTimeslots($ctrl.configData.consoleSettings);
                        }
                    })
                    .catch(function (exception) {
                        if (exception && exception.errorMessage) {
                            util.toastError(exception.errorMessage);
                        }
                    })
                    .finally(function () {
                        // hideLoading();
                    });
                };

                /**
                 * scope init
                 */
                (function init() {
                    var elWindow = angular.element($window);
                    $scope.DEFAULT_PHOTO_URL = DEFAULT_PHOTO_URL;
                    $scope.GRID_SETTINGS = GRID_SETTINGS;
                    $scope.TABS = TABS;
                    $scope.EVENT_TYPE = EVENT_TYPE;
                    $scope.OBJECT_TYPE = OBJECT_TYPE;
                    $scope.MODE = MODE;

                    $ctrl.readonly = false;

                    $ctrl.highlightedException = null;
                    $ctrl.gridData = null;
                    $ctrl.date = null;
                    $ctrl.today = moment().toDate();
                    $ctrl.weekColumns = [];
                    $ctrl.timeslots = [];
                    $ctrl.calendarDays = [];
                    $ctrl.isQueuedJobsSideMenuOpened = false;
                    $ctrl.infoPopoverData = null;

                    $ctrl.queuedJobsSideMenuData = {
                        invalid: false,
                        allJobs: [],
                        currentViewJobs: [],
                        otherJobs: [],
                        jobMap: {} //to check job in grid has exception or not
                    };

                    $ctrl.navigateToJob = navigateToJob;
                    $ctrl.isFilterValid = isFilterValid;
                    $ctrl.getInvalidFilters = getInvalidFilters;
                    $ctrl.toggleQueuedJobsSideMenu = toggleQueuedJobsSideMenu;
                    $ctrl.util = util;

                    $ctrl.showCancelEventModal = showCancelEventModal;
                    $ctrl.showEventModal = showEventModal;
                    $ctrl.showEventAllocationModal = showEventAllocationModal;
                    $ctrl.onSelectTimes = onSelectTimes;
                    $ctrl.hideInfoPopover = hideInfoPopover;
                    $ctrl.showInfoPopover = showInfoPopover;

                    $ctrl.tab = TABS.TREATMENT;

                    $scope.$on('toggleQueuedJobsMenu', function(){
                        toggleQueuedJobsSideMenu(true);
                    })

                    /**
                     * watch start date changed
                     */
                    $scope.$watchGroup([
                        '$ctrl.date',
                        '$ctrl.filter.region',
                        '$ctrl.today',
                    ], function (values) {
                        if (values && values[0] && angular.isDate(values[0])) {
                            $ctrl.calendarDays = util.calculateCalendarDays(values[0], $ctrl.configData, $ctrl.filter.region ? [$ctrl.filter.region] : [], $ctrl.today);
                        } else {
                            $ctrl.calendarDays = [];
                        }
                    });

                    $scope.$watch(function() {
                        return {
                            filter: $ctrl.filter,
                            days: $ctrl.calendarDays
                        }
                    }, function () {
                        rebuildWeekColumns();
                        rebuildScheduleConsole();
                    }, true);

                    $scope.$watch(function() {
                        return {
                            days: $ctrl.calendarDays
                        }
                    }, function () {
                        rebuildQueuedJobs();
                    }, true);

                    elWindow.scroll(function(){
                        $timeout(function(){
                            hideInfoPopover();
                        })
                    });
                })();
            }
        ]
    });
})(angular, moment, jQuery);