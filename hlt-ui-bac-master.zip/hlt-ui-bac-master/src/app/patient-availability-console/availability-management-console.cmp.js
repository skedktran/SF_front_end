(function (angular, moment, $) {
    angular.module('hltApp')
        .component('availabilityManagementConsole', {
            templateUrl: 'src/app/patient-availability-console/availability-management-console.tpl.html',
            bindings: {
                mode: '<',
                date: '=',
                configData: '<',
                filter: '<',
                tab: '<',
                layout: '=',
                patientId: '<',
                viewRegion: '<'
            },
            controller: [
                '$window',
                '$timeout',
                '$q',
                '$scope',
                '$filter',
                'util',
                'dateUtil',
                'checkAvailabilityUtil',
                'api',
                'constants',
                'model',
                function ($window, $timeout, $q, $scope, $filter, util, dateUtil, checkAvailabilityUtil, api, constants, model) {
                    var $ctrl = this;
                    var currentParams = {};
                    var parentElClass = null;
                    if($('.check-availability-modal').length) {
                        parentElClass = '.check-availability-modal';
                    }

                    var MODE = constants.PAC_MODE;
                    var LAYOUT_MODE = constants.LAYOUT_MODE;
                    var TABS = constants.PATIENT_AVAILABILITY_TABS;
                    var DEFAULT_PHOTO_URL = $filter('skedSfUrl')(constants.DEFAULT_AVATAR_URL);
                    var INTEGER_PATTERN = constants.INTEGER_PATTERN;
                    var GRID_SETTINGS = constants.DEFAULT_GRID_SETTINGS;
                    var OBJECT_TYPE = constants.OBJECT_TYPE;
                    var WEEK_DAYS = [
                        'Sunday',
                        'Monday',
                        'Tuesday',
                        'Wednesday',
                        'Thursday',
                        'Friday',
                        'Saturday',
                    ];

                    var commonExceptionHanlder = function (exception) {
                        util.toastError('Can not perform action due to server error.');

                        return $q.reject(exception);
                    };

                    var showLoading = function () {
                        util.showLoading();
                    };

                    var hideLoading = function () {
                        util.hideLoading();
                    };

                    /**
                 * check whether calendar params are really changed
                 */
                    var isParamsReallyChanged = function (params) {
                        return !_.isEqual(angular.copy(params), angular.copy(currentParams));
                    };

    
                    var doGetGridData = function (params) {
                        return api.getClientAvailability(params)
                            .catch(commonExceptionHanlder);
                    };

                    var doGetClientEvents = function (query) {
                        return api.getClientEvents(query)
                            .catch(commonExceptionHanlder);
                    };

                    var processGridData = function (data) {
                        var gridData = model.PACGridDataModel.fromServer(data, $ctrl.configData);
                        var allDayEvents = [];
                        var builtGridData = {
                            today: gridData.today,
                            timezone: gridData.timezone,
                            availabilitiesByDate: {},
                            allDayEventsByDate: {},
                            allDayEventsCount: 0, 
                            allEventsByDate: {}
                        };

                        var processData = function(items, mapObject) {
                            if (angular.isArray(items) && items.length > 0) {
                                angular.forEach(items, function (item) {
                                // date/time
                                    if (item.endTime >= 2400) {
                                        item.endTime = 0;
                                        item.endDate.setDate(item.endDate.getDate() + 1);
                                    }

                                    if (item.scheduleId) {
                                        item.schedule = _.find(gridData.schedules, {id: item.scheduleId});
                                    }

                                    if (util.isAllDayEvent(item)) {
                                        allDayEvents.push(item);
                                    } else {
                                        var dateKey = dateUtil.dateToString(item.startDate);

                                        // push item to data map
                                        if (!angular.isArray(mapObject[dateKey])) {
                                            mapObject[dateKey] = [];
                                        } 

                                        mapObject[dateKey].push(item);
                                    }
                                });

                                angular.forEach(mapObject, function (items) {
                                    util.processTimeslots($ctrl.configData, $ctrl.timeslots, items, true, GRID_SETTINGS);
                                    util.processTimeslotsPreferredTimes(items, $ctrl.timeslots);

                                    // sort by y position
                                    items.sort(function (item1, item2) {
                                        return item1.timeslotData && item2.timeslotData && item1.timeslotData.y - item2.timeslotData.y;
                                    });

                                    // check overlapping
                                    angular.forEach(items, function (item, index) {
                                        util.checkOverlappingEvent(items, item, 1);
                                    });

                                    // calculate postion and width
                                    angular.forEach(items, function (item) {
                                        if (item.overlapInfo) {
                                            angular.forEach(item.overlapInfo.overlappedEvents, function (overlappedEvent) {
                                                if (item.overlapInfo.maxLevel < overlappedEvent.overlapInfo.maxLevel) {
                                                    item.overlapInfo.maxLevel = overlappedEvent.overlapInfo.maxLevel;
                                                } else {
                                                    overlappedEvent.overlapInfo.maxLevel = item.overlapInfo.maxLevel;
                                                }
                                            });

                                            if(item.timeslotData) {
                                                item.timeslotData.w = ((Math.round(10000 / item.overlapInfo.maxLevel)) / 100);
                                                item.timeslotData.x = item.timeslotData.w * (item.overlapInfo.level - 1);
                                            }
                                        }
                                    });
                                });
                            }
                        };

                        processData(gridData.availabilities, builtGridData.availabilitiesByDate);

                        // concat all events to a single array
                        angular.forEach($ctrl.calendarDays, function (day) {
                            var eventsAndAvailability = [].concat(builtGridData.availabilitiesByDate[day.dateIso] || []);
                            var allEvents, event;

                            allEvents = angular.extend([], builtGridData.allDayEventsByDate[day.dateIso]);

                            if (eventsAndAvailability.length > 0) {
                                for (var i = 0; i < allEvents.length; i++) {
                                    event = allEvents[i];
                                    if (event.redundant) {
                                        allEvents[i] = eventsAndAvailability[0];
                                        eventsAndAvailability.splice(0, 1);

                                        if (eventsAndAvailability.length === 0) {
                                            break;
                                        }
                                    }
                                }

                                if (eventsAndAvailability.length > 0) {
                                    allEvents = allEvents.concat(eventsAndAvailability);
                                }
                            }

                            builtGridData.allEventsByDate[day.dateIso] = allEvents;
                        });

                        return builtGridData;
                    };

                    var isFilterValid = function() {
                    //if(!filter) return false;
                    //if(!filter.region || !filter.region.id) return false;
                        if(!$ctrl.calendarDays || !$ctrl.calendarDays.length || !$ctrl.patientId || !$ctrl.viewRegion) return false;
                        return [];
                    };

                    var getInvalidFilters = function(filter) {
                    //if(!filter) return [];
                        var filters = [];
                        //if(!filter.region || !filter.region.id) filters.push('Region');
                        if(!$ctrl.calendarDays || !$ctrl.calendarDays.length) filters.push($ctrl.layout === LAYOUT_MODE.MONTH ? 'Month' : 'Start Week');
                        if(!$ctrl.patientId) filters.push('Service User');
                        if(!$ctrl.viewRegion) filters.push('Please select a region to view available time slots');
                        return filters;
                    };

                    var rebuildScheduleConsole = function (forceBuild) {
                        if (isFilterValid($ctrl.filter, $ctrl.calendarDays)) {
                            var params = {
                            //patientId: $ctrl.patientId,
                            //caseId: $ctrl.caseId,
                                startDate: $ctrl.calendarDays[0].dateIso,
                                endDate: $ctrl.calendarDays[$ctrl.calendarDays.length - 1].dateIso,
                                regionId: $ctrl.viewRegion.id,
                                objectTypes: [OBJECT_TYPE.CLIENT_AVAILABILITY]
                            };

                            if (forceBuild || isParamsReallyChanged(params)) {
                                var resetScroll = isNeedToResetScroll(params);
                                currentParams = params;
                                showLoading();

                                var queryParams, queryFn, successFn;
                                if($ctrl.mode === MODE.CHECK_AVAILABILITY) {
                                    queryParams = angular.copy(params);
                                    queryParams.patientIds = $ctrl.patientId;
                                    //delete queryParams.patientId;
                                    //delete queryParams.caseId;
                                    delete queryParams.objectTypes;

                                    queryFn = doGetClientEvents;
                                    successFn = function(result) {
                                        checkAvailabilityUtil.initSettings($ctrl.calendarDays, $ctrl.configData, GRID_SETTINGS);
                                        $ctrl.gridData = processGridDataForCheckAvailabilityMode(result.data);
                                        $ctrl.today = $ctrl.gridData.today;
                                    };
                                } else {
                                    queryParams = angular.copy(params);
                                    queryFn = doGetGridData;
                                    successFn = function(result) {
                                        $ctrl.gridData = processGridData(result.data);
                                        $ctrl.today = $ctrl.gridData.today;
                                    };
                                }

                                return queryFn(queryParams)
                                    .then(function (result) {
                                        if (result.success) {
                                            successFn(result);

                                            var _hidePopoverFn = function(){
                                                if(!$ctrl.ignoreHideOnScroll) {
                                                    hideInfoPopover();
                                                }
                                            };
                                            $timeout(function(){
                                                $('.hco-rac-data-content-wrapper').off('scroll', _hidePopoverFn);
                                                $('.hco-rac-data-content-wrapper').on('scroll', _hidePopoverFn);

                                                if(resetScroll) {
                                                    resetGridScroll();
                                                } else {
                                                    $('.hco-rac-data-content-wrapper').trigger('scroll');
                                                }
                                            });
                                        } else {
                                            return $q.reject(result);
                                        }
                                    })
                                    .catch(function (exception) {
                                        if (exception && exception.errorMessage) {
                                            util.toastError(exception.errorMessage);
                                        }
                                    })
                                    .finally(function () {
                                        hideLoading();
                                    });
                            }
                        } else {
                            $ctrl.gridData = null;
                            currentParams = {};
                        }
                    };

                    var onSelectTimes = function(event, data) {
                        if($ctrl.mode === MODE.CHECK_AVAILABILITY) {
                            $ctrl.ignoreHideOnScroll = true;
                            $timeout(function(){
                                showInfoPopover(event, data, false);
                            });

                            $timeout(function() {
                                $ctrl.ignoreHideOnScroll = false;
                            }, 100);
                        } else {
                            showAvailabilityModal({
                                startDate: data.selectedDate,
                                endDate: data.selectedDate,
                                startTime: data.startTimeSlot.start,
                                endTime: data.endTimeSlot.end
                            });
                        }
                    
                    };

                    var createNewEvent = function (selectedDate) {
                        showAvailabilityModal({
                            startDate: selectedDate,
                            endDate: selectedDate,
                            startTime: $ctrl.configData.consoleSettings.calendarStart || 0,
                            endTime: $ctrl.configData.consoleSettings.calendarEnd || 2400
                        });
                    };

                    var showAvailabilityModal = function (item) {
                        util.showModal({
                            template: '<availability-modal class="sked-modal-container" availability="availability" config-data="configData" on-close="onClose(this, message)" ></availability-modal>',
                        }, {
                            availability: item ? angular.copy(item) : null,
                            //patient: $ctrl.configData.patient,
                            //region: $ctrl.filter.region,
                            configData: $ctrl.configData,
                            onClose: function (modalScope, message) {
                                modalScope.closeModal();

                                if (message === 'done') {
                                    rebuildScheduleConsole(true);
                                }
                            }
                        });
                    };

                    var showDeleteAvailabilityModal = function (item) {
                        if (item && item.id) {
                            util.showModal({
                                template: '<delete-availability-modal class="sked-modal-container" availability="availability" config-data="configData" on-close="onClose(this, message)" ></delete-availability-modal>',
                            }, {
                                availability: item ? angular.copy(item) : null,
                                //region: $ctrl.filter.region,
                                configData: $ctrl.configData,
                                onClose: function (modalScope, message) {
                                    modalScope.closeModal();

                                    if (message === 'done') {
                                        util.toastSuccess('Availability has been deleted successfully.');
                                        rebuildScheduleConsole(true);
                                    }
                                }
                            });
                        }
                    };

                    var hideInfoPopover = function ($event) {
                        $timeout(function () {
                            if ($ctrl.infoPopoverData && !$ctrl.isShowingInfoPopover) {
                                $ctrl.infoPopoverData.show = false;
                                angular.element('.hco-info-popover').hide();

                                if($ctrl.infoPopoverData.item && $ctrl.infoPopoverData.item.handleHideTimeslotSelection) {
                                    $ctrl.infoPopoverData.item.handleHideTimeslotSelection();
                                }

                                $ctrl.infoPopoverData = null;
                            }  
                        });

                        if ($event && $event.stopPropagation) {
                            $event.stopPropagation();
                        }
                    };

                    var showInfoPopover = function ($event, item, showByMousePos) {
                        var currentlyOpened = !!$ctrl.infoPopoverData,
                            currentPosition = currentlyOpened ? $ctrl.infoPopoverData.position : null;
                        var contentPanelEl = angular.element('.hco-pac-page.main-pac-page');
                        var el = angular.element($event.currentTarget),
                            elWidth, elHeight, posX, posY, mouseOffsetX;

                        mouseOffsetX = $event.offsetX;

                        elOffset = el.offset();
                        elWidth = el.width();
                        elHeight = el.height();

                        if (showByMousePos) {
                            posX = elOffset.left + mouseOffsetX + ($ctrl.mode === MODE.CHECK_AVAILABILITY ? 4 : 8);
                        } else {
                            posX = elOffset.left + elWidth + ($ctrl.mode === MODE.CHECK_AVAILABILITY ? 4 : 8);
                        }
                    
                        posY = elOffset.top;

                        if(parentElClass) {
                            posY += $(parentElClass).scrollTop();
                        }

                        $ctrl.infoPopoverData = {
                            item: buildDataForInfoPopover(item),
                            position: currentPosition,
                            show: currentlyOpened
                        };

                        $ctrl.isShowingInfoPopover = true;
                        $timeout(function () {
                            var infoPopoverEl = angular.element('.hco-info-popover');
                            var containerHeight = contentPanelEl.height(),
                                containerWidth = contentPanelEl.width();
                            var infoPopoverElHeight = infoPopoverEl.height(),
                                infoPopoverElWidth = infoPopoverEl.width();

                            if($ctrl.mode !== MODE.CHECK_AVAILABILITY) {
                                posY -= (infoPopoverElHeight / 2);
                            }

                            if (posY < 0) {
                                posY = 8;
                            } else if (posY + infoPopoverElHeight > containerHeight) {
                                posY = containerHeight - infoPopoverElHeight - 16;
                            }

                            if (posX + infoPopoverElWidth > containerWidth) {
                                posX = containerWidth - infoPopoverElWidth - 16;
                            }

                            $ctrl.infoPopoverData.show = true;
                            $ctrl.infoPopoverData.position = {
                                x: posX,
                                y: posY
                            };

                            $ctrl.isShowingInfoPopover = false;
                        });
                    
                        if (currentlyOpened && $event && $event.stopPropagation) {
                            $event.stopPropagation();
                        }
                    };

                    var isNeedToResetScroll = function(params) {
                    //reset scroll when start date changed
                        return !_.isEqual(angular.copy(_.pick(params, 'startDate')), angular.copy(_.pick(currentParams, 'startDate')));
                    };

                    var resetGridScroll = function() {
                        var contentWrapperEl = $('.hco-rac-data-content-wrapper');
                        // contentWrapperEl.scrollTop(0);
                        contentWrapperEl.scrollLeft(0);
                    };

                    /*check availability*/
                    var scrollToAvailability = function(item) {
                        if(!item || !item.id) return;

                        var targetEl = $('#check-availability-' + item.id);
                        var contentWrapperEl = $('.hco-rac-data-content-wrapper');
                        var headerEl = $('.hco-rac-data-header-wrapper');

                        if(targetEl && targetEl[0]) {
                            eL = targetEl.offset().left;
                            eT = targetEl.offset().top;
                            eW = targetEl.outerWidth();
                            pT = contentWrapperEl.offset().top;
                            pL = contentWrapperEl.offset().left;
                            pSL = contentWrapperEl.scrollLeft();
                            pST = contentWrapperEl.scrollTop();
                            pW = contentWrapperEl.outerWidth();
                            tsH = $('.timeslot__items li').outerHeight();

                            contentWrapperEl.scrollTop(pST + eT - pT - tsH);
                            contentWrapperEl.scrollLeft(pSL + eL - pL - eW);
                        }
                    };

                    var findNextAvailability = function() {
                        if(!isCheckAvailabilityFilterValid()) {
                            return;
                        }

                        var totalDuration = $ctrl.checkAvailabilityFilter.durationInHours * 60 + $ctrl.checkAvailabilityFilter.durationInMinutes.id;
                        var availableBlock = checkAvailabilityUtil.findAvailableBlocks($ctrl.checkAvailabilityData.unvailableSlots, $ctrl.checkAvailabilityData.clientEvents, $ctrl.checkAvailabilityFilter.acceptedRatio.id / 100, totalDuration, $ctrl.checkAvailabilityFilter.startTime);
                        var suggestedAvailabilitiesByDate = {};
                        var firstFound = null;

                        if(availableBlock) {
                            var startIndex = availableBlock.startIndex;
                            var lastSlotDate;
                            for(var slotIndex = availableBlock.startIndex; slotIndex <= availableBlock.endIndex; slotIndex++) {
                                var slotDate = checkAvailabilityUtil.getDateStringBySlotIndex(slotIndex);
                                if(!lastSlotDate) lastSlotDate = slotDate; //set to first index item
                                var isLast =  slotIndex === availableBlock.endIndex;

                                if(!suggestedAvailabilitiesByDate[slotDate]) {
                                    suggestedAvailabilitiesByDate[slotDate] = [];
                                }

                                if(lastSlotDate !== slotDate || isLast) {
                                    var slotData = checkAvailabilityUtil.buildSlotDataBySlotIndex(startIndex, slotIndex, isLast);
                                    var availability = {
                                        id: lastSlotDate + '-' + startIndex,
                                        startIndex: slotData.startIndex,
                                        endIndex: slotData.endIndex,
                                        backgroundColor: '#00d008',
                                        borderColor: '#034e06',
                                        opacity: 0.375,
                                        timeslotData: slotData.timeslotData
                                    };

                                    if(!firstFound) {
                                        firstFound = availability;
                                    }
                                    suggestedAvailabilitiesByDate[lastSlotDate].push(availability);

                                    startIndex = slotIndex;
                                }

                                lastSlotDate = slotDate;
                            }
                        } else {
                            util.toastWarning('Could not find any available time');
                        }

                        if(firstFound) {
                            $timeout(function(){
                                scrollToAvailability(firstFound);

                                //check if have startTime and duration, select slots automatically
                                if($ctrl.draggableTimeslotsApi && isCheckAvailabilityDurationValid()) {
                                    var availableSlot = checkAvailabilityUtil.findAvailableSlot(availableBlock, $ctrl.checkAvailabilityFilter.startTime, totalDuration);
                                    if(availableSlot && availableSlot.startDate === availableSlot.endDate) {
                                    //hightlight draggable timeslots
                                        $ctrl.draggableTimeslotsApi.selectTimeslotsByDate[availableSlot.startDate](availableSlot.timeslotData.y, availableSlot.timeslotData.y + availableSlot.timeslotData.h, GRID_SETTINGS.slotSize.h);
                                    }
                                }
                            });
                        }
                        $ctrl.gridData.suggestedAvailabilitiesByDate = suggestedAvailabilitiesByDate;
                    };

                    var processGridDataForCheckAvailabilityMode = function (data) {
                        var gridData = model.PACGridDataModel.fromServer(data, $ctrl.configData);
                        $ctrl.checkAvailabilityData = checkAvailabilityUtil.buildClientEvents(data.clientEvents);
                    
                        var unavailabilitiesByDate = {};
                        var lastSlotDate = null;
                        var lastSlot = null;
                        var startIndex = 0;
                        $ctrl.checkAvailabilityData.unvailableSlots.forEach(function(slot, slotIndex){
                            var slotDate = checkAvailabilityUtil.getDateStringBySlotIndex(slotIndex);
                            if(!lastSlotDate) lastSlotDate = slotDate; //set to first index item
                            if(!lastSlot) lastSlot = slot; //set to first index item
                            var isLast =  $ctrl.checkAvailabilityData.unvailableSlots.length - 1 === slotIndex;

                            if(!unavailabilitiesByDate[slotDate]) {
                                unavailabilitiesByDate[slotDate] = [];
                            }

                            if(lastSlotDate !== slotDate || lastSlot.numOfUnavailableClients !== slot.numOfUnavailableClients || isLast) {
                                var slotData = checkAvailabilityUtil.buildSlotDataBySlotIndex(startIndex, slotIndex, isLast);
                                unavailabilitiesByDate[lastSlotDate].push({
                                    startIndex: slotData.startIndex,
                                    endIndex: slotData.endIndex,
                                    numOfUnavailableClients: lastSlot.numOfUnavailableClients,
                                    backgroundColor: checkAvailabilityUtil.getBackgroundByMatchedPercentage(lastSlot.numOfUnavailableClients, $ctrl.checkAvailabilityData.clientEvents, $ctrl.configData.availabilityStatusColorSettings),
                                    opacity: 0.175,
                                    timeslotData: lastSlot.numOfUnavailableClients > 0 ? slotData.timeslotData : null
                                });

                                startIndex = slotIndex;
                            }

                            lastSlotDate = slotDate;
                            lastSlot = slot;
                        });

                        return {
                            unavailabilitiesByDate: unavailabilitiesByDate,
                            today: gridData.today,
                            timezone: gridData.timezone,
                            allDayEventsCount: 0
                        };
                    };

                    var setDefaultCheckAvailabilityFilter = function(filter, configData) {
                        filter.acceptedRatio = _.find(configData.checkAvailabilityAcceptedRatios, {selected: true});
                        var defaultDurationInHours = Math.floor(configData.consoleSettings.defaultDuration / 60);
                        var defaultDurationInMinutes = configData.consoleSettings.defaultDuration % 60;

                        filter.durationInHours = defaultDurationInHours;
                        filter.durationInMinutes = _.find($ctrl.configData.minuteOptions, {id: defaultDurationInMinutes});
                        if(!filter.durationInMinutes && $ctrl.configData.minuteOptions.length) {
                            filter.durationInMinutes = $ctrl.configData.minuteOptions[0];
                        }
                    };

                    var clearCheckAvailabilityFilter = function(){
                        $ctrl.checkAvailabilityFilter = {
                            startTime: null,
                            duration: null,
                            acceptedRatio: null
                        };

                        setDefaultCheckAvailabilityFilter($ctrl.checkAvailabilityFilter, $ctrl.configData);

                        if($ctrl.gridData) {
                            $ctrl.gridData.suggestedAvailabilitiesByDate = {};
                        }
                        checkAvailabilityUtil.initSettings($ctrl.calendarDays, $ctrl.configData, GRID_SETTINGS);
                    };

                    var isCheckAvailabilityDurationValid = function() {
                        var filter = $ctrl.checkAvailabilityFilter;
                        if(util.isNullOrEmpty(filter.durationInHours) || util.isNullOrEmpty(filter.durationInMinutes)) return true;

                        var totalDuration = filter.durationInHours * 60 + filter.durationInMinutes.id;
                        if(totalDuration <= 0) return false;

                        return true;
                    };

                    var isCheckAvailabilityFilterValid = function() {
                        var filter = $ctrl.checkAvailabilityFilter;
                        if(!filter.acceptedRatio) return false;

                        if($ctrl.checkAvailabilityFilterForm.$invalid) {
                            return false;
                        }

                        if(!isCheckAvailabilityDurationValid()) return false;
                    
                        return true;
                    };

                    var buildDataForInfoPopover = function(data) {
                        if($ctrl.mode !== MODE.CHECK_AVAILABILITY) return data;

                        var builtData = checkAvailabilityUtil.getUnavailableAndAvailableClientsBySlotTime($ctrl.checkAvailabilityData.allClients, $ctrl.checkAvailabilityData.unvailableSlots, data.selectedDate, data.startTimeSlot.start, data.endTimeSlot.start);
                        data.unavailableClients = builtData.unavailableClients;
                        data.availableClients = builtData.availableClients;
                        return data;
                    };

                    var refreshCheckAvailability = function() {
                        rebuildScheduleConsole(true);
                    };

                    var toggleCreateJob = function(data) {
                        $scope.$emit('toggleCreateJob', {
                            startDate: data.selectedDate,
                            endDate: data.selectedDate,
                            startTime: data.startTimeSlot.start,
                            endTime: data.endTimeSlot.end,
                            duration: dateUtil.getMinuteValue(data.endTimeSlot.end) - dateUtil.getMinuteValue(data.startTimeSlot.start)
                        });
                    };

                    var getWeekDays = function () {
                        var weekDays = [];
                        firstDay = $ctrl.configData.consoleSettings.firstDay || 0;

                        for (var i = 0 ; i < 7; i++) {
                            weekDays.push(WEEK_DAYS[((i + firstDay)%7)]);
                        }

                        return weekDays;
                    };

                    /*end*/

                    /**
                 * controller init
                 */
                    $ctrl.$onInit = function () {
                    // showLoading();

                        //array of patient ids
                        if($ctrl.patientId && $ctrl.patientId.indexOf(',') !== -1) {
                            $ctrl.patientId = _.compact($ctrl.patientId.split(','));
                        }

                        // //array of case ids
                        // if($ctrl.caseId && $ctrl.caseId.indexOf(',') !== -1) {
                        //     $ctrl.caseId = _.compact($ctrl.caseId.split(','));
                        // }

                        $q.all([
                        ])
                            .then(function (results) {
                                //check availability
                                if ($ctrl.mode === MODE.CHECK_AVAILABILITY) {
                                    setDefaultCheckAvailabilityFilter($ctrl.checkAvailabilityFilter, $ctrl.configData);
                                }

                                // timeslots
                                if ($ctrl.configData && $ctrl.configData.consoleSettings) {
                                    $ctrl.timeslots = util.calculateCalendarTimeslots($ctrl.configData.consoleSettings);
                                }
                            })
                            .catch(function (exception) {
                                if (exception && exception.errorMessage) {
                                    util.toastError(exception.errorMessage);
                                }
                            })
                            .finally(function () {
                                // hideLoading();
                            });
                    };

                    /**
                 * scope init
                 */
                    (function init() {
                        var elWindow = angular.element($window);
                        var elParent = parentElClass ? angular.element(parentElClass) : elWindow;

                        $scope.DEFAULT_PHOTO_URL = DEFAULT_PHOTO_URL;
                        $scope.GRID_SETTINGS = GRID_SETTINGS;
                        $scope.OBJECT_TYPE = OBJECT_TYPE;
                        $scope.TABS = TABS;
                        $scope.INTEGER_PATTERN = INTEGER_PATTERN;
                        $scope.MODE = MODE;
                        $scope.LAYOUT_MODE = LAYOUT_MODE;
                        $scope.WEEK_DAYS = WEEK_DAYS;

                        $ctrl.parentElClass = parentElClass;
                        $ctrl.gridData = null;
                        $ctrl.date = null;
                        $ctrl.today = moment().toDate();
                        $ctrl.timeslots = [];
                        $ctrl.infoPopoverData = {};
                        $ctrl.isFilterValid = isFilterValid;
                        $ctrl.getInvalidFilters = getInvalidFilters;
                        $ctrl.util = util;
                    
                        $ctrl.showDeleteAvailabilityModal = showDeleteAvailabilityModal;
                        $ctrl.showAvailabilityModal = showAvailabilityModal;
                        $ctrl.onSelectTimes = onSelectTimes;
                        $ctrl.showInfoPopover = showInfoPopover;
                        $ctrl.hideInfoPopover = hideInfoPopover;

                        $ctrl.createNewEvent = createNewEvent;

                        /*check availability*/
                        $ctrl.checkAvailabilityFilterForm = {};
                        $ctrl.checkAvailabilityFilter = {
                            startTime: null,
                            durationInHours: null,
                            durationInMinutes: null,
                            acceptedRatio: null
                        };
                        $ctrl.checkAvailabilityData = null;
                        $ctrl.draggableTimeslotsApi = {};
                        $ctrl.findNextAvailability = findNextAvailability;
                        $ctrl.clearCheckAvailabilityFilter = clearCheckAvailabilityFilter;
                        $ctrl.isCheckAvailabilityFilterValid = isCheckAvailabilityFilterValid;
                        $ctrl.isCheckAvailabilityDurationValid = isCheckAvailabilityDurationValid;
                        $ctrl.toggleCreateJob = toggleCreateJob;
                        /*end*/

                        $ctrl.getWeekDays = getWeekDays;

                        $scope.$on('refreshCheckAvailability', function(){
                            refreshCheckAvailability();
                        });

                        $scope.$on('pac.refreshConsole', function(){
                            rebuildScheduleConsole(true);
                        });

                        /**
                     * watch start date changed
                     */
                        $scope.$watchGroup([
                            '$ctrl.date',
                            //'$ctrl.filter.region',
                            '$ctrl.today',
                            '$ctrl.layout'
                        ], function (values) {
                            var startDate, endDate, firstDay, restDayCount;

                            $ctrl.calendarDays = [];
                            $ctrl.calendarWeeks = [];

                            if ($ctrl.date && angular.isDate($ctrl.date)) {
                                firstDay = $ctrl.configData.consoleSettings.firstDay || 0;

                                if ($ctrl.layout === LAYOUT_MODE.MONTH) {
                                    startDate = angular.copy($ctrl.date);
                                    endDate = angular.copy($ctrl.date);
                                    startDate.setDate(1);
                                    endDate.setDate(1);

                                    // identify calendar start date
                                    startDate.setDate(1 - startDate.getDay() + firstDay);

                                    // identify calendar end date
                                    endDate.setMonth(endDate.getMonth() + 1);
                                
                                    restDayCount = (7 - endDate.getDay() + firstDay);
                                    if (restDayCount < 7) {
                                        endDate.setDate(endDate.getDate() + restDayCount);
                                    }

                                    $ctrl.calendarDays = util.calculateCalendarDays(startDate, $ctrl.configData, $ctrl.filter.region ? [$ctrl.filter.region] : [], $ctrl.today, endDate);
                                    $ctrl.calendarWeeks = util.buildCalendarWeeks($ctrl.calendarDays, $ctrl.date.getMonth(), firstDay);
                                } else {
                                    startDate = angular.copy($ctrl.date);

                                    startDate.setDate(startDate.getDate() - ((startDate.getDay() + 7 - firstDay) % 7));
                                    endDate = angular.copy(startDate);
                                    endDate.setDate(endDate.getDate() + ($ctrl.configData.consoleSettings.viewPeriod * 7));

                                    $ctrl.calendarDays = util.calculateCalendarDays(startDate, $ctrl.configData, $ctrl.filter.region ? [$ctrl.filter.region] : [], $ctrl.today, endDate);
                                }
                            } 
                        });

                        $scope.$watch(function() {
                            return {
                                patientId: $ctrl.patientId,
                                filter: $ctrl.filter,
                                days: $ctrl.calendarDays,
                                regionId: $ctrl.viewRegion && $ctrl.viewRegion.id
                            };
                        }, function () {
                            rebuildScheduleConsole();
                        }, true);

                        elParent.scroll(function(){
                            $timeout(function(){
                                if(!$ctrl.ignoreHideOnScroll) {
                                    hideInfoPopover();
                                }
                            });
                        });
                    })();
                }
            ]
        });
})(angular, moment, jQuery);