(function (angular, jQuery, _) {
    angular.module('hltApp')
    .factory('checkAvailabilityUtil', [
        '$q',
        '$rootScope',
        '$filter',
        '$document',
        '$templateRequest',
        '$compile',
        '$timeout',
        'dateUtil',
        'util',
        'constants',
        function ($q, $rootScope, $filter, $document, $templateRequest, $compile, $timeout, dateUtil, util, constants) {
            var DATE_TIME_IN_MINUTES = 24 * 60;

            //must be set by initSettings
            var settings = {};

            var populateDataToSlot = function(unvailableSlots, step, eventStart, eventStartRowIndexByStartDate, client) {
                var tempStart = eventStart + step;

                var eventStartRow = eventStartRowIndexByStartDate + Math.floor(tempStart / DATE_TIME_IN_MINUTES);
                tempStart = tempStart % DATE_TIME_IN_MINUTES;

                // offset to eventStartRow
                var eventRowOffset = Math.floor(tempStart / settings.blockLength);
                var eventIndex = eventStartRow * settings.numOfBlocksPerDay + eventRowOffset;

                if (eventIndex < unvailableSlots.length && unvailableSlots[eventIndex] && !unvailableSlots[eventIndex].unavailableClientsMap[client.id]) {
                    // Has not yed added this client to unAvailability 
                    unvailableSlots[eventIndex].numOfUnavailableClients++;
                    unvailableSlots[eventIndex].unavailableClientsMap[client.id] = client;
                }
            }

            var addClientEvents = function(unvailableSlots, clientEvent) {
                clientEvent.allEvents.forEach(function(event){
                    var eventStart = dateUtil.getMinuteValue(event.startTime);
                    var duration = event.duration;
                    var step = 0;

                    // Consider a row contains numOfBlocksPerDay elements
                    var eventStartRowIndexByStartDate = dateUtil.getDiff(settings.calStartDate, dateUtil.parseDateString(event.startDate));
                
                    while (step < duration) {
                        populateDataToSlot(unvailableSlots, step, eventStart, eventStartRowIndexByStartDate, clientEvent.ownerInfo);
                        step += settings.blockLength;
                    }
                    if ((eventStart + duration) % settings.blockLength !== 0) {
                        populateDataToSlot(unvailableSlots, duration, eventStart, eventStartRowIndexByStartDate, clientEvent.ownerInfo);
                    }
                })  
            }

            var isAvailableRatioMetAcceptedRatio = function(matchedUnavailableClients, allClients, acceptedRatio) {
                var ratioNumberOfAvailableToTotalClient = 1 - (matchedUnavailableClients.length / allClients.length);
                if (ratioNumberOfAvailableToTotalClient < acceptedRatio) {
                    return false;
                }
                return true;
            }

            var isStartTimeValid = function(startTime, startIndex, endIndex) {
                var needToCheckStartTime = !util.isNullOrEmpty(startTime);
                if(!needToCheckStartTime) return true;
                var startDate = getDateStringBySlotIndex(startIndex);
                var endDate = getDateStringBySlotIndex(endIndex);
                var startTimeInMinutes = dateUtil.getMinuteValue(startTime);
                var currentSlotTimeInMinutes = getTimeMinutesBySlotIndex(endIndex);

                return startDate != endDate || currentSlotTimeInMinutes >= startTimeInMinutes;
            }

            var findAvailableBlocks = function(unvailableSlots, allClients, acceptedRatio, duration, startTime) {
                // Number of Slot: input duration / block length
                var requiredNumberOfAvaiSlots = Math.round(duration / settings.blockLength);

                var numberOfSlots = unvailableSlots.length;
                var lastIndexToCheck = numberOfSlots - requiredNumberOfAvaiSlots;
                var found = false;
                for (var i = 0; i <= unvailableSlots.length; i++) {
                    var checkingIndex = (settings.startingIndex + i)%unvailableSlots.length;
                    // console.log('###checkingIndex: ' + checkingIndex);
                    if (checkingIndex > lastIndexToCheck) {
                        settings.lastFoundIndex = null;
                        continue;
                    }

                    if (!indexIsInCalendarSettingRange(checkingIndex % settings.numOfBlocksPerDay, settings.offsetSlotIndexCompareToCalendarStart, settings.offsetSlotIndexCompareToCalendarEnd)) {
                        continue;
                    }

                    var matchedUnavailableClientIds = [];
                    var foundRequiredNumberOfAvailableSlots = true;
                    var tempCheckingIndex = checkingIndex;
                    
                    // Find continuous blocks that have number of available clients ratio >= acceptedRatio
                    while(tempCheckingIndex < numberOfSlots) {
                        
                        if (!indexIsInCalendarSettingRange(tempCheckingIndex % settings.numOfBlocksPerDay, settings.offsetSlotIndexCompareToCalendarStart, settings.offsetSlotIndexCompareToCalendarEnd)) {
                            break;
                        }

                        matchedUnavailableClientIds = _.union(matchedUnavailableClientIds, Object.keys(unvailableSlots[tempCheckingIndex].unavailableClientsMap));

                        if (!isAvailableRatioMetAcceptedRatio(matchedUnavailableClientIds, allClients, acceptedRatio) || !isStartTimeValid(startTime, checkingIndex, tempCheckingIndex)) {
                            // It doesn't meet the accepted number of available clients ratio or not meet start time checking
                            break;
                        }
                        tempCheckingIndex++;
                    }

                    if ((tempCheckingIndex - checkingIndex) >= requiredNumberOfAvaiSlots && (tempCheckingIndex - 1) != settings.lastFoundIndex) {
                        // console.log('checkingIndex: ' + checkingIndex, ' Number of continuos blocks: ', (tempCheckingIndex - checkingIndex), ' lastFoundIndex', settings.lastFoundIndex );
                        // DEBUG
                        // var dateOfCheckingIndex = dateUtil.addDay(startDate,Math.floor(checkingIndex/numOfBlocksPerDay));
                        // var timeInMinutesOfCheckingIndex = (checkingIndex%numOfBlocksPerDay)*blockLength;
                        // var timeInNumberOfCheckingIndex = Math.floor(timeInMinutesOfCheckingIndex/60)*100 + timeInMinutesOfCheckingIndex%60;
                        // console.log('##dateOfCheckingIndex: ', dateOfCheckingIndex, '  timeInMinutesOfCheckingIndex: ',timeInMinutesOfCheckingIndex, ' timeInNumberOfCheckingIndex: ', timeInNumberOfCheckingIndex );
                        
                        settings.lastFoundIndex = tempCheckingIndex - 1;
                        settings.startingIndex = checkingIndex;
                        found = true;
                        break;
                    }
                }

                // Wrap search
                settings.startingIndex++;
                
                return found ? {
                    startIndex: checkingIndex,
                    endIndex: tempCheckingIndex - 1
                } : null;
            }

            var indexIsInCalendarSettingRange = function(index, startIndex, endIndex) {
                return (index >= startIndex) && (index <= endIndex);
            }

            var findAvailableSlot = function(availableBlock, startTime, duration) {
                var lastSlotDate;
                var requiredNumberOfSlots = Math.round(duration / settings.blockLength);
                var numberOfSlots = 0;
                var startIndex = availableBlock.startIndex;

                for(var slotIndex = availableBlock.startIndex; slotIndex <= availableBlock.endIndex; slotIndex++) {
                    numberOfSlots = numberOfSlots + 1;
                    var slotDate = getDateStringBySlotIndex(slotIndex);
                    var slotTimeInMinutes = getTimeMinutesBySlotIndex(slotIndex);
                    var startTimeInMinutes = dateUtil.getMinuteValue(startTime);

                    if(numberOfSlots >= requiredNumberOfSlots) {
                        //found, break and return
                        return buildSlotDataBySlotIndex(startIndex, slotIndex + 1);
                    };

                    if((lastSlotDate && lastSlotDate !== slotDate) || slotTimeInMinutes < startTimeInMinutes) {
                        numberOfSlots = 0;
                        startIndex = slotIndex + 1;
                    }

                    lastSlotDate = slotDate;
                }           

                return null;
            }

            var buildClientEvents = function(clientEvents) {
                var unvailableSlots = [];
                var allClientsMap = {};

                for (var i = 0; i < settings.numOfBlocksPerDay * settings.numOfDays; i++) {
                    unvailableSlots[i] = {'numOfUnavailableClients' : 0, 'unavailableClientsMap' : {}};
                }
                
                clientEvents.forEach(function(clientEvent){
                    clientEvent.ownerInfo = {
                        id: clientEvent.id,
                        name: clientEvent.name
                    };
                    
                    if(!allClientsMap[clientEvent.ownerInfo.id]) {
                        allClientsMap[clientEvent.ownerInfo.id] = clientEvent.ownerInfo;
                    }

                    addClientEvents(unvailableSlots, clientEvent);
                })
                
                return {
                    clientEvents: clientEvents, 
                    unvailableSlots: unvailableSlots,
                    allClients: _.values(allClientsMap)
                }
            }

            function getDateStringBySlotIndex(index) {
                var noOfDays = Math.floor(index / settings.numOfBlocksPerDay);
                return dateUtil.dateToString(dateUtil.addDay(settings.calStartDate, noOfDays));
            }

            function getTimeMinutesBySlotIndex(index) {
                return (index % settings.numOfBlocksPerDay) * settings.blockLength;
            }

            function getRemBySlotIndex(index) {
                return (index % settings.numOfBlocksPerDay) * settings.GRID_SETTINGS.slotSize.h;
            }

            function getBackgroundByMatchedPercentage(numOfUnavailableClients, allClients, availabilityStatusColorSettings) {
                var percentage = (1 - numOfUnavailableClients / allClients.length) * 100;
                var status;
                _.values(availabilityStatusColorSettings).forEach(function(item){
                    if(!status && item.lowerPercentage <= percentage && item.upperPercentage >= percentage) {
                        status = item;
                    }
                })
                return status ? status.backgroundColor : null;
            };

            function buildSlotDataBySlotIndex(startIndex, endIndex, isLast) {
                //isLast = false, endIndex is index of next slot to end slot => we have to -1
                //isLast = true, startIndex -> endIndex
                var tempSlotIdex = endIndex;
                if(!isLast) tempSlotIdex = tempSlotIdex - 1; 

                var startIndexWithOffset = Math.max(startIndex % settings.numOfBlocksPerDay - settings.offsetSlotIndexCompareToCalendarStart, -1);
                var endIndexWithOffset = Math.max(tempSlotIdex % settings.numOfBlocksPerDay - settings.offsetSlotIndexCompareToCalendarStart, -1);

                //check if exceed last
                if(endIndexWithOffset >= (settings.offsetSlotIndexCompareToCalendarEnd - settings.offsetSlotIndexCompareToCalendarStart)) {
                    endIndexWithOffset = settings.offsetSlotIndexCompareToCalendarEnd - settings.offsetSlotIndexCompareToCalendarStart - 1;
                }

                return {
                    startDate: getDateStringBySlotIndex(startIndex),
                    endDate: getDateStringBySlotIndex(endIndex),
                    startIndex: startIndex,
                    endIndex: tempSlotIdex,
                    timeslotData: endIndexWithOffset < 0 ? null : {
                        y: getRemBySlotIndex(startIndexWithOffset),
                        h: getRemBySlotIndex(endIndexWithOffset - startIndexWithOffset) + settings.GRID_SETTINGS.slotSize.h
                    }
                }
            };

            function getUnavailableAndAvailableClientsBySlotTime(allClients, unvailableSlots, startDate, startTime, endTime) {
                //work only if in same date

                var eventStartRowIndexByStartDate = dateUtil.getDiff(settings.calStartDate, dateUtil.parseDateString(startDate));
                var startTimeIndex = Math.floor(dateUtil.getMinuteValue(startTime) / settings.blockLength);
                var endTimeIndex = Math.floor(dateUtil.getMinuteValue(endTime) / settings.blockLength);

                var startIndex = eventStartRowIndexByStartDate * settings.numOfBlocksPerDay + startTimeIndex;
                var endIndex = eventStartRowIndexByStartDate * settings.numOfBlocksPerDay + endTimeIndex;

                var unavailableClientsMap = [];
                var availableClientsMap = [];

                for(var i = startIndex; i <= endIndex; i++) {
                    var unavailabSlot = unvailableSlots[i];
                    _.keys(unavailabSlot.unavailableClientsMap).forEach(function(clientId){
                        unavailableClientsMap[clientId] = unavailabSlot.unavailableClientsMap[clientId];
                    })
                }

                var unavailableClients =  _.values(unavailableClientsMap);
                var availableClients = _.differenceWith(allClients, unavailableClients, function(client1, client2){
                    return client1.id === client2.id;
                })

                return {
                    unavailableClients: unavailableClients,
                    availableClients: availableClients
                }
            };

            function initSettings(calendarDays, configData, GRID_SETTINGS) {
                settings.startingIndex = 0;
                settings.lastFoundIndex = null;
                settings.blockLength = configData.consoleSettings.calendarStep;
                settings.calStartDate = calendarDays[0].date;
                settings.calEndDate = calendarDays[calendarDays.length - 1].date;
                settings.numOfBlocksPerDay = DATE_TIME_IN_MINUTES / configData.consoleSettings.calendarStep;
                settings.numOfDays = dateUtil.getDiff(settings.calStartDate, settings.calEndDate) + 1;
                settings.GRID_SETTINGS = GRID_SETTINGS;
                settings.consoleSettings = configData.consoleSettings;
                settings.offsetSlotIndexCompareToCalendarStart = Math.floor(dateUtil.getMinuteValue(settings.consoleSettings.calendarStart) / configData.consoleSettings.calendarStep);
                settings.offsetSlotIndexCompareToCalendarEnd = Math.floor(dateUtil.getMinuteValue(settings.consoleSettings.calendarEnd) / configData.consoleSettings.calendarStep);

            }

            return {
                initSettings: initSettings,
                buildClientEvents: buildClientEvents,
                findAvailableBlocks: findAvailableBlocks,
                findAvailableSlot: findAvailableSlot,
                getDateStringBySlotIndex: getDateStringBySlotIndex,
                getRemBySlotIndex: getRemBySlotIndex,
                getBackgroundByMatchedPercentage: getBackgroundByMatchedPercentage,
                buildSlotDataBySlotIndex: buildSlotDataBySlotIndex,
                getTimeMinutesBySlotIndex: getTimeMinutesBySlotIndex,
                getUnavailableAndAvailableClientsBySlotTime: getUnavailableAndAvailableClientsBySlotTime
            }

        }
    ])
})(angular, jQuery, _);