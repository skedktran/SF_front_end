(function (angular) {
    angular.module('hltApp')
    .directive('rowHeightSync', [
        '$timeout',
        '$window',
        function($timeout, $window) {
            return function ($scope, $el, $attr) {
                var syncEl = angular.element($attr.rowHeightSync);
                var windowEl = angular.element($window);

                var syncContextProperties = $attr.syncContextProperties.split(',');

                var adjustRowHeight = function () {
                    $timeout(function () {
                        var rows = $el.find('[sync-row]'),
                            syncRows = syncEl.find('[sync-row]');

                        if (rows.length > 0) {
                            rows.map(function (indx, row) {
                                var rowEl = angular.element(row),
                                    ryncRowlEl = angular.element(syncRows.get(indx));

                                if (rowEl.outerHeight() < ryncRowlEl.outerHeight()) {
                                    rowEl.outerHeight(ryncRowlEl.outerHeight());
                                } else if (rowEl.outerHeight() > ryncRowlEl.outerHeight()) {
                                    ryncRowlEl.outerHeight(rowEl.outerHeight());
                                }
                                
                            });
                        }

                        windowEl.resize();
                    });
                };


                //$scope.$watch($attr.syncContextProperty, adjustRowHeight, true);
                $scope.$watchCollection(function () {
                    var checkingCollection = [];

                    angular.forEach(syncContextProperties, function (property) {
                        checkingCollection = checkingCollection.concat(($scope.$eval(property) || []));
                    });
                    
                    return checkingCollection;
                }, adjustRowHeight);
            };
        }
    ])
})(angular);