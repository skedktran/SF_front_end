!(function (angular, topWindow) {
  angular.module('hltApp')
    .component('createAssignmentModal', {
      templateUrl: 'src/app/asset-management-console/amc-create-assignment-modal.tpl.html',
      bindings: {
        onClose: '&',
        configData: '<',
        onSave: '<',
        onSaveSuccess: '<'
      },
      controller: [
        '$q',
        'util',
        function ($q, util) {
          var $ctrl = this;

          var timeRangeValidator = {
            timeRange: function (modelValue, modelController) {
              var modelName = modelController.$name;
              var isValid = false;

              if (modelName === 'startDate') {
                isValid = !angular.isDate($ctrl.endDate) || moment(modelValue).format('YYYY-MM-DD') <= moment($ctrl.endDate).format('YYYY-MM-DD');
                $ctrl.amcCreateAssignmentForm.endDate.$setValidity('timeRange', isValid);
              } else if (modelName === 'endDate') {
                isValid = !angular.isDate($ctrl.startDate) || !modelValue || moment($ctrl.startDate).format('YYYY-MM-DD') <= moment(modelValue).format('YYYY-MM-DD');
                $ctrl.amcCreateAssignmentForm.startDate.$setValidity('timeRange', isValid);
              }

              return isValid;
            }
          };

          var validateSettings = function () {
            var form = $ctrl.amcCreateAssignmentForm;
            var errorMessage;

            if (form) {
              form.$setSubmitted();

              if (form.$invalid) {
                if (form.$error.required) {
                  errorMessage = 'Please check all required fields.';
                } else if (form.$error.timeRange) {
                  errorMessage = 'Calendar start date should before calendar end date.';
                }

                util.toastError(errorMessage);
                return false;
              }
            }

            return true;
          };
                
          var submit = function () {
            var process = $q.resolve();
            $ctrl.contentLoading = true;
            if (validateSettings()) {
              process = $ctrl.onSave({
                startDate: $ctrl.startDate ? moment($ctrl.startDate).format('YYYY-MM-DD') : null,
                endDate: $ctrl.endDate ? moment($ctrl.endDate).format('YYYY-MM-DD') : null,
                assignmentNotes: $ctrl.assignmentNotes
              })
                .then(function (results) { 
                  if (results.success){ 
                    util.toastSuccess('Success create asset assignment');
                    $ctrl.onSaveSuccess && $ctrl.onSaveSuccess();
                    $ctrl.onClose();
                  } else {
                    throw results;
                  }
                })
                .catch(function (err) {
                  if (err.errorMessage === 'EXCEPTION_ASSET_ALLOCATION_CONFLICT') {
                    util.toastError('Can not assign asset with selected date range due to assignment conflict. Please review asset assignment history!');
                  } else {
                    util.toastError('Unknown issue, please retry later!');
                  }
                });
            }
            process.finally(function() {
              $ctrl.contentLoading = false;
            });
          };

          /**
                 * init block
                 * used for setting up controller
                 */
          !(function () {
            $ctrl.amcCreateAssignmentForm = null;
            $ctrl.timeRangeValidator = timeRangeValidator;
            $ctrl.submit = submit;

            $ctrl.$onInit = function () {
              $ctrl.isModalOpen = true;
              $ctrl.startDate = new Date();
              $ctrl.commonDateOptions = {
                firstDay: _.get($ctrl, 'configData.consoleSettings.firstDay',  0),
                dateFormat: _.get($ctrl, 'configData.consoleSettings.datePickerFormat', 'MM/dd/yy')
              };
            };
          })();
        }
      ]
    });
})(angular, top);