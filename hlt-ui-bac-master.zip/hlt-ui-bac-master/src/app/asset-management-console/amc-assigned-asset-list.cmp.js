!(function (angular) {
  angular.module('hltApp')
    .component('amcAssignedAssetList', {
      templateUrl: 'src/app/asset-management-console/amc-assigned-asset-list.tpl.html',
      bindings: {
        recordId: '<',
        configData: '<'
      },
      controller: [
        '$scope',
        'api',
        'util',
        function ($scope, api, util) {
          var $ctrl = this;
          /**
                     * common remote action error handler
                     */
          var commonExceptionHanlder = function (exception) {
            console.error(exception);
            util.toastError('Can not perform action due to server error.');

            throw exception;
          };
          var loadAssetAllocations = function () {
            var query = {
              pageNo: $ctrl.page.pageNumber,
              pageSize: $ctrl.page.recordsPerPage,
              queryText: $ctrl.filters.searchString || '',
              assetCategories: _.get($ctrl.filters, 'resourceCategories.length') === _.get($ctrl.configData, 'resourceAssetCategories.length') ? null : _.map($ctrl.filters.resourceCategories, 'id'),
              recordId: $ctrl.recordId
            };
            util.showLoading();
            $ctrl.isSelectAll = false;
            $ctrl.selectedItems = [];
            return api.getAssetAllocations(query)
              .then(function (results) {
                if (results.success) {
                  $ctrl.assetAllocations = results.data.assetAllocations;
                  $ctrl.page.numberOfPages = results.data.totalPages || 0;
                  $ctrl.page.totalRecords = results.data.totalRecords || 0;
                } else {
                  $ctrl.assetAllocations = [];
                  throw results;
                }
              })
              .catch(commonExceptionHanlder)
              .finally(util.hideLoading);
          };



          var selectItem = function (id) {
            var elementIndex = $ctrl.selectedItems.indexOf(id);
            if (elementIndex >= 0) {
              $ctrl.selectedItems.splice(elementIndex, 1);
            } else {
              $ctrl.selectedItems.push(id);
            }
            $ctrl.isSelectAll = $ctrl.selectedItems.length === $ctrl.assetAllocations.length;
          };

          var selectAllItems = function () {
            if ($ctrl.isSelectAll) {
              $ctrl.selectedItems = _.map($ctrl.assetAllocations, 'id');
            } else {
              $ctrl.selectedItems = [];
            }
          };

          var openReturnAssetModal = function () {
            util.showModal({
              template: '<return-asset-modal config-data="configData" on-close="onClose(this, reloadList)" record-id="recordId" selected-items="selectedItems"></return-asset-modal>',
            }, {
              configData: $ctrl.configData,
              onClose: function (scope, reloadList) {
                scope.closeModal();
                if (reloadList) {
                  loadAssetAllocations();
                }
              },
              recordId: $ctrl.recordId,
              selectedItems: $ctrl.selectedItems
            });
          };
          /**
                     * init block
                     * used for setting up controller
                     */
          !(function () {
            $ctrl.selectItem = selectItem;
            $ctrl.selectAllItems = selectAllItems;
            $ctrl.openReturnAssetModal = openReturnAssetModal;

            $ctrl.$onInit = function () {
              $ctrl.filters = {
                searchString: '',
                resourceCategories: _.clone($ctrl.configData.resourceAssetCategories),
              };

              $ctrl.commonDateOptions = {
                firstDay: _.get($ctrl, 'configData.consoleSettings.firstDay', 0),
                dateFormat: _.get($ctrl, 'configData.consoleSettings.datePickerFormat', 'MM/dd/yy')
              };

              $ctrl.isSelectAll = false;
              $ctrl.selectedItems = [];

              $ctrl.page = {
                recordCountOptions: [5, 10, 15, 20, 25],
                recordsPerPage: 25,
                pageNumber: 1,
                numberOfPages: 0,
                totalRecords: 0
              };

              var initial = true;
              loadAssetAllocations()
                .finally(function () {
                  initial = false;
                });

              var reloadGrid = function () {
                if (!initial) {
                  loadAssetAllocations();
                }
              };


              $scope.$watchCollection('$ctrl.filters.resourceCategories', reloadGrid);

              $scope.$watchGroup([
                '$ctrl.filters.searchString',
                '$ctrl.page.pageNumber',
                '$ctrl.filters.startDate',
                '$ctrl.filters.endDate',
                '$ctrl.page.recordsPerPage'
              ], reloadGrid);
            };
          })();
        }
      ]
    });
})(angular);