(function (angular) {
	angular.module('hltApp')
	.component('personAsset', {
		templateUrl: 'src/app/asset-management-console/person-asset.tpl.html',
		bindings: {
			recordId : '<'	
		},
		controller: [
			'api',
			'constants',
            'model',
            'util',
			function (api, constants, model, util) {
                var $ctrl = this;				
                var TABS = {
					AVAILABLE: {
						icon: 'new',
						title: 'Available'
					},
					ASSIGNED: {
						icon: 'approval',
						title: 'Assigned'
                    },
                    UNAVAILABLE: {
                        icon: 'close',
                        title: 'Unavailable'
                    }    
				};
                /**
				 * common remote action error handler
				 */
				var commonExceptionHanlder = function (exception) {
					console.error(exception);
					util.toastError('Can not perform action due to server error.');

					throw exception;
				};

                var getConfigData = function () {
					var SC_REQUIRED_CONFIG_DATA = [
						'resourceAssetCategories'
					];
					var requestParams = {
						configKeys: SC_REQUIRED_CONFIG_DATA
					}

					return api.initialize(requestParams)
						.then(function (results) {
							if (results.success) {
								$ctrl.configData= model.ConfigDataModel.fromServer(results.data);
							} else {
								throw results;
							}
                        })
                        .catch(commonExceptionHanlder)
						
				};
                
                /**
				 * init block
				 * used for setting up controller
				 */
				(function () {
					$ctrl.TABS = TABS;
					$ctrl.ASSET_ASSIGNMENT_STATUSES = constants.ASSET_ASSIGNMENT_STATUSES;

                    $ctrl.$onInit = function () {
                        $ctrl.asset = null;

                        util.showLoading()
						return getConfigData()
							.then(function () {
								$ctrl.currentTab = TABS.AVAILABLE;
							})
                            .finally(util.hideLoading)
                    }
				})();
			}
		]
	});
})(angular);