!(function (angular, topWindow) {
  angular.module('hltApp')
    .component('returnAssetModal', {
      templateUrl: 'src/app/asset-management-console/amc-return-asset-modal.tpl.html',
      bindings: {
        onClose: '&',
        configData: '<',
        onSave: '<',
        recordId: '<',
        selectedItems: '<'
      },
      controller: [
        'api',
        'util',
        function (api, util) {
          var $ctrl = this;
                
          var submit = function () {
            $ctrl.contentLoading = true;
            api.returnAsset({
              endDate: $ctrl.endDate ? moment($ctrl.endDate).format('YYYY-MM-DD') : null,
              returnNotes: $ctrl.returnNotes,
              recordId: $ctrl.recordId,
              assetAssignmentIds: $ctrl.selectedItems
            }).then(function (results) { 
              if (results.success){ 
                util.toastSuccess('Success create asset assignment');
                $ctrl.onClose({reloadList: true});
              } else {
                throw results;
              }
            }).catch(function (err) {
              util.toastError('Unknown issue, please retry later!');
            })
              .finally(function() {
                $ctrl.contentLoading = false;
              });
          };

          /**
                 * init block
                 * used for setting up controller
                 */
          !(function () {
            $ctrl.submit = submit;

            $ctrl.$onInit = function () {
              $ctrl.isModalOpen = true;
              $ctrl.endDate = new Date();

              $ctrl.commonDateOptions = {
                firstDay: _.get($ctrl, 'configData.consoleSettings.firstDay',  0),
                dateFormat: _.get($ctrl, 'configData.consoleSettings.datePickerFormat', 'MM/dd/yy')
              };
            };
          })();
        }
      ]
    });
})(angular, top);