(function (angular) {
    angular.module('hltApp')
        .component('amcResourceList', {
            templateUrl: 'src/app/asset-management-console/amc-resource-list.tpl.html',
            bindings: {
                asset : '<',
                configData: '<',
                getRegionName: '<',
                openCreateAssignmentModal: '<'
            },
            controller: [
                '$scope',
                'api',
                'util',
                function ($scope, api, util) {
                    var $ctrl = this;
			
			
                    /**
				 * common remote action error handler
				 */
                    var commonExceptionHanlder = function (exception) {
                        console.error(exception);
                        util.toastError('Can not perform action due to server error.');

                        throw exception;
                    };
                    var loadResourceList = function () {
                        var query = {
                            regionIds: _.get($ctrl, 'filters.regions.length') === _.get($ctrl, 'configData.regions.length') ? null:$ctrl.filters.regions.map(function (region) {return region.id;}),
                            pageNo: $ctrl.page.pageNumber,
                            pageSize:  $ctrl.page.recordsPerPage,
                            queryText: $ctrl.filters.searchString || '',
                            resourceEmploymentTypes: _.get($ctrl.filters, 'resourceEmploymentTypes.length') === _.get($ctrl.configData, 'resourceEmploymentTypes.length') ? null : _.map($ctrl.filters.resourceEmploymentTypes, 'id'),
                            resourceCategories: _.get($ctrl.filters, 'resourceCategories.length') === _.get($ctrl.configData, 'resourcePersonCategories.length') ? null : _.map($ctrl.filters.resourceCategories, 'id'),
                            tagIds: _.isEmpty($ctrl.filters.tags) ? null : _.map($ctrl.filters.tags, 'id')
                        };
                        util.showLoading();
                        $ctrl.isSelectAll = false;
                        $ctrl.selectedItems = [];
                        return api.getResources(query)
                            .then(function (results) {
                                if (results.success) {
                                    $ctrl.resources = results.data.resources;
                                    $ctrl.page.numberOfPages = results.data.totalPages || 0;
                                    $ctrl.page.totalRecords = results.data.totalRecords || 0;
                                } else {
                                    $ctrl.resources = [];
                                    throw results;
                                }
                            })
                            .catch(commonExceptionHanlder)
                            .finally(util.hideLoading);
                    };

                    var searchTags = function (searchString) {
                        searchString = _.toLower(searchString);
                        if (searchString) {
                            return _.filter($ctrl.configData.tags, function (tag) {
                                return _.toLower(tag.name).indexOf(searchString) >= 0;
                            });
                        }
                        return $ctrl.configData.tags;
                    };

                    var selectResource = function (id) {
                        if (!$ctrl.asset.allowConcurrentAssignment) {
                            $ctrl.selectedItems = [id];
                        } else {
                            var elementIndex = $ctrl.selectedItems.indexOf(id);
                            if (elementIndex >= 0) {
                                $ctrl.selectedItems.splice(elementIndex, 1);
                            } else {
                                $ctrl.selectedItems.push(id);
                            }
                            $ctrl.isSelectAll = $ctrl.selectedItems.length === $ctrl.resources.length;
                        }
                    };

                    var selectAllResource = function () {
                        if ($ctrl.isSelectAll) {
                            $ctrl.selectedItems = _.map($ctrl.resources, 'id');
                        } else {
                            $ctrl.selectedItems = [];
                        }
                    };
                

                    var _openCreateAssignmentModal = function () {
                        $ctrl.openCreateAssignmentModal({
                            onSave: function (data) {
                                return api.createResourceAssetAllocation(_.assign({}, data, {
                                    resourceIds: $ctrl.selectedItems,
                                    recordId: $ctrl.asset.id
                                }));
                            },
                            onSaveSuccess: function() {
                                $ctrl.selectedItems = [];
                                $ctrl.isSelectAll = false;
                            }
                        });
                    };

                    /**
				 * init block
				 * used for setting up controller
				 */
                    !(function () {
                        $ctrl.searchTags = searchTags;
                        $ctrl.selectResource = selectResource;
                        $ctrl.selectAllResource = selectAllResource;
                        $ctrl.api = api;
                        $ctrl._openCreateAssignmentModal = _openCreateAssignmentModal;
			

                        $ctrl.$onInit = function () {
                            $ctrl.selectedItems = [];
                            $ctrl.isSelectAll = false;
                            $ctrl.filters = {
                                regions: _.clone($ctrl.configData.regions),
                                resourceEmploymentTypes: _.clone($ctrl.configData.resourceEmploymentTypes),
                                resourceCategories: _.clone($ctrl.configData.resourcePersonCategories),
                                tags: [],
                                searchString: ''
                            };

                            $ctrl.page = {
                                recordCountOptions: [5, 10, 15, 20, 25],
                                recordsPerPage: 25,
                                pageNumber: 1,
                                numberOfPages: 0,
                                totalRecords: 0
                            };

                            var initial = true;
                            loadResourceList()
                                .finally(function() {
                                    initial = false;
                                });

                            var reloadGrid = function () {
                                if (!initial) {
                                    loadResourceList();
                                }
                            };

                            [
                                '$ctrl.filters.regions',
                                '$ctrl.filters.resourceEmploymentTypes',
                                '$ctrl.filters.resourceCategories',
                                '$ctrl.filters.tags'
                            ].forEach(function (field) {
                                $scope.$watchCollection(field, reloadGrid);
                            });
						
                            $scope.$watchGroup([
                                '$ctrl.filters.searchString',
                                '$ctrl.page.pageNumber',
                                '$ctrl.page.recordsPerPage'
                            ],reloadGrid);
                        };
                    })();
                }
            ]
        });
})(angular);