(function (angular) {
    angular.module('hltApp')
        .component('amcServiceUserList', {
            templateUrl: 'src/app/asset-management-console/amc-service-user-list.tpl.html',
            bindings: {
                asset : '<',
                configData: '<',
                getRegionName: '<',
                openCreateAssignmentModal: '<'
            },
            controller: [
                '$scope',
                'api',
                'util',
                function ($scope, api, util) {
                    var $ctrl = this;
			
			
                    /**
				 * common remote action error handler
				 */
                    var commonExceptionHanlder = function (exception) {
                        console.error(exception);
                        util.toastError('Can not perform action due to server error.');

                        throw exception;
                    };
                    var loadServiceUserList = function () {
                        var query = {
                            regionIds: _.get($ctrl, 'filters.regions.length') === _.get($ctrl, 'configData.regions.length') ? null:$ctrl.filters.regions.map(function (region) {return region.id;}),
                            pageNo: $ctrl.page.pageNumber,
                            pageSize:  $ctrl.page.recordsPerPage,
                            queryText: $ctrl.filters.searchString || '',
                        };
                        util.showLoading();
                        $ctrl.isSelectAll = false;
                        $ctrl.selectedItems = [];
                        return api.getServiceUsers(query)
                            .then(function (results) {
                                if (results.success) {
                                    $ctrl.isSelectAll = false;
                                    $ctrl.serviceUsers = results.data.serviceUsers;
                                    $ctrl.page.numberOfPages = results.data.totalPages || 0;
                                    $ctrl.page.totalRecords = results.data.totalRecords || 0;
                                } else {
                                    $ctrl.serviceUsers = [];
                                    throw results;
                                }
                            })
                            .catch(commonExceptionHanlder)
                            .finally(util.hideLoading);
                    };


                    var selectItem = function (id) {
                        if (!$ctrl.asset.allowConcurrentAssignment) {
                            $ctrl.selectedItems = [id];
                        } else {
                            var elementIndex = $ctrl.selectedItems.indexOf(id);
                            if (elementIndex >= 0) {
                                $ctrl.selectedItems.splice(elementIndex, 1);
                            } else {
                                $ctrl.selectedItems.push(id);
                            }
                            $ctrl.isSelectAll = $ctrl.selectedItems.length === $ctrl.serviceUsers.length;
                        }
                    };

                    var selectAllItems = function () {
                        if ($ctrl.isSelectAll) {
                            $ctrl.selectedItems = _.map($ctrl.serviceUsers, 'id');
                        } else {
                            $ctrl.selectedItems = [];
                        }
                    };

                    var _openCreateAssignmentModal = function () {
                        $ctrl.openCreateAssignmentModal({
                            onSave: function (data) {
                                return api.createAccountAssetAllocation(_.assign({}, data, {
                                    serviceUserIds: $ctrl.selectedItems,
                                    recordId: $ctrl.asset.id
                                }));
                            },
                            onSaveSuccess: function() {
                                $ctrl.selectedItems = [];
                                $ctrl.isSelectAll = false;
                            }
                        });
                    };
                
                    /**
				 * init block
				 * used for setting up controller
				 */
                    !(function () {
                        $ctrl.selectItem = selectItem;
                        $ctrl.selectAllItems = selectAllItems;
                        $ctrl._openCreateAssignmentModal = _openCreateAssignmentModal;
			

                        $ctrl.$onInit = function () {
                            $ctrl.selectedItems = [];
                            $ctrl.isSelectAll = false;
                            $ctrl.filters = {
                                regions: _.clone($ctrl.configData.regions),
                                searchString: ''
                            };

                            $ctrl.page = {
                                recordCountOptions: [5, 10, 15, 20, 25],
                                recordsPerPage: 25,
                                pageNumber: 1,
                                numberOfPages: 0,
                                totalRecords: 0
                            };

                            var initial = true;
                            loadServiceUserList()
                                .finally(function() {
                                    initial = false;
                                });

                            var reloadGrid = function () {
                                if (!initial) {
                                    loadServiceUserList();
                                }
                            };

                            
                            $scope.$watchCollection('$ctrl.filters.regions', reloadGrid);
						
                            $scope.$watchGroup([
                                '$ctrl.filters.searchString',
                                '$ctrl.page.pageNumber',
                                '$ctrl.page.recordsPerPage'
                            ], reloadGrid);                    
                        };
                    })();
                }
            ]
        });
})(angular);