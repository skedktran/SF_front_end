!(function (angular) {
    angular.module('hltApp')
        .component('amcAssetList', {
            templateUrl: 'src/app/asset-management-console/amc-asset-list.tpl.html',
            bindings: {
                recordId : '<',
                assetAssignmentStatus: '<',
                configData: '<'
            },
            controller: [
                '$scope',
                'api',
                'constants',
                'util',
                function ($scope, api, constants, util) {
                    var $ctrl = this;
                    /**
				 * common remote action error handler
				 */
                    var commonExceptionHanlder = function (exception) {
                        console.error(exception);
                        util.toastError('Can not perform action due to server error.');

                        throw exception;
                    };
                    var loadAssets = function () {
                        var query = {
                            pageNo: $ctrl.page.pageNumber,
                            pageSize:  $ctrl.page.recordsPerPage,
                            queryText: $ctrl.filters.searchString || '',
                            resourceCategories: _.get($ctrl.filters, 'resourceCategories.length') === _.get($ctrl.configData, 'resourceAssetCategories.length') ? null : _.map($ctrl.filters.resourceCategories, 'id'),
                            recordId: $ctrl.recordId,
                            assetAssignmentStatuses: [$ctrl.assetAssignmentStatus]
                        };
                        util.showLoading();
                        $ctrl.isSelectAll = false;
                        $ctrl.selectedItems = [];
                        return api.getAssets(query)
                            .then(function (results) {
                                if (results.success) {
                                    $ctrl.assets = results.data.assets;
                                    $ctrl.page.numberOfPages = results.data.totalPages || 0;
                                    $ctrl.page.totalRecords = results.data.totalRecords || 0;
                                } else {
                                    $ctrl.assets = [];
                                    throw results;
                                }
                            })
                            .catch(commonExceptionHanlder)
                            .finally(util.hideLoading);
                    };
                


                    var selectItem = function (id) {
                        var elementIndex = $ctrl.selectedItems.indexOf(id);
                        if (elementIndex >= 0) {
                            $ctrl.selectedItems.splice(elementIndex, 1);
                        } else {
                            $ctrl.selectedItems.push(id);
                        }
                        $ctrl.isSelectAll = $ctrl.selectedItems.length === $ctrl.assets.length;
                    };

                    var selectAllItems = function () {
                        if ($ctrl.isSelectAll) {
                            $ctrl.selectedItems = _.map($ctrl.assets, 'id');
                        } else {
                            $ctrl.selectedItems = [];
                        }
                    };

                    var openCreateAssignmentModal = function () {
                        util.showModal({
                            template: '<create-assignment-modal config-data="configData" on-close="onClose(this)" on-save="onSave" on-save-success="onSaveSuccess"></create-assignment-modal>',
                        }, {
                            configData: $ctrl.configData,
                            onClose: function (scope) {
                                scope.closeModal();
                            },
                            onSave: function (data) {
                                return api.createPersonAssetAllocation(_.assign({}, data, {
                                    recordId: $ctrl.recordId,
                                    assetIds: $ctrl.selectedItems
                                }));
                            },
                            onSaveSuccess: function () {
                                $ctrl.selectedItems = [];
                                $ctrl.isSelectAll = false;
                            }
                        });
                    };
                    /**
				 * init block
				 * used for setting up controller
				 */
                    !(function () {
                        $ctrl.selectItem = selectItem;
                        $ctrl.selectAllItems = selectAllItems;
                        $ctrl.openCreateAssignmentModal = openCreateAssignmentModal;
					
                        $ctrl.ASSET_ASSIGNMENT_STATUSES = constants.ASSET_ASSIGNMENT_STATUSES;

                        $ctrl.$onInit = function () {
                            $ctrl.filters = {
                                searchString: '',
                                resourceCategories: _.clone($ctrl.configData.resourceAssetCategories),
                            };
                            $ctrl.isSelectAll = false;
                            $ctrl.selectedItems = [];

                            $ctrl.page = {
                                recordCountOptions: [5, 10, 15, 20, 25],
                                recordsPerPage: 25,
                                pageNumber: 1,
                                numberOfPages: 0,
                                totalRecords: 0
                            };

                            var initial = true;
                            loadAssets()
                                .finally(function() {
                                    initial = false;
                                });

                            var reloadGrid = function () {
                                if (!initial) {
                                    loadAssets();
                                }
                            };

                            $scope.$watchCollection('$ctrl.filters.resourceCategories', reloadGrid);
						
                            $scope.$watchGroup([
                                '$ctrl.filters.searchString',
                                '$ctrl.page.pageNumber',
                                '$ctrl.page.recordsPerPage'
                            ],reloadGrid);
                        };
                    })();
                }
            ]
        });
})(angular);