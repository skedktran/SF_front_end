(function (angular) {
	angular.module('hltApp')
	.component('assetManagementConsole', {
		templateUrl: 'src/app/asset-management-console/asset-management-console.tpl.html',
		bindings: {
            assetId : '<'
		},
		controller: [
			'$q',
			'api',
			'constants',
            'model',
            'util',
			function ($q, api, constants, model, util) {
                var $ctrl = this;				
                var ALL_TABS = {
					RESOURCES: {
						icon: 'questions_and_answers',
						title: 'Resources'
					},
					SERVICE_USERS: {
						icon: 'people',
						title: 'Service Users'
                    },
                    ASSIGNMENTS: {
                        icon: 'list',
                        title: 'Assignments'
                    }    
                };
                /**
				 * common remote action error handler
				 */
				var commonExceptionHanlder = function (exception) {
					console.error(exception);
					util.toastError('Can not perform action due to server error.');

					throw exception;
				};

				var getAssetData = function () {

                    if (!$ctrl.assetId) {
                        return util.toastError('Missing require assetId')
					}
					var requestParams = {
						recordId : $ctrl.assetId
					}

					
					return api.getAsset(requestParams)
						.then(function (results) {
							if (results.success) {
								$ctrl.asset = model.AssetModel.fromServer(results.data);
							} else {
								throw results;
							}
						})
						.catch(commonExceptionHanlder)
				}

				var getRegionName = function (id) {
					return _.get(
						_.find($ctrl.configData.regions, {id: id}),
						'name'
					)
				}

				var openCreateAssignmentModal = function (options) {
					util.showModal({
						template: '<create-assignment-modal config-data="configData" on-close="onClose(this)" on-save="onSave" on-save-success="onSaveSuccess"></create-assignment-modal>',
					}, {
						configData: $ctrl.configData,
						onClose: function (scope) {
							scope.closeModal();
						},
						onSave: options.onSave,
						onSaveSuccess: options.onSaveSuccess
					});
				};

                var getConfigData = function () {
					var SC_REQUIRED_CONFIG_DATA = [
						'regions',
						'resourceEmploymentTypes',
						'resourcePersonCategories',
						'tags',
						'assetAllocationStatuses'
					];
					var requestParams = {
						configKeys: SC_REQUIRED_CONFIG_DATA
					}

					return api.initialize(requestParams)
						.then(function (results) {
							if (results.success) {
								$ctrl.configData= model.ConfigDataModel.fromServer(results.data);
							} else {
								throw results;
							}
                        })
                        .catch(commonExceptionHanlder)
						
				};
				var getInitialTab = function () {
					var allowAssignmentTo = $ctrl.asset.allowAssignmentTo;
								
					$ctrl.TABS = {};
					if (allowAssignmentTo.indexOf(constants.PERSON_TYPES.RESOURCES) >=0 ) {
						$ctrl.TABS.RESOURCES = ALL_TABS.RESOURCES;
						!$ctrl.currentTab && ($ctrl.currentTab = ALL_TABS.RESOURCES);
					}
					if (allowAssignmentTo.indexOf(constants.PERSON_TYPES.SERVICE_USERS) >=0 ) {
						$ctrl.TABS.SERVICE_USERS = ALL_TABS.SERVICE_USERS;
						!$ctrl.currentTab && ($ctrl.currentTab = ALL_TABS.SERVICE_USERS);
					}
					
					$ctrl.TABS.ASSIGNMENTS = ALL_TABS.ASSIGNMENTS;
					!$ctrl.currentTab && ($ctrl.currentTab = ALL_TABS.ASSIGNMENTS);
				};
                
                /**
				 * init block
				 * used for setting up controller
				 */
				!(function () {
					$ctrl.getRegionName = getRegionName;
					$ctrl.ALL_TABS = ALL_TABS;
					$ctrl.openCreateAssignmentModal = openCreateAssignmentModal;

                    $ctrl.$onInit = function () {
						$ctrl.asset = null;

                        util.showLoading()
						return $q.all([
							getConfigData(),
							getAssetData()
						])
							.then(getInitialTab)
                            .finally(util.hideLoading)
                    }
				})();
			}
		]
	});
})(angular);