!(function (angular) {
    angular.module('hltApp')
        .component('amcAssignmentList', {
            templateUrl: 'src/app/asset-management-console/amc-assignment-list.tpl.html',
            bindings: {
                asset : '<',
                configData: '<'
            },
            controller: [
                '$scope',
                'api',
                'constants',
                'model',
                'util',
                function ($scope, api, constants, model,  util) {
                    var $ctrl = this;
                    var personTypes = model.PicklistItemModel.fromServerIdList(constants.PERSON_TYPES.SINGLE);

                    var selectItem = function (id) {
                        var elementIndex = $ctrl.selectedItems.indexOf(id);
                        if (elementIndex >= 0) {
                            $ctrl.selectedItems.splice(elementIndex, 1);
                        } else {
                            $ctrl.selectedItems.push(id);
                        }
                        $ctrl.isSelectAll = $ctrl.selectedItems.length === $ctrl.assignedAssetAllocations.length;
                    };

                    var selectAllItems = function () {
                        if ($ctrl.isSelectAll) {
                            $ctrl.selectedItems = _.map($ctrl.assignedAssetAllocations, 'id');
                        } else {
                            $ctrl.selectedItems = [];
                        }
                    };
                    

                    var openReturnAssetModal = function () {
                        util.showModal({
                            template: '<return-asset-modal config-data="configData" on-close="onClose(this, reloadList)" record-id="recordId" selected-items="selectedItems"></return-asset-modal>',
                        }, {
                            configData: $ctrl.configData,
                            onClose: function (scope, reloadList) {
                                scope.closeModal();
                                if (reloadList) {
                                    loadAssignmentList();
                                }
                            },
                            recordId: $ctrl.recordId,
                            selectedItems: $ctrl.selectedItems
                        });
                    };
                    /**
				 * common remote action error handler
				 */
                    var commonExceptionHanlder = function (exception) {
                        console.error(exception);
                        util.toastError('Can not perform action due to server error.');

                        throw exception;
                    };
                    var loadAssignmentList = function () {
                        var query = {
                            pageNo: $ctrl.page.pageNumber,
                            pageSize:  $ctrl.page.recordsPerPage,
                            queryText: $ctrl.filters.searchString || '',
                            personTypes: _.get($ctrl.filters, 'personTypes.length') === _.get($ctrl, 'personTypes.length') ? null :  _.map($ctrl.filters.personTypes, 'id'),
                            statuses: _.get($ctrl.filters, 'assetAllocationStatuses.length') === _.get($ctrl.configData, 'assetAllocationStatuses.length') ? null :  _.map($ctrl.filters.assetAllocationStatuses, 'id'),
                            recordId: $ctrl.asset.id
                        };
                        util.showLoading();
                        $ctrl.isSelectAll = false;
                        $ctrl.selectedItems = [];
                        return api.getAssetAllocations(query)
                            .then(function (results) {
                                if (results.success) {
                                    $ctrl.assetAllocations = results.data.assetAllocations;
                                    $ctrl.assignedAssetAllocations = _.filter($ctrl.assetAllocations, function (assetAllocation) {
                                        return assetAllocation.status === 'Assigned';
                                    });
                                    $ctrl.page.numberOfPages = results.data.totalPages || 0;
                                    $ctrl.page.totalRecords = results.data.totalRecords || 0;
                                } else {
                                    $ctrl.assetAllocations = [];
                                    throw results;
                                }
                            })
                            .catch(commonExceptionHanlder)
                            .finally(util.hideLoading);
                    };
                    /**
				 * init block
				 * used for setting up controller
				 */
                    !(function () {
                        $ctrl.openReturnAssetModal = openReturnAssetModal;
                        $ctrl.personTypes = personTypes;
                        $ctrl.selectItem = selectItem;
                        $ctrl.selectAllItems = selectAllItems;

                        $ctrl.$onInit = function () {
                            $ctrl.filters = {
                                searchString: '',
                                personTypes: _.clone($ctrl.personTypes),
                                assetAllocationStatuses : _.clone($ctrl.configData.assetAllocationStatuses)
                            };

                            $ctrl.page = {
                                recordCountOptions: [5, 10, 15, 20, 25],
                                recordsPerPage: 25,
                                pageNumber: 1,
                                numberOfPages: 0,
                                totalRecords: 0
                            };

                            var initial = true;
                            loadAssignmentList()
                                .finally(function() {
                                    initial = false;
                                });

                            var reloadGrid = function () {
                                if (!initial) {
                                    loadAssignmentList();
                                }
                            };

                            [
                                '$ctrl.filters.personTypes',
                                '$ctrl.filters.assetAllocationStatuses',
                            ].forEach(function (field) {
                                $scope.$watchCollection(field, reloadGrid);
                            });
                            $scope.$watchGroup([
                                '$ctrl.filters.searchString',
                                '$ctrl.page.pageNumber',
                                '$ctrl.page.recordsPerPage'
                            ], reloadGrid);
                        };
                    })();
                }
            ]
        });
})(angular);