(function (angular) {

  var googleMap, hltApp, colorPickerApp;
  try {
    googleMap = angular.module('uiGmapgoogle-maps');
  } catch (e) {
    angular.module('uiGmapgoogle-maps', []);
  }
	
  try {
    colorPickerApp = angular.module('colorpicker');
  } catch (e) {
    angular.module('colorpicker', []);
  }

  hltApp = angular.module('hltApp', [
    'ngSanitize',
    'skedApp.core',
    'skedApp.shared',
    'hltApp.model',
    'ui.date',
    'uiGmapgoogle-maps',
    'colorpicker'
  ])
    .constant('JOB_STATUS', {
      QUEUED: 'Queued',
      PENDING_ALLOCATION: 'Pending Allocation',
      PENDING_DISPATCH: 'Pending Dispatch',
      DISPATCHED: 'Dispatched',
      READY: 'Ready',
      EN_ROUTE: 'En Route',
      ON_SITE: 'On Site',
      IN_PROGRESS: 'In Progress',
      COMPLETE: 'Complete',
      CANCELLED: 'Cancelled'
    })
    .factory('constants', ['$filter', function($filter){
      var dateFilter = $filter('date');
      var SERVICE_USERS=  'Service Users';
      var RESOURCES=  'Resources';
      var SERVICE_USER_AVAIBILITY_TYPE = { 
        UNAVAILABILITY_ONLY: 'Unavailability Only',
        AVAILABILITY_ONLY: 'Availability Only'
      };
      return {
        SERVICE_USER_AVAIBILITY_TYPE: SERVICE_USER_AVAIBILITY_TYPE,
        DEFAULT_SERVICE_USER_AVAIBILITY_TYPE: SERVICE_USER_AVAIBILITY_TYPE.UNAVAILABILITY_ONLY,
        ASSET_ASSIGNMENT_STATUSES: {
          AVAILABLE: 'Available',
          UNAVAILABLE: 'Not Available'
        },
        PERSON_TYPES: {
          SINGLE: ['Service User', 'Resource'],
          PLURAL: [SERVICE_USERS, RESOURCES],
          SERVICE_USERS:SERVICE_USERS,
          RESOURCES: RESOURCES
        },
        DEFAULT_GET_GEOLOCATION_ERROR: 'Could not identify the address',
        DEFAULT_AVATAR_URL: 'slds/images/avatar3.jpg',
        DEFAULT_GRID_SETTINGS: {
          leftColWidth: 6.5,
          headerHeight: 3,
          weekInfoHeaderHeight: 1.5,
          slotSize: {
            w: 11.5,
            h: 2.5
          },
          allDayBlock: {
            h: 1.125,
            m: 0.125
          }
        },
        PAC_MODE: {
          LONG_TERM_SCHEDULING: 'normal',
          PORTAL: 'portal',
          CHECK_AVAILABILITY: 'check-availability'
        },
        LAYOUT_MODE: {
          TWO_WEEKS: 'Weeks',
          MONTH: 'Month'
        },
        ADDRESS_TYPE: {
          LOCATION: 'Location',
          ACCOUNT: 'Account',
          SITE: 'Site',
          CLIENT: 'Client',
          ADDRESS: 'Address'
        },
        MAX_ASSET_COUNT: 10,
        MAX_REQUIRED_RESOURCES_COUNT: 10,
        PATIENT_AVAILABILITY_TABS: {
          AVAILABILITY: 'availability',
          TREATMENT: 'treatment',
          CAPACITY_GRID: 'capacity_grid'
        },
        EVENT_TYPE: {
          TREATMENT: 'Treatment',
          ASSESSMENT: 'Assessment',
          SUPPORT: 'Support',
          GROUP_EVENT: 'Group Event',
          INITIAL_EVALUATION: 'Initial Evaluation'
        },
        OBJECT_TYPE: {
          CLIENT_AVAILABILITY: 'clientAvailability',
          AVAILABILITY: 'availability',
          JOB: 'job',
          CONTACT: 'contact',
          // CASE: 'caseModel',
          SUPPORT_PLAN: 'supportPlan',
          ACCOUNT: 'account',
          TAG: 'tag',
          RESOURCE: 'resource',
          ACTIVITY: 'activity',
          AVAILABILITY_TEMPLATE: 'availabilityTemplate',
          AVAILABILITY_PATTERN: 'availabilityPattern'
        },
        AVAILABILITY_TYPE: {
          // ON_CALL: 'On-call',
          OTHER: 'Other',
          PTO: 'PTO'
        },
        PAGE_MODE: {
          CREATE: 'CREATE',
          EDIT: 'EDIT'
        },
        RECURRING_PATTERN: {
          WEEKLY: {
            value: 1,
            label: 'Weekly'
          },
          FORTNIGHTLY: {
            value: 2,
            label: 'Every 2 Weeks'
          }
        },
        SCHEDULE_MODE: {
          SINGLE: 0,
          REPEAT: 1,
          SCHEDULE: 2
        },
        INTEGER_PATTERN: /^([0-9]*)$/,
        EDIT_RECURRING_ACTION: {
          ONLY_ME: {
            value: 'only_me',
            getLabel: function (event) {
              return 'Only this ' + (event.objectTypeString || 'one');
            } 
          },
          SAME_WEEKDAY: {
            value: 'same_weekday',
            getLabel: function (event) {
              return 'Same Weekday (' + dateFilter(event.originalStartDate, 'EEEE') + ')';
            }
          },
          FOLLOWING_EVENTS: {
            value: 'following_events',
            label: 'Following Events'
          },
          ALL_EVENTS: {
            value: 'all_events',
            label: 'All Events'
          }
        },
        WEEK_DAYS: {
          SUN: {
            label: 'Sun',
            fullLabel: 'Sunday',
            value: 'sun'
          },
          MON: {
            label: 'Mon',
            fullLabel: 'Monday',
            value: 'mon'
          },
          TUE: {
            label: 'Tue',
            fullLabel: 'Tuesday',
            value: 'tue'
          },
          WED: {
            label: 'Wed',
            fullLabel: 'Wednesday',
            value: 'wed'
          },
          THU: {
            label: 'Thu',
            fullLabel: 'Thursday',
            value: 'thu'
          },
          FRI: {
            label: 'Fri',
            fullLabel: 'Friday',
            value: 'fri'
          },
          SAT: {
            label: 'Sat',
            fullLabel: 'Saturday',
            value: 'sat'
          },
        },
        TIME_SHEET_STATUS: {
          DRAFT: 'Draft',
          PENDING_FOR_APPROVAL: 'Pending for Approval',
          APPROVED: 'Approved',
          DECLINED: 'Declined'
        },
        AVAILABILITY_STATUS: {
          PENDING: 'Pending',
          APPROVED: 'Approved',
          DECLINED: 'Declined',
          WAITLIST: 'Waitlist',
        },
        SETTING_KEY: {
          ADMIN: 'admin',
          RAC: 'rac',
          PAC: 'pac',
          EVENT_TYPE: 'eventType',
          PERMISSION: 'permission',
          EXPENSE: 'expense',
          LOCATION: 'location',
          AUDIT: 'audit',
          ASSESSMENT_HELP_TEXTS: 'assessmentHelpTexts',
          MOBILE: 'mobile',
          LONE_WORKER: 'loneWorker',
          SERVICE_USER_FIELD_MAPPING: 'serviceUserFieldMappings',
          MOBILE_LOOKUP_FIELDS: 'mobileLookupFields'
        },
        AVAILABILITY_PATTERN_TYPE: {
          WEEKLY: 'weekly',
          CUSTOM: 'custom'
        }
      };
    }])
    .config([
      '$locationProvider',
      function ($locationProvider) {
        $locationProvider.html5Mode({
          enabled: true,
          requireBase: false,
          rewriteLinks: false
        });

      }
    ]);

  if (googleMap) {
    hltApp.config([
      'uiGmapGoogleMapApiProvider',
      function (uiGmapGoogleMapApiProvider) {
        uiGmapGoogleMapApiProvider.configure({
          key: 'AIzaSyDU3eov_1jKLgx3qBOGm1GxrYGSrHuvVvo',
          v: '3.29',
          libraries: 'geometry,places'
        });
      }
    ]);
  }
})(angular);