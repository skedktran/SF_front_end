var skedUtil = skedUtil || {};
skedUtil.ModalHelper = (function () {

	function isFunction(functionToCheck) {
		return functionToCheck && {}.toString.call(functionToCheck) === '[object Function]';
	}

	function createElement(tagName, attrs, styles) {
		var el = document.createElement(tagName);

		if (attrs) {
			for (attrName in attrs) {
				if (attrs.hasOwnProperty(attrName)) {
					el.setAttribute(attrName, attrs[attrName]);
				}
			}
		}

		if (styles) {
			setCssStyles(el, styles);
		}

		return el;
	};

	function setCssStyles (el, cssStyles) {
		if (cssStyles) {
			for (key in cssStyles) {
				if (cssStyles.hasOwnProperty(key)) {
					el.style[key] = cssStyles[key];
				}
			}
		}
	};

	/**
	 * constructor
	 */
	var ModalHelper = function (resourcePath) {
		this.resourcePath = resourcePath;
	};

	/**
	 * helper method, add a link element to header to get css resources
	 */
	ModalHelper.prototype.requireCssFile = function(filename) {
		var fileref;
		var currentFileRef = document.querySelector('link[href="'+ filename +'"]');
		
		if (!currentFileRef || currentFileRef.length === 0) {
			fileref = createElement('link', {
				rel: 'stylesheet',
				type: 'text/css',
				href: filename
			}); 

			document.getElementsByTagName('head')[0].appendChild(fileref); 
		}
	};

	/**
	 * helper method help register iframe events which are the channel to communicate between modal and parent
	 */
	ModalHelper.prototype.registerIframeEvent = function (eventHandler) {
		// Here "addEventListener" is for standards-compliant web browsers and "attachEvent" is for IE Browsers. 
		var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent"; 
		var eventer = window[eventMethod]; 

		// Now... 
		// if 
		// "attachEvent", then we need to select "onmessage" as the event. 
		// if 
		// "addEventListener", then we need to select "message" as the event 

		var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message"; 

		if (isFunction(eventHandler)) {
			eventer(messageEvent, eventHandler, false); 
		}
	};

	/**
	 * main method to load model through iframe tag
	 */
	ModalHelper.prototype.loadIframeModal = function (iframeUrl, searchParams) {
		var helper = this;
		var bodyEl = document.getElementsByTagName('body')[0];
		var currentOverflow = bodyEl.style.overflow || '';
		var child_domain = iframeUrl.substring(0, iframeUrl.indexOf('/', 9)); 
		var parent_domain = window.location.protocol + '//' + window.location.host; 
		var fullUrl, params = [];

		searchParams = searchParams || {};
		if (!searchParams.hasOwnProperty('parent_domain')) {
			searchParams['parent_domain'] = parent_domain;
		}

		for (var paramKey in searchParams) {
			if (searchParams.hasOwnProperty(paramKey)) {
				params.push([paramKey, searchParams[paramKey]].join('='))
			}
		}

		fullUrl = [iframeUrl, params.join('&')].join((iframeUrl.indexOf('?') === -1)?'?':'&');

		var modalDialog = createElement('iframe', {
			src: fullUrl,
			frameborder: 0,
			height: '100%',
			width: '100%',
			marginheight: 0,
			marginwidth: 0,
			scrolling: 'false'
		}, {
			transition: 'opacity .2s linear, background-color .2s linear',
			opacity: 0,
			visibility: 0,
			'background-color': 'rgba(43,40,38,.6)',
	    'background-image': 'url('+ helper.resourcePath + '/slds/images/spinners/slds_spinner_brand.gif)',
	    'background-size': '64px',
	    'background-repeat': 'no-repeat',
	    'background-position': 'center',
	    position: 'fixed',
	    top: 0,
	    left: 0,
	    right: 0,
	    bottom: 0,
	    padding: 0,
	    margin: 0,
	    'z-index': 199
		});

		bodyEl.appendChild(modalDialog);
		bodyEl.style.overflow = 'hidden';

		// trigger animation
		setTimeout(function () {
			setCssStyles(modalDialog, {
				opacity: 1,
				visibility: 'visible'
			});
		}, 0);

		return {
			hideIframeLoading: function() {
				modalDialog.style['background-image'] = '';
			},
			showIframeLoading: function() {
				setCssStyles(modalDialog, {
					'background-color': 'rgba(255,255,255,.75)',
					'background-image': 'url(' + helper.resourcePath + '/slds/images/spinners/slds_spinner.gif)'
				});
			},
			hideIframeBackdrop: function () {
				modalDialog.style['background-color'] = 'transparent';
			},
			closeModal: function (callback) {
				bodyEl.style.overflow = currentOverflow;
				modalDialog.style.opacity = 0;

				setTimeout(function () {
					bodyEl.removeChild(modalDialog);
					if (isFunction(callback)) {
          	callback();
          }
				}, 200);
			},
			registerModalEvent: helper.registerIframeEvent
		};
	};
	
	return ModalHelper;
})();