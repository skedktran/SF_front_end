requireScript('/scripts/modal-helper.js')
	.done(function () {

		var iframe_url = 'http://localhost:9000/job-allocation.html';

		//--var modalHelper = new skedUtil.ModalHelper('/resource/sked_ACH_Vendors');
		var modalHelper = new skedUtil.ModalHelper('vendor');

		// show modal
		var modalController = modalHelper.loadIframeModal(iframe_url, {
			rootRecordId: 'a1hg0000001SPSo'
		});

		// Listen to message from child IFrame window 
		modalController.registerModalEvent(function (event) { 
			var data = event.data,
				message = data.message;

			if (message === 'cancel') {
				modalController.closeModal();
			} else if (message === 'loaded') {
				modalController.hideIframeLoading();
			} else if (message === 'done') {
				//modalController.showIframeLoading();
				//window.location.reload();
				modalController.closeModal();
			}
		});

	});